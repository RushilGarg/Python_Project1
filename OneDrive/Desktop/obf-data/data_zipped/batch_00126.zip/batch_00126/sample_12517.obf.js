var a0_0x3e07b4=a0_0x3ccc;(function(_0x2e6183,_0x525f17){var _0x19d88c=a0_0x3ccc,_0x3f9e77=_0x2e6183();while(!![]){try{var _0x579589=-parseInt(_0x19d88c(0x83))/0x1+-parseInt(_0x19d88c(0x8c))/0x2*(-parseInt(_0x19d88c(0x8d))/0x3)+parseInt(_0x19d88c(0x86))/0x4*(parseInt(_0x19d88c(0x88))/0x5)+parseInt(_0x19d88c(0x8a))/0x6+parseInt(_0x19d88c(0x85))/0x7+parseInt(_0x19d88c(0x87))/0x8*(-parseInt(_0x19d88c(0x84))/0x9)+-parseInt(_0x19d88c(0x8e))/0xa;if(_0x579589===_0x525f17)break;else _0x3f9e77['push'](_0x3f9e77['shift']());}catch(_0x492877){_0x3f9e77['push'](_0x3f9e77['shift']());}}}(a0_0x485e,0xaa9e8));import{LitElement,html,css}from'../../web_modules/lit-element.js';import'../components/Link.js';import'../components/Carousel.js';function a0_0x3ccc(_0x51ac9f,_0x34877a){var _0x485e5b=a0_0x485e();return a0_0x3ccc=function(_0x3cccca,_0x14a525){_0x3cccca=_0x3cccca-0x82;var _0x270a1e=_0x485e5b[_0x3cccca];return _0x270a1e;},a0_0x3ccc(_0x51ac9f,_0x34877a);}import'../components/Social.js';import'../components/Quote.js';function a0_0x485e(){var _0x5f296e=['26526XnmwlK','8405080ofZpPT','render','1066514izFSJQ','117kpXrIb','5634111omFhrt','2824096pBxaNV','837112gLfslZ','5ilRgGN','styles','7463604wgLDbs','r-about','274wjFCnY'];a0_0x485e=function(){return _0x5f296e;};return a0_0x485e();}class About extends LitElement{static get[a0_0x3e07b4(0x89)](){return css`
    img {
      border-radius: 50%;
      width: 72px;
      height: 72px;
      float: left;
      margin-right: 5px;
    }
    `;}[a0_0x3e07b4(0x82)](){return html`
    <div>
      <img role="presentation" src="images/me-blur.jpg">
      <div>
        My name is <span title="Ruh-juht Sai-guhl"><strong>Rajat Sehgal</strong></span>, I am
        a <strong>Software Engineering Manager</strong>, located in the <r-link text="Greater Boston"></r-link> area.
        I have been working at <r-link text="MathWorks"></r-link> for more than 9 years now.
        <br>
        Before that I was at <r-link text="University of Florida"></r-link>, where I completed
        my <strong>Masters</strong> in <strong>Computer Science</strong> while also working as a
        Software Developer at the <r-link text="Florida Museum of Natural History"></r-link>. I was born and
        brought up in <r-link text="New Delhi"></r-link>, India where I also earned
        my <strong>Bachelors</strong> in <strong>Computer Science</strong>.
        <br>
        When I am not at work and my wife is fast asleep, I enjoy working on some
        side <r-link text="projects"></r-link>.
      </div>
      <r-social></r-social>
      <r-carousel>
        <r-quote text="Rajat’s deep and growing knowledge of web UI technologies, coupled with his strong design skills make him a powerhouse developer. He is always working to further his knowledge and technique in these areas. As a result he is widely respected and consulted." author="Peter Muellers"></r-quote>
        <r-quote text="Rajat is a hardworking and detail driven individual who likes to deliver very modular and highly extensible code. He's Efficient in analyzing issues and deriving action items. He continually seeks solutions, not blame." author="Saoli Mitra"></r-quote>
        <r-quote text="Rajat is meticulous when it comes to starting a new piece of work. He evaluates and understands the problem statement with respect to use cases, before thinking about the design and implementation details." author="Deepak Anand"></r-quote>
        <r-quote text="I find Rajat to be very easy to work with, very responsive and willing when it comes to answering questions." author="Melissa DeVeau"></r-quote>
        <r-quote text="Rajat possesses excellent communication skills and has been very helpful in sharing his knowledge." author="Koundinya Surepeddi"></r-quote>
        <r-quote text="Rajat has a good command over the language and was able to point out a lot of good practices for writing clean code." author="Keerthi Gurijala"></r-quote>
      </r-carousel>
    </div>
    `;}}customElements['define'](a0_0x3e07b4(0x8b),About);