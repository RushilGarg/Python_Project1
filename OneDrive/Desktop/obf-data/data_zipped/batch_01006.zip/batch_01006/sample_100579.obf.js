/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x32603b=a0_0x38de;function a0_0x38de(_0x244808,_0x1c2496){var _0x169a3d=a0_0x169a();return a0_0x38de=function(_0x38de9d,_0x24df23){_0x38de9d=_0x38de9d-0x1de;var _0x5e62de=_0x169a3d[_0x38de9d];return _0x5e62de;},a0_0x38de(_0x244808,_0x1c2496);}(function(_0x25502a,_0x14a399){var _0xfc637=a0_0x38de,_0x4441a0=_0x25502a();while(!![]){try{var _0x900c4e=parseInt(_0xfc637(0x1e2))/0x1*(-parseInt(_0xfc637(0x1e8))/0x2)+-parseInt(_0xfc637(0x1e5))/0x3*(parseInt(_0xfc637(0x1e3))/0x4)+-parseInt(_0xfc637(0x1e4))/0x5*(-parseInt(_0xfc637(0x1df))/0x6)+parseInt(_0xfc637(0x1de))/0x7*(-parseInt(_0xfc637(0x1eb))/0x8)+parseInt(_0xfc637(0x1e7))/0x9+parseInt(_0xfc637(0x1e0))/0xa+parseInt(_0xfc637(0x1e6))/0xb*(parseInt(_0xfc637(0x1ea))/0xc);if(_0x900c4e===_0x14a399)break;else _0x4441a0['push'](_0x4441a0['shift']());}catch(_0x1d1f3f){_0x4441a0['push'](_0x4441a0['shift']());}}}(a0_0x169a,0x3a96b));function a0_0x169a(){var _0x102517=['558CbdKhN','295450SIiIOU','debug','68UgxDtH','4SfrQjF','23530krhbzB','14013PwQmNu','784883OTvTAI','2933064jhUEDw','9136xgEZuT','exports','12AqNqJJ','8cOqiGA','2164246SSAUgV'];a0_0x169a=function(){return _0x102517;};return a0_0x169a();}var logger=require(a0_0x32603b(0x1e1)),debug=logger('random:streams:cosine');module[a0_0x32603b(0x1e9)]=debug;