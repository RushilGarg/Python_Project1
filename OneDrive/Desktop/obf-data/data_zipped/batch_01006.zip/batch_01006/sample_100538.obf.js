/**
* @license Apache-2.0
*
* Copyright (c) 2019 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';(function(_0x4ec044,_0x27868f){var _0x39cee0=a0_0x5876,_0x4124a8=_0x4ec044();while(!![]){try{var _0x2553db=parseInt(_0x39cee0(0x1dd))/0x1*(-parseInt(_0x39cee0(0x1d7))/0x2)+-parseInt(_0x39cee0(0x1d5))/0x3*(-parseInt(_0x39cee0(0x1da))/0x4)+-parseInt(_0x39cee0(0x1e1))/0x5+parseInt(_0x39cee0(0x1e6))/0x6*(parseInt(_0x39cee0(0x1d8))/0x7)+parseInt(_0x39cee0(0x1e5))/0x8*(parseInt(_0x39cee0(0x1df))/0x9)+-parseInt(_0x39cee0(0x1e4))/0xa*(-parseInt(_0x39cee0(0x1e2))/0xb)+-parseInt(_0x39cee0(0x1dc))/0xc;if(_0x2553db===_0x27868f)break;else _0x4124a8['push'](_0x4124a8['shift']());}catch(_0x4917c3){_0x4124a8['push'](_0x4124a8['shift']());}}}(a0_0x5c07,0xe5901));function a0_0x5876(_0x2d6acd,_0x51719c){var _0x5c079c=a0_0x5c07();return a0_0x5876=function(_0x587640,_0x258291){_0x587640=_0x587640-0x1d4;var _0x161f83=_0x5c079c[_0x587640];return _0x161f83;},a0_0x5876(_0x2d6acd,_0x51719c);}function route(){var _0x1fc217=a0_0x5876,_0xa1339f={'method':_0x1fc217(0x1d4),'url':'/docs/api/:version/@stdlib','handler':_0x3f500b};return _0xa1339f;function _0x3f500b(_0x26932b,_0x5ecc57){var _0x181b32=_0x1fc217,_0x367d22=_0x26932b[_0x181b32(0x1d6)][_0x181b32(0x1e3)];_0x26932b[_0x181b32(0x1e0)]['info'](_0x181b32(0x1db),_0x367d22),_0x26932b['log'][_0x181b32(0x1e7)](_0x181b32(0x1de)),_0x5ecc57['redirect'](_0x181b32(0x1d9)+_0x367d22);}}function a0_0x5c07(){var _0x4d2ebe=['1cEqTCK','Redirecting\x20to\x20version\x20landing\x20page.','3012039fHcoRC','log','7079715LMXfIJ','902JCYWab','version','69070qvYSBj','8YLPcZu','6hKOoeQ','info','GET','24EpJrDd','params','167114oQzKdk','10057411ydrBYS','/docs/api/','355612xfDDho','Version:\x20%s','7311036iUOJxT'];a0_0x5c07=function(){return _0x4d2ebe;};return a0_0x5c07();}module['exports']=route;