/**
 * SeekQuarry/Yioop --
 * Open Source Pure PHP Search Engine, Crawler, and Indexer
 *
 * Copyright (C) 2009 - 2015  Chris Pollett chris@pollett.org
 *
 * LICENSE:
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * END LICENSE
 *
 * @author Chris Pollett
 * @license http://www.gnu.org/licenses/ GPL3
 * @link http://www.seekquarry.com/
 * @copyright 2009 - 2015s
 * @filesource
 */
var a0_0x145cdf=a0_0x45eb;(function(_0x487965,_0x526451){var _0x24400e=a0_0x45eb,_0x180cda=_0x487965();while(!![]){try{var _0x53bc82=parseInt(_0x24400e(0x9a))/0x1*(parseInt(_0x24400e(0x98))/0x2)+parseInt(_0x24400e(0x9e))/0x3+parseInt(_0x24400e(0x9d))/0x4+parseInt(_0x24400e(0xa0))/0x5+-parseInt(_0x24400e(0x9c))/0x6+parseInt(_0x24400e(0x9b))/0x7+-parseInt(_0x24400e(0xa2))/0x8*(parseInt(_0x24400e(0xa1))/0x9);if(_0x53bc82===_0x526451)break;else _0x180cda['push'](_0x180cda['shift']());}catch(_0x4e51d6){_0x180cda['push'](_0x180cda['shift']());}}}(a0_0x3187,0x86893));function a0_0x45eb(_0x4e477b,_0xff9258){var _0x31878d=a0_0x3187();return a0_0x45eb=function(_0x45eb7d,_0x3009c5){_0x45eb7d=_0x45eb7d-0x98;var _0x33597e=_0x31878d[_0x45eb7d];return _0x33597e;},a0_0x45eb(_0x4e477b,_0xff9258);}function a0_0x3187(){var _0x32ddad=['301528cBjgAw','10586dUZbro','туфхцчшщъыьэюяіѳѣѵ','75mkDztc','4595367hAlODx','1803360wyfgxd','1710676QSTThL','2814882QtwUGc','абвгдеёжзийклмнопрс','3091390XgVhHX','522pmejum'];a0_0x3187=function(){return _0x32ddad;};return a0_0x3187();}var alpha=a0_0x145cdf(0x9f)+a0_0x145cdf(0x99),roman_array={};function analyzeQuery(){}