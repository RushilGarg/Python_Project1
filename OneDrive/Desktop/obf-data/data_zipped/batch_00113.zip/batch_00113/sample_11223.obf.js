/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x80e9e2=a0_0x6a78;(function(_0x7e898a,_0x2b1f98){var _0x54847f=a0_0x6a78,_0x39752a=_0x7e898a();while(!![]){try{var _0x35a2e2=-parseInt(_0x54847f(0xca))/0x1*(parseInt(_0x54847f(0xbc))/0x2)+-parseInt(_0x54847f(0xc6))/0x3+-parseInt(_0x54847f(0xba))/0x4+-parseInt(_0x54847f(0xc5))/0x5+parseInt(_0x54847f(0xcc))/0x6*(-parseInt(_0x54847f(0xc2))/0x7)+parseInt(_0x54847f(0xbf))/0x8+parseInt(_0x54847f(0xbb))/0x9*(parseInt(_0x54847f(0xc7))/0xa);if(_0x35a2e2===_0x2b1f98)break;else _0x39752a['push'](_0x39752a['shift']());}catch(_0x392fc5){_0x39752a['push'](_0x39752a['shift']());}}}(a0_0x533d,0x4611d));var tape=require('tape'),objectKeys=require(a0_0x80e9e2(0xc4)),isPlainObject=require(a0_0x80e9e2(0xc3)),table=require(a0_0x80e9e2(0xbd))['EMOJI_CODE_PICTO'];function a0_0x6a78(_0xe7576f,_0x2d66fe){var _0x533de5=a0_0x533d();return a0_0x6a78=function(_0x6a786d,_0x397870){_0x6a786d=_0x6a786d-0xb9;var _0x4363a1=_0x533de5[_0x6a786d];return _0x4363a1;},a0_0x6a78(_0xe7576f,_0x2d66fe);}tape(a0_0x80e9e2(0xc9),function test(_0x4c6faa){var _0x1163ef=a0_0x80e9e2;_0x4c6faa['ok'](!![],__filename),_0x4c6faa[_0x1163ef(0xcd)](typeof table,_0x1163ef(0xc0),_0x1163ef(0xc9)),_0x4c6faa[_0x1163ef(0xc8)]();}),tape(a0_0x80e9e2(0xcb),function test(_0x1ebd84){var _0x4c9db2=a0_0x80e9e2,_0x4b7b35=table();_0x1ebd84[_0x4c9db2(0xcd)](isPlainObject(_0x4b7b35),!![],'returns\x20an\x20object'),_0x1ebd84[_0x4c9db2(0xc8)]();}),tape('the\x20returned\x20object\x20has\x20keys',function test(_0x4aa66b){var _0x403449=a0_0x80e9e2,_0x2f89fe=table();_0x4aa66b[_0x403449(0xcd)](objectKeys(_0x2f89fe)[_0x403449(0xbe)]>0x0,!![],'has\x20keys'),_0x4aa66b['end']();}),tape(a0_0x80e9e2(0xb9),function test(_0x424ad5){var _0x571db1=a0_0x80e9e2,_0x3c78c5=table();_0x424ad5[_0x571db1(0xcd)](_0x3c78c5[':smile:'],'😄',_0x571db1(0xc1)),_0x424ad5[_0x571db1(0xcd)](_0x3c78c5[':unicorn:'],'🦄',_0x571db1(0xc1)),_0x424ad5[_0x571db1(0xc8)]();});function a0_0x533d(){var _0x35c09f=['872168krlEzA','function','returns\x20expected\x20value','161SJlFSt','@stdlib/assert/is-plain-object','@stdlib/utils/keys','562840DTyCPe','1714722syljoR','2035220puHOGp','end','main\x20export\x20is\x20a\x20function','5273CtXXDb','the\x20function\x20returns\x20an\x20object','82506OREBpj','equal','the\x20returned\x20object\x20maps\x20emoji\x20codes\x20to\x20pictographs','828876AHGVQH','72rSolYv','92wDGLNI','./../','length'];a0_0x533d=function(){return _0x35c09f;};return a0_0x533d();}