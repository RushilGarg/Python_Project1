/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x58a4(){var _0x3aad04=['exports','2889180YnBCeP','1091684QTSrIu','16VpSMQC','6997386CHBRMV','1110823HnsiIl','56ekTAkJ','336445jcmdvA','30543pUMnSI','@stdlib/math/base/special/pow','284842jMRYHI'];a0_0x58a4=function(){return _0x3aad04;};return a0_0x58a4();}var a0_0x4459aa=a0_0x1431;(function(_0x33967b,_0x4c2a21){var _0x4e30a7=a0_0x1431,_0x3d44de=_0x33967b();while(!![]){try{var _0x5214d3=parseInt(_0x4e30a7(0x14c))/0x1+-parseInt(_0x4e30a7(0x149))/0x2+-parseInt(_0x4e30a7(0x147))/0x3*(parseInt(_0x4e30a7(0x14d))/0x4)+parseInt(_0x4e30a7(0x146))/0x5+parseInt(_0x4e30a7(0x14e))/0x6+parseInt(_0x4e30a7(0x14f))/0x7*(-parseInt(_0x4e30a7(0x150))/0x8)+-parseInt(_0x4e30a7(0x14b))/0x9;if(_0x5214d3===_0x4c2a21)break;else _0x3d44de['push'](_0x3d44de['shift']());}catch(_0x543b75){_0x3d44de['push'](_0x3d44de['shift']());}}}(a0_0x58a4,0xad648));var pow=require(a0_0x4459aa(0x148));function delay(_0x48756a,_0x15fc30){var _0x40c806=pow(0x2,_0x48756a)-0x1;return _0x40c806>_0x15fc30&&(_0x40c806=_0x15fc30),_0x40c806;}function a0_0x1431(_0x63f3f4,_0x247ea3){var _0x58a416=a0_0x58a4();return a0_0x1431=function(_0x14313b,_0x4141ba){_0x14313b=_0x14313b-0x146;var _0x508ad8=_0x58a416[_0x14313b];return _0x508ad8;},a0_0x1431(_0x63f3f4,_0x247ea3);}module[a0_0x4459aa(0x14a)]=delay;