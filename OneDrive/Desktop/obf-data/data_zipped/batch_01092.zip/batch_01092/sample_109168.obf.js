/*  
 * JCE Editor                 2.2.4
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    16 July 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
function a0_0x32fb(){var _0x162203=['button','Installer','ui-state-loading','270544OEbGDr','addClass','button.install_uninstall','jce','84310TxMEkz','678387lIASOq','127197ZUNhCR','val','tabs','6mQEEbP','remove','icon-remove','1743833YeWPuX','329857KPybnR','input[name=\x22task\x22]','#tabs','submit','2IJQQQg','10188NnNjMs','70PINeKZ','button#install_button','2104hcKrpQ','div#tabs\x20input:checkbox:checked','icon-install'];a0_0x32fb=function(){return _0x162203;};return a0_0x32fb();}function a0_0x2137(_0x5343a4,_0x2024da){var _0x32fb40=a0_0x32fb();return a0_0x2137=function(_0x2137ab,_0x2c50f5){_0x2137ab=_0x2137ab-0x13f;var _0x4d3642=_0x32fb40[_0x2137ab];return _0x4d3642;},a0_0x2137(_0x5343a4,_0x2024da);}(function(_0x4a273a,_0x250a11){var _0x5868b1=a0_0x2137,_0x4b209b=_0x4a273a();while(!![]){try{var _0x52ca22=parseInt(_0x5868b1(0x141))/0x1+-parseInt(_0x5868b1(0x14c))/0x2*(parseInt(_0x5868b1(0x140))/0x3)+-parseInt(_0x5868b1(0x156))/0x4+parseInt(_0x5868b1(0x13f))/0x5+parseInt(_0x5868b1(0x144))/0x6*(parseInt(_0x5868b1(0x147))/0x7)+parseInt(_0x5868b1(0x150))/0x8*(parseInt(_0x5868b1(0x14d))/0x9)+-parseInt(_0x5868b1(0x14e))/0xa*(parseInt(_0x5868b1(0x148))/0xb);if(_0x52ca22===_0x250a11)break;else _0x4b209b['push'](_0x4b209b['shift']());}catch(_0x49eec1){_0x4b209b['push'](_0x4b209b['shift']());}}}(a0_0x32fb,0x2db54),function(_0x34d62c){var _0x5e1fdf=a0_0x2137;_0x34d62c[_0x5e1fdf(0x159)][_0x5e1fdf(0x154)]={'init':function(_0x5b7625){var _0xa53296=_0x5e1fdf;_0x34d62c(_0xa53296(0x14a))[_0xa53296(0x143)](),_0x34d62c(_0xa53296(0x14f))[_0xa53296(0x153)]({'icons':{'primary':_0xa53296(0x152)}}),_0x34d62c(_0xa53296(0x158))[_0xa53296(0x153)]({'icons':{'primary':_0xa53296(0x146)}})['click'](function(_0x580423){var _0x1d9fd9=_0xa53296;_0x34d62c(_0x1d9fd9(0x151))['length']&&(_0x34d62c(this)[_0x1d9fd9(0x157)](_0x1d9fd9(0x155)),_0x34d62c(_0x1d9fd9(0x149))[_0x1d9fd9(0x142)](_0x1d9fd9(0x145)),_0x34d62c('form[name=\x22adminForm\x22]')[_0x1d9fd9(0x14b)]()),_0x580423['preventDefault']();});}};}(jQuery));