/**
 * @license Highstock JS v7.1.3 (2019-08-14)
 * @module highcharts/indicators/price-channel
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2019 Daniel Studencki
 *
 * License: www.highcharts.com/license
 */
'use strict';(function(_0x4f16ea,_0xc4e6b7){var _0x13d2f2=a0_0x4b3e,_0x2ef178=_0x4f16ea();while(!![]){try{var _0x2617e9=-parseInt(_0x13d2f2(0x151))/0x1+parseInt(_0x13d2f2(0x152))/0x2+-parseInt(_0x13d2f2(0x14c))/0x3+-parseInt(_0x13d2f2(0x150))/0x4+parseInt(_0x13d2f2(0x153))/0x5*(parseInt(_0x13d2f2(0x14d))/0x6)+-parseInt(_0x13d2f2(0x155))/0x7*(-parseInt(_0x13d2f2(0x14f))/0x8)+parseInt(_0x13d2f2(0x14e))/0x9*(parseInt(_0x13d2f2(0x154))/0xa);if(_0x2617e9===_0xc4e6b7)break;else _0x2ef178['push'](_0x2ef178['shift']());}catch(_0x4e729e){_0x2ef178['push'](_0x2ef178['shift']());}}}(a0_0x605f,0x36bf5));import'../../indicators/price-channel.src.js';function a0_0x4b3e(_0x2f6913,_0x5b873f){var _0x605f15=a0_0x605f();return a0_0x4b3e=function(_0x4b3e0d,_0xfb360b){_0x4b3e0d=_0x4b3e0d-0x14c;var _0x414643=_0x605f15[_0x4b3e0d];return _0x414643;},a0_0x4b3e(_0x2f6913,_0x5b873f);}function a0_0x605f(){var _0x58d498=['66305aoCSaB','632760AifJjl','1445983uhavup','1144368MHExee','48TMFytp','81OYpukC','8ajKdsZ','965220gwqeFN','365523THNakt','660776FiDLfI'];a0_0x605f=function(){return _0x58d498;};return a0_0x605f();}