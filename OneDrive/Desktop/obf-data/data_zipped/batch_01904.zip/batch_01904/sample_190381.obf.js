/**
 * @license Highstock JS v7.2.0 (2019-09-03)
 * @module highcharts/indicators/regressions
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2019 Kamil Kulig
 *
 * License: www.highcharts.com/license
 */
'use strict';(function(_0xb8da51,_0x4c07a4){var _0x581bc5=a0_0x44ca,_0x252626=_0xb8da51();while(!![]){try{var _0x3a5ec5=parseInt(_0x581bc5(0x16f))/0x1+-parseInt(_0x581bc5(0x16b))/0x2+-parseInt(_0x581bc5(0x16e))/0x3+parseInt(_0x581bc5(0x170))/0x4*(-parseInt(_0x581bc5(0x168))/0x5)+-parseInt(_0x581bc5(0x16a))/0x6+parseInt(_0x581bc5(0x16d))/0x7*(parseInt(_0x581bc5(0x169))/0x8)+parseInt(_0x581bc5(0x16c))/0x9;if(_0x3a5ec5===_0x4c07a4)break;else _0x252626['push'](_0x252626['shift']());}catch(_0x5a1e43){_0x252626['push'](_0x252626['shift']());}}}(a0_0x38aa,0x9766b));function a0_0x44ca(_0x3f8bef,_0xfdfd2d){var _0x38aaae=a0_0x38aa();return a0_0x44ca=function(_0x44cad2,_0x333966){_0x44cad2=_0x44cad2-0x168;var _0x12c3eb=_0x38aaae[_0x44cad2];return _0x12c3eb;},a0_0x44ca(_0x3f8bef,_0xfdfd2d);}import'../../indicators/regressions.src.js';function a0_0x38aa(){var _0xf46dca=['2061012GRzjOP','24564PoYhuN','8116245YwcGsN','14gHRaiz','2255967nbInLb','949675nCQTVQ','48uAxMGF','262685CWCsXI','2027504MVsfFJ'];a0_0x38aa=function(){return _0xf46dca;};return a0_0x38aa();}