/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x15821c=a0_0x2fe9;(function(_0x5f085c,_0x1760a9){var _0x2c178b=a0_0x2fe9,_0x380243=_0x5f085c();while(!![]){try{var _0x116c6e=-parseInt(_0x2c178b(0x18d))/0x1+parseInt(_0x2c178b(0x18b))/0x2*(parseInt(_0x2c178b(0x190))/0x3)+parseInt(_0x2c178b(0x192))/0x4+parseInt(_0x2c178b(0x194))/0x5+parseInt(_0x2c178b(0x18f))/0x6+-parseInt(_0x2c178b(0x195))/0x7*(-parseInt(_0x2c178b(0x197))/0x8)+parseInt(_0x2c178b(0x191))/0x9*(-parseInt(_0x2c178b(0x18e))/0xa);if(_0x116c6e===_0x1760a9)break;else _0x380243['push'](_0x380243['shift']());}catch(_0x2ac94b){_0x380243['push'](_0x380243['shift']());}}}(a0_0x5a73,0x5493c));function a0_0x2fe9(_0x587685,_0x3ae9aa){var _0x5a732f=a0_0x5a73();return a0_0x2fe9=function(_0x2fe949,_0x42b395){_0x2fe949=_0x2fe949-0x18b;var _0x1cc682=_0x5a732f[_0x2fe949];return _0x1cc682;},a0_0x2fe9(_0x587685,_0x3ae9aa);}function a0_0x5a73(){var _0x598032=['72ZCqCKX','158uoVTzf','exports','57028KSOcmq','19811970PyIiwu','3635580fHjSFd','4821VgVaAy','9kSOBcD','2617524EwYHXl','@stdlib/math/base/special/ln','2750580bAqUzt','347879jyqVBi','@stdlib/math/base/assert/is-nan'];a0_0x5a73=function(){return _0x598032;};return a0_0x5a73();}var isnan=require(a0_0x15821c(0x196)),ln=require(a0_0x15821c(0x193));function xlogy(_0x56ac16,_0x4afc52){if(_0x56ac16===0x0&&!isnan(_0x4afc52))return 0x0;return _0x56ac16*ln(_0x4afc52);}module[a0_0x15821c(0x18c)]=xlogy;