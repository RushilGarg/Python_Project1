/**
 * Easylife_GridEnhancer extension
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the MIT License
 * that is bundled with this package in the file LICENSE_GRID_ENHANCER.txt.
 * It is also available through the world-wide-web at this URL:
 * http://opensource.org/licenses/mit-license.php
 *
 * @category       Easylife
 * @package        Easylife_GridEnhancer
 * @copyright      Copyright (c) 2013
 * @license        http://opensource.org/licenses/mit-license.php MIT License
 * @deprecated     starting 0.2.0
 */
var a0_0xbb15bd=a0_0xddc9;(function(_0xf35eaa,_0x36b44b){var _0x384e91=a0_0xddc9,_0x4b938b=_0xf35eaa();while(!![]){try{var _0x4fc9b5=parseInt(_0x384e91(0x137))/0x1*(parseInt(_0x384e91(0x13c))/0x2)+parseInt(_0x384e91(0x130))/0x3*(parseInt(_0x384e91(0x139))/0x4)+parseInt(_0x384e91(0x135))/0x5*(parseInt(_0x384e91(0x138))/0x6)+-parseInt(_0x384e91(0x134))/0x7+-parseInt(_0x384e91(0x12f))/0x8*(-parseInt(_0x384e91(0x132))/0x9)+parseInt(_0x384e91(0x131))/0xa+-parseInt(_0x384e91(0x13a))/0xb;if(_0x4fc9b5===_0x36b44b)break;else _0x4b938b['push'](_0x4b938b['shift']());}catch(_0x18055c){_0x4b938b['push'](_0x4b938b['shift']());}}}(a0_0x43d3,0x89f53));function a0_0x43d3(){var _0x10bf7c=['Grid','184872XJJrJb','undefined','24HgMaXf','3voqAMX','7611530YBlPqH','1981845dcibgI','Product','5827815CKKLkN','415WyZcLP','create','2OXZvVn','47340RmLfdX','4093044kulqZw','20758661HHvPxv'];a0_0x43d3=function(){return _0x10bf7c;};return a0_0x43d3();}if(typeof Easylife_GridEnhancer==a0_0xbb15bd(0x12e))var Easylife_GridEnhancer={};function a0_0xddc9(_0xa09ed5,_0x2b92b2){var _0x43d372=a0_0x43d3();return a0_0xddc9=function(_0xddc9b4,_0x1fef71){_0xddc9b4=_0xddc9b4-0x12e;var _0x11f1e0=_0x43d372[_0xddc9b4];return _0x11f1e0;},a0_0xddc9(_0xa09ed5,_0x2b92b2);}Easylife_GridEnhancer[a0_0xbb15bd(0x133)]=Class[a0_0xbb15bd(0x136)](Easylife_GridEnhancer[a0_0xbb15bd(0x13b)]);