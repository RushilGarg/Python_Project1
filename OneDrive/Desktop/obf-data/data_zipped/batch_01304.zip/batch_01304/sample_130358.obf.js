/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2af79f=a0_0x3f48;function a0_0x3f48(_0x5031a3,_0x1f401b){var _0x4a9612=a0_0x4a96();return a0_0x3f48=function(_0x3f48b7,_0x1858b4){_0x3f48b7=_0x3f48b7-0x198;var _0x3b1108=_0x4a9612[_0x3f48b7];return _0x3b1108;},a0_0x3f48(_0x5031a3,_0x1f401b);}(function(_0x4a5c73,_0x5a34e6){var _0x27c981=a0_0x3f48,_0x3b0853=_0x4a5c73();while(!![]){try{var _0x1981a0=-parseInt(_0x27c981(0x19e))/0x1*(parseInt(_0x27c981(0x19f))/0x2)+parseInt(_0x27c981(0x1a0))/0x3*(-parseInt(_0x27c981(0x199))/0x4)+-parseInt(_0x27c981(0x19d))/0x5+parseInt(_0x27c981(0x19b))/0x6*(-parseInt(_0x27c981(0x198))/0x7)+parseInt(_0x27c981(0x1a1))/0x8*(-parseInt(_0x27c981(0x19c))/0x9)+parseInt(_0x27c981(0x1a4))/0xa+parseInt(_0x27c981(0x19a))/0xb;if(_0x1981a0===_0x5a34e6)break;else _0x3b0853['push'](_0x3b0853['shift']());}catch(_0xe31064){_0x3b0853['push'](_0x3b0853['shift']());}}}(a0_0x4a96,0x68523));var isArrayArray=require(a0_0x2af79f(0x1a2)),bool=isArrayArray([[],[],[]]);function a0_0x4a96(){var _0x19da8c=['185078MFtGKd','2DLToar','1305078xgEFNR','16gBeglq','./../lib','log','1662500dBYMfG','254394JnwTWq','4ObgnUW','20982522mwPFSF','6qqmFZT','1077201YNztAU','3753145XpKpav'];a0_0x4a96=function(){return _0x19da8c;};return a0_0x4a96();}console['log'](bool),bool=isArrayArray([[],{}]),console['log'](bool),bool=isArrayArray([]),console[a0_0x2af79f(0x1a3)](bool),bool=isArrayArray({}),console[a0_0x2af79f(0x1a3)](bool),bool=isArrayArray(['a','b']),console[a0_0x2af79f(0x1a3)](bool),bool=isArrayArray(null),console['log'](bool);