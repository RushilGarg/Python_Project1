/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x55bf(_0x508db9,_0x355fdc){var _0x178162=a0_0x1781();return a0_0x55bf=function(_0x55bf10,_0x5ef8f6){_0x55bf10=_0x55bf10-0x16c;var _0x2be6dd=_0x178162[_0x55bf10];return _0x2be6dd;},a0_0x55bf(_0x508db9,_0x355fdc);}var a0_0xab534f=a0_0x55bf;(function(_0x10efc8,_0x3613be){var _0x25a49f=a0_0x55bf,_0x3d5cc4=_0x10efc8();while(!![]){try{var _0x32a4f3=parseInt(_0x25a49f(0x16e))/0x1*(parseInt(_0x25a49f(0x16d))/0x2)+-parseInt(_0x25a49f(0x172))/0x3+parseInt(_0x25a49f(0x176))/0x4+-parseInt(_0x25a49f(0x177))/0x5*(parseInt(_0x25a49f(0x171))/0x6)+parseInt(_0x25a49f(0x16f))/0x7+-parseInt(_0x25a49f(0x16c))/0x8*(-parseInt(_0x25a49f(0x174))/0x9)+parseInt(_0x25a49f(0x173))/0xa;if(_0x32a4f3===_0x3613be)break;else _0x3d5cc4['push'](_0x3d5cc4['shift']());}catch(_0x4471e0){_0x3d5cc4['push'](_0x3d5cc4['shift']());}}}(a0_0x1781,0x86bf5));var factory=require(a0_0xab534f(0x178)),randint32=require(a0_0xab534f(0x175)),minstd=factory({'seed':randint32()});function a0_0x1781(){var _0x8786bb=['110552pIeyhN','658hOKgIP','597TGeNfp','5091114paYuXI','exports','4837692BZrHeN','2657169lnTLvn','6840770plencN','99jjNTZY','./rand_int32.js','1936516MbPsyW','5SerQxn','./factory.js'];a0_0x1781=function(){return _0x8786bb;};return a0_0x1781();}module[a0_0xab534f(0x170)]=minstd;