/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x223947=a0_0x875f;(function(_0x2704d4,_0x25f797){var _0x3778f3=a0_0x875f,_0x1a2943=_0x2704d4();while(!![]){try{var _0x3b9960=-parseInt(_0x3778f3(0x1e9))/0x1*(parseInt(_0x3778f3(0x1f1))/0x2)+-parseInt(_0x3778f3(0x1f0))/0x3+parseInt(_0x3778f3(0x1e5))/0x4+-parseInt(_0x3778f3(0x1e7))/0x5+parseInt(_0x3778f3(0x1f2))/0x6*(-parseInt(_0x3778f3(0x1ed))/0x7)+parseInt(_0x3778f3(0x1e6))/0x8*(-parseInt(_0x3778f3(0x1e4))/0x9)+parseInt(_0x3778f3(0x1ec))/0xa;if(_0x3b9960===_0x25f797)break;else _0x1a2943['push'](_0x1a2943['shift']());}catch(_0x5784ae){_0x1a2943['push'](_0x1a2943['shift']());}}}(a0_0x4e51,0x992e8));var join=require(a0_0x223947(0x1ee))[a0_0x223947(0x1ef)],tryRequire=require(a0_0x223947(0x1e8)),snanmax=require(a0_0x223947(0x1e3)),tmp=tryRequire(join(__dirname,a0_0x223947(0x1ea)));function a0_0x875f(_0x3d61f6,_0x3d226d){var _0x4e5161=a0_0x4e51();return a0_0x875f=function(_0x875fea,_0x3a527d){_0x875fea=_0x875fea-0x1e3;var _0x2dca6b=_0x4e5161[_0x875fea];return _0x2dca6b;},a0_0x875f(_0x3d61f6,_0x3d226d);}!(tmp instanceof Error)&&(snanmax=tmp);module[a0_0x223947(0x1eb)]=snanmax;function a0_0x4e51(){var _0x20c949=['4dBpxRN','4481016ktcDvT','./main.js','63ZTRHZX','4537272MIeTLy','116248VDwZPr','3455005aNgqXH','@stdlib/utils/try-require','390650DwaTrH','./native.js','exports','30222810NnGuCi','7QwinEa','path','join','3624939TyLnKO'];a0_0x4e51=function(){return _0x20c949;};return a0_0x4e51();}