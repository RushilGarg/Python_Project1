/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x3e5875=a0_0x2e2b;(function(_0x27d07e,_0x57de58){var _0x177767=a0_0x2e2b,_0x137e8f=_0x27d07e();while(!![]){try{var _0x4a92b0=-parseInt(_0x177767(0x151))/0x1+parseInt(_0x177767(0x157))/0x2+parseInt(_0x177767(0x158))/0x3*(-parseInt(_0x177767(0x155))/0x4)+parseInt(_0x177767(0x14a))/0x5+parseInt(_0x177767(0x146))/0x6+parseInt(_0x177767(0x14c))/0x7+-parseInt(_0x177767(0x143))/0x8*(-parseInt(_0x177767(0x144))/0x9);if(_0x4a92b0===_0x57de58)break;else _0x137e8f['push'](_0x137e8f['shift']());}catch(_0x2e9ae9){_0x137e8f['push'](_0x137e8f['shift']());}}}(a0_0x3433,0xb77d8));function a0_0x2e2b(_0x448a8e,_0x43eb18){var _0x3433f9=a0_0x3433();return a0_0x2e2b=function(_0x2e2bec,_0x386cff){_0x2e2bec=_0x2e2bec-0x142;var _0x1fb25=_0x3433f9[_0x2e2bec];return _0x1fb25;},a0_0x2e2b(_0x448a8e,_0x43eb18);}var bench=require(a0_0x3e5875(0x148)),randu=require('@stdlib/random/base/randu'),isnan=require(a0_0x3e5875(0x154))[a0_0x3e5875(0x147)],pkg=require(a0_0x3e5875(0x14f))[a0_0x3e5875(0x14d)],trythenAsync=require(a0_0x3e5875(0x150));function a0_0x3433(){var _0x14657b=['9fEPyjy','iterations','5237700QgEKbz','isPrimitive','@stdlib/bench','toc','979585xlunyV','pass','3538206wTSJbr','name','beep','./../package.json','./../lib','1266045aCrWON','tic','fail','@stdlib/assert/is-nan','8136ItUEcj','benchmark\x20finished','196626CGFvTn','2097nZLhcD','should\x20not\x20return\x20NaN','end','14133992kFHyfR'];a0_0x3433=function(){return _0x14657b;};return a0_0x3433();}bench(pkg,function benchmark(_0x532113){var _0x4a6216=a0_0x3e5875,_0x208bf9;_0x208bf9=0x0,_0x532113[_0x4a6216(0x152)]();return _0x2bc475();function _0x2bc475(_0x8bf41f,_0x4017b6){var _0x549a56=_0x4a6216;_0x208bf9+=0x1;_0x8bf41f&&_0x532113[_0x549a56(0x153)]('should\x20not\x20return\x20an\x20error');if(_0x208bf9<=_0x532113[_0x549a56(0x145)])return trythenAsync(_0x380027,_0x43f8e4,_0x2bc475);_0x532113[_0x549a56(0x149)](),isnan(_0x4017b6)&&_0x532113[_0x549a56(0x153)](_0x549a56(0x159)),_0x532113[_0x549a56(0x14b)](_0x549a56(0x156)),_0x532113[_0x549a56(0x142)]();}function _0x380027(_0xa2d06c){setTimeout(_0x158d6c,0x0);function _0x158d6c(){var _0x1c0f34=a0_0x2e2b;if(randu()>0.5)return _0xa2d06c(null,randu()*0x64);_0xa2d06c(new Error(_0x1c0f34(0x14e)));}}function _0x43f8e4(_0x3f1187){setTimeout(_0x42a328,0x0);function _0x42a328(){_0x3f1187(null,-0x1*randu()*0x64);}}});