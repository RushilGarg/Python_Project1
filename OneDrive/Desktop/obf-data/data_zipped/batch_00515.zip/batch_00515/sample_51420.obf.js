/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const a0_0x583de9=a0_0x4ea0;(function(_0x2be33d,_0x2f13b4){const _0x1d1528=a0_0x4ea0,_0x3351dc=_0x2be33d();while(!![]){try{const _0x3deae0=parseInt(_0x1d1528(0x152))/0x1+parseInt(_0x1d1528(0x14f))/0x2+parseInt(_0x1d1528(0x160))/0x3+parseInt(_0x1d1528(0x15f))/0x4*(parseInt(_0x1d1528(0x15b))/0x5)+-parseInt(_0x1d1528(0x161))/0x6*(-parseInt(_0x1d1528(0x163))/0x7)+parseInt(_0x1d1528(0x162))/0x8*(-parseInt(_0x1d1528(0x158))/0x9)+-parseInt(_0x1d1528(0x153))/0xa*(parseInt(_0x1d1528(0x154))/0xb);if(_0x3deae0===_0x2f13b4)break;else _0x3351dc['push'](_0x3351dc['shift']());}catch(_0x5101a6){_0x3351dc['push'](_0x3351dc['shift']());}}}(a0_0x4599,0xdc95b));function a0_0x4ea0(_0x13680a,_0x1925cd){const _0x4599e5=a0_0x4599();return a0_0x4ea0=function(_0x4ea034,_0x133c8d){_0x4ea034=_0x4ea034-0x14f;let _0x1778b3=_0x4599e5[_0x4ea034];return _0x1778b3;},a0_0x4ea0(_0x13680a,_0x1925cd);}function a0_0x4599(){const _0x59ea28=['2394952CfXpBt','14kRDTqn','output','3419290gzlfxW','dense','model','1611654JuDMvM','10xTjnCR','36873199JeqYMC','length','softmax','https://storage.googleapis.com/tfjs-speech-command-model-14w/model.json','36eioWDe','layers','apply','3659715QzKQDu','trainable','expelliarmus','lumos','4ZGBqqM','1768272qKgmax','2431302HfamDH'];a0_0x4599=function(){return _0x59ea28;};return a0_0x4599();}import*as a0_0x293466 from'@tensorflow/tfjs';const audioTransferLearningModelURL=a0_0x583de9(0x157);export const labelNames=['accio',a0_0x583de9(0x15d),a0_0x583de9(0x15e),'nox'];export async function loadAudioTransferLearningModel(){const _0x10e339=a0_0x583de9,_0x24dff7=await a0_0x293466['loadModel'](audioTransferLearningModelURL);for(let _0x513380=0x0;_0x513380<_0x24dff7[_0x10e339(0x159)][_0x10e339(0x155)];++_0x513380){_0x24dff7[_0x10e339(0x159)][_0x513380][_0x10e339(0x15c)]=![];}const _0x32cffc=_0x24dff7['layers'][0xa][_0x10e339(0x164)],_0x33556f=labelNames[_0x10e339(0x155)],_0x3531e0=a0_0x293466[_0x10e339(0x159)][_0x10e339(0x150)]({'units':_0x33556f,'activation':_0x10e339(0x156)}),_0x38414c=_0x3531e0[_0x10e339(0x15a)](_0x32cffc);return a0_0x293466[_0x10e339(0x151)]({'inputs':_0x24dff7['inputs'],'outputs':_0x38414c});}