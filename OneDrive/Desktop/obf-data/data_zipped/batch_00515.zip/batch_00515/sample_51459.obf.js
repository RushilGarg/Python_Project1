function a0_0x2ff5(){var _0x149e07=['getFatQuery','2488956HdrzpZ','6kingOF','FIELDS_CHANGE','1418815UNLKJA','turnsRemaining','44158260MnDvnR','getVariables','getConfigs','44119RSwyFF','4528167MyvfWK','getOptimisticResponse','171570LFTEQs','Mutation','958504zZanrH','game','fragments','6Qwqlgd','hidingSpot','16gGGuTh','getMutation','props','99hOHZIP','143GUyIYO'];a0_0x2ff5=function(){return _0x149e07;};return a0_0x2ff5();}function a0_0x50de(_0x29f6f4,_0x232920){var _0x2ff5c1=a0_0x2ff5();return a0_0x50de=function(_0x50decc,_0x381b02){_0x50decc=_0x50decc-0x105;var _0x24d1a7=_0x2ff5c1[_0x50decc];return _0x24d1a7;},a0_0x50de(_0x29f6f4,_0x232920);}var a0_0x58b296=a0_0x50de;(function(_0x419df6,_0xdb1534){var _0xfd4e9b=a0_0x50de,_0x530d01=_0x419df6();while(!![]){try{var _0x29cbc7=parseInt(_0xfd4e9b(0x10b))/0x1*(-parseInt(_0xfd4e9b(0x113))/0x2)+-parseInt(_0xfd4e9b(0x11b))/0x3+parseInt(_0xfd4e9b(0x115))/0x4*(-parseInt(_0xfd4e9b(0x106))/0x5)+parseInt(_0xfd4e9b(0x11c))/0x6*(parseInt(_0xfd4e9b(0x10c))/0x7)+-parseInt(_0xfd4e9b(0x110))/0x8*(parseInt(_0xfd4e9b(0x118))/0x9)+-parseInt(_0xfd4e9b(0x10e))/0xa*(parseInt(_0xfd4e9b(0x119))/0xb)+parseInt(_0xfd4e9b(0x108))/0xc;if(_0x29cbc7===_0xdb1534)break;else _0x530d01['push'](_0x530d01['shift']());}catch(_0x2e9798){_0x530d01['push'](_0x530d01['shift']());}}}(a0_0x2ff5,0xa8233));export default class CheckHidingSpotForTreasureMutation extends Relay[a0_0x58b296(0x10f)]{static [a0_0x58b296(0x112)]={'game':()=>Relay['QL']`
      fragment on Game {
        id,
        turnsRemaining,
      }
    `,'hidingSpot':()=>Relay['QL']`
      fragment on HidingSpot {
        id,
      }
    `};[a0_0x58b296(0x116)](){return Relay['QL']`mutation{checkHidingSpotForTreasure}`;}['getCollisionKey'](){return'check_'+this['props']['game']['id'];}[a0_0x58b296(0x11a)](){return Relay['QL']`
      fragment on CheckHidingSpotForTreasurePayload {
        hidingSpot {
          hasBeenChecked,
          hasTreasure,
        },
        game {
          turnsRemaining,
          state,
        },
      }
    `;}[a0_0x58b296(0x10a)](){var _0x403a44=a0_0x58b296;return[{'type':_0x403a44(0x105),'fieldIDs':{'hidingSpot':this[_0x403a44(0x117)]['hidingSpot']['id'],'game':this[_0x403a44(0x117)][_0x403a44(0x111)]['id']}}];}[a0_0x58b296(0x109)](){var _0x579f88=a0_0x58b296;return{'id':this[_0x579f88(0x117)][_0x579f88(0x114)]['id']};}[a0_0x58b296(0x10d)](){var _0x11a72d=a0_0x58b296;return{'game':{'turnsRemaining':this[_0x11a72d(0x117)][_0x11a72d(0x111)][_0x11a72d(0x107)]-0x1,'state':'PENDING'},'hidingSpot':{'id':this[_0x11a72d(0x117)]['hidingSpot']['id'],'hasBeenChecked':!![]}};}}