function a0_0x2730(_0x31df3f,_0x179622){const _0x2d338b=a0_0x2d33();return a0_0x2730=function(_0x273003,_0x3e1238){_0x273003=_0x273003-0x1a2;let _0x3a9c31=_0x2d338b[_0x273003];return _0x3a9c31;},a0_0x2730(_0x31df3f,_0x179622);}function a0_0x2d33(){const _0x4224a0=['share','shareMessage','398922yVRXEp','stopPropagation','error','15FwdZPm','exports','100rwNyDy','306497BWIhvT','translate','126651flrmBm','354116hOazcD','5mazAEp','notifyUploadEncryptDone','shareLinkDescription','36839176sEbseo','610389cpuaMJ','okButton','2219246ZXOAPn','-send-brand','shareLinkButton','40bwqsEs','ABORT_ERR'];a0_0x2d33=function(){return _0x4224a0;};return a0_0x2d33();}const a0_0x58e070=a0_0x2730;(function(_0xce34c1,_0x2e24ed){const _0x5b7da1=a0_0x2730,_0x9466b6=_0xce34c1();while(!![]){try{const _0x53f30f=-parseInt(_0x5b7da1(0x1af))/0x1+-parseInt(_0x5b7da1(0x1a2))/0x2+parseInt(_0x5b7da1(0x1ac))/0x3*(-parseInt(_0x5b7da1(0x1b2))/0x4)+-parseInt(_0x5b7da1(0x1b3))/0x5*(parseInt(_0x5b7da1(0x1a9))/0x6)+-parseInt(_0x5b7da1(0x1b1))/0x7*(-parseInt(_0x5b7da1(0x1a5))/0x8)+-parseInt(_0x5b7da1(0x1b7))/0x9*(parseInt(_0x5b7da1(0x1ae))/0xa)+parseInt(_0x5b7da1(0x1b6))/0xb;if(_0x53f30f===_0x2e24ed)break;else _0x9466b6['push'](_0x9466b6['shift']());}catch(_0x8cfb29){_0x9466b6['push'](_0x9466b6['shift']());}}}(a0_0x2d33,0xcc1b3));const html=require('choo/html');module[a0_0x58e070(0x1ad)]=function(_0x1fedc0,_0x331ab5){const _0x10944d=function(_0x24b289,_0x154c86,_0x47d40c){const _0x2fde62=a0_0x2730;return html`
      <send-share-dialog
        class="flex flex-col items-center text-center p-4 max-w-sm m-auto"
      >
        <h1 class="text-3xl font-bold my-4">
          ${_0x24b289[_0x2fde62(0x1b0)](_0x2fde62(0x1b4))}
        </h1>
        <p class="font-normal leading-normal text-grey-80 dark:text-grey-40">
          ${_0x24b289[_0x2fde62(0x1b0)](_0x2fde62(0x1b5))}<br />
          <span class="word-break-all">${_0x1fedc0}</span>
        </p>
        <input
          type="text"
          id="share-url"
          class="w-full my-4 border rounded-lg leading-loose h-12 px-2 py-1 dark:bg-grey-80"
          value="${_0x331ab5}"
          readonly="true"
        />
        <button
          class="btn rounded-lg w-full flex-shrink-0 focus:outline"
          onclick="${_0x28513d}"
          title="${_0x24b289[_0x2fde62(0x1b0)]('shareLinkButton')}"
        >
          ${_0x24b289[_0x2fde62(0x1b0)](_0x2fde62(0x1a4))}
        </button>
        <button
          class="link-blue my-4 font-medium cursor-pointer focus:outline"
          onclick="${_0x47d40c}"
          title="${_0x24b289[_0x2fde62(0x1b0)]('okButton')}"
        >
          ${_0x24b289['translate'](_0x2fde62(0x1b8))}
        </button>
      </send-share-dialog>
    `;async function _0x28513d(_0x5a6d44){const _0xdf7264=_0x2fde62;_0x5a6d44[_0xdf7264(0x1aa)]();try{await navigator[_0xdf7264(0x1a7)]({'title':_0x24b289[_0xdf7264(0x1b0)](_0xdf7264(0x1a3)),'text':_0x24b289[_0xdf7264(0x1b0)](_0xdf7264(0x1a8),{'name':_0x1fedc0}),'url':_0x331ab5});}catch(_0x59cef0){if(_0x59cef0['code']===_0x59cef0[_0xdf7264(0x1a6)])return;console[_0xdf7264(0x1ab)](_0x59cef0);}_0x47d40c();}};return _0x10944d['type']='share',_0x10944d;};