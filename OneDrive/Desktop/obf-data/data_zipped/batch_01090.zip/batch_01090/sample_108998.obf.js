/*
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x58ea(_0x26cace,_0x17750b){var _0x62c0cb=a0_0x62c0();return a0_0x58ea=function(_0x58eafd,_0xd45f2d){_0x58eafd=_0x58eafd-0x117;var _0x3cc7ff=_0x62c0cb[_0x58eafd];return _0x3cc7ff;},a0_0x58ea(_0x26cace,_0x17750b);}var a0_0x4bb15d=a0_0x58ea;(function(_0x275f69,_0x5bc7e4){var _0x18fd03=a0_0x58ea,_0x91f5c2=_0x275f69();while(!![]){try{var _0x5a5a8c=-parseInt(_0x18fd03(0x11e))/0x1+parseInt(_0x18fd03(0x11c))/0x2+parseInt(_0x18fd03(0x127))/0x3+parseInt(_0x18fd03(0x11a))/0x4*(parseInt(_0x18fd03(0x129))/0x5)+-parseInt(_0x18fd03(0x120))/0x6*(-parseInt(_0x18fd03(0x119))/0x7)+parseInt(_0x18fd03(0x12a))/0x8+-parseInt(_0x18fd03(0x11b))/0x9*(parseInt(_0x18fd03(0x126))/0xa);if(_0x5a5a8c===_0x5bc7e4)break;else _0x91f5c2['push'](_0x91f5c2['shift']());}catch(_0x35d0dd){_0x91f5c2['push'](_0x91f5c2['shift']());}}}(a0_0x62c0,0x3e1e5),CLASS({'name':a0_0x4bb15d(0x124),'package':'foam.core.dao','extends':a0_0x4bb15d(0x118),'requires':['foam.dao.ProxyDAO'],'properties':[{'name':a0_0x4bb15d(0x121),'factory':function(){return[];}},{'type':a0_0x4bb15d(0x11d),'name':a0_0x4bb15d(0x11f),'factory':function(){var _0x272076=a0_0x4bb15d;return this[_0x272076(0x117)][_0x272076(0x128)](_0x272076(0x122))[_0x272076(0x123)];}}],'methods':{'put':function(_0x342bec,_0x56f71c){this['pending']['push']({'o':_0x342bec,'sink':_0x56f71c});},'join':function(){var _0x4cd44c=a0_0x4bb15d,_0x28fac2=this[_0x4cd44c(0x121)];for(var _0x12b59d=0x0;_0x12b59d<_0x28fac2['length'];++_0x12b59d){this[_0x4cd44c(0x11f)](_0x28fac2[_0x12b59d]['o'],_0x28fac2[_0x12b59d][_0x4cd44c(0x125)]);}this['pending']=[];}}}));function a0_0x62c0(){var _0x2b8129=['sink','230oanwJV','1078023reyGNv','getFeature','5XiNYYV','3465008juBgzO','ProxyDAO','foam.dao.ProxyDAO','198961HzCvXI','901676CKEHBm','260847oBchvj','74124YKQxaS','Function','162325FpJZzx','put_','6dVWbrI','pending','put','code','ManuallyDelayedPutDAO'];a0_0x62c0=function(){return _0x2b8129;};return a0_0x62c0();}