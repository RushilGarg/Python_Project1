const a0_0x5d71b0=a0_0x3886;(function(_0x4df4f2,_0x31ad7e){const _0x5bd62f=a0_0x3886,_0x404564=_0x4df4f2();while(!![]){try{const _0x53216e=-parseInt(_0x5bd62f(0xe4))/0x1*(parseInt(_0x5bd62f(0xe5))/0x2)+parseInt(_0x5bd62f(0xe2))/0x3*(parseInt(_0x5bd62f(0xe0))/0x4)+parseInt(_0x5bd62f(0xe8))/0x5+-parseInt(_0x5bd62f(0xdc))/0x6*(parseInt(_0x5bd62f(0xde))/0x7)+parseInt(_0x5bd62f(0xdf))/0x8+-parseInt(_0x5bd62f(0xe7))/0x9+parseInt(_0x5bd62f(0xe6))/0xa*(-parseInt(_0x5bd62f(0xe3))/0xb);if(_0x53216e===_0x31ad7e)break;else _0x404564['push'](_0x404564['shift']());}catch(_0x5ce0de){_0x404564['push'](_0x404564['shift']());}}}(a0_0x550e,0xa04de));import a0_0x885959 from'styled-components';function a0_0x550e(){const _0x3f3258=['stoneClick','3773745GpINBX','8220542NVbMDw','491388iRNieZ','4zyvJAo','10SWhbtD','4346649DfRbYi','6266405HhAunw','div:hover\x20{\x20cursor:\x20pointer;\x20}','607350XPskPT','function','49XYOjOM','8536352rnxyJv','4pMqCeb'];a0_0x550e=function(){return _0x3f3258;};return a0_0x550e();}import a0_0x26c2e4 from'../Stones';const StyledStones=a0_0x885959(a0_0x26c2e4)`
  display: inline-block;
  width: 100%;
  min-height: 30px;

  div {
    display: inline-block;
    width: 20px;
    height: 20px;
    border: 1px solid #000000;
    border-radius: 50%;
    margin: 0 1px 0 0;
    padding: 0;
    text-align: center;
    font-size: 16px;
    line-height: 20px;
  }
  ${_0x516cda=>typeof _0x516cda[a0_0x5d71b0(0xe1)]==a0_0x5d71b0(0xdd)?a0_0x5d71b0(0xe9):''}
  div.black {
    color: white;
    background: black;
  }
  div.red {
    color: white;
    background: red;
  }
  div.blue {
    color: white;
    background: blue;
  }
  div.white {
    color: black;
    background: white;
  }
  div.disabled {
    color: #AAA;
    background: #666;
  }
  div.plus,
  div.and,
  div.equals {
    color: black;
    background: white;
    border: none;
  }
`;function a0_0x3886(_0x1f48a5,_0x2a254b){const _0x550eee=a0_0x550e();return a0_0x3886=function(_0x3886a7,_0x315126){_0x3886a7=_0x3886a7-0xdc;let _0x5a894d=_0x550eee[_0x3886a7];return _0x5a894d;},a0_0x3886(_0x1f48a5,_0x2a254b);}export default StyledStones;