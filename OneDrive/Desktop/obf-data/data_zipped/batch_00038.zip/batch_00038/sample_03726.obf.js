/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x3361(){var _0x594199=['5058gEqfYP','3431210SfeqNy','117071SmDZyU','exports','240400RoDHSB','119osAZuO','10986VRrsTL','1770255PNXcvU','4028hKrrln','_yScale','11InBZjg','122geaYrW','215cSagdC'];a0_0x3361=function(){return _0x594199;};return a0_0x3361();}function a0_0x5e87(_0x5d87eb,_0x4d7735){var _0x33611f=a0_0x3361();return a0_0x5e87=function(_0x5e8736,_0x191997){_0x5e8736=_0x5e8736-0x1d2;var _0x355257=_0x33611f[_0x5e8736];return _0x355257;},a0_0x5e87(_0x5d87eb,_0x4d7735);}var a0_0x37f3fa=a0_0x5e87;(function(_0x4d094a,_0x14fda3){var _0x2b7d3d=a0_0x5e87,_0x5f1ff4=_0x4d094a();while(!![]){try{var _0x1fb8f0=parseInt(_0x2b7d3d(0x1dc))/0x1+parseInt(_0x2b7d3d(0x1d8))/0x2*(parseInt(_0x2b7d3d(0x1da))/0x3)+parseInt(_0x2b7d3d(0x1d5))/0x4*(parseInt(_0x2b7d3d(0x1d9))/0x5)+-parseInt(_0x2b7d3d(0x1d3))/0x6*(-parseInt(_0x2b7d3d(0x1d2))/0x7)+-parseInt(_0x2b7d3d(0x1de))/0x8+parseInt(_0x2b7d3d(0x1d4))/0x9+-parseInt(_0x2b7d3d(0x1db))/0xa*(parseInt(_0x2b7d3d(0x1d7))/0xb);if(_0x1fb8f0===_0x14fda3)break;else _0x5f1ff4['push'](_0x5f1ff4['shift']());}catch(_0x5b5635){_0x5f1ff4['push'](_0x5f1ff4['shift']());}}}(a0_0x3361,0x1cc6d));function get(){var _0x45b4a2=a0_0x5e87;return this[_0x45b4a2(0x1d6)];}module[a0_0x37f3fa(0x1dd)]=get;