'use strict';const a0_0x650103=a0_0x3038;(function(_0x1665ad,_0x48acb8){const _0x2415de=a0_0x3038,_0x94af4b=_0x1665ad();while(!![]){try{const _0x50d945=parseInt(_0x2415de(0xc5))/0x1+parseInt(_0x2415de(0xc6))/0x2+parseInt(_0x2415de(0xb5))/0x3+-parseInt(_0x2415de(0x8e))/0x4+-parseInt(_0x2415de(0x8f))/0x5*(-parseInt(_0x2415de(0xab))/0x6)+-parseInt(_0x2415de(0xa2))/0x7*(-parseInt(_0x2415de(0xb6))/0x8)+parseInt(_0x2415de(0x97))/0x9*(-parseInt(_0x2415de(0xa0))/0xa);if(_0x50d945===_0x48acb8)break;else _0x94af4b['push'](_0x94af4b['shift']());}catch(_0xeb017d){_0x94af4b['push'](_0x94af4b['shift']());}}}(a0_0x47eb,0x34f75));function a0_0x47eb(){const _0x3834f3=['name','../../query/generateRQLFieldAlias','$.*.actor.id','getFieldByStorageKey','782228IrVZpv','121195RDWPIA','does\x20not\x20omit\x20\x22empty\x22\x20required\x20ref\x20query\x20dependencies','splitDeferredRelayQueries()','.edges.*.node.id','handles\x20fragments\x20that\x20are\x20not\x20nodes','__typename','toBe','returns\x20the\x20original\x20query\x20when\x20there\x20are\x20no\x20deferred\x20fragments','4194ujwHaW','drops\x20the\x20required\x20portion\x20if\x20it\x20is\x20empty','correctly\x20produces\x20multi-level\x20JSONPaths\x20in\x20ref\x20queries','Page','splits\x20a\x20nested\x20feed\x20on\x20the\x20viewer\x20root','String','extend','filter','build','16040JxUlqO','getChildren','2360519qTTUuf','splits\x20nested\x20deferred\x20fragments','toEqualQueryRoot','does\x20not\x20flatten\x20fragments\x20when\x20splitting\x20root\x20queries','metadata','length','omits\x20required\x20queries\x20with\x20only\x20generated\x20`id`\x20fields','splits\x20a\x20deferred\x20fragment\x20on\x20the\x20viewer\x20root','actor','36SvjOys','deferred','splitDeferredRelayQueries','../../RelayPublic','toEqual','works\x20with\x20nested\x20node\x20ancestors','isDeferred','splits\x20a\x20nested\x20deferred\x20fragments\x20as\x20a\x20ref\x20queries','toContainQueryNode','isGenerated','590886JcLELe','8IIYXVV','getID','uses\x20the\x20auto-generated\x20alias\x20in\x20ref\x20query\x20paths','handles\x20a\x20nested\x20defer\x20with\x20no\x20required\x20part','hometown','returns\x20the\x20original\x20query\x20when\x20there\x20are\x20no\x20fragments','isRefQueryDependency','Field','String!','node','resetModules','splits\x20a\x20deferred\x20fragment\x20on\x20a\x20query\x20without\x20an\x20ID\x20argument','splits\x20a\x20deferred\x20fragment\x20nested\x20inside\x20a\x20ref\x20query','required','$.*.hometown.id','329077GJilPu','302560haZowW','getName','handles\x20paths\x20with\x20plural\x20fields','cloneAsRefQueryDependency','$.*.actor.hometown.id','RelayTestUtils','getConcreteQueryNode','$.*.actors.*.id','Root','clone','friends.first(5)','../flattenRelayQuery','../splitDeferredRelayQueries','$.*.'];a0_0x47eb=function(){return _0x3834f3;};return a0_0x47eb();}function a0_0x3038(_0xba5990,_0x582e45){const _0x47ebc7=a0_0x47eb();return a0_0x3038=function(_0x3038e7,_0x9b16ab){_0x3038e7=_0x3038e7-0x7f;let _0x59cf15=_0x47ebc7[_0x3038e7];return _0x59cf15;},a0_0x3038(_0xba5990,_0x582e45);}const RelayClassic=require(a0_0x650103(0xae)),RelayQuery=require('../../query/RelayQuery'),RelayTestUtils=require(a0_0x650103(0x81)),flattenRelayQuery=require(a0_0x650103(0x87)),generateRQLFieldAlias=require(a0_0x650103(0x8b)),splitDeferredRelayQueries=require(a0_0x650103(0x88));describe(a0_0x650103(0x91),()=>{const _0x4704e1=a0_0x650103,{defer:_0x2e0c51,getNode:_0x71a3ff,getRefNode:_0x1f069a}=RelayTestUtils;function _0x330c8a(_0x210a06){const _0x91484e=a0_0x3038,_0x5ad3f3=_0x210a06[_0x91484e(0xa1)]()[_0x91484e(0x9e)](_0x5a8455=>!(_0x5a8455 instanceof RelayQuery[_0x91484e(0xbd)]&&_0x5a8455[_0x91484e(0xb4)]()));return _0x210a06[_0x91484e(0x85)](_0x5ad3f3);}beforeEach(()=>{const _0x1d6ad7=a0_0x3038;jest[_0x1d6ad7(0xc0)](),expect[_0x1d6ad7(0x9d)](RelayTestUtils['matchers']);}),it(_0x4704e1(0xbb),()=>{const _0x218e7e=_0x4704e1,_0x146920=RelayClassic['QL']`query{node(id:"4"){id,name}}`,_0x3bb7fd=_0x71a3ff(_0x146920),{required:_0x5e68fb,deferred:_0x5c737f}=splitDeferredRelayQueries(_0x3bb7fd);expect(_0x5e68fb)[_0x218e7e(0x95)](_0x3bb7fd),expect(_0x5c737f)[_0x218e7e(0xaf)]([]);}),it(_0x4704e1(0x96),()=>{const _0x506611=_0x4704e1,_0x57c9ef=RelayClassic['QL']`fragment on User{hometown{name}}`,_0x55e2db=RelayClassic['QL']`
      query {
        node(id:"4") {
          id
          name
          ${_0x57c9ef}
        }
      }
    `,_0x334643=_0x71a3ff(_0x55e2db),{required:_0x3c1b71,deferred:_0x230fb2}=splitDeferredRelayQueries(_0x334643);expect(_0x3c1b71)[_0x506611(0x95)](_0x334643),expect(_0x230fb2)[_0x506611(0xaf)]([]);}),it(_0x4704e1(0xa9),()=>{const _0x294100=_0x4704e1,_0x23dff4=RelayClassic['QL']`
      fragment on Viewer {
        newsFeed(first: 10) {
          edges {
            node {
              id
              actorCount
            }
          }
        }
      }
    `,_0x2ab67e=RelayClassic['QL']`
      query {
        viewer {
          actor {
            id
          }
          ${_0x2e0c51(_0x23dff4)}
        }
      }
    `,_0x3a87b8=_0x71a3ff(_0x2ab67e),{required:_0x2cf449,deferred:_0x53d364}=splitDeferredRelayQueries(_0x3a87b8);expect(_0x2cf449[_0x294100(0xc7)]())[_0x294100(0x95)](_0x3a87b8[_0x294100(0xc7)]()),expect(_0x2cf449)['toEqualQueryRoot'](_0x71a3ff(RelayClassic['QL']`query{viewer{actor{id}}}`)),expect(_0x2cf449[_0x294100(0xb7)]())[_0x294100(0x95)]('q3'),expect(_0x53d364[_0x294100(0xa7)])['toBe'](0x1),expect(_0x53d364[0x0][_0x294100(0xc3)]['getName']())[_0x294100(0x95)](_0x3a87b8['getName']()),expect(_0x53d364[0x0][_0x294100(0xc3)])['toEqualQueryRoot'](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          ${_0x23dff4}
        }
      }
    `)),expect(_0x53d364[0x0][_0x294100(0xc3)][_0x294100(0xb7)]())[_0x294100(0x95)]('q2'),expect(_0x53d364[0x0]['required'][_0x294100(0xb1)]())[_0x294100(0x95)](!![]),expect(_0x53d364[0x0][_0x294100(0xac)])['toEqual']([]);}),it(_0x4704e1(0xc1),()=>{const _0x42a302=_0x4704e1,_0x413167=RelayClassic['QL']`
      fragment on Actor {
        name
      }
    `,_0x19c792=RelayClassic['QL']`
      query {
        username(name:"yuzhi") {
          id
          ${_0x2e0c51(_0x413167)}
        }
      }
    `,_0x1a463d=_0x71a3ff(_0x19c792),{deferred:_0x51170f}=splitDeferredRelayQueries(_0x1a463d);expect(_0x51170f[_0x42a302(0xa7)])['toBe'](0x1),expect(_0x51170f[0x0][_0x42a302(0xc3)][_0x42a302(0x82)]()[_0x42a302(0xa6)])['toEqual']({'identifyingArgName':_0x42a302(0x8a),'identifyingArgType':_0x42a302(0xbe),'isAbstract':!![],'isPlural':![]});}),it(_0x4704e1(0x9b),()=>{const _0x44fcc6=_0x4704e1,_0x43b017=RelayClassic['QL']`
      fragment on Viewer {
        newsFeed(first: 10) {
          edges {
            node {
              id
              actorCount
            }
          }
        }
      }
    `,_0xa5d908=RelayClassic['QL']`
      fragment on Viewer {
        actor {
          name
        }
        ${_0x2e0c51(_0x43b017)}
      }
    `,_0x4be0b3=RelayClassic['QL']`
      query {
        viewer {
          actor {
            id
          }
          ${_0xa5d908}
        }
      }
    `,_0x31c8df=_0x71a3ff(_0x4be0b3),{required:_0x5a947c,deferred:_0x22f198}=splitDeferredRelayQueries(_0x31c8df);expect(_0x5a947c[_0x44fcc6(0xc7)]())[_0x44fcc6(0x95)](_0x31c8df[_0x44fcc6(0xc7)]()),expect(_0x5a947c)[_0x44fcc6(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          actor {
            id
          }
          ${RelayClassic['QL']`
      fragment on Viewer {
        actor {
          name,
        }
      }
    `}
        }
      }
    `)),expect(_0x22f198['length'])[_0x44fcc6(0x95)](0x1),expect(_0x22f198[0x0]['required']['getName']())[_0x44fcc6(0x95)](_0x31c8df[_0x44fcc6(0xc7)]()),expect(_0x22f198[0x0][_0x44fcc6(0xc3)])[_0x44fcc6(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          ${_0x43b017}
        }
      }
    `)),expect(_0x22f198[0x0][_0x44fcc6(0xc3)][_0x44fcc6(0xb1)]())['toBe'](!![]),expect(_0x22f198[0x0]['deferred'])[_0x44fcc6(0xaf)]([]);}),it(_0x4704e1(0xa3),()=>{const _0x28190c=_0x4704e1,_0x2f8145=RelayClassic['QL']`fragment on NonNodeStory{message{text}}`,_0x2c33ea=RelayClassic['QL']`
      fragment on Viewer {
        newsFeed(first: 10) {
          edges {
            node {
              tracking
              ${_0x2e0c51(_0x2f8145)}
            }
          }
        }
      }
    `,_0x22dec4=RelayClassic['QL']`
      query {
        viewer {
          actor {
            name
          }
          ${_0x2e0c51(_0x2c33ea)}
        }
      }
    `,_0x135d84=_0x71a3ff(_0x22dec4),{required:_0x1c56a3,deferred:_0x4e35d4}=splitDeferredRelayQueries(_0x135d84);expect(_0x1c56a3[_0x28190c(0xc7)]())[_0x28190c(0x95)](_0x135d84[_0x28190c(0xc7)]()),expect(_0x1c56a3)[_0x28190c(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer{actor{id,name}}
      }
    `)),expect(_0x1c56a3[_0x28190c(0xb7)]())[_0x28190c(0x95)]('q5'),expect(_0x4e35d4[_0x28190c(0xa7)])[_0x28190c(0x95)](0x1),expect(_0x4e35d4[0x0][_0x28190c(0xc3)][_0x28190c(0xc7)]())[_0x28190c(0x95)](_0x135d84[_0x28190c(0xc7)]()),expect(_0x4e35d4[0x0]['required'])[_0x28190c(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          ${RelayClassic['QL']`
      fragment on Viewer {
        newsFeed(first: 10) {
          edges {
            cursor,
            node {
              id,
              tracking
            }
          },
          pageInfo {
            hasNextPage,
            hasPreviousPage
          }
        }
      }
    `}
        }
      }
    `)),expect(_0x4e35d4[0x0][_0x28190c(0xc3)][_0x28190c(0xb7)]())[_0x28190c(0x95)]('q4'),expect(_0x4e35d4[0x0][_0x28190c(0xc3)][_0x28190c(0xb1)]())[_0x28190c(0x95)](!![]),expect(_0x4e35d4[0x0][_0x28190c(0xac)][_0x28190c(0xa7)])[_0x28190c(0x95)](0x1),expect(_0x4e35d4[0x0][_0x28190c(0xac)][0x0][_0x28190c(0xc3)][_0x28190c(0xc7)]())[_0x28190c(0x95)](_0x135d84[_0x28190c(0xc7)]()),expect(flattenRelayQuery(_0x4e35d4[0x0]['deferred'][0x0][_0x28190c(0xc3)]))[_0x28190c(0xa4)](flattenRelayQuery(_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          newsFeed(first: 10) {
            edges {
              cursor
              node {
                ${_0x2f8145}
                id
              }
            }
            pageInfo {
              hasNextPage
              hasPreviousPage
            }
          }
        }
      }
    `))),expect(_0x4e35d4[0x0]['deferred'][0x0][_0x28190c(0xc3)][_0x28190c(0xb7)]())[_0x28190c(0x95)]('q2'),expect(_0x4e35d4[0x0][_0x28190c(0xac)][0x0]['required'][_0x28190c(0xb1)]())[_0x28190c(0x95)](!![]),expect(_0x4e35d4[0x0]['deferred'][0x0][_0x28190c(0xac)])['toEqual']([]);}),it('splits\x20deferred\x20fragments\x20using\x20ref\x20queries',()=>{const _0x2cf9b9=_0x4704e1,_0x9e7f2f=RelayClassic['QL']`fragment on Page{profilePicture{uri}}`,_0x4f155d=RelayClassic['QL']`
      query {
        node(id:"4") {
          id
          name
          hometown {
            ${_0x2e0c51(_0x9e7f2f)}
          }
        }
      }
    `,_0x192a82=_0x71a3ff(_0x4f155d),{required:_0x9c4a8b,deferred:_0x31afc3}=splitDeferredRelayQueries(_0x192a82);expect(_0x9c4a8b['getName']())[_0x2cf9b9(0x95)](_0x192a82[_0x2cf9b9(0xc7)]()),expect(_0x9c4a8b)[_0x2cf9b9(0xa4)](_0x71a3ff(RelayClassic['QL']`query{node(id:"4"){hometown{id},id,name}}`)),expect(_0x9c4a8b[_0x2cf9b9(0xb7)]())[_0x2cf9b9(0x95)]('q1'),expect(_0x9c4a8b[_0x2cf9b9(0x8d)](_0x2cf9b9(0xba))[_0x2cf9b9(0x8d)]('id')[_0x2cf9b9(0xbc)]())[_0x2cf9b9(0x95)](!![]),expect(_0x31afc3['length'])['toBe'](0x1),expect(_0x31afc3[0x0][_0x2cf9b9(0xc3)][_0x2cf9b9(0xc7)]())[_0x2cf9b9(0x95)](_0x192a82[_0x2cf9b9(0xc7)]()),expect(_0x31afc3[0x0][_0x2cf9b9(0xc3)])[_0x2cf9b9(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0x9e7f2f}
            }
          }
        `,{'path':_0x2cf9b9(0xc4)}))),expect(_0x31afc3[0x0][_0x2cf9b9(0xc3)]['getID']())[_0x2cf9b9(0x95)]('q2'),expect(_0x31afc3[0x0]['required']['isDeferred']())[_0x2cf9b9(0x95)](!![]),expect(_0x31afc3[0x0]['deferred'])[_0x2cf9b9(0xaf)]([]);}),it(_0x4704e1(0xb2),()=>{const _0x3c713c=_0x4704e1,_0x357ddb=RelayClassic['QL']`fragment on Page{profilePicture{uri}}`,_0x20d245=RelayClassic['QL']`
      fragment on User {
        hometown {
          name
          ${_0x2e0c51(_0x357ddb)}
        }
      }
    `,_0x4c8398=RelayClassic['QL']`
      query {
        node(id:"4") {
          id
          name
          ${_0x2e0c51(_0x20d245)}
        }
      }
    `,_0x49ded7=_0x71a3ff(_0x4c8398),{required:_0x2517ff,deferred:_0x19489b}=splitDeferredRelayQueries(_0x49ded7);expect(_0x2517ff[_0x3c713c(0xc7)]())[_0x3c713c(0x95)](_0x49ded7[_0x3c713c(0xc7)]()),expect(_0x2517ff)[_0x3c713c(0xa4)](_0x71a3ff(RelayClassic['QL']`query{node(id:"4"){id,name}}`)),expect(_0x2517ff[_0x3c713c(0xb7)]())[_0x3c713c(0x95)]('q3'),expect(_0x19489b[_0x3c713c(0xa7)])[_0x3c713c(0x95)](0x1),expect(_0x19489b[0x0][_0x3c713c(0xc3)]['getName']())['toBe'](_0x49ded7[_0x3c713c(0xc7)]()),expect(_0x19489b[0x0][_0x3c713c(0xc3)])[_0x3c713c(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4") {
          ${RelayClassic['QL']`fragment on User{hometown{name}}`},
          id
        }
      }
    `)),expect(_0x19489b[0x0][_0x3c713c(0xc3)]['getID']())[_0x3c713c(0x95)]('q2'),expect(_0x19489b[0x0][_0x3c713c(0xc3)][_0x3c713c(0xb1)]())['toBe'](!![]),expect(_0x19489b[0x0][_0x3c713c(0xc3)][_0x3c713c(0xa1)]()[0x0][_0x3c713c(0xa1)]()[0x0]['getChildren']()[0x0][_0x3c713c(0xbc)]())[_0x3c713c(0x95)](!![]),expect(_0x19489b[0x0][_0x3c713c(0xac)]['length'])[_0x3c713c(0x95)](0x1),expect(_0x19489b[0x0][_0x3c713c(0xac)][0x0][_0x3c713c(0xc3)][_0x3c713c(0xc7)]())[_0x3c713c(0x95)](_0x49ded7[_0x3c713c(0xc7)]()),expect(_0x19489b[0x0][_0x3c713c(0xac)][0x0]['required'])['toEqualQueryRoot'](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q2) {
              ${_0x357ddb}
            }
          }
        `,{'path':_0x3c713c(0xc4)}))),expect(_0x19489b[0x0]['deferred'][0x0][_0x3c713c(0xc3)][_0x3c713c(0xb7)]())[_0x3c713c(0x95)]('q4'),expect(_0x19489b[0x0][_0x3c713c(0xac)][0x0][_0x3c713c(0xc3)][_0x3c713c(0xb1)]())[_0x3c713c(0x95)](!![]),expect(_0x19489b[0x0]['deferred'][0x0][_0x3c713c(0xac)])[_0x3c713c(0xaf)]([]);}),it(_0x4704e1(0xc2),()=>{const _0x20ca21=_0x4704e1,_0x2e7eee=RelayClassic['QL']`fragment on Page{address{city}}`,_0x51038b=RelayClassic['QL']`
      fragment on Page {
        profilePicture {
          uri
        }
        ${_0x2e0c51(_0x2e7eee)}
      }
    `,_0x5d78f2=RelayClassic['QL']`
      query {
        node(id:"4") {
          id
          name
          hometown {
            ${_0x2e0c51(_0x51038b)}
          }
        }
      }
    `,_0x3e7b5c=_0x71a3ff(_0x5d78f2),{required:_0x354e0f,deferred:_0x3b5231}=splitDeferredRelayQueries(_0x3e7b5c);expect(_0x354e0f[_0x20ca21(0xc7)]())[_0x20ca21(0x95)](_0x3e7b5c[_0x20ca21(0xc7)]()),expect(_0x354e0f)[_0x20ca21(0xa4)](_0x71a3ff(RelayClassic['QL']`query{node(id:"4"){hometown{id},id,name}}`)),expect(_0x354e0f['getFieldByStorageKey'](_0x20ca21(0xba))['getFieldByStorageKey']('id')[_0x20ca21(0xbc)]())[_0x20ca21(0x95)](!![]),expect(_0x354e0f[_0x20ca21(0xb7)]())['toBe']('q1'),expect(_0x3b5231['length'])['toBe'](0x1),expect(_0x3b5231[0x0][_0x20ca21(0xc3)]['getName']())[_0x20ca21(0x95)](_0x3e7b5c[_0x20ca21(0xc7)]()),expect(_0x3b5231[0x0][_0x20ca21(0xc3)])['toEqualQueryRoot'](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${RelayClassic['QL']`fragment on Page{id,profilePicture{uri}}`}
            }
          }
        `,{'path':'$.*.hometown.id'}))),expect(_0x3b5231[0x0][_0x20ca21(0xc3)][_0x20ca21(0xb7)]())[_0x20ca21(0x95)]('q2'),expect(_0x3b5231[0x0][_0x20ca21(0xc3)]['isDeferred']())['toBe'](!![]),expect(_0x3b5231[0x0][_0x20ca21(0xac)]['length'])[_0x20ca21(0x95)](0x1),expect(_0x3b5231[0x0][_0x20ca21(0xac)][0x0][_0x20ca21(0xc3)][_0x20ca21(0xc7)]())['toBe'](_0x3e7b5c[_0x20ca21(0xc7)]()),expect(_0x3b5231[0x0]['deferred'][0x0][_0x20ca21(0xc3)])[_0x20ca21(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q2) {
              ${_0x2e7eee}
            }
          }
        `,{'path':'$.*.hometown.id'}))),expect(_0x3b5231[0x0]['deferred'][0x0][_0x20ca21(0xc3)][_0x20ca21(0xb7)]())[_0x20ca21(0x95)]('q3'),expect(_0x3b5231[0x0]['deferred'][0x0][_0x20ca21(0xc3)][_0x20ca21(0xb1)]())[_0x20ca21(0x95)](!![]),expect(_0x3b5231[0x0][_0x20ca21(0xac)][0x0][_0x20ca21(0xac)])['toEqual']([]);}),it(_0x4704e1(0x98),()=>{const _0xbead89=_0x4704e1,_0x3f9813=RelayClassic['QL']`
      fragment on Viewer {
        newsFeed(first: 10) {
          edges {
            node {
              id
              actorCount
            }
          }
        }
      }
    `,_0x20ddb4=RelayClassic['QL']`
      query {
        viewer {
          ${_0x2e0c51(_0x3f9813)}
        }
      }
    `,_0x43d7c3=_0x71a3ff(_0x20ddb4),{required:_0x29d0d9,deferred:_0x56137b}=splitDeferredRelayQueries(_0x43d7c3);expect(_0x29d0d9)[_0xbead89(0x95)](null),expect(_0x56137b[_0xbead89(0xa7)])[_0xbead89(0x95)](0x1),expect(_0x56137b[0x0][_0xbead89(0xc3)]['getName']())[_0xbead89(0x95)](_0x43d7c3[_0xbead89(0xc7)]()),expect(_0x56137b[0x0][_0xbead89(0xc3)])[_0xbead89(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          ${_0x3f9813}
        }
      }
    `)),expect(_0x56137b[0x0][_0xbead89(0xc3)]['isDeferred']())[_0xbead89(0x95)](!![]),expect(_0x56137b[0x0][_0xbead89(0xac)])[_0xbead89(0xaf)]([]);}),it(_0x4704e1(0xb9),()=>{const _0x455858=_0x4704e1,_0x6d8665=RelayClassic['QL']`fragment on Viewer{primaryEmail}`,_0x909d3d=RelayClassic['QL']`
      fragment on Viewer {
        ${_0x2e0c51(_0x6d8665)}
      }
    `,_0x186522=RelayClassic['QL']`
      query {
        viewer {
          isFbEmployee
          ${_0x2e0c51(_0x909d3d)}
        }
      }
    `,_0x29676b=_0x71a3ff(_0x186522),{required:_0x50496c,deferred:_0xef8f34}=splitDeferredRelayQueries(_0x29676b);expect(_0x50496c[_0x455858(0xc7)]())[_0x455858(0x95)](_0x29676b[_0x455858(0xc7)]()),expect(_0x50496c)[_0x455858(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer{isFbEmployee}
      }
    `)),expect(_0xef8f34['length'])[_0x455858(0x95)](0x1),expect(_0xef8f34[0x0][_0x455858(0xc3)])[_0x455858(0x95)](null),expect(_0xef8f34[0x0]['deferred'][_0x455858(0xa7)])[_0x455858(0x95)](0x1),expect(_0xef8f34[0x0][_0x455858(0xac)][0x0][_0x455858(0xc3)][_0x455858(0xc7)]())[_0x455858(0x95)](_0x29676b['getName']()),expect(_0xef8f34[0x0][_0x455858(0xac)][0x0]['required'])['toEqualQueryRoot'](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          ${_0x6d8665}
        }
      }
    `)),expect(_0xef8f34[0x0][_0x455858(0xac)][0x0][_0x455858(0xc3)][_0x455858(0xb1)]())['toBe'](!![]),expect(_0xef8f34[0x0][_0x455858(0xac)][0x0][_0x455858(0xac)])[_0x455858(0xaf)]([]);}),it('handles\x20a\x20nested\x20ref\x20query\x20defer\x20with\x20no\x20required\x20part',()=>{const _0x30781a=_0x4704e1,_0x230e7c=RelayClassic['QL']`fragment on Actor{hometown{name}}`,_0x230dc8=RelayClassic['QL']`
      fragment on Viewer {
        ${_0x2e0c51(_0x230e7c)}
      }
    `,_0x66d745=RelayClassic['QL']`
      query {
        viewer {
          actor {
            name
            ${_0x2e0c51(_0x230dc8)}
          }
        }
      }
    `,_0x3acd67=_0x71a3ff(_0x66d745),{required:_0x42478c,deferred:_0x4d5717}=splitDeferredRelayQueries(_0x3acd67);expect(_0x42478c[_0x30781a(0xc7)]())[_0x30781a(0x95)](_0x3acd67['getName']()),expect(_0x42478c)[_0x30781a(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer{actor{id,name}}
      }
    `)),expect(_0x42478c[_0x30781a(0xb7)]())[_0x30781a(0x95)]('q1'),expect(_0x42478c['getFieldByStorageKey'](_0x30781a(0xaa))[_0x30781a(0x8d)]('id')[_0x30781a(0xbc)]())[_0x30781a(0x95)](!![]),expect(_0x4d5717[_0x30781a(0xa7)])[_0x30781a(0x95)](0x1),expect(_0x4d5717[0x0]['required'])[_0x30781a(0x95)](null),expect(_0x4d5717[0x0][_0x30781a(0xac)][_0x30781a(0xa7)])[_0x30781a(0x95)](0x1),expect(_0x4d5717[0x0]['deferred'][0x0]['required'][_0x30781a(0xc7)]())[_0x30781a(0x95)](_0x3acd67[_0x30781a(0xc7)]()),expect(_0x4d5717[0x0][_0x30781a(0xac)][0x0]['required'])[_0x30781a(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0x230e7c}
            }
          }
        `,{'path':_0x30781a(0x8c)}))),expect(_0x4d5717[0x0]['deferred'][0x0]['required']['getID']())['toBe']('q2'),expect(_0x4d5717[0x0]['deferred'][0x0][_0x30781a(0xc3)]['isDeferred']())[_0x30781a(0x95)](!![]),expect(_0x4d5717[0x0][_0x30781a(0xac)][0x0][_0x30781a(0xac)])[_0x30781a(0xaf)]([]);}),it(_0x4704e1(0xc8),()=>{const _0x5bcff3=_0x4704e1,_0xc0f664=RelayClassic['QL']`fragment on Actor{name}`,_0x569ec1=RelayClassic['QL']`
      query {
        node(id:"123") {
          actors {
            id
            ${_0x2e0c51(_0xc0f664)}
          }
        }
      }
    `,_0x253e70=_0x71a3ff(_0x569ec1),{required:_0x54821b,deferred:_0x46f1f7}=splitDeferredRelayQueries(_0x253e70);expect(_0x54821b[_0x5bcff3(0xc7)]())['toBe'](_0x253e70[_0x5bcff3(0xc7)]()),expect(_0x54821b)[_0x5bcff3(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"123") {
          actors {
            id
          }
        }
      }
    `)),expect(_0x54821b['getID']())['toBe']('q1'),expect(_0x46f1f7['length'])['toBe'](0x1),expect(_0x46f1f7[0x0]['required']['getName']())['toBe'](_0x253e70[_0x5bcff3(0xc7)]()),expect(_0x46f1f7[0x0][_0x5bcff3(0xc3)])[_0x5bcff3(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0xc0f664}
            }
          }
        `,{'path':_0x5bcff3(0x83)}))),expect(_0x46f1f7[0x0][_0x5bcff3(0xc3)][_0x5bcff3(0xb7)]())['toBe']('q2'),expect(_0x46f1f7[0x0]['required'][_0x5bcff3(0xb1)]())['toBe'](!![]),expect(_0x46f1f7[0x0]['deferred'])[_0x5bcff3(0xaf)]([]);}),it(_0x4704e1(0xb0),()=>{const _0x2f0152=_0x4704e1,_0x16b1eb=RelayClassic['QL']`fragment on Node{name}`,_0x5a6422=RelayClassic['QL']`
      query {
        viewer {
          actor {
            hometown {
              ${_0x2e0c51(_0x16b1eb)}
            }
          }
        }
      }
    `,_0x58f19b=_0x71a3ff(_0x5a6422),{required:_0x49aa2e,deferred:_0x548ad4}=splitDeferredRelayQueries(_0x58f19b);expect(_0x49aa2e[_0x2f0152(0xc7)]())[_0x2f0152(0x95)](_0x58f19b[_0x2f0152(0xc7)]()),expect(_0x49aa2e)[_0x2f0152(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer {
          actor {
            hometown {
              id
            }
          }
        }
      }
    `)),expect(_0x49aa2e['getID']())[_0x2f0152(0x95)]('q1'),expect(_0x548ad4[_0x2f0152(0xa7)])[_0x2f0152(0x95)](0x1),expect(_0x548ad4[0x0]['required'][_0x2f0152(0xc7)]())[_0x2f0152(0x95)](_0x58f19b[_0x2f0152(0xc7)]()),expect(_0x548ad4[0x0]['required'])[_0x2f0152(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0x16b1eb}
            }
          }
        `,{'path':_0x2f0152(0x80)}))),expect(_0x548ad4[0x0][_0x2f0152(0xc3)]['getID']())[_0x2f0152(0x95)]('q2'),expect(_0x548ad4[0x0][_0x2f0152(0xc3)][_0x2f0152(0xb1)]())[_0x2f0152(0x95)](!![]),expect(_0x548ad4[0x0][_0x2f0152(0xac)])[_0x2f0152(0xaf)]([]);}),it(_0x4704e1(0xb8),()=>{const _0x576037=_0x4704e1,_0x3e10ce=RelayClassic['QL']`fragment on User{firstName}`,_0x16b05e=RelayClassic['QL']`
      query {
        node(id:"4") {
          friends(first: 5) {
            edges {
              node {
                name
                ${_0x2e0c51(_0x3e10ce)}
              }
            }
          }
        }
      }
    `,_0xfe9d65=_0x71a3ff(_0x16b05e),{required:_0x1ac427,deferred:_0x4e86fc}=splitDeferredRelayQueries(_0xfe9d65);expect(_0x1ac427[_0x576037(0xc7)]())[_0x576037(0x95)](_0xfe9d65[_0x576037(0xc7)]()),expect(_0x1ac427)[_0x576037(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4") {
          friends(first: 5) {
            edges {
              node {
                id
                name
              }
            }
          }
        }
      }
    `)),expect(_0x1ac427[_0x576037(0xb7)]())[_0x576037(0x95)]('q1');const _0x51ee4b=generateRQLFieldAlias(_0x576037(0x86));expect(_0x4e86fc['length'])[_0x576037(0x95)](0x1),expect(_0x4e86fc[0x0][_0x576037(0xc3)][_0x576037(0xc7)]())[_0x576037(0x95)](_0xfe9d65[_0x576037(0xc7)]()),expect(_0x4e86fc[0x0][_0x576037(0xc3)])[_0x576037(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0x3e10ce}
            }
          }
        `,{'path':_0x576037(0x89)+_0x51ee4b+_0x576037(0x92)}))),expect(_0x4e86fc[0x0]['required'][_0x576037(0xb7)]())[_0x576037(0x95)]('q2'),expect(_0x4e86fc[0x0][_0x576037(0xc3)][_0x576037(0xb1)]())[_0x576037(0x95)](!![]),expect(_0x4e86fc[0x0][_0x576037(0xac)])['toEqual']([]);}),it(_0x4704e1(0x99),()=>{const _0x2475a7=_0x4704e1,_0x21aab4=RelayClassic['QL']`fragment on Actor{name}`,_0x3453df=RelayClassic['QL']`
      query {
        node(id:"4") {
          friends(first: 5) {
            edges {
              node {
                ${_0x2e0c51(_0x21aab4)}
              }
            }
          }
        }
      }
    `,_0x12dd1d=_0x71a3ff(_0x3453df),{required:_0x2c87c2,deferred:_0x4428df}=splitDeferredRelayQueries(_0x12dd1d);expect(_0x2c87c2[_0x2475a7(0xc7)]())[_0x2475a7(0x95)](_0x12dd1d[_0x2475a7(0xc7)]()),expect(_0x2c87c2)[_0x2475a7(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4") {
          friends(first: 5) {
            edges {
              node {
                id
              }
            }
          }
        }
      }
    `)),expect(_0x2c87c2[_0x2475a7(0xb7)]())[_0x2475a7(0x95)]('q1');const _0x122d59=generateRQLFieldAlias(_0x2475a7(0x86));expect(_0x4428df[_0x2475a7(0xa7)])[_0x2475a7(0x95)](0x1),expect(_0x4428df[0x0][_0x2475a7(0xc3)]['getName']())[_0x2475a7(0x95)](_0x12dd1d[_0x2475a7(0xc7)]()),expect(_0x4428df[0x0][_0x2475a7(0xc3)])['toEqualQueryRoot'](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0x21aab4}
            }
          }
        `,{'path':'$.*.'+_0x122d59+_0x2475a7(0x92)}))),expect(_0x4428df[0x0][_0x2475a7(0xc3)]['getID']())[_0x2475a7(0x95)]('q2'),expect(_0x4428df[0x0][_0x2475a7(0xc3)]['isDeferred']())[_0x2475a7(0x95)](!![]),expect(_0x4428df[0x0][_0x2475a7(0xac)])[_0x2475a7(0xaf)]([]);}),it(_0x4704e1(0x93),()=>{const _0xb4154=_0x4704e1,_0x2f2969=RelayClassic['QL']`fragment on Image{uri}`,_0x18b3a5=RelayClassic['QL']`
      query {
        node(id:"4") {
          id
          profilePicture(size: 100) {
            ${_0x2e0c51(_0x2f2969)}
          }
        }
      }
    `,_0x33aa1b=_0x71a3ff(_0x18b3a5),{required:_0x35c47d,deferred:_0x2d9e96}=splitDeferredRelayQueries(_0x33aa1b);expect(_0x35c47d['getName']())[_0xb4154(0x95)](_0x33aa1b[_0xb4154(0xc7)]()),expect(_0x35c47d)[_0xb4154(0xa4)](_0x71a3ff(RelayClassic['QL']`query{node(id:"4"){id}}`)),expect(_0x2d9e96[_0xb4154(0xa7)])['toBe'](0x1),expect(_0x2d9e96[0x0]['required'][_0xb4154(0xc7)]())[_0xb4154(0x95)](_0x33aa1b[_0xb4154(0xc7)]()),expect(_0x2d9e96[0x0][_0xb4154(0xc3)])[_0xb4154(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4") {
          profilePicture(size: 100) {
            ${_0x2f2969}
          }
        }
      }
    `)),expect(_0x2d9e96[0x0][_0xb4154(0xc3)]['isDeferred']())[_0xb4154(0x95)](!![]),expect(_0x2d9e96[0x0][_0xb4154(0xac)])['toEqual']([]);}),it(_0x4704e1(0xa8),()=>{const _0x5f240f=_0x4704e1,_0x3b912e=RelayClassic['QL']`fragment on Node{name}`,_0x2e2ef2=RelayClassic['QL']`
      query {
        node(id:"4") {
              ${_0x2e0c51(_0x3b912e)}
            }
      }
    `,_0x4b5a41=_0x71a3ff(_0x2e2ef2),{required:_0xad53ac,deferred:_0x165108}=splitDeferredRelayQueries(_0x4b5a41);expect(_0xad53ac)[_0x5f240f(0x95)](null),expect(_0x165108[_0x5f240f(0xa7)])[_0x5f240f(0x95)](0x1),expect(_0x165108[0x0][_0x5f240f(0xc3)]['getName']())['toBe'](_0x4b5a41[_0x5f240f(0xc7)]()),expect(_0x165108[0x0]['required'])[_0x5f240f(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
          node(id:"4") {
            ${_0x3b912e}
        }
      }
    `)),expect(_0x165108[0x0][_0x5f240f(0xc3)]['isDeferred']())[_0x5f240f(0x95)](!![]),expect(_0x165108[0x0][_0x5f240f(0xac)])['toEqual']([]);}),it(_0x4704e1(0x90),()=>{const _0x549eb9=_0x4704e1,_0x2c6374=RelayClassic['QL']`fragment on Node{name}`,_0x2804fe=RelayQuery[_0x549eb9(0xbd)][_0x549eb9(0x9f)]({'fieldName':'id','metadata':{'isRequisite':!![]},'type':_0x549eb9(0x9c)}),_0x3f2e63=RelayQuery[_0x549eb9(0xbd)]['build']({'fieldName':_0x549eb9(0x94),'metadata':{'isRequisite':!![]},'type':_0x549eb9(0x9c)});let _0x1a1b46=RelayQuery[_0x549eb9(0x84)][_0x549eb9(0x9f)](_0x549eb9(0xad),_0x549eb9(0xbf),'4',[_0x2804fe,_0x3f2e63,RelayQuery['Field'][_0x549eb9(0x9f)]({'fieldName':_0x549eb9(0xba),'children':[_0x2804fe,_0x71a3ff(_0x2e0c51(_0x2c6374))],'metadata':{'canHaveSubselections':!![],'isGenerated':!![],'inferredPrimaryKey':'id','inferredRootCallName':_0x549eb9(0xbf)},'type':_0x549eb9(0x9a)})],{'identifyingArgName':'id'});_0x1a1b46=_0x1a1b46[_0x549eb9(0x85)](_0x1a1b46[_0x549eb9(0xa1)]()['map']((_0x34ea69,_0x19d540)=>{const _0x295545=_0x549eb9;return _0x19d540===0x1?_0x34ea69[_0x295545(0x85)](_0x34ea69[_0x295545(0xa1)]()['map']((_0x22e364,_0x20154c)=>{const _0x2725eb=_0x295545;return _0x20154c===0x0?_0x22e364[_0x2725eb(0x7f)]():_0x22e364;})):_0x34ea69;}));const {required:_0x25348a,deferred:_0x38ac99}=splitDeferredRelayQueries(_0x1a1b46);expect(_0x38ac99[0x0][_0x549eb9(0xc3)]['getName']())[_0x549eb9(0x95)](_0x1a1b46[_0x549eb9(0xc7)]()),expect(_0x25348a)[_0x549eb9(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4"){hometown{id},id}
      }
    `)),expect(_0x25348a['getID']())['toBe']('q1'),expect(_0x38ac99[_0x549eb9(0xa7)])[_0x549eb9(0x95)](0x1),expect(_0x38ac99[0x0][_0x549eb9(0xc3)][_0x549eb9(0xc7)]())['toBe'](_0x1a1b46[_0x549eb9(0xc7)]()),expect(_0x38ac99[0x0]['required'])[_0x549eb9(0xa4)](_0x330c8a(_0x1f069a(RelayClassic['QL']`
          query {
            nodes(ids:$ref_q1) {
              ${_0x2c6374}
            }
          }
        `,{'path':'$.*.hometown.id'}))),expect(_0x38ac99[0x0][_0x549eb9(0xc3)][_0x549eb9(0xb7)]())[_0x549eb9(0x95)]('q2'),expect(_0x38ac99[0x0][_0x549eb9(0xc3)][_0x549eb9(0xb1)]())[_0x549eb9(0x95)](!![]),expect(_0x38ac99[0x0][_0x549eb9(0xac)])['toEqual']([]);}),it('preserves\x20required\x20queries\x20with\x20only\x20a\x20non-generated\x20`id`\x20field',()=>{const _0x3c1839=_0x4704e1,_0x437343=RelayClassic['QL']`fragment on Node{name}`,_0x5860a8=RelayClassic['QL']`
      query {
        node(id:"4") {
              id
              ${_0x2e0c51(_0x437343)}
            }
      }
    `,_0xd0a522=_0x71a3ff(_0x5860a8),{required:_0xc2ae66,deferred:_0x37ff33}=splitDeferredRelayQueries(_0xd0a522);expect(_0x37ff33[0x0][_0x3c1839(0xc3)]['getName']())['toBe'](_0xd0a522[_0x3c1839(0xc7)]()),expect(_0xc2ae66)[_0x3c1839(0xa4)](_0x71a3ff(RelayClassic['QL']`query{node(id:"4"){id}}`)),expect(_0x37ff33[_0x3c1839(0xa7)])[_0x3c1839(0x95)](0x1),expect(_0x37ff33[0x0][_0x3c1839(0xc3)]['getName']())[_0x3c1839(0x95)](_0xd0a522[_0x3c1839(0xc7)]()),expect(_0x37ff33[0x0]['required'])[_0x3c1839(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4") {
          ${_0x437343}
        }
      }
    `)),expect(_0x37ff33[0x0][_0x3c1839(0xc3)]['isDeferred']())[_0x3c1839(0x95)](!![]),expect(_0x37ff33[0x0][_0x3c1839(0xac)])[_0x3c1839(0xaf)]([]);}),it('does\x20not\x20split\x20empty\x20fragments',()=>{const _0x2f6d4a=_0x4704e1,_0x1be683=RelayClassic['QL']`fragment on Viewer{${null}}`,_0x4315e8=RelayClassic['QL']`fragment on Viewer{${_0x1be683}}`,_0x1b0dc1=RelayClassic['QL']`
      query {
        viewer {
              primaryEmail
              ${_0x2e0c51(_0x4315e8)}
            }
      }
    `,_0xf58898=_0x71a3ff(_0x1b0dc1),{required:_0xda8a58,deferred:_0x4c3191}=splitDeferredRelayQueries(_0xf58898);expect(_0xda8a58['getName']())[_0x2f6d4a(0x95)](_0xf58898[_0x2f6d4a(0xc7)]()),expect(_0xda8a58)[_0x2f6d4a(0xa4)](_0x71a3ff(RelayClassic['QL']`
      query {
        viewer{primaryEmail}
      }
    `)),expect(_0x4c3191[_0x2f6d4a(0xa7)])[_0x2f6d4a(0x95)](0x0);}),it(_0x4704e1(0xa5),()=>{const _0xa29940=_0x4704e1,_0x316fad=RelayClassic['QL']`fragment on Node{name}`,_0x12e337=_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"4") {
          ${_0x2e0c51(_0x316fad)}
        }
      }
    `),{deferred:_0x516e0e}=splitDeferredRelayQueries(_0x12e337);expect(_0x516e0e['length'])['toBe'](0x1),expect(_0x516e0e[0x0][_0xa29940(0xc3)])[_0xa29940(0xb3)](_0x71a3ff(_0x316fad));}),it('does\x20not\x20flatten\x20fragments\x20when\x20splitting\x20ref\x20queries',()=>{const _0x3fbbed=_0x4704e1,_0x322f52=RelayClassic['QL']`fragment on Feedback{likers{count}}`,_0x51fcbb=_0x71a3ff(RelayClassic['QL']`
      query {
        node(id:"STORY_ID") {
          feedback {
            ${_0x2e0c51(_0x322f52)}
          }
        }
      }
    `),{deferred:_0x3a87c4}=splitDeferredRelayQueries(_0x51fcbb);expect(_0x3a87c4[_0x3fbbed(0xa7)])[_0x3fbbed(0x95)](0x1),expect(_0x3a87c4[0x0][_0x3fbbed(0xc3)])[_0x3fbbed(0xb3)](_0x71a3ff(_0x322f52));});});