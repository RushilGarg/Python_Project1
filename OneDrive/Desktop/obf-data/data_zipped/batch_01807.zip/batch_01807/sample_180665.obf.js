/**
 * @fileOverview Requirejs module containing the antie.widgets.HorizontalList class.
 *
 * @preserve Copyright (c) 2013 British Broadcasting Corporation
 * (http://www.bbc.co.uk) and TAL Contributors (1)
 *
 * (1) TAL Contributors are listed in the AUTHORS file and at
 *     https://github.com/fmtvp/TAL/AUTHORS - please extend this file,
 *     not this notice.
 *
 * @license Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * 
 * All rights reserved
 * Please contact us for an alternative licence
 */
function a0_0x75af(){var _0x58cdd2=['setActiveChildWidget','WRAP_MODE_NONE','def','7003404WtwrXu','12LaUaMn','_childWidgetOrder','98FnoIYe','antie/widgets/list','31255190pDsqCT','WRAP_MODE_WRAP','_super','428360yxHgIJ','antie/events/keyevent','772546dzcVFL','8444007OfcdAp','addClass','stopPropagation','_wrapMode','_maskElement','5357160xErQXq','addEventListener','length','keyCode','VK_LEFT','1567656tizMYT','VK_RIGHT','4TEUjZB'];a0_0x75af=function(){return _0x58cdd2;};return a0_0x75af();}var a0_0x48927f=a0_0x5d59;function a0_0x5d59(_0x2d8b1a,_0x498e9d){var _0x75afae=a0_0x75af();return a0_0x5d59=function(_0x5d595b,_0x3b1e5){_0x5d595b=_0x5d595b-0xfb;var _0x325baa=_0x75afae[_0x5d595b];return _0x325baa;},a0_0x5d59(_0x2d8b1a,_0x498e9d);}(function(_0x4d58ee,_0x427f4c){var _0x574cbd=a0_0x5d59,_0x4d2c1c=_0x4d58ee();while(!![]){try{var _0x43ed1=-parseInt(_0x574cbd(0x105))/0x1*(parseInt(_0x574cbd(0x112))/0x2)+parseInt(_0x574cbd(0x110))/0x3*(parseInt(_0x574cbd(0xfc))/0x4)+parseInt(_0x574cbd(0x10b))/0x5+parseInt(_0x574cbd(0xfb))/0x6+-parseInt(_0x574cbd(0xfe))/0x7*(-parseInt(_0x574cbd(0x103))/0x8)+parseInt(_0x574cbd(0x106))/0x9+-parseInt(_0x574cbd(0x100))/0xa;if(_0x43ed1===_0x427f4c)break;else _0x4d2c1c['push'](_0x4d2c1c['shift']());}catch(_0x8ff49f){_0x4d2c1c['push'](_0x4d2c1c['shift']());}}}(a0_0x75af,0xc910c),require[a0_0x48927f(0x115)]('antie/widgets/horizontallist',[a0_0x48927f(0xff),a0_0x48927f(0x104)],function(_0xaa3d0e,_0x3c6b7b){'use strict';var _0x5313b6=a0_0x48927f;var _0x21a87b=_0xaa3d0e['extend']({'init':function(_0x30ebc0,_0x5bff8d,_0x543b81){var _0x3f4962=a0_0x5d59;this[_0x3f4962(0x10a)]=null,this[_0x3f4962(0x102)](_0x30ebc0,_0x5bff8d,_0x543b81),this[_0x3f4962(0x107)]('horizontallist');var _0x44254f=this;this[_0x3f4962(0x10c)]('keydown',function(_0x119fd0){_0x44254f['_onKeyDown'](_0x119fd0);});},'setWrapMode':function(_0x34c5c2){var _0xc95bda=a0_0x5d59;this[_0xc95bda(0x109)]=_0x34c5c2;},'_onKeyDown':function(_0x51f2c1){var _0x5e3da2=a0_0x5d59;if(_0x51f2c1[_0x5e3da2(0x10e)]!=_0x3c6b7b[_0x5e3da2(0x10f)]&&_0x51f2c1[_0x5e3da2(0x10e)]!=_0x3c6b7b[_0x5e3da2(0x111)])return;var _0x1fd9b9=this['_selectedIndex'],_0x512a23=null;do{if(_0x51f2c1[_0x5e3da2(0x10e)]==_0x3c6b7b[_0x5e3da2(0x10f)])_0x1fd9b9--;else _0x51f2c1[_0x5e3da2(0x10e)]==_0x3c6b7b[_0x5e3da2(0x111)]&&_0x1fd9b9++;if(this[_0x5e3da2(0x109)]==_0x21a87b[_0x5e3da2(0x101)])_0x1fd9b9=(_0x1fd9b9+this[_0x5e3da2(0xfd)][_0x5e3da2(0x10d)])%this['_childWidgetOrder'][_0x5e3da2(0x10d)];else{if(_0x1fd9b9<0x0||_0x1fd9b9>=this[_0x5e3da2(0xfd)]['length'])break;}var _0x56de07=this['_childWidgetOrder'][_0x1fd9b9];if(_0x56de07['isFocusable']()){_0x512a23=_0x56de07;break;}}while(!![]);return _0x512a23&&(this[_0x5e3da2(0x113)](_0x512a23),_0x51f2c1[_0x5e3da2(0x108)]()),_0x512a23!=null;}});return _0x21a87b[_0x5313b6(0x114)]=0x0,_0x21a87b[_0x5313b6(0x101)]=0x1,_0x21a87b;}));