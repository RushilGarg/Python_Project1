/**
 * @license Highstock JS v8.0.3 (2020-03-06)
 * @module highcharts/indicators/wma
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2019 Kacper Madej
 *
 * License: www.highcharts.com/license
 */
'use strict';(function(_0x35eb49,_0x143fa1){var _0x410e96=a0_0x1df2,_0x207a61=_0x35eb49();while(!![]){try{var _0x353827=parseInt(_0x410e96(0x164))/0x1*(-parseInt(_0x410e96(0x16b))/0x2)+-parseInt(_0x410e96(0x16a))/0x3+parseInt(_0x410e96(0x166))/0x4*(-parseInt(_0x410e96(0x169))/0x5)+-parseInt(_0x410e96(0x16c))/0x6+parseInt(_0x410e96(0x165))/0x7+parseInt(_0x410e96(0x167))/0x8+parseInt(_0x410e96(0x168))/0x9;if(_0x353827===_0x143fa1)break;else _0x207a61['push'](_0x207a61['shift']());}catch(_0x23f208){_0x207a61['push'](_0x207a61['shift']());}}}(a0_0x5d70,0x29e21));function a0_0x5d70(){var _0x530ff1=['389578yPTAUN','4heRXsz','2652424dlLLFo','6050034hkYgxS','1030550XpThrt','942372tCdxvA','874LylzWI','315414FpRvLr','721JHkcIu'];a0_0x5d70=function(){return _0x530ff1;};return a0_0x5d70();}function a0_0x1df2(_0x199df6,_0x4649ab){var _0x5d70d9=a0_0x5d70();return a0_0x1df2=function(_0x1df271,_0x383c62){_0x1df271=_0x1df271-0x164;var _0x36ba23=_0x5d70d9[_0x1df271];return _0x36ba23;},a0_0x1df2(_0x199df6,_0x4649ab);}import'../../indicators/wma.src.js';