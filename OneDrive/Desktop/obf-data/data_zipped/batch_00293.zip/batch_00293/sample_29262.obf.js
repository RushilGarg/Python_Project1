/**
 * @copyright 2020, John Molakvoæ <skjnldsv@protonmail.com>
 *
 * @author John Molakvoæ <skjnldsv@protonmail.com>
 *
 * @license GNU AGPL version 3 or any later version
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Affero General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Affero General Public License for more details.
 *
 * You should have received a copy of the GNU Affero General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
const a0_0x1eb874=a0_0x232e;(function(_0xc4c805,_0x1abb18){const _0x422b3e=a0_0x232e,_0xd95c0e=_0xc4c805();while(!![]){try{const _0x1a9ced=parseInt(_0x422b3e(0x126))/0x1+-parseInt(_0x422b3e(0x12c))/0x2*(-parseInt(_0x422b3e(0x115))/0x3)+parseInt(_0x422b3e(0x12e))/0x4+parseInt(_0x422b3e(0x125))/0x5*(parseInt(_0x422b3e(0x11e))/0x6)+-parseInt(_0x422b3e(0x116))/0x7*(parseInt(_0x422b3e(0x12a))/0x8)+parseInt(_0x422b3e(0x121))/0x9+parseInt(_0x422b3e(0x11a))/0xa*(-parseInt(_0x422b3e(0x118))/0xb);if(_0x1a9ced===_0x1abb18)break;else _0xd95c0e['push'](_0xd95c0e['shift']());}catch(_0x45bcb2){_0xd95c0e['push'](_0xd95c0e['shift']());}}}(a0_0x5d8f,0x22ff3));import{generateOcsUrl}from'@nextcloud/router';import{loadState}from'@nextcloud/initial-state';import a0_0x3b6b56 from'@nextcloud/axios';export const defaultLimit=loadState(a0_0x1eb874(0x122),a0_0x1eb874(0x12b));export const minSearchLength=0x2;export const regexFilterIn=/[^-]in:([a-z_-]+)/ig;export const regexFilterNot=/-in:([a-z_-]+)/ig;const createCancelToken=()=>a0_0x3b6b56[a0_0x1eb874(0x12d)][a0_0x1eb874(0x11c)]();export async function getTypes(){const _0x25c730=a0_0x1eb874;try{const {data:_0x27bc59}=await a0_0x3b6b56[_0x25c730(0x114)](generateOcsUrl(_0x25c730(0x119),0x2)+'providers',{'params':{'from':window[_0x25c730(0x11d)][_0x25c730(0x124)][_0x25c730(0x117)](_0x25c730(0x129),'')+window[_0x25c730(0x11d)][_0x25c730(0x119)]}});if(_0x25c730(0x128)in _0x27bc59&&'data'in _0x27bc59['ocs']&&Array[_0x25c730(0x11b)](_0x27bc59[_0x25c730(0x128)]['data'])&&_0x27bc59[_0x25c730(0x128)][_0x25c730(0x11f)]['length']>0x0)return _0x27bc59[_0x25c730(0x128)][_0x25c730(0x11f)];}catch(_0x42ceab){console['error'](_0x42ceab);}return[];}function a0_0x232e(_0x7630df,_0x291d28){const _0x5d8fb2=a0_0x5d8f();return a0_0x232e=function(_0x232e0e,_0x185405){_0x232e0e=_0x232e0e-0x113;let _0x1cd587=_0x5d8fb2[_0x232e0e];return _0x1cd587;},a0_0x232e(_0x7630df,_0x291d28);}export function search({type:_0x2f48dc,query:_0x897779,cursor:_0x1b4ba1}){const _0x4a9da7=a0_0x1eb874,_0x2c4393=createCancelToken(),_0x118778=async()=>a0_0x3b6b56[_0x4a9da7(0x114)](generateOcsUrl(_0x4a9da7(0x119),0x2)+(_0x4a9da7(0x120)+_0x2f48dc+_0x4a9da7(0x113)),{'cancelToken':_0x2c4393[_0x4a9da7(0x127)],'params':{'term':_0x897779,'cursor':_0x1b4ba1,'from':window['location'][_0x4a9da7(0x124)][_0x4a9da7(0x117)]('/index.php','')+window['location'][_0x4a9da7(0x119)]}});return{'request':_0x118778,'cancel':_0x2c4393[_0x4a9da7(0x123)]};}function a0_0x5d8f(){const _0x3fbe53=['token','ocs','/index.php','8abLAhe','limit-default','50650nWQnUx','CancelToken','1128960nijWwA','/search','get','33jhjsXJ','858046dUUMba','replace','43340OmZtiG','search','2110VLEdUI','isArray','source','location','36354lcWXBa','data','providers/','1606806AisIIM','unified-search','cancel','pathname','65vdEMyC','279149PkzqTj'];a0_0x5d8f=function(){return _0x3fbe53;};return a0_0x5d8f();}