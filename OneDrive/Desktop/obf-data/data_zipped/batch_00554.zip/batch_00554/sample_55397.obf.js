/**
 * @license
 * Copyright 2017 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';const a0_0xc69ec6=a0_0x1bab;(function(_0x18f66b,_0x14b6d8){const _0x6cfd5f=a0_0x1bab,_0x58f047=_0x18f66b();while(!![]){try{const _0x530796=parseInt(_0x6cfd5f(0xf7))/0x1+-parseInt(_0x6cfd5f(0xfc))/0x2*(-parseInt(_0x6cfd5f(0x100))/0x3)+parseInt(_0x6cfd5f(0xf9))/0x4+parseInt(_0x6cfd5f(0xf5))/0x5*(parseInt(_0x6cfd5f(0x103))/0x6)+-parseInt(_0x6cfd5f(0xfd))/0x7*(parseInt(_0x6cfd5f(0x104))/0x8)+-parseInt(_0x6cfd5f(0x101))/0x9+parseInt(_0x6cfd5f(0xf8))/0xa;if(_0x530796===_0x14b6d8)break;else _0x58f047['push'](_0x58f047['shift']());}catch(_0x2bdb2c){_0x58f047['push'](_0x58f047['shift']());}}}(a0_0x31a0,0x8ad86));function a0_0x31a0(){const _0x445329=['1524uYJynd','56fnHoOW','prefer\x20a\x20language\x20other\x20than\x20the\x20default.','16165clwIXg','`<html>`\x20element\x20has\x20a\x20`[lang]`\x20attribute.','718670hrBIId','4974230uxzboe','208224YpTHcq','exports','meta','174626oeNJkc','1015679FWEETI','html-has-lang','The\x20`lang`\x20attribute\x20is\x20useful\x20for\x20multilingual\x20screen\x20reader\x20users\x20who\x20may\x20','6sZqrgw','6116112rAmBXo','Accessibility'];a0_0x31a0=function(){return _0x445329;};return a0_0x31a0();}const AxeAudit=require('./axe-audit');class HTMLHasLang extends AxeAudit{static get[a0_0xc69ec6(0xfb)](){const _0x372b63=a0_0xc69ec6;return{'category':_0x372b63(0x102),'name':_0x372b63(0xfe),'description':_0x372b63(0xf6),'helpText':_0x372b63(0xff)+_0x372b63(0x105),'requiredArtifacts':[_0x372b63(0x102)]};}}function a0_0x1bab(_0x50ad88,_0x92d0b3){const _0x31a097=a0_0x31a0();return a0_0x1bab=function(_0x1bab2b,_0x259802){_0x1bab2b=_0x1bab2b-0xf5;let _0x54e676=_0x31a097[_0x1bab2b];return _0x54e676;},a0_0x1bab(_0x50ad88,_0x92d0b3);}module[a0_0xc69ec6(0xfa)]=HTMLHasLang;