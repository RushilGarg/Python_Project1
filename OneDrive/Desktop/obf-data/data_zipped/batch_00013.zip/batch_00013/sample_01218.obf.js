function a0_0x2757(){const _0x3db740=['map','settings','HTML','entries','604194ADofbB','822035rRgsdm','1250816HHWQhC','3943216wavoLg','827610vvoZGG','compact\x20','144vtHmST','Minified\x20AMP\x20JavaScript\x20is\x20served\x20from\x20the\x20AMP\x20Project\x20CDN.','.documentModes[','2283YnvARn','select-html-mode-','mode','exports','\x20selected','minified','jsMode','default','./html','./document-modes','462720EwcOKg','serve-mode-','htmlEnvelopePrefix'];a0_0x2757=function(){return _0x3db740;};return a0_0x2757();}const a0_0x21e06d=a0_0x2b43;(function(_0x1bb4be,_0xd86726){const _0xad012e=a0_0x2b43,_0x44f9df=_0x1bb4be();while(!![]){try{const _0x5806e0=-parseInt(_0xad012e(0x131))/0x1*(-parseInt(_0xad012e(0x12e))/0x2)+parseInt(_0xad012e(0x128))/0x3+parseInt(_0xad012e(0x13b))/0x4+parseInt(_0xad012e(0x129))/0x5+parseInt(_0xad012e(0x12c))/0x6+-parseInt(_0xad012e(0x12a))/0x7+-parseInt(_0xad012e(0x12b))/0x8;if(_0x5806e0===_0xd86726)break;else _0x44f9df['push'](_0x44f9df['shift']());}catch(_0x2d4951){_0x44f9df['push'](_0x44f9df['shift']());}}}(a0_0x2757,0x1b64e));function a0_0x2b43(_0xcc79d2,_0xa4453d){const _0x275729=a0_0x2757();return a0_0x2b43=function(_0x2b4321,_0xbb2062){_0x2b4321=_0x2b4321-0x125;let _0x35d838=_0x275729[_0x2b4321];return _0x35d838;},a0_0x2b43(_0xcc79d2,_0xa4453d);}const documentModes=require(a0_0x21e06d(0x13a)),{AmpState,ampStateKey}=require('./amphtml-helpers'),{html,joinFragments}=require(a0_0x21e06d(0x139)),jsModes=[{'value':a0_0x21e06d(0x138),'description':'Unminified\x20AMP\x20JavaScript\x20is\x20served\x20from\x20the\x20local\x20server.\x20For\x0a\x20\x20\x20\x20local\x20development\x20you\x20will\x20usually\x20want\x20to\x20serve\x20unminified\x20JS\x20to\x20test\x20your\x0a\x20\x20\x20\x20changes.'},{'value':a0_0x21e06d(0x136),'description':html`
      Minified AMP JavaScript is served from the local server. This is only
      available after running <code>amp dist --fortesting</code>
    `},{'value':'cdn','description':a0_0x21e06d(0x12f)}],stateId=a0_0x21e06d(0x125),htmlEnvelopePrefixStateKey=a0_0x21e06d(0x13d),jsModeStateKey=a0_0x21e06d(0x137),panelStateKey='panel',htmlEnvelopePrefixKey=ampStateKey(stateId,htmlEnvelopePrefixStateKey),panelKey=ampStateKey(stateId,panelStateKey),PanelSelectorButton=({expression:_0xb1d943,type:_0x2e9401,value:_0x487bad})=>html`
    <button
      class="settings-panel-button"
      [class]="'settings-panel-button' + (${panelKey} != '${_0x2e9401}' ? '' : ' open')"
      data-type="${_0x2e9401}"
      tabindex="0"
      on="tap: AMP.setState({
        ${stateId}: {
          ${panelStateKey}: (${panelKey} != '${_0x2e9401}' ? '${_0x2e9401}' : null),
        }
      })"
    >
      <span>${_0x2e9401}</span> <strong [text]="${_0xb1d943}">${_0x487bad}</strong>
    </button>
  `,PanelSelector=({children:_0x4b5873,compact:compact=![],key:_0x2d92af,name:name=null})=>html`
  <amp-selector
    layout="container"
    name="${name||_0x2d92af}"
    class="${compact?a0_0x21e06d(0x12d):''}"
    on="select: AMP.setState({
      ${stateId}: {
        ${panelStateKey}: null,
        ${_0x2d92af}: event.targetOption,
      }
    })"
  >
    ${joinFragments(_0x4b5873)}
  </amp-selector>
`,PanelSelectorBlock=({children:_0x13eccd,id:_0x492757,selected:_0x3cffbc,value:_0x2cac69})=>html`
  <div
    class="selector-block"
    ${_0x3cffbc?a0_0x21e06d(0x135):''}
    id="${_0x492757}"
    option="${_0x2cac69}"
  >
    <div class="check-icon icon"></div>
    ${_0x13eccd}
  </div>
`,HtmlEnvelopeSelector=({htmlEnvelopePrefix:_0x2ee034})=>PanelSelector({'compact':!![],'key':htmlEnvelopePrefixStateKey,'children':Object[a0_0x21e06d(0x127)](documentModes)['map'](([_0xa08b51,_0x33d395])=>PanelSelectorBlock({'id':a0_0x21e06d(0x132)+_0x33d395,'value':_0xa08b51,'selected':_0x2ee034===_0xa08b51,'children':html`<strong>${_0x33d395}</strong>`}))}),JsModeSelector=({jsMode:_0x269f1f})=>PanelSelector({'key':jsModeStateKey,'name':a0_0x21e06d(0x133),'children':jsModes[a0_0x21e06d(0x13e)](({description:_0x57ab0e,value:_0x883888})=>PanelSelectorBlock({'id':a0_0x21e06d(0x13c)+_0x883888,'value':_0x883888,'selected':_0x269f1f===_0x883888,'children':html`
          <strong>${_0x883888}</strong>
          <p>${_0x57ab0e}</p>
        `}))}),SettingsPanelButtons=({htmlEnvelopePrefix:_0x373870,jsMode:_0x2a8803})=>html`
  <div style="flex: 1">
    <div class="settings-panel-button-container">
      ${PanelSelectorButton({'type':a0_0x21e06d(0x126),'expression':stateId+a0_0x21e06d(0x130)+htmlEnvelopePrefixKey+']','value':documentModes[_0x373870]})}
      ${PanelSelectorButton({'type':'JS','expression':stateId+'.'+jsModeStateKey,'value':_0x2a8803})}
    </div>
    ${SettingsPanel({'htmlEnvelopePrefix':_0x373870,'jsMode':_0x2a8803})}
  </div>
`,SettingsSubpanel=({children:_0xff7bea,type:_0x123c22})=>html`
  <div hidden [hidden]="${panelKey} != '${_0x123c22}'">${_0xff7bea}</div>
`,SettingsPanel=({htmlEnvelopePrefix:_0x1a0f14,jsMode:_0x47aec3})=>html`
  <div class="settings-panel" hidden [hidden]="${panelKey} == null">
    ${AmpState(stateId,{'documentModes':documentModes,[panelStateKey]:null,[htmlEnvelopePrefixStateKey]:_0x1a0f14,[jsModeStateKey]:_0x47aec3})}
    ${SettingsSubpanel({'type':a0_0x21e06d(0x126),'children':html`
        <h4>Select an envelope to serve HTML documents.</h4>
        ${HtmlEnvelopeSelector({'htmlEnvelopePrefix':_0x1a0f14})}
      `})}
    ${SettingsSubpanel({'type':'JS','children':html`
        <h4>Select the JavaScript binaries to use in served documents.</h4>
        <form
          action="/serve_mode_change"
          action-xhr="/serve_mode_change"
          target="_blank"
          id="serve-mode-form"
        >
          ${JsModeSelector({'jsMode':_0x47aec3})}
        </form>
      `})}
  </div>
`;module[a0_0x21e06d(0x134)]={'SettingsPanel':SettingsPanel,'SettingsPanelButtons':SettingsPanelButtons,'htmlEnvelopePrefixKey':htmlEnvelopePrefixKey};