/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x55535b=a0_0x5087;function a0_0x5087(_0x8f87c4,_0x41d174){var _0x3fde20=a0_0x3fde();return a0_0x5087=function(_0x508764,_0x1881dd){_0x508764=_0x508764-0x12c;var _0x10b594=_0x3fde20[_0x508764];return _0x10b594;},a0_0x5087(_0x8f87c4,_0x41d174);}(function(_0x536863,_0x4100c0){var _0x2107c0=a0_0x5087,_0xc564af=_0x536863();while(!![]){try{var _0x321a49=-parseInt(_0x2107c0(0x139))/0x1*(-parseInt(_0x2107c0(0x143))/0x2)+-parseInt(_0x2107c0(0x132))/0x3*(-parseInt(_0x2107c0(0x134))/0x4)+parseInt(_0x2107c0(0x131))/0x5+parseInt(_0x2107c0(0x12f))/0x6*(-parseInt(_0x2107c0(0x136))/0x7)+-parseInt(_0x2107c0(0x13c))/0x8*(-parseInt(_0x2107c0(0x147))/0x9)+-parseInt(_0x2107c0(0x137))/0xa*(parseInt(_0x2107c0(0x142))/0xb)+parseInt(_0x2107c0(0x13e))/0xc;if(_0x321a49===_0x4100c0)break;else _0xc564af['push'](_0xc564af['shift']());}catch(_0x55410b){_0xc564af['push'](_0xc564af['shift']());}}}(a0_0x3fde,0xc39eb),CLASS({'package':a0_0x55535b(0x140),'name':a0_0x55535b(0x144),'requires':[a0_0x55535b(0x13f),a0_0x55535b(0x130),a0_0x55535b(0x141)],'properties':[{'name':a0_0x55535b(0x13b),'type':a0_0x55535b(0x146),'enum':a0_0x55535b(0x13f),'postSet':function(_0x37409b,_0x6f22d0){var _0x489982=a0_0x55535b;console[_0x489982(0x12d)](_0x489982(0x133),_0x6f22d0);},'javaPostSet':a0_0x55535b(0x12c)}],'methods':[{'name':a0_0x55535b(0x135),'labels':[a0_0x55535b(0x12e)],'javaCode':a0_0x55535b(0x13d)},{'name':a0_0x55535b(0x138),'labels':[a0_0x55535b(0x13a)],'code':function toE(_0x32549a){var _0x50560f=a0_0x55535b;return this[_0x50560f(0x148)][_0x50560f(0x145)]({'data':this},_0x32549a);}}]}));function a0_0x3fde(){var _0x4b7d65=['foam.demos','foam.u2.DetailView','825GtnZyL','54ElrkBT','EnumDemo','create','Enum','1338174kGiwAG','DetailView','System.out.println(\x22Enum\x20set\x20to\x20\x22\x20+\x20newValue);','log','java','4782rMjGtT','foam.u2.EnumView','1770010jlhnkb','33iGhNAY','enum\x20set\x20to','266748qLSOIQ','main','4963UvimAK','170670RxJBAT','toE','18215zDdeZr','javascript','enumProperty','16tsuIuh','this.setEnumProperty(SomeEnum.FOO);','9235452lsMDnG','foam.demos.SomeEnum'];a0_0x3fde=function(){return _0x4b7d65;};return a0_0x3fde();}