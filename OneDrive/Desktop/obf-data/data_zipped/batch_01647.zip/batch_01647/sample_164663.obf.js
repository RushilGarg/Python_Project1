/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x3ef0b4=a0_0x4f46;function a0_0x42d8(){var _0x4834fe=['124OkoXHD','Specifying\x20the\x20preferred\x20height\x20of\x20this\x20view\x20for\x20the\x20ScrollView,\x20since\x20an\x20empty\x20row\x20is\x20too\x20small.','220664qJKsoV','email-citation','40730QTTDxN','1259018UlvQCM','foam.ui.DetailView','com.google.mail','1053SvenAZ','1412210LSDuwU','10748244rCmVLq','1278104pGbOey','controller','foam.ui.RelativeDateTimeFieldView','preferredHeight','6MXXGQT','11SmhGsB','14sGjRMD','21666LttnIw','foam.ui.md.MonogramStringView','EMailCitationView2'];a0_0x42d8=function(){return _0x4834fe;};return a0_0x42d8();}function a0_0x4f46(_0x5175c3,_0x179280){var _0x42d850=a0_0x42d8();return a0_0x4f46=function(_0x4f464d,_0x59731e){_0x4f464d=_0x4f464d-0x1ca;var _0x4e44ea=_0x42d850[_0x4f464d];return _0x4e44ea;},a0_0x4f46(_0x5175c3,_0x179280);}(function(_0xd3256f,_0x20376a){var _0x21c94b=a0_0x4f46,_0x3add4b=_0xd3256f();while(!![]){try{var _0x11a0d4=-parseInt(_0x21c94b(0x1de))/0x1+-parseInt(_0x21c94b(0x1cc))/0x2+-parseInt(_0x21c94b(0x1d9))/0x3*(-parseInt(_0x21c94b(0x1dc))/0x4)+parseInt(_0x21c94b(0x1d0))/0x5*(parseInt(_0x21c94b(0x1d6))/0x6)+-parseInt(_0x21c94b(0x1d8))/0x7*(-parseInt(_0x21c94b(0x1d2))/0x8)+-parseInt(_0x21c94b(0x1cf))/0x9*(parseInt(_0x21c94b(0x1cb))/0xa)+parseInt(_0x21c94b(0x1d7))/0xb*(parseInt(_0x21c94b(0x1d1))/0xc);if(_0x11a0d4===_0x20376a)break;else _0x3add4b['push'](_0x3add4b['shift']());}catch(_0x575eb3){_0x3add4b['push'](_0x3add4b['shift']());}}}(a0_0x42d8,0x60647),CLASS({'name':a0_0x3ef0b4(0x1db),'package':a0_0x3ef0b4(0x1ce),'extends':a0_0x3ef0b4(0x1cd),'requires':[a0_0x3ef0b4(0x1da),a0_0x3ef0b4(0x1d4),'foam.ui.ImageBooleanView'],'imports':[a0_0x3ef0b4(0x1d3)],'properties':[{'name':'className','defaultValue':a0_0x3ef0b4(0x1ca)},{'name':a0_0x3ef0b4(0x1d5),'help':a0_0x3ef0b4(0x1dd),'defaultValue':0x52}],'templates':[function CSS(){},function toHTML(){}]}));