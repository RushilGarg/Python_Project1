#! /usr/bin/env node

/**
 * 
 * Say and Play something with help of InboundXML and TelAPI
 *
 * --------------------------------------------------------------------------------
 * 
 * @category  TelApi Helper
 * @package   TelApi
 * @author    Nevio Vesic <nevio@telapi.com>
 * @license   http://creativecommons.org/licenses/MIT/ MIT
 * @copyright (2012) TelTech Systems, Inc. <info@telapi.com>
 */
var a0_0xc8a2a5=a0_0x4d57;function a0_0x1477(){var _0x18c8c7=['inboundxml','man','toString','Example\x20usage\x20of\x20TelAPI\x20Node.JS\x20InboundXML\x20Play\x20element','100pTGTmx','35NPORBq','101928oBNDwd','418jYUWcU','6lpGIAd','\x0a\x0aInboundXML\x20Say\x20and\x20Play\x20Element:\x20\x0a\x0a','3385992cYKfpP','Play','45468oanEmB','301526oWgizM','52104YQeKUP','util','2380016OsnadV','log','1720085GcrvmZ','telapi','append','4vIbsyF','http://funny-stuff.audio4fun.com/download/sounds/87.mp3'];a0_0x1477=function(){return _0x18c8c7;};return a0_0x1477();}(function(_0x50d94f,_0x4c547f){var _0x413427=a0_0x4d57,_0xecb935=_0x50d94f();while(!![]){try{var _0x1158d1=parseInt(_0x413427(0x1d2))/0x1+-parseInt(_0x413427(0x1c3))/0x2*(parseInt(_0x413427(0x1cb))/0x3)+-parseInt(_0x413427(0x1cf))/0x4+parseInt(_0x413427(0x1c0))/0x5*(-parseInt(_0x413427(0x1cd))/0x6)+-parseInt(_0x413427(0x1ca))/0x7*(-parseInt(_0x413427(0x1d5))/0x8)+-parseInt(_0x413427(0x1d1))/0x9*(-parseInt(_0x413427(0x1c9))/0xa)+-parseInt(_0x413427(0x1cc))/0xb*(-parseInt(_0x413427(0x1d3))/0xc);if(_0x1158d1===_0x4c547f)break;else _0xecb935['push'](_0xecb935['shift']());}catch(_0x15e832){_0xecb935['push'](_0xecb935['shift']());}}}(a0_0x1477,0xb6265));var util=require(a0_0xc8a2a5(0x1d4)),InboundXML=require(a0_0xc8a2a5(0x1c1))[a0_0xc8a2a5(0x1c5)],response=new InboundXML['Response']();function a0_0x4d57(_0xfaf1ed,_0xb65bbd){var _0x1477ca=a0_0x1477();return a0_0x4d57=function(_0x4d5753,_0x43279a){_0x4d5753=_0x4d5753-0x1bf;var _0x3727af=_0x1477ca[_0x4d5753];return _0x3727af;},a0_0x4d57(_0xfaf1ed,_0xb65bbd);}response[a0_0xc8a2a5(0x1c2)](new InboundXML['Say'](a0_0xc8a2a5(0x1c8),{'voice':a0_0xc8a2a5(0x1c6)})),response['append'](new InboundXML[(a0_0xc8a2a5(0x1d0))](a0_0xc8a2a5(0x1c4))),util[a0_0xc8a2a5(0x1bf)](a0_0xc8a2a5(0x1ce)+response[a0_0xc8a2a5(0x1c7)]());