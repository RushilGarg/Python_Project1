(function(_0x56a90b,_0x483d23){var _0x297399=a0_0xcdb8,_0x21bd6c=_0x56a90b();while(!![]){try{var _0x2051fd=-parseInt(_0x297399(0xff))/0x1+parseInt(_0x297399(0xfe))/0x2+parseInt(_0x297399(0x104))/0x3*(parseInt(_0x297399(0x100))/0x4)+-parseInt(_0x297399(0x101))/0x5+parseInt(_0x297399(0x105))/0x6+-parseInt(_0x297399(0x103))/0x7+-parseInt(_0x297399(0x102))/0x8;if(_0x2051fd===_0x483d23)break;else _0x21bd6c['push'](_0x21bd6c['shift']());}catch(_0x3f35b1){_0x21bd6c['push'](_0x21bd6c['shift']());}}}(a0_0x4cd5,0x275a2));function a0_0x4cd5(){var _0x51c29d=['613711VDJOkK','51RDdbEG','1850544vWEAwX','538684UVBZMM','158244qYiipD','42404MYGWVU','1288885DYTWmx','744824lOqGLY'];a0_0x4cd5=function(){return _0x51c29d;};return a0_0x4cd5();}function a0_0xcdb8(_0xfcc669,_0x32dac0){var _0x4cd5f6=a0_0x4cd5();return a0_0xcdb8=function(_0xcdb887,_0x480a73){_0xcdb887=_0xcdb887-0xfe;var _0x5afa8e=_0x4cd5f6[_0xcdb887];return _0x5afa8e;},a0_0xcdb8(_0xfcc669,_0x32dac0);}import{css}from'lit-element';export default css`

    button {
        background-color: white;
        border: none;
        color: #a0a0a0;
        cursor: pointer;
        font-family: 'Roboto';
        text-transform: uppercase;
        width: 80px;
        height: 80px;
    }

    button:hover {
        background-color: #dcdcdc;
    }

    mwc-icon {
        display: block;
        margin-bottom: 6px;
    }
`;