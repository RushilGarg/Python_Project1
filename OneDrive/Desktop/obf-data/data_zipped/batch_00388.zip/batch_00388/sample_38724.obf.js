/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
'use strict';const a0_0x20018c=a0_0x367f;(function(_0x217331,_0x37d077){const _0x4f4d64=a0_0x367f,_0x42353d=_0x217331();while(!![]){try{const _0x29e242=-parseInt(_0x4f4d64(0x1e1))/0x1*(-parseInt(_0x4f4d64(0x4de))/0x2)+parseInt(_0x4f4d64(0xf6))/0x3*(parseInt(_0x4f4d64(0x4c1))/0x4)+parseInt(_0x4f4d64(0x277))/0x5*(-parseInt(_0x4f4d64(0x495))/0x6)+parseInt(_0x4f4d64(0x3e3))/0x7*(-parseInt(_0x4f4d64(0x391))/0x8)+parseInt(_0x4f4d64(0x30b))/0x9+parseInt(_0x4f4d64(0x141))/0xa*(parseInt(_0x4f4d64(0x440))/0xb)+-parseInt(_0x4f4d64(0x41b))/0xc;if(_0x29e242===_0x37d077)break;else _0x42353d['push'](_0x42353d['shift']());}catch(_0x1b43c2){_0x42353d['push'](_0x42353d['shift']());}}}(a0_0x8a45,0x21f1c));Object[a0_0x20018c(0x41d)](exports,a0_0x20018c(0x4f2),{'value':!![]});function _interopDefault(_0x691f2b){const _0x23a078=a0_0x20018c;return _0x691f2b&&typeof _0x691f2b==='object'&&'default'in _0x691f2b?_0x691f2b[_0x23a078(0x50e)]:_0x691f2b;}var tfjsCore=require(a0_0x20018c(0x46f)),LongExports=require(a0_0x20018c(0xf2)),LongExports__default=_interopDefault(LongExports),tfjsLayers=require('@tensorflow/tfjs-layers'),tfjsConverter=require(a0_0x20018c(0x38f)),tfjsData=require(a0_0x20018c(0x2e2)),tfjsBackendCpu=require(a0_0x20018c(0x209)),tfjsBackendWebgl=require(a0_0x20018c(0x367));const Abs=a0_0x20018c(0x1c5),Acos=a0_0x20018c(0x56b),Acosh=a0_0x20018c(0x2ba),Add=a0_0x20018c(0x468),AddN=a0_0x20018c(0x199),All=a0_0x20018c(0xe2),Any=a0_0x20018c(0x144),ArgMax='ArgMax',ArgMin=a0_0x20018c(0x4e8),Asin='Asin',Asinh=a0_0x20018c(0x2e9),Atan='Atan',Atanh='Atanh',Atan2=a0_0x20018c(0x5c1),AvgPool='AvgPool',AvgPoolGrad=a0_0x20018c(0x4aa),AvgPool3D=a0_0x20018c(0x446),AvgPool3DGrad=a0_0x20018c(0x1bd),BatchMatMul='BatchMatMul',BatchToSpaceND=a0_0x20018c(0x3b9),Bincount=a0_0x20018c(0x5d0),BroadcastTo=a0_0x20018c(0x24e),BroadcastArgs=a0_0x20018c(0x294),Cast=a0_0x20018c(0x45b),Ceil=a0_0x20018c(0x31f),ClipByValue=a0_0x20018c(0x111),Complex=a0_0x20018c(0x477),ComplexAbs=a0_0x20018c(0x577),Concat='Concat',Conv2D=a0_0x20018c(0x3bb),Conv2DBackpropFilter=a0_0x20018c(0x3fd),Conv2DBackpropInput=a0_0x20018c(0x449),Conv3D=a0_0x20018c(0x4c8),Conv3DBackpropFilterV2=a0_0x20018c(0xfe),Conv3DBackpropInputV2=a0_0x20018c(0x2e8),Cos=a0_0x20018c(0x2fe),Cosh=a0_0x20018c(0x1d4),Cumsum=a0_0x20018c(0x3d5),CropAndResize=a0_0x20018c(0x3be),DenseBincount=a0_0x20018c(0x5a5),DepthToSpace=a0_0x20018c(0x56d),DepthwiseConv2dNative=a0_0x20018c(0x152),DepthwiseConv2dNativeBackpropFilter=a0_0x20018c(0x266),DepthwiseConv2dNativeBackpropInput=a0_0x20018c(0x15f),Diag='Diag',Dilation2D='Dilation2D',Dilation2DBackpropInput=a0_0x20018c(0x3fc),Dilation2DBackpropFilter=a0_0x20018c(0x3d6),RealDiv=a0_0x20018c(0x3c6),Einsum='Einsum',Elu=a0_0x20018c(0x444),EluGrad='EluGrad',Erf='Erf',Equal=a0_0x20018c(0x58f),Exp='Exp',ExpandDims=a0_0x20018c(0x396),Expm1=a0_0x20018c(0x3bd),FFT=a0_0x20018c(0x34d),Fill=a0_0x20018c(0x497),FlipLeftRight=a0_0x20018c(0x47a),Floor='Floor',FloorDiv='FloorDiv',FusedBatchNorm=a0_0x20018c(0x352),GatherV2='GatherV2',GatherNd=a0_0x20018c(0x28e),Greater='Greater',GreaterEqual=a0_0x20018c(0x3ad),Identity='Identity',IFFT=a0_0x20018c(0x4a5),Imag=a0_0x20018c(0x14f),IsFinite='IsFinite',IsInf=a0_0x20018c(0x31e),IsNan=a0_0x20018c(0x293),LeakyRelu=a0_0x20018c(0x51a),Less='Less',LessEqual=a0_0x20018c(0x53e),LinSpace=a0_0x20018c(0x348),Log='Log',Log1p=a0_0x20018c(0x12c),LogicalAnd=a0_0x20018c(0x5d3),LogicalNot='LogicalNot',LogicalOr=a0_0x20018c(0x410),LogSoftmax=a0_0x20018c(0x2c5),LRN=a0_0x20018c(0x23d),LRNGrad='LRNGrad',Max=a0_0x20018c(0x2a9),Maximum=a0_0x20018c(0x4f6),MaxPool=a0_0x20018c(0x492),MaxPoolGrad=a0_0x20018c(0x1ea),MaxPool3D=a0_0x20018c(0x5c8),MaxPool3DGrad=a0_0x20018c(0x3d9),MaxPoolWithArgmax='MaxPoolWithArgmax',Mean=a0_0x20018c(0x38d),Min=a0_0x20018c(0x44c),Minimum=a0_0x20018c(0x172),MirrorPad=a0_0x20018c(0x2da),Mod=a0_0x20018c(0x281),Multinomial=a0_0x20018c(0x1f0),Multiply=a0_0x20018c(0x4c0),Neg=a0_0x20018c(0x286),NotEqual=a0_0x20018c(0xe9),NonMaxSuppressionV3=a0_0x20018c(0x1b7),NonMaxSuppressionV4=a0_0x20018c(0x561),NonMaxSuppressionV5=a0_0x20018c(0x4f5),OnesLike='OnesLike',OneHot=a0_0x20018c(0x3cf),Pack='Pack',PadV2=a0_0x20018c(0x3e1),Pool=a0_0x20018c(0x488),Pow=a0_0x20018c(0x566),Prelu='Prelu',Prod=a0_0x20018c(0x28c),Range='Range',Real='Real',Reciprocal=a0_0x20018c(0x42a),Relu='Relu',Reshape=a0_0x20018c(0x3eb),ResizeNearestNeighbor=a0_0x20018c(0x536),ResizeNearestNeighborGrad=a0_0x20018c(0x58c),ResizeBilinear=a0_0x20018c(0x4f8),ResizeBilinearGrad=a0_0x20018c(0x59e),Relu6=a0_0x20018c(0x13e),Reverse=a0_0x20018c(0x463),Round=a0_0x20018c(0x214),Rsqrt='Rsqrt',ScatterNd=a0_0x20018c(0x13d),Select='Select',Selu=a0_0x20018c(0x1e0),Slice='Slice',Sin=a0_0x20018c(0x3b2),Sinh=a0_0x20018c(0x52a),Sign=a0_0x20018c(0x439),Sigmoid=a0_0x20018c(0x1c7),Softplus=a0_0x20018c(0x368),Sqrt=a0_0x20018c(0x57f),Sum=a0_0x20018c(0x54e),SpaceToBatchND=a0_0x20018c(0x306),SplitV=a0_0x20018c(0x133),Softmax=a0_0x20018c(0x56c),SparseFillEmptyRows='SparseFillEmptyRows',SparseReshape=a0_0x20018c(0x5c3),SparseSegmentMean=a0_0x20018c(0x26e),SparseSegmentSum=a0_0x20018c(0x1cb),SparseToDense=a0_0x20018c(0x3ea),SquaredDifference=a0_0x20018c(0x490),Square='Square',StridedSlice=a0_0x20018c(0x234),StringNGrams=a0_0x20018c(0x148),StringSplit=a0_0x20018c(0x441),StringToHashBucketFast=a0_0x20018c(0x49f),Sub='Sub',Tan=a0_0x20018c(0x5ba),Tanh=a0_0x20018c(0x502),Tile='Tile',TopK=a0_0x20018c(0x27a),Transform=a0_0x20018c(0x158),Transpose='Transpose',Unique=a0_0x20018c(0x231),Unpack=a0_0x20018c(0x19d),UnsortedSegmentSum=a0_0x20018c(0x255),ZerosLike='ZerosLike',Step=a0_0x20018c(0x419),FromPixels=a0_0x20018c(0x27b),RotateWithOffset=a0_0x20018c(0x482),_FusedMatMul=a0_0x20018c(0xf5),FusedConv2D=a0_0x20018c(0xfa),FusedDepthwiseConv2D=a0_0x20018c(0x10a),EPSILON_FLOAT32=1e-7,EPSILON_FLOAT16=0.0001;class DataStorage{constructor(_0x2940be,_0x40028a){const _0x1ecb0e=a0_0x20018c;this[_0x1ecb0e(0x162)]=_0x2940be,this['dataMover']=_0x40028a,this[_0x1ecb0e(0x186)]=new WeakMap(),this['dataIdsCount']=0x0;}[a0_0x20018c(0x40f)](_0x4ee8c9){const _0x5c69f8=a0_0x20018c;return!this[_0x5c69f8(0x186)][_0x5c69f8(0x18a)](_0x4ee8c9)&&this[_0x5c69f8(0x116)][_0x5c69f8(0x447)](this['backend'],_0x4ee8c9),this[_0x5c69f8(0x186)][_0x5c69f8(0x40f)](_0x4ee8c9);}[a0_0x20018c(0x5a6)](_0x395985,_0x49dc22){const _0x5da4d7=a0_0x20018c;this[_0x5da4d7(0x514)]++,this[_0x5da4d7(0x186)][_0x5da4d7(0x5a6)](_0x395985,_0x49dc22);}[a0_0x20018c(0x18a)](_0x461fb5){const _0x222cb9=a0_0x20018c;return this[_0x222cb9(0x186)][_0x222cb9(0x18a)](_0x461fb5);}[a0_0x20018c(0x541)](_0x40a793){const _0x50a811=a0_0x20018c;return this[_0x50a811(0x514)]--,this[_0x50a811(0x186)][_0x50a811(0x541)](_0x40a793);}[a0_0x20018c(0x358)](){const _0xc7a312=a0_0x20018c;return this[_0xc7a312(0x514)];}}class KernelBackend{[a0_0x20018c(0x595)](_0x16b46c){const _0x31b17f=a0_0x20018c;return notYetImplemented(_0x31b17f(0x595));}['incRef'](_0x45df14){const _0x1ab547=a0_0x20018c;return notYetImplemented(_0x1ab547(0x437));}[a0_0x20018c(0x140)](){return!![];}[a0_0x20018c(0x5d5)](_0xf070de){return notYetImplemented('time');}[a0_0x20018c(0x405)](_0x1139b7){return notYetImplemented('read');}['readSync'](_0x4b1f04){return notYetImplemented('readSync');}[a0_0x20018c(0x358)](){const _0x554c4e=a0_0x20018c;return notYetImplemented(_0x554c4e(0x358));}[a0_0x20018c(0x3f0)](_0x43e8c7,_0xe442da){return notYetImplemented('disposeData');}[a0_0x20018c(0x594)](_0x2ac551,_0x545dd1,_0x504280){const _0x2e2362=a0_0x20018c;return notYetImplemented(_0x2e2362(0x594));}[a0_0x20018c(0x1f9)](_0x18724b,_0x5bb024,_0x53e2f4,_0x486349,_0x5ce01b){const _0x2dd7ad=a0_0x20018c;return notYetImplemented(_0x2dd7ad(0x1f9));}[a0_0x20018c(0x27f)](){const _0x1f04b2=a0_0x20018c;return notYetImplemented(_0x1f04b2(0x27f));}[a0_0x20018c(0x163)](){const _0xc485a5=a0_0x20018c;return notYetImplemented(_0xc485a5(0x163));}[a0_0x20018c(0x55c)](){const _0x550a1f=a0_0x20018c;return this[_0x550a1f(0x163)]()===0x20?EPSILON_FLOAT32:EPSILON_FLOAT16;}['dispose'](){const _0x2c62bf=a0_0x20018c;return notYetImplemented(_0x2c62bf(0x47d));}}function notYetImplemented(_0x36461a){const _0x1cd920=a0_0x20018c;throw new Error('\x27'+_0x36461a+_0x1cd920(0x442)+'This\x20kernel\x20may\x20not\x20be\x20supported\x20by\x20the\x20tfjs\x20backend\x20you\x20have\x20chosen');}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function shuffle(_0x48fbb8){const _0x28d525=a0_0x20018c;let _0x4a9528=_0x48fbb8[_0x28d525(0x104)],_0x4bf11b=0x0;while(_0x4a9528>0x0){_0x4bf11b=Math[_0x28d525(0x4ce)]()*_0x4a9528|0x0,_0x4a9528--,swap(_0x48fbb8,_0x4a9528,_0x4bf11b);}}function shuffleCombo(_0x25003b,_0x118199){const _0x1fb6ae=a0_0x20018c;if(_0x25003b['length']!==_0x118199[_0x1fb6ae(0x104)])throw new Error(_0x1fb6ae(0x5c0)+(_0x1fb6ae(0x590)+_0x25003b['length'])+(_0x1fb6ae(0x438)+_0x118199[_0x1fb6ae(0x104)]));let _0x530199=_0x25003b[_0x1fb6ae(0x104)],_0x4a2e6b=0x0;while(_0x530199>0x0){_0x4a2e6b=Math[_0x1fb6ae(0x4ce)]()*_0x530199|0x0,_0x530199--,swap(_0x25003b,_0x530199,_0x4a2e6b),swap(_0x118199,_0x530199,_0x4a2e6b);}}function clamp(_0x2a0f77,_0x104776,_0x4eabce){const _0x3b5de0=a0_0x20018c;return Math['max'](_0x2a0f77,Math[_0x3b5de0(0x58b)](_0x104776,_0x4eabce));}function nearestLargerEven(_0xcde48a){return _0xcde48a%0x2===0x0?_0xcde48a:_0xcde48a+0x1;}function swap(_0x2256a2,_0x410dc5,_0x2af8e8){const _0x1ac830=_0x2256a2[_0x410dc5];_0x2256a2[_0x410dc5]=_0x2256a2[_0x2af8e8],_0x2256a2[_0x2af8e8]=_0x1ac830;}function sum(_0x490d9f){let _0x366df1=0x0;for(let _0x1440f5=0x0;_0x1440f5<_0x490d9f['length'];_0x1440f5++){_0x366df1+=_0x490d9f[_0x1440f5];}return _0x366df1;}function randUniform(_0xc3c335,_0x549ead){const _0x2deee3=Math['random']();return _0x549ead*_0x2deee3+(0x1-_0x2deee3)*_0xc3c335;}function distSquared(_0x523f56,_0x3a04fe){const _0x1f42e4=a0_0x20018c;let _0x2d355f=0x0;for(let _0x1dae8f=0x0;_0x1dae8f<_0x523f56[_0x1f42e4(0x104)];_0x1dae8f++){const _0x5aa23a=Number(_0x523f56[_0x1dae8f])-Number(_0x3a04fe[_0x1dae8f]);_0x2d355f+=_0x5aa23a*_0x5aa23a;}return _0x2d355f;}function assert(_0x5dcf16,_0x25f224){const _0x3d5e24=a0_0x20018c;if(!_0x5dcf16)throw new Error(typeof _0x25f224===_0x3d5e24(0x5cf)?_0x25f224:_0x25f224());}function assertShapesMatch(_0x1c859c,_0x86e0c1,_0x27da53=''){const _0x19abaa=a0_0x20018c;assert(arraysEqual(_0x1c859c,_0x86e0c1),()=>_0x27da53+(_0x19abaa(0x3c9)+_0x1c859c+_0x19abaa(0x1de)+_0x86e0c1+_0x19abaa(0x248)));}function assertNonNull(_0x50b573){const _0x50aead=a0_0x20018c;assert(_0x50b573!=null,()=>_0x50aead(0x334));}function flatten(_0x37cad8,_0x81fb69=[],_0x34c23f=![]){const _0x5cf4ee=a0_0x20018c;_0x81fb69==null&&(_0x81fb69=[]);if(Array[_0x5cf4ee(0x576)](_0x37cad8)||isTypedArray(_0x37cad8)&&!_0x34c23f)for(let _0x338bb6=0x0;_0x338bb6<_0x37cad8[_0x5cf4ee(0x104)];++_0x338bb6){flatten(_0x37cad8[_0x338bb6],_0x81fb69,_0x34c23f);}else _0x81fb69[_0x5cf4ee(0x30f)](_0x37cad8);return _0x81fb69;}function sizeFromShape(_0x272437){const _0x17fd71=a0_0x20018c;if(_0x272437[_0x17fd71(0x104)]===0x0)return 0x1;let _0x25cfa0=_0x272437[0x0];for(let _0x429e6b=0x1;_0x429e6b<_0x272437['length'];_0x429e6b++){_0x25cfa0*=_0x272437[_0x429e6b];}return _0x25cfa0;}function isScalarShape(_0x265a9b){const _0x1b81f6=a0_0x20018c;return _0x265a9b[_0x1b81f6(0x104)]===0x0;}function arraysEqual(_0x896bd4,_0x5f52e1){const _0xfda7de=a0_0x20018c;if(_0x896bd4===_0x5f52e1)return!![];if(_0x896bd4==null||_0x5f52e1==null)return![];if(_0x896bd4[_0xfda7de(0x104)]!==_0x5f52e1[_0xfda7de(0x104)])return![];for(let _0xebc4d=0x0;_0xebc4d<_0x896bd4[_0xfda7de(0x104)];_0xebc4d++){if(_0x896bd4[_0xebc4d]!==_0x5f52e1[_0xebc4d])return![];}return!![];}function isInt(_0x2f25a7){return _0x2f25a7%0x1===0x0;}function tanh(_0x142097){const _0x2536ed=a0_0x20018c;if(Math[_0x2536ed(0x564)]!=null)return Math[_0x2536ed(0x564)](_0x142097);if(_0x142097===Infinity)return 0x1;else{if(_0x142097===-Infinity)return-0x1;else{const _0x2e3a2d=Math[_0x2536ed(0x57c)](0x2*_0x142097);return(_0x2e3a2d-0x1)/(_0x2e3a2d+0x1);}}}function sizeToSquarishShape(_0x40d1a9){const _0x23f217=a0_0x20018c,_0x5018bd=Math['ceil'](Math[_0x23f217(0x106)](_0x40d1a9));return[_0x5018bd,Math[_0x23f217(0x4a7)](_0x40d1a9/_0x5018bd)];}function createShuffledIndices(_0x353d93){const _0x1be05d=new Uint32Array(_0x353d93);for(let _0x49b4b7=0x0;_0x49b4b7<_0x353d93;++_0x49b4b7){_0x1be05d[_0x49b4b7]=_0x49b4b7;}return shuffle(_0x1be05d),_0x1be05d;}function rightPad(_0x12aaef,_0x5804df){const _0x4a2383=a0_0x20018c;if(_0x5804df<=_0x12aaef['length'])return _0x12aaef;return _0x12aaef+'\x20'[_0x4a2383(0x13b)](_0x5804df-_0x12aaef[_0x4a2383(0x104)]);}function repeatedTry(_0x1f6bc4,_0x2bb745=_0x5e26d9=>0x0,_0x1f5701){return new Promise((_0x5b466c,_0x53eab4)=>{let _0x47b31b=0x0;const _0xf2c986=()=>{if(_0x1f6bc4()){_0x5b466c();return;}_0x47b31b++;const _0x23c28e=_0x2bb745(_0x47b31b);if(_0x1f5701!=null&&_0x47b31b>=_0x1f5701){_0x53eab4();return;}setTimeout(_0xf2c986,_0x23c28e);};_0xf2c986();});}function inferFromImplicitShape(_0x47be38,_0x586dda){const _0xe21dd0=a0_0x20018c;let _0x26f408=0x1,_0x1dd7fc=-0x1;for(let _0x4348ec=0x0;_0x4348ec<_0x47be38[_0xe21dd0(0x104)];++_0x4348ec){if(_0x47be38[_0x4348ec]>=0x0)_0x26f408*=_0x47be38[_0x4348ec];else{if(_0x47be38[_0x4348ec]===-0x1){if(_0x1dd7fc!==-0x1)throw Error(_0xe21dd0(0x23b)+('Found\x20-1\x20at\x20dim\x20'+_0x1dd7fc+'\x20and\x20dim\x20'+_0x4348ec));_0x1dd7fc=_0x4348ec;}else{if(_0x47be38[_0x4348ec]<0x0)throw Error(_0xe21dd0(0x262)+_0x47be38[_0x4348ec]+_0xe21dd0(0x3da)+_0x4348ec);}}}if(_0x1dd7fc===-0x1){if(_0x586dda>0x0&&_0x586dda!==_0x26f408)throw Error(_0xe21dd0(0x374)+_0x586dda+')\x20must\x20match\x20the\x20product\x20of\x20shape\x20'+_0x47be38);return _0x47be38;}if(_0x26f408===0x0)throw Error(_0xe21dd0(0x260)+_0x47be38+_0xe21dd0(0x110)+_0xe21dd0(0x35a));if(_0x586dda%_0x26f408!==0x0)throw Error(_0xe21dd0(0x29e)+(_0xe21dd0(0x32a)+_0x586dda+_0xe21dd0(0x3ef)+_0x26f408));const _0x403ab1=_0x47be38[_0xe21dd0(0x2b0)]();return _0x403ab1[_0x1dd7fc]=_0x586dda/_0x26f408,_0x403ab1;}function parseAxisParam(_0x235c06,_0x4464f){const _0x57894b=a0_0x20018c,_0x441b44=_0x4464f[_0x57894b(0x104)];return _0x235c06=_0x235c06==null?_0x4464f[_0x57894b(0x3ab)]((_0xb63c20,_0x452b8a)=>_0x452b8a):[][_0x57894b(0x300)](_0x235c06),assert(_0x235c06['every'](_0x268f38=>_0x268f38>=-_0x441b44&&_0x268f38<_0x441b44),()=>_0x57894b(0x23f)+_0x441b44+',\x20'+_0x441b44+')\x20but\x20'+(_0x57894b(0x19c)+_0x235c06)),assert(_0x235c06[_0x57894b(0x271)](_0x1928e9=>isInt(_0x1928e9)),()=>_0x57894b(0x222)+(_0x57894b(0x19c)+_0x235c06)),_0x235c06[_0x57894b(0x3ab)](_0x36668b=>_0x36668b<0x0?_0x441b44+_0x36668b:_0x36668b);}function squeezeShape(_0x260f3d,_0x1400fe){const _0x4bb791=a0_0x20018c,_0x1c6bee=[],_0x50ea0a=[],_0x4eaeaf=_0x1400fe!=null&&Array[_0x4bb791(0x576)](_0x1400fe)&&_0x1400fe[_0x4bb791(0x104)]===0x0,_0x8fe8f8=_0x1400fe==null||_0x4eaeaf?null:parseAxisParam(_0x1400fe,_0x260f3d)[_0x4bb791(0x2f6)]();let _0x3e968c=0x0;for(let _0x1ba0bb=0x0;_0x1ba0bb<_0x260f3d[_0x4bb791(0x104)];++_0x1ba0bb){if(_0x8fe8f8!=null){if(_0x8fe8f8[_0x3e968c]===_0x1ba0bb&&_0x260f3d[_0x1ba0bb]!==0x1)throw new Error(_0x4bb791(0x522)+_0x1ba0bb+_0x4bb791(0x14b)+_0x260f3d[_0x1ba0bb]+_0x4bb791(0x3a8));(_0x8fe8f8[_0x3e968c]==null||_0x8fe8f8[_0x3e968c]>_0x1ba0bb)&&_0x260f3d[_0x1ba0bb]===0x1&&(_0x1c6bee['push'](_0x260f3d[_0x1ba0bb]),_0x50ea0a['push'](_0x1ba0bb)),_0x8fe8f8[_0x3e968c]<=_0x1ba0bb&&_0x3e968c++;}_0x260f3d[_0x1ba0bb]!==0x1&&(_0x1c6bee[_0x4bb791(0x30f)](_0x260f3d[_0x1ba0bb]),_0x50ea0a[_0x4bb791(0x30f)](_0x1ba0bb));}return{'newShape':_0x1c6bee,'keptDims':_0x50ea0a};}function getTypedArrayFromDType(_0x4e1da2,_0x580881){const _0x47cbb8=a0_0x20018c;let _0x53b9a3=null;if(_0x4e1da2==null||_0x4e1da2===_0x47cbb8(0x28b))_0x53b9a3=new Float32Array(_0x580881);else{if(_0x4e1da2===_0x47cbb8(0x4d1))_0x53b9a3=new Int32Array(_0x580881);else{if(_0x4e1da2===_0x47cbb8(0x188))_0x53b9a3=new Uint8Array(_0x580881);else throw new Error(_0x47cbb8(0x404)+_0x4e1da2);}}return _0x53b9a3;}function getArrayFromDType(_0x4a135a,_0x4aa70e){const _0x22a0eb=a0_0x20018c;let _0x30096c=null;if(_0x4a135a==null||_0x4a135a===_0x22a0eb(0x28b))_0x30096c=new Float32Array(_0x4aa70e);else{if(_0x4a135a===_0x22a0eb(0x4d1))_0x30096c=new Int32Array(_0x4aa70e);else{if(_0x4a135a===_0x22a0eb(0x188))_0x30096c=new Uint8Array(_0x4aa70e);else{if(_0x4a135a==='string')_0x30096c=new Array(_0x4aa70e);else throw new Error(_0x22a0eb(0x404)+_0x4a135a);}}}return _0x30096c;}function checkConversionForErrors(_0x5ef5c9,_0x59dd91){const _0x328b85=a0_0x20018c;for(let _0x15620e=0x0;_0x15620e<_0x5ef5c9[_0x328b85(0x104)];_0x15620e++){const _0x5d8b91=_0x5ef5c9[_0x15620e];if(isNaN(_0x5d8b91)||!isFinite(_0x5d8b91))throw Error(_0x328b85(0x4d9)+_0x59dd91+_0x328b85(0x3bc)+_0x5d8b91+'.');}}function isValidDtype(_0x5b3cae){const _0x2fbc0d=a0_0x20018c;return _0x5b3cae==='bool'||_0x5b3cae===_0x2fbc0d(0xe8)||_0x5b3cae===_0x2fbc0d(0x28b)||_0x5b3cae===_0x2fbc0d(0x4d1)||_0x5b3cae==='string';}function hasEncodingLoss(_0x37d353,_0x238790){const _0x2220e2=a0_0x20018c;if(_0x238790==='complex64')return![];if(_0x238790===_0x2220e2(0x28b)&&_0x37d353!=='complex64')return![];if(_0x238790===_0x2220e2(0x4d1)&&_0x37d353!==_0x2220e2(0x28b)&&_0x37d353!==_0x2220e2(0xe8))return![];if(_0x238790==='bool'&&_0x37d353==='bool')return![];return!![];}function isTypedArray(_0x3405b0){return _0x3405b0 instanceof Float32Array||_0x3405b0 instanceof Int32Array||_0x3405b0 instanceof Uint8Array;}function bytesPerElement(_0x182c7e){const _0x55a22b=a0_0x20018c;if(_0x182c7e===_0x55a22b(0x28b)||_0x182c7e===_0x55a22b(0x4d1))return 0x4;else{if(_0x182c7e==='complex64')return 0x8;else{if(_0x182c7e===_0x55a22b(0x188))return 0x1;else throw new Error(_0x55a22b(0x524)+_0x182c7e);}}}function bytesFromStringArray(_0x41062e){const _0x30b7b2=a0_0x20018c;if(_0x41062e==null)return 0x0;let _0x598e36=0x0;return _0x41062e[_0x30b7b2(0x1e4)](_0x509aae=>_0x598e36+=_0x509aae[_0x30b7b2(0x104)]),_0x598e36;}function isString(_0x39c6d6){const _0x2bd220=a0_0x20018c;return typeof _0x39c6d6===_0x2bd220(0x5cf)||_0x39c6d6 instanceof String;}function isBoolean(_0x2a8982){const _0x2da60d=a0_0x20018c;return typeof _0x2a8982===_0x2da60d(0x4eb);}function isNumber(_0x4d2f93){const _0x3f8320=a0_0x20018c;return typeof _0x4d2f93===_0x3f8320(0x4ac);}function inferDtype(_0x847c91){const _0x4a81a2=a0_0x20018c;if(Array[_0x4a81a2(0x576)](_0x847c91))return inferDtype(_0x847c91[0x0]);if(_0x847c91 instanceof Float32Array)return'float32';else{if(_0x847c91 instanceof Int32Array||_0x847c91 instanceof Uint8Array)return'int32';else{if(isNumber(_0x847c91))return'float32';else{if(isString(_0x847c91))return _0x4a81a2(0x5cf);else{if(isBoolean(_0x847c91))return'bool';}}}}return _0x4a81a2(0x28b);}function isFunction(_0x241bbe){const _0x1ec71a=a0_0x20018c;return!!(_0x241bbe&&_0x241bbe[_0x1ec71a(0x3ae)]&&_0x241bbe[_0x1ec71a(0x5ae)]&&_0x241bbe[_0x1ec71a(0x3db)]);}function nearestDivisor(_0x49c1c0,_0x5020bb){for(let _0x2b3dd1=_0x5020bb;_0x2b3dd1<_0x49c1c0;++_0x2b3dd1){if(_0x49c1c0%_0x2b3dd1===0x0)return _0x2b3dd1;}return _0x49c1c0;}function computeStrides(_0xbd4d30){const _0x50b067=_0xbd4d30['length'];if(_0x50b067<0x2)return[];const _0x1a14d3=new Array(_0x50b067-0x1);_0x1a14d3[_0x50b067-0x2]=_0xbd4d30[_0x50b067-0x1];for(let _0x158cb0=_0x50b067-0x3;_0x158cb0>=0x0;--_0x158cb0){_0x1a14d3[_0x158cb0]=_0x1a14d3[_0x158cb0+0x1]*_0xbd4d30[_0x158cb0+0x1];}return _0x1a14d3;}function createNestedArray(_0x2a0dd8,_0x21f16e,_0x4bef71,_0xf666b6=![]){const _0xaf9188=a0_0x20018c,_0x19dbf7=new Array();if(_0x21f16e[_0xaf9188(0x104)]===0x1){const _0x1476eb=_0x21f16e[0x0]*(_0xf666b6?0x2:0x1);for(let _0x103854=0x0;_0x103854<_0x1476eb;_0x103854++){_0x19dbf7[_0x103854]=_0x4bef71[_0x2a0dd8+_0x103854];}}else{const _0x5bf316=_0x21f16e[0x0],_0x29d940=_0x21f16e[_0xaf9188(0x2b0)](0x1),_0x381d22=_0x29d940['reduce']((_0x52fdd3,_0x33aa79)=>_0x52fdd3*_0x33aa79)*(_0xf666b6?0x2:0x1);for(let _0x173641=0x0;_0x173641<_0x5bf316;_0x173641++){_0x19dbf7[_0x173641]=createNestedArray(_0x2a0dd8+_0x173641*_0x381d22,_0x29d940,_0x4bef71,_0xf666b6);}}return _0x19dbf7;}function toNestedArray(_0x6b6ada,_0x485ac3,_0x4eac5d=![]){const _0x451a9c=a0_0x20018c;if(_0x6b6ada['length']===0x0)return _0x485ac3[0x0];const _0x12cb20=_0x6b6ada[_0x451a9c(0x48a)]((_0x1a7824,_0x330ef4)=>_0x1a7824*_0x330ef4)*(_0x4eac5d?0x2:0x1);if(_0x12cb20===0x0)return[];if(_0x12cb20!==_0x485ac3[_0x451a9c(0x104)])throw new Error('['+_0x6b6ada+_0x451a9c(0x2c4)+_0x485ac3[_0x451a9c(0x104)]+(_0x4eac5d?'\x20for\x20a\x20complex\x20tensor':'')+'.');return createNestedArray(0x0,_0x6b6ada,_0x485ac3,_0x4eac5d);}function makeOnesTypedArray(_0x24a3f1,_0x583064){const _0x607e1a=a0_0x20018c,_0x17fa9d=makeZerosTypedArray(_0x24a3f1,_0x583064);for(let _0x4fb1bc=0x0;_0x4fb1bc<_0x17fa9d[_0x607e1a(0x104)];_0x4fb1bc++){_0x17fa9d[_0x4fb1bc]=0x1;}return _0x17fa9d;}function makeZerosTypedArray(_0xb0ce5b,_0x3d5c21){const _0x23248d=a0_0x20018c;if(_0x3d5c21==null||_0x3d5c21===_0x23248d(0x28b)||_0x3d5c21===_0x23248d(0xe8))return new Float32Array(_0xb0ce5b);else{if(_0x3d5c21==='int32')return new Int32Array(_0xb0ce5b);else{if(_0x3d5c21===_0x23248d(0x188))return new Uint8Array(_0xb0ce5b);else throw new Error('Unknown\x20data\x20type\x20'+_0x3d5c21);}}}function makeZerosNestedTypedArray(_0x48fa13,_0x498cc0){const _0x3c4c06=a0_0x20018c,_0x3ff335=_0x48fa13[_0x3c4c06(0x48a)]((_0x551f15,_0x460f64)=>_0x551f15*_0x460f64,0x1);if(_0x498cc0==null||_0x498cc0===_0x3c4c06(0x28b))return toNestedArray(_0x48fa13,new Float32Array(_0x3ff335));else{if(_0x498cc0===_0x3c4c06(0x4d1))return toNestedArray(_0x48fa13,new Int32Array(_0x3ff335));else{if(_0x498cc0===_0x3c4c06(0x188))return toNestedArray(_0x48fa13,new Uint8Array(_0x3ff335));else throw new Error(_0x3c4c06(0x404)+_0x498cc0);}}}function assertNonNegativeIntegerDimensions(_0x2a85eb){_0x2a85eb['forEach'](_0x2de78e=>{const _0x41d369=a0_0x367f;assert(Number[_0x41d369(0x387)](_0x2de78e)&&_0x2de78e>=0x0,()=>_0x41d369(0x40b)+(_0x41d369(0x1a6)+_0x2a85eb+'].'));});}function locToIndex(_0x26b12e,_0x2ecd86,_0x22c534){const _0x2633b3=a0_0x20018c;if(_0x2ecd86===0x0)return 0x0;else{if(_0x2ecd86===0x1)return _0x26b12e[0x0];}let _0x14432f=_0x26b12e[_0x26b12e[_0x2633b3(0x104)]-0x1];for(let _0x55ead3=0x0;_0x55ead3<_0x26b12e[_0x2633b3(0x104)]-0x1;++_0x55ead3){_0x14432f+=_0x22c534[_0x55ead3]*_0x26b12e[_0x55ead3];}return _0x14432f;}function indexToLoc(_0x4ee8cf,_0x3236b0,_0x260472){const _0x2c8f16=a0_0x20018c;if(_0x3236b0===0x0)return[];else{if(_0x3236b0===0x1)return[_0x4ee8cf];}const _0x5bf818=new Array(_0x3236b0);for(let _0x2ff086=0x0;_0x2ff086<_0x5bf818['length']-0x1;++_0x2ff086){_0x5bf818[_0x2ff086]=Math[_0x2c8f16(0x476)](_0x4ee8cf/_0x260472[_0x2ff086]),_0x4ee8cf-=_0x5bf818[_0x2ff086]*_0x260472[_0x2ff086];}return _0x5bf818[_0x5bf818['length']-0x1]=_0x4ee8cf,_0x5bf818;}function isPromise(_0x3c96a6){const _0x1fdfe8=a0_0x20018c;return _0x3c96a6&&_0x3c96a6[_0x1fdfe8(0x236)]&&typeof _0x3c96a6[_0x1fdfe8(0x236)]==='function';}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function warn(..._0x31207b){const _0x231c8a=a0_0x20018c;!(env()[_0x231c8a(0x501)](_0x231c8a(0x2b1))||env()[_0x231c8a(0x501)]('PROD'))&&console['warn'](..._0x31207b);}function log(..._0x10b619){const _0x45aced=a0_0x20018c;!(env()[_0x45aced(0x501)](_0x45aced(0x2b1))||env()[_0x45aced(0x501)](_0x45aced(0x252)))&&console[_0x45aced(0x4d2)](..._0x10b619);}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const TENSORFLOWJS_FLAGS_PREFIX=a0_0x20018c(0x563);class Environment{constructor(_0x3730cd){const _0x44be4d=a0_0x20018c;this[_0x44be4d(0x108)]=_0x3730cd,this[_0x44be4d(0x2d1)]={},this['flagRegistry']={},this[_0x44be4d(0x295)]={},this[_0x44be4d(0x377)]=getQueryParams,this[_0x44be4d(0x2b8)]();}['setPlatform'](_0x10581c,_0x460e30){const _0x17a506=a0_0x20018c;this['platform']!=null&&warn(_0x17a506(0x1a7)+this[_0x17a506(0x1d9)]+'\x20has\x20already\x20been\x20set.\x20'+(_0x17a506(0xff)+_0x460e30+'.')),this[_0x17a506(0x1d9)]=_0x10581c,this[_0x17a506(0x18e)]=_0x460e30;}['registerFlag'](_0x210982,_0x30df70,_0x2ed14b){const _0x3eedc9=a0_0x20018c;this[_0x3eedc9(0x582)][_0x210982]={'evaluationFn':_0x30df70,'setHook':_0x2ed14b};if(this[_0x3eedc9(0x295)][_0x210982]!=null){const _0x474e47=this[_0x3eedc9(0x295)][_0x210982];warn(_0x3eedc9(0x2d2)+_0x210982+':\x20'+_0x474e47+'.'),this[_0x3eedc9(0x5a6)](_0x210982,_0x474e47);}}async[a0_0x20018c(0x326)](_0x1ecf4c){const _0x10e9d7=a0_0x20018c;if(_0x1ecf4c in this['flags'])return this[_0x10e9d7(0x2d1)][_0x1ecf4c];return this['flags'][_0x1ecf4c]=await this[_0x10e9d7(0x1e6)](_0x1ecf4c),this['flags'][_0x1ecf4c];}[a0_0x20018c(0x40f)](_0xc9f7b3){const _0x1a003a=a0_0x20018c;if(_0xc9f7b3 in this[_0x1a003a(0x2d1)])return this[_0x1a003a(0x2d1)][_0xc9f7b3];const _0x334a21=this[_0x1a003a(0x1e6)](_0xc9f7b3);if(isPromise(_0x334a21))throw new Error(_0x1a003a(0x22e)+_0xc9f7b3+_0x1a003a(0x5a2)+_0x1a003a(0xf0));return this[_0x1a003a(0x2d1)][_0xc9f7b3]=_0x334a21,this[_0x1a003a(0x2d1)][_0xc9f7b3];}['getNumber'](_0x46259a){const _0x23235b=a0_0x20018c;return this[_0x23235b(0x40f)](_0x46259a);}[a0_0x20018c(0x501)](_0x123e88){return this['get'](_0x123e88);}[a0_0x20018c(0x4f4)](){return this['flags'];}get[a0_0x20018c(0x2fc)](){return this['flags'];}[a0_0x20018c(0x5a6)](_0x9eda18,_0x2f63ac){const _0x282cb3=a0_0x20018c;if(this[_0x282cb3(0x582)][_0x9eda18]==null)throw new Error(_0x282cb3(0x17c)+_0x9eda18+_0x282cb3(0x542));this[_0x282cb3(0x2d1)][_0x9eda18]=_0x2f63ac,this[_0x282cb3(0x582)][_0x9eda18]['setHook']!=null&&this[_0x282cb3(0x582)][_0x9eda18][_0x282cb3(0x2f3)](_0x2f63ac);}[a0_0x20018c(0x1e6)](_0x4a6566){const _0x4451aa=a0_0x20018c;if(this[_0x4451aa(0x582)][_0x4a6566]==null)throw new Error(_0x4451aa(0x2f7)+_0x4a6566+'\x27:\x20no\x20evaluation\x20function\x20found.');return this[_0x4451aa(0x582)][_0x4a6566][_0x4451aa(0x513)]();}[a0_0x20018c(0x382)](_0x25a428){const _0x50c333=a0_0x20018c;this[_0x50c333(0x2d1)]=Object[_0x50c333(0xe3)]({},_0x25a428);}[a0_0x20018c(0x12d)](){const _0x440295=a0_0x20018c;this[_0x440295(0x2d1)]={},this['urlFlags']={},this[_0x440295(0x2b8)]();}[a0_0x20018c(0x2b8)](){const _0x39105d=a0_0x20018c;if(typeof this[_0x39105d(0x108)]==='undefined'||typeof this[_0x39105d(0x108)][_0x39105d(0x2e5)]===_0x39105d(0x312)||typeof this['global']['location'][_0x39105d(0x16b)]==='undefined')return;const _0x4b3ed5=this[_0x39105d(0x377)](this[_0x39105d(0x108)][_0x39105d(0x2e5)][_0x39105d(0x16b)]);if(TENSORFLOWJS_FLAGS_PREFIX in _0x4b3ed5){const _0x46101e=_0x4b3ed5[TENSORFLOWJS_FLAGS_PREFIX][_0x39105d(0x45d)](',');_0x46101e[_0x39105d(0x1e4)](_0x369cda=>{const _0xfd9404=_0x39105d,[_0x25ed11,_0x54ee97]=_0x369cda[_0xfd9404(0x45d)](':');this['urlFlags'][_0x25ed11]=parseValue(_0x25ed11,_0x54ee97);});}}}function getQueryParams(_0x3b7d07){const _0xda2188=a0_0x20018c,_0x119fbe={};return _0x3b7d07[_0xda2188(0x2ee)](/[?&]([^=?&]+)(?:=([^&]*))?/g,(_0x5a28f0,..._0x4cd3e7)=>{const _0x5e6622=_0xda2188;return decodeParam(_0x119fbe,_0x4cd3e7[0x0],_0x4cd3e7[0x1]),_0x4cd3e7[_0x5e6622(0x46d)]('=');}),_0x119fbe;}function decodeParam(_0x2b0971,_0x59e5b1,_0x2aa114){_0x2b0971[decodeURIComponent(_0x59e5b1)]=decodeURIComponent(_0x2aa114||'');}function parseValue(_0xd68289,_0x16a640){const _0x475c6f=a0_0x20018c;_0x16a640=_0x16a640['toLowerCase']();if(_0x16a640===_0x475c6f(0x1b9)||_0x16a640===_0x475c6f(0x4a4))return _0x16a640===_0x475c6f(0x1b9);else{if(''+ +_0x16a640===_0x16a640)return+_0x16a640;}throw new Error(_0x475c6f(0x426)+_0x16a640+_0x475c6f(0x113)+_0xd68289+'.');}function env(){return ENV;}let ENV=null;function setEnvironmentGlobal(_0x31f17c){ENV=_0x31f17c;}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
let globalNameSpace;function getGlobalNamespace(){const _0x4fb9c6=a0_0x20018c;if(globalNameSpace==null){let _0x115bc3;if(typeof window!==_0x4fb9c6(0x312))_0x115bc3=window;else{if(typeof global!==_0x4fb9c6(0x312))_0x115bc3=global;else{if(typeof process!==_0x4fb9c6(0x312))_0x115bc3=process;else{if(typeof self!==_0x4fb9c6(0x312))_0x115bc3=self;else throw new Error(_0x4fb9c6(0x545));}}}globalNameSpace=_0x115bc3;}return globalNameSpace;}function getGlobalMap(){const _0x43f6d5=a0_0x20018c,_0x4ba74b=getGlobalNamespace();return _0x4ba74b[_0x43f6d5(0xe0)]==null&&(_0x4ba74b[_0x43f6d5(0xe0)]=new Map()),_0x4ba74b[_0x43f6d5(0xe0)];}function getGlobal(_0x325518,_0x2a69b2){const _0x1f0cb4=a0_0x20018c,_0x5ccdf9=getGlobalMap();if(_0x5ccdf9['has'](_0x325518))return _0x5ccdf9[_0x1f0cb4(0x40f)](_0x325518);else{const _0x2d1732=_0x2a69b2();return _0x5ccdf9[_0x1f0cb4(0x5a6)](_0x325518,_0x2d1732),_0x5ccdf9[_0x1f0cb4(0x40f)](_0x325518);}}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const kernelRegistry=getGlobal(a0_0x20018c(0x456),()=>new Map()),gradRegistry=getGlobal(a0_0x20018c(0x1f1),()=>new Map());function getKernel(_0x2dccaa,_0x3ae575){const _0x28ed75=a0_0x20018c,_0x4c3c9e=makeKey(_0x2dccaa,_0x3ae575);return kernelRegistry[_0x28ed75(0x40f)](_0x4c3c9e);}function getGradient(_0xfeafa2){const _0xcb9559=a0_0x20018c;return gradRegistry[_0xcb9559(0x40f)](_0xfeafa2);}function getKernelsForBackend(_0x1cb41d){const _0x5879d7=a0_0x20018c,_0x773135=kernelRegistry[_0x5879d7(0x1d2)](),_0x271709=[];while(!![]){const {done:_0x5b1e55,value:_0x19c0ca}=_0x773135[_0x5879d7(0x360)]();if(_0x5b1e55)break;const [_0x172883,_0xba6a2b]=_0x19c0ca,[_0x1d62cb]=_0x172883[_0x5879d7(0x45d)]('_');_0x1d62cb===_0x1cb41d&&_0x271709[_0x5879d7(0x30f)](_0xba6a2b);}return _0x271709;}function registerKernel(_0xc648f9){const _0x1901f4=a0_0x20018c,{kernelName:_0x5e3ef5,backendName:_0xb679e2}=_0xc648f9,_0x52256a=makeKey(_0x5e3ef5,_0xb679e2);kernelRegistry['has'](_0x52256a)&&warn(_0x1901f4(0x16e)+_0x5e3ef5+_0x1901f4(0x2cd)+('\x27'+_0xb679e2+_0x1901f4(0x1d7))),kernelRegistry['set'](_0x52256a,_0xc648f9);}function registerGradient(_0x330776){const _0x40e775=a0_0x20018c,{kernelName:_0x22fc2c}=_0x330776;gradRegistry['has'](_0x22fc2c)&&(env()[_0x40e775(0x501)](_0x40e775(0x153))&&warn(_0x40e775(0x206)+_0x22fc2c+'\x27')),gradRegistry['set'](_0x22fc2c,_0x330776);}function unregisterKernel(_0x6893fc,_0x20dad7){const _0xc2a87e=a0_0x20018c,_0x5bc44e=makeKey(_0x6893fc,_0x20dad7);if(!kernelRegistry[_0xc2a87e(0x18a)](_0x5bc44e))throw new Error(_0xc2a87e(0x16e)+_0x6893fc+_0xc2a87e(0x2cd)+('\x27'+_0x20dad7+_0xc2a87e(0x28f)));kernelRegistry[_0xc2a87e(0x541)](_0x5bc44e);}function unregisterGradient(_0x3697c8){const _0x268d19=a0_0x20018c;if(!gradRegistry[_0x268d19(0x18a)](_0x3697c8))throw new Error(_0x268d19(0x565)+_0x3697c8+_0x268d19(0x559));gradRegistry['delete'](_0x3697c8);}function copyRegisteredKernels(_0x296897,_0x7f4afd){const _0x2f2b8a=a0_0x20018c,_0xf94851=getKernelsForBackend(_0x296897);_0xf94851[_0x2f2b8a(0x1e4)](_0x355154=>{const _0x481c0c=_0x2f2b8a,_0xe805e8=Object[_0x481c0c(0xe3)]({},_0x355154,{'backendName':_0x7f4afd});registerKernel(_0xe805e8);});}function makeKey(_0x382bd1,_0x47db0c){return _0x47db0c+'_'+_0x382bd1;}/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const Long=LongExports__default||LongExports;function hexToLong(_0x4bc8f6){const _0x5dcff6=a0_0x20018c;return Long[_0x5dcff6(0x31a)](_0x4bc8f6,!![],0x10);}const k0=hexToLong('c3a5c85c97cb3127'),k1=hexToLong('b492b66fbe98f273'),k2=hexToLong(a0_0x20018c(0x2d4));function shiftMix(_0x23ad25){const _0x36eb60=a0_0x20018c;return _0x23ad25[_0x36eb60(0x16d)](_0x23ad25[_0x36eb60(0x197)](0x2f));}function fetch(_0x5397fc,_0x23b331,_0x3e7d89){const _0x96c9e=a0_0x20018c,_0x5dce6a=_0x5397fc['slice'](_0x23b331,_0x23b331+_0x3e7d89);return Long[_0x96c9e(0x1bc)](Array['from'](_0x5dce6a),!![],!![]);}function fetch64(_0x48a75f,_0x41f437){return fetch(_0x48a75f,_0x41f437,0x8);}function fetch32(_0x4679b7,_0xb4ca60){return fetch(_0x4679b7,_0xb4ca60,0x4);}function rotate64(_0x5c986d,_0x50d5a4){const _0x124ac2=a0_0x20018c;return _0x50d5a4===0x0?_0x5c986d:_0x5c986d[_0x124ac2(0x197)](_0x50d5a4)['or'](_0x5c986d['shl'](0x40-_0x50d5a4));}function hashLen16(_0x469a4d,_0x137a84,_0x2c389e=hexToLong(a0_0x20018c(0x4d5))){const _0x5974c8=a0_0x20018c;let _0x47550b=_0x469a4d['xor'](_0x137a84)['mul'](_0x2c389e);_0x47550b=_0x47550b[_0x5974c8(0x16d)](_0x47550b['shru'](0x2f));let _0x271756=_0x137a84['xor'](_0x47550b)['mul'](_0x2c389e);return _0x271756=_0x271756['xor'](_0x271756[_0x5974c8(0x197)](0x2f)),_0x271756=_0x271756['mul'](_0x2c389e),_0x271756;}function weakHashLen32WithSeeds(_0xfa4b2d,_0x29781a,_0x18a70b,_0x2f0240,_0x2d4da5,_0x499643){const _0x4c6f8e=a0_0x20018c;_0x2d4da5=_0x2d4da5[_0x4c6f8e(0x4ed)](_0xfa4b2d),_0x499643=rotate64(_0x499643[_0x4c6f8e(0x4ed)](_0x2d4da5)[_0x4c6f8e(0x4ed)](_0x2f0240),0x15);const _0x13cb0a=_0x2d4da5;return _0x2d4da5=_0x2d4da5[_0x4c6f8e(0x4ed)](_0x29781a),_0x2d4da5=_0x2d4da5[_0x4c6f8e(0x4ed)](_0x18a70b),_0x499643=_0x499643[_0x4c6f8e(0x4ed)](rotate64(_0x2d4da5,0x2c)),[_0x2d4da5[_0x4c6f8e(0x4ed)](_0x2f0240),_0x499643[_0x4c6f8e(0x4ed)](_0x13cb0a)];}function weakHashLen32WithSeedsStr(_0x2b06ad,_0x5869c5,_0x53d16d,_0x21b2e0){return weakHashLen32WithSeeds(fetch64(_0x2b06ad,_0x5869c5),fetch64(_0x2b06ad,_0x5869c5+0x8),fetch64(_0x2b06ad,_0x5869c5+0x10),fetch64(_0x2b06ad,_0x5869c5+0x18),_0x53d16d,_0x21b2e0);}function hashLen0to16(_0x5ab617,_0x226d43=_0x5ab617[a0_0x20018c(0x104)]){const _0x349451=a0_0x20018c;if(_0x226d43>=0x8){const _0x598808=k2[_0x349451(0x4ed)](_0x226d43*0x2),_0x35f6f9=fetch64(_0x5ab617,0x0)['add'](k2),_0x36f25d=fetch64(_0x5ab617,_0x226d43-0x8),_0x342d57=rotate64(_0x36f25d,0x25)[_0x349451(0x1a0)](_0x598808)[_0x349451(0x4ed)](_0x35f6f9),_0x2977d8=rotate64(_0x35f6f9,0x19)['add'](_0x36f25d)['mul'](_0x598808);return hashLen16(_0x342d57,_0x2977d8,_0x598808);}if(_0x226d43>=0x4){const _0x3667df=k2[_0x349451(0x4ed)](_0x226d43*0x2),_0x54e656=fetch32(_0x5ab617,0x0);return hashLen16(_0x54e656[_0x349451(0x26f)](0x3)['add'](_0x226d43),fetch32(_0x5ab617,_0x226d43-0x4),_0x3667df);}if(_0x226d43>0x0){const _0xdc79d5=_0x5ab617[0x0],_0x40ec5c=_0x5ab617[_0x226d43>>0x1],_0x2dce14=_0x5ab617[_0x226d43-0x1],_0x356e10=_0xdc79d5+(_0x40ec5c<<0x8),_0x1e524c=_0x226d43+(_0x2dce14<<0x2);return shiftMix(k2[_0x349451(0x1a0)](_0x356e10)[_0x349451(0x16d)](k0[_0x349451(0x1a0)](_0x1e524c)))['mul'](k2);}return k2;}function hashLen17to32(_0x20ae56,_0x44f6e2=_0x20ae56[a0_0x20018c(0x104)]){const _0x18f1ec=a0_0x20018c,_0x568d5b=k2[_0x18f1ec(0x4ed)](_0x44f6e2*0x2),_0x1c167d=fetch64(_0x20ae56,0x0)[_0x18f1ec(0x1a0)](k1),_0x2c400c=fetch64(_0x20ae56,0x8),_0x219ca3=fetch64(_0x20ae56,_0x44f6e2-0x8)[_0x18f1ec(0x1a0)](_0x568d5b),_0x2c024e=fetch64(_0x20ae56,_0x44f6e2-0x10)[_0x18f1ec(0x1a0)](k2);return hashLen16(rotate64(_0x1c167d['add'](_0x2c400c),0x2b)['add'](rotate64(_0x219ca3,0x1e))[_0x18f1ec(0x4ed)](_0x2c024e),_0x1c167d[_0x18f1ec(0x4ed)](rotate64(_0x2c400c[_0x18f1ec(0x4ed)](k2),0x12))[_0x18f1ec(0x4ed)](_0x219ca3),_0x568d5b);}function hashLen33to64(_0x38827f,_0x5ea42b=_0x38827f[a0_0x20018c(0x104)]){const _0x1ae13c=a0_0x20018c,_0xae4896=k2['add'](_0x5ea42b*0x2),_0xdb1d20=fetch64(_0x38827f,0x0)[_0x1ae13c(0x1a0)](k2),_0x54abfc=fetch64(_0x38827f,0x8),_0x175f24=fetch64(_0x38827f,_0x5ea42b-0x8)['mul'](_0xae4896),_0x4579b6=fetch64(_0x38827f,_0x5ea42b-0x10)[_0x1ae13c(0x1a0)](k2),_0x372987=rotate64(_0xdb1d20[_0x1ae13c(0x4ed)](_0x54abfc),0x2b)[_0x1ae13c(0x4ed)](rotate64(_0x175f24,0x1e))[_0x1ae13c(0x4ed)](_0x4579b6),_0x53f2e2=hashLen16(_0x372987,_0xdb1d20['add'](rotate64(_0x54abfc[_0x1ae13c(0x4ed)](k2),0x12))[_0x1ae13c(0x4ed)](_0x175f24),_0xae4896),_0x270a6d=fetch64(_0x38827f,0x10)[_0x1ae13c(0x1a0)](_0xae4896),_0x51e4fe=fetch64(_0x38827f,0x18),_0xaccf1=_0x372987[_0x1ae13c(0x4ed)](fetch64(_0x38827f,_0x5ea42b-0x20))[_0x1ae13c(0x1a0)](_0xae4896),_0x1fe9a3=_0x53f2e2[_0x1ae13c(0x4ed)](fetch64(_0x38827f,_0x5ea42b-0x18))[_0x1ae13c(0x1a0)](_0xae4896);return hashLen16(rotate64(_0x270a6d[_0x1ae13c(0x4ed)](_0x51e4fe),0x2b)[_0x1ae13c(0x4ed)](rotate64(_0xaccf1,0x1e))[_0x1ae13c(0x4ed)](_0x1fe9a3),_0x270a6d[_0x1ae13c(0x4ed)](rotate64(_0x51e4fe[_0x1ae13c(0x4ed)](_0xdb1d20),0x12))[_0x1ae13c(0x4ed)](_0xaccf1),_0xae4896);}function fingerPrint64(_0x5c95f1,_0x45e181=_0x5c95f1[a0_0x20018c(0x104)]){const _0x6bec2e=a0_0x20018c,_0x318abc=Long['fromNumber'](0x51,!![]);if(_0x45e181<=0x20)return _0x45e181<=0x10?hashLen0to16(_0x5c95f1,_0x45e181):hashLen17to32(_0x5c95f1,_0x45e181);else{if(_0x45e181<=0x40)return hashLen33to64(_0x5c95f1,_0x45e181);}let _0x3fd7a7=_0x318abc,_0x58240c=_0x318abc['mul'](k1)[_0x6bec2e(0x4ed)](0x71),_0x193351=shiftMix(_0x58240c[_0x6bec2e(0x1a0)](k2)[_0x6bec2e(0x4ed)](0x71))['mul'](k2),_0x4f7c24=[Long[_0x6bec2e(0x2f1)],Long[_0x6bec2e(0x2f1)]],_0x2dc8ab=[Long[_0x6bec2e(0x2f1)],Long[_0x6bec2e(0x2f1)]];_0x3fd7a7=_0x3fd7a7[_0x6bec2e(0x1a0)](k2)['add'](fetch64(_0x5c95f1,0x0));let _0x59a611=0x0;const _0x15fe1f=(_0x45e181-0x1>>0x6)*0x40,_0xe6b6d5=_0x15fe1f+(_0x45e181-0x1&0x3f)-0x3f;do{_0x3fd7a7=rotate64(_0x3fd7a7['add'](_0x58240c)[_0x6bec2e(0x4ed)](_0x4f7c24[0x0])[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x8)),0x25)[_0x6bec2e(0x1a0)](k1),_0x58240c=rotate64(_0x58240c[_0x6bec2e(0x4ed)](_0x4f7c24[0x1])[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x30)),0x2a)[_0x6bec2e(0x1a0)](k1),_0x3fd7a7=_0x3fd7a7[_0x6bec2e(0x16d)](_0x2dc8ab[0x1]),_0x58240c=_0x58240c[_0x6bec2e(0x4ed)](_0x4f7c24[0x0])[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x28)),_0x193351=rotate64(_0x193351['add'](_0x2dc8ab[0x0]),0x21)['mul'](k1),_0x4f7c24=weakHashLen32WithSeedsStr(_0x5c95f1,_0x59a611,_0x4f7c24[0x1][_0x6bec2e(0x1a0)](k1),_0x3fd7a7['add'](_0x2dc8ab[0x0])),_0x2dc8ab=weakHashLen32WithSeedsStr(_0x5c95f1,_0x59a611+0x20,_0x193351[_0x6bec2e(0x4ed)](_0x2dc8ab[0x1]),_0x58240c[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x10))),[_0x193351,_0x3fd7a7]=[_0x3fd7a7,_0x193351],_0x59a611+=0x40;}while(_0x59a611!==_0x15fe1f);const _0x1141a0=k1[_0x6bec2e(0x4ed)](_0x193351[_0x6bec2e(0x4bd)](0xff)['shl'](0x1));return _0x59a611=_0xe6b6d5,_0x2dc8ab[0x0]=_0x2dc8ab[0x0]['add'](_0x45e181-0x1&0x3f),_0x4f7c24[0x0]=_0x4f7c24[0x0][_0x6bec2e(0x4ed)](_0x2dc8ab[0x0]),_0x2dc8ab[0x0]=_0x2dc8ab[0x0][_0x6bec2e(0x4ed)](_0x4f7c24[0x0]),_0x3fd7a7=rotate64(_0x3fd7a7[_0x6bec2e(0x4ed)](_0x58240c)[_0x6bec2e(0x4ed)](_0x4f7c24[0x0])[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x8)),0x25)[_0x6bec2e(0x1a0)](_0x1141a0),_0x58240c=rotate64(_0x58240c[_0x6bec2e(0x4ed)](_0x4f7c24[0x1])[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x30)),0x2a)[_0x6bec2e(0x1a0)](_0x1141a0),_0x3fd7a7=_0x3fd7a7[_0x6bec2e(0x16d)](_0x2dc8ab[0x1][_0x6bec2e(0x1a0)](0x9)),_0x58240c=_0x58240c[_0x6bec2e(0x4ed)](_0x4f7c24[0x0][_0x6bec2e(0x1a0)](0x9)[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x28))),_0x193351=rotate64(_0x193351[_0x6bec2e(0x4ed)](_0x2dc8ab[0x0]),0x21)[_0x6bec2e(0x1a0)](_0x1141a0),_0x4f7c24=weakHashLen32WithSeedsStr(_0x5c95f1,_0x59a611,_0x4f7c24[0x1]['mul'](_0x1141a0),_0x3fd7a7[_0x6bec2e(0x4ed)](_0x2dc8ab[0x0])),_0x2dc8ab=weakHashLen32WithSeedsStr(_0x5c95f1,_0x59a611+0x20,_0x193351[_0x6bec2e(0x4ed)](_0x2dc8ab[0x1]),_0x58240c[_0x6bec2e(0x4ed)](fetch64(_0x5c95f1,_0x59a611+0x10))),[_0x193351,_0x3fd7a7]=[_0x3fd7a7,_0x193351],hashLen16(hashLen16(_0x4f7c24[0x0],_0x2dc8ab[0x0],_0x1141a0)['add'](shiftMix(_0x58240c)[_0x6bec2e(0x1a0)](k0))[_0x6bec2e(0x4ed)](_0x193351),hashLen16(_0x4f7c24[0x1],_0x2dc8ab[0x1],_0x1141a0)['add'](_0x3fd7a7),_0x1141a0);}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function createScalarValue(_0x2d5a7f,_0x459aaf){const _0x182b31=a0_0x20018c;if(_0x459aaf===_0x182b31(0x5cf))return encodeString(_0x2d5a7f);return toTypedArray([_0x2d5a7f],_0x459aaf);}function noConversionNeeded(_0x5e6fef,_0x216c3d){const _0x49dd0a=a0_0x20018c;return _0x5e6fef instanceof Float32Array&&_0x216c3d===_0x49dd0a(0x28b)||_0x5e6fef instanceof Int32Array&&_0x216c3d===_0x49dd0a(0x4d1)||_0x5e6fef instanceof Uint8Array&&_0x216c3d===_0x49dd0a(0x188);}function toTypedArray(_0x2d5d35,_0x4bdb7f){const _0x1dd9f5=a0_0x20018c;if(_0x4bdb7f===_0x1dd9f5(0x5cf))throw new Error(_0x1dd9f5(0x194));Array[_0x1dd9f5(0x576)](_0x2d5d35)&&(_0x2d5d35=flatten(_0x2d5d35));env()[_0x1dd9f5(0x501)](_0x1dd9f5(0x153))&&checkConversionForErrors(_0x2d5d35,_0x4bdb7f);if(noConversionNeeded(_0x2d5d35,_0x4bdb7f))return _0x2d5d35;if(_0x4bdb7f==null||_0x4bdb7f===_0x1dd9f5(0x28b)||_0x4bdb7f===_0x1dd9f5(0xe8))return new Float32Array(_0x2d5d35);else{if(_0x4bdb7f==='int32')return new Int32Array(_0x2d5d35);else{if(_0x4bdb7f===_0x1dd9f5(0x188)){const _0x2d44ab=new Uint8Array(_0x2d5d35[_0x1dd9f5(0x104)]);for(let _0x234b6c=0x0;_0x234b6c<_0x2d44ab[_0x1dd9f5(0x104)];++_0x234b6c){Math[_0x1dd9f5(0x1f8)](_0x2d5d35[_0x234b6c])!==0x0&&(_0x2d44ab[_0x234b6c]=0x1);}return _0x2d44ab;}else throw new Error('Unknown\x20data\x20type\x20'+_0x4bdb7f);}}}function now(){const _0x1ee759=a0_0x20018c;return env()['platform'][_0x1ee759(0x3d4)]();}function fetch$1(_0x4f46ca,_0x47d719){const _0x277bda=a0_0x20018c;return env()['platform'][_0x277bda(0x43d)](_0x4f46ca,_0x47d719);}function encodeString(_0x4534cc,_0x2d99c8=a0_0x20018c(0x59b)){const _0x252d35=a0_0x20018c;return _0x2d99c8=_0x2d99c8||_0x252d35(0x59b),env()[_0x252d35(0x18e)][_0x252d35(0x227)](_0x4534cc,_0x2d99c8);}function decodeString(_0x4007af,_0x546dd1=a0_0x20018c(0x59b)){const _0x4cab6c=a0_0x20018c;return _0x546dd1=_0x546dd1||'utf-8',env()['platform'][_0x4cab6c(0x5a8)](_0x4007af,_0x546dd1);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class Profiler{constructor(_0x480404,_0x24e2b9){const _0x1089f9=a0_0x20018c;this['backendTimer']=_0x480404,this[_0x1089f9(0x573)]=_0x24e2b9,_0x24e2b9==null&&(this[_0x1089f9(0x573)]=new Logger());}[a0_0x20018c(0x23c)](_0x213686,_0x4718ef,_0x53b7a0){const _0x25e60=a0_0x20018c;let _0x203fa2;const _0x31e6fb=()=>{_0x203fa2=_0x53b7a0();};let _0x319c3e;const _0x46003e=now();if(this['backendTimer']['timerAvailable']())_0x319c3e=this[_0x25e60(0x3b7)][_0x25e60(0x5d5)](_0x31e6fb);else{_0x31e6fb();for(const _0xcbd9d of _0x203fa2){_0xcbd9d[_0x25e60(0x350)]();}_0x319c3e=Promise[_0x25e60(0x12a)]({'kernelMs':now()-_0x46003e});}if(env()[_0x25e60(0x501)](_0x25e60(0x359)))for(let _0x53fb03=0x0;_0x53fb03<_0x203fa2['length'];_0x53fb03++){const _0x3bc681=_0x203fa2[_0x53fb03];_0x3bc681['data']()[_0x25e60(0x236)](_0x478e44=>{const _0x4cac0c=_0x25e60;checkComputationForErrors(_0x478e44,_0x3bc681[_0x4cac0c(0x51c)],_0x213686);});}const _0x2064c1={'kernelName':_0x213686,'outputs':_0x203fa2,'inputs':_0x4718ef,'timeMs':_0x319c3e['then'](_0x555286=>_0x555286[_0x25e60(0x3df)]),'extraInfo':_0x319c3e['then'](_0x3a5ec2=>_0x3a5ec2['getExtraProfileInfo']!=null?_0x3a5ec2['getExtraProfileInfo']():'')};return _0x2064c1;}['logKernelProfile'](_0x3432f5){const {kernelName:_0x10e2bc,outputs:_0xce4dba,timeMs:_0x33074a,inputs:_0x280965,extraInfo:_0x153cc2}=_0x3432f5;_0xce4dba['forEach'](_0x22c23a=>{const _0x12fab9=a0_0x367f;Promise[_0x12fab9(0x21f)]([_0x22c23a[_0x12fab9(0x186)](),_0x33074a,_0x153cc2])[_0x12fab9(0x236)](_0x4bdbcf=>{const _0x4af348=_0x12fab9;this[_0x4af348(0x573)][_0x4af348(0x430)](_0x10e2bc,_0x22c23a,_0x4bdbcf[0x0],_0x4bdbcf[0x1],_0x280965,_0x4bdbcf[0x2]);});});}}function checkComputationForErrors(_0x46832d,_0x4a7e34,_0x3eb3dc){const _0x16bc48=a0_0x20018c;if(_0x4a7e34!==_0x16bc48(0x28b))return![];for(let _0x1e2c39=0x0;_0x1e2c39<_0x46832d[_0x16bc48(0x104)];_0x1e2c39++){const _0x617861=_0x46832d[_0x1e2c39];if(isNaN(_0x617861)||!isFinite(_0x617861))return console[_0x16bc48(0x297)]('Found\x20'+_0x617861+_0x16bc48(0x193)+_0x3eb3dc+'\x27'),!![];}return![];}class Logger{[a0_0x20018c(0x430)](_0x47b337,_0x236e26,_0x1ba497,_0x57a02a,_0x1c3cc8,_0x43d262){const _0xf610fd=a0_0x20018c,_0x136f82=typeof _0x57a02a==='number'?rightPad(_0x57a02a+'ms',0x9):_0x57a02a[_0xf610fd(0x2bb)],_0x159e9e=rightPad(_0x47b337,0x19),_0x2ee8ed=_0x236e26[_0xf610fd(0x36e)],_0x2b9868=_0x236e26[_0xf610fd(0x302)],_0x30f846=rightPad(_0x236e26['shape'][_0xf610fd(0x499)](),0xe);let _0x74d970='';for(const _0x40ec76 in _0x1c3cc8){const _0x2755a0=_0x1c3cc8[_0x40ec76];if(_0x2755a0!=null){const _0x211784=_0x2755a0[_0xf610fd(0x50f)]||_0x236e26[_0xf610fd(0x50f)],_0x1fedf3=_0x211784[_0xf610fd(0x104)];_0x74d970+=_0x40ec76+':\x20'+_0x1fedf3+'D\x20'+(_0x1fedf3>0x0?_0x211784:'')+'\x20';}}console[_0xf610fd(0x4d2)]('%c'+_0x159e9e+'\x09%c'+_0x136f82+_0xf610fd(0x189)+_0x2ee8ed+'D\x20'+_0x30f846+_0xf610fd(0x189)+_0x2b9868+_0xf610fd(0x189)+_0x74d970+_0xf610fd(0x189)+_0x43d262,'font-weight:bold',_0xf610fd(0x4ab),_0xf610fd(0x4b4),'color:\x20orange',_0xf610fd(0x174),_0xf610fd(0x3b4));}}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function getFilteredNodesXToY(_0xfcaf9f,_0x4f00ae,_0x284508){const _0x27def4=a0_0x20018c,_0x472592={},_0x543b45={};for(let _0x5da694=0x0;_0x5da694<_0x4f00ae['length'];_0x5da694++){_0x472592[_0x4f00ae[_0x5da694]['id']]=!![];}for(let _0x407bcd=0x0;_0x407bcd<_0xfcaf9f[_0x27def4(0x104)];_0x407bcd++){const _0x5e98e5=_0xfcaf9f[_0x407bcd],_0x420a8a=_0x5e98e5[_0x27def4(0x462)];for(const _0x4ed84a in _0x420a8a){const _0x20d078=_0x420a8a[_0x4ed84a];let _0x1aaa23=![];for(let _0x3da921=0x0;_0x3da921<_0x4f00ae['length'];_0x3da921++){if(_0x472592[_0x20d078['id']]){_0x5e98e5[_0x27def4(0x1c9)]['forEach'](_0x2c3217=>_0x472592[_0x2c3217['id']]=!![]),_0x1aaa23=!![],_0x543b45[_0x5e98e5['id']]=!![];break;}}if(_0x1aaa23)break;}}const _0x563e5f={};_0x563e5f[_0x284508['id']]=!![];const _0x5014f7={};for(let _0x820424=_0xfcaf9f[_0x27def4(0x104)]-0x1;_0x820424>=0x0;_0x820424--){const _0x1f07e2=_0xfcaf9f[_0x820424],_0x4208a3=_0x1f07e2[_0x27def4(0x462)];for(let _0x2f3496=0x0;_0x2f3496<_0x1f07e2[_0x27def4(0x1c9)][_0x27def4(0x104)];_0x2f3496++){if(_0x563e5f[_0x1f07e2['outputs'][_0x2f3496]['id']]){for(const _0x50b44c in _0x4208a3){_0x563e5f[_0x4208a3[_0x50b44c]['id']]=!![],_0x5014f7[_0x1f07e2['id']]=!![];}break;}}}const _0x54f641=[];for(let _0x21c1b2=0x0;_0x21c1b2<_0xfcaf9f[_0x27def4(0x104)];_0x21c1b2++){const _0x273374=_0xfcaf9f[_0x21c1b2];if(_0x543b45[_0x273374['id']]&&_0x5014f7[_0x273374['id']]){const _0x9d6275={};for(const _0x3b6815 in _0x273374[_0x27def4(0x462)]){const _0x5e3239=_0x273374['inputs'][_0x3b6815];_0x472592[_0x5e3239['id']]&&(_0x9d6275[_0x3b6815]=_0x5e3239);}const _0x1b0174=Object['assign']({},_0x273374);_0x1b0174[_0x27def4(0x462)]=_0x9d6275,_0x1b0174['outputs']=_0x273374['outputs'],_0x54f641[_0x27def4(0x30f)](_0x1b0174);}}return _0x54f641;}function backpropagateGradients(_0x530132,_0x40fa4d,_0x755acc,_0x168392){const _0x3c9a9d=a0_0x20018c;for(let _0x3a91ee=_0x40fa4d['length']-0x1;_0x3a91ee>=0x0;_0x3a91ee--){const _0x3d863f=_0x40fa4d[_0x3a91ee],_0xe2d40f=[];_0x3d863f[_0x3c9a9d(0x1c9)][_0x3c9a9d(0x1e4)](_0x34dd94=>{const _0x4cb46a=_0x3c9a9d,_0x4ffb7f=_0x530132[_0x34dd94['id']];_0x4ffb7f!=null?_0xe2d40f[_0x4cb46a(0x30f)](_0x4ffb7f):_0xe2d40f['push'](null);});if(_0x3d863f['gradient']==null)throw new Error(_0x3c9a9d(0x126)+(_0x3c9a9d(0x533)+_0x3d863f[_0x3c9a9d(0x2b4)]+'.'));const _0x4aa7be=_0x3d863f[_0x3c9a9d(0x115)](_0xe2d40f);for(const _0x3195e7 in _0x3d863f['inputs']){if(!(_0x3195e7 in _0x4aa7be))throw new Error(_0x3c9a9d(0x34c)+_0x3195e7+'.\x20'+(_0x3c9a9d(0x127)+Object['keys'](_0x4aa7be)+'.'));const _0x330ecc=_0x755acc(()=>_0x4aa7be[_0x3195e7]());if(_0x330ecc['dtype']!==_0x3c9a9d(0x28b))throw new Error(_0x3c9a9d(0x25a)+_0x3d863f[_0x3c9a9d(0x2b4)]+'.\x20The\x20gradient\x20of\x20input\x20'+(_0x3195e7+_0x3c9a9d(0x22b)+_0x330ecc[_0x3c9a9d(0x51c)]+'\x27'));const _0x3fa611=_0x3d863f[_0x3c9a9d(0x462)][_0x3195e7];if(!arraysEqual(_0x330ecc[_0x3c9a9d(0x50f)],_0x3fa611[_0x3c9a9d(0x50f)]))throw new Error(_0x3c9a9d(0x25a)+_0x3d863f[_0x3c9a9d(0x2b4)]+_0x3c9a9d(0xe7)+('\x27'+_0x3195e7+_0x3c9a9d(0x51d)+_0x330ecc[_0x3c9a9d(0x50f)]+_0x3c9a9d(0x342))+('the\x20shape\x20of\x20the\x20input\x20\x27'+_0x3fa611[_0x3c9a9d(0x50f)]+'\x27'));if(_0x530132[_0x3fa611['id']]==null)_0x530132[_0x3fa611['id']]=_0x330ecc;else{const _0x27317b=_0x530132[_0x3fa611['id']];_0x530132[_0x3fa611['id']]=_0x168392(_0x27317b,_0x330ecc),_0x27317b[_0x3c9a9d(0x47d)]();}}}}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const FORMAT_LIMIT_NUM_VALS=0x14,FORMAT_NUM_FIRST_LAST_VALS=0x3,FORMAT_NUM_SIG_DIGITS=0x7;function tensorToString(_0x49cc76,_0x1ba79c,_0x27a57b,_0x4b3d9c){const _0x294594=a0_0x20018c,_0x327749=computeStrides(_0x1ba79c),_0x55fed2=computeMaxSizePerColumn(_0x49cc76,_0x1ba79c,_0x27a57b,_0x327749),_0x12ff1b=_0x1ba79c[_0x294594(0x104)],_0x2bfba7=subTensorToString(_0x49cc76,_0x1ba79c,_0x27a57b,_0x327749,_0x55fed2),_0x2a0366=['Tensor'];return _0x4b3d9c&&(_0x2a0366['push'](_0x294594(0x230)+_0x27a57b),_0x2a0366['push']('\x20\x20rank:\x20'+_0x12ff1b),_0x2a0366[_0x294594(0x30f)](_0x294594(0x479)+_0x1ba79c+']'),_0x2a0366[_0x294594(0x30f)](_0x294594(0x208))),_0x2a0366['push'](_0x2bfba7['map'](_0x42380a=>'\x20\x20\x20\x20'+_0x42380a)[_0x294594(0x46d)]('\x0a')),_0x2a0366['join']('\x0a');}function computeMaxSizePerColumn(_0xe8a8b1,_0x10e89f,_0x1c18d5,_0x3aeb02){const _0x162209=a0_0x20018c,_0x1a2ed1=sizeFromShape(_0x10e89f),_0x2f027c=_0x3aeb02[_0x3aeb02['length']-0x1],_0x3a9177=new Array(_0x2f027c)['fill'](0x0),_0x58ecfd=_0x10e89f['length'],_0x27b6f9=_0x1c18d5===_0x162209(0xe8)?createComplexTuples(_0xe8a8b1):_0xe8a8b1;if(_0x58ecfd>0x1)for(let _0x2ccc69=0x0;_0x2ccc69<_0x1a2ed1/_0x2f027c;_0x2ccc69++){const _0x2e3c09=_0x2ccc69*_0x2f027c;for(let _0x36b084=0x0;_0x36b084<_0x2f027c;_0x36b084++){_0x3a9177[_0x36b084]=Math['max'](_0x3a9177[_0x36b084],valToString(_0x27b6f9[_0x2e3c09+_0x36b084],0x0,_0x1c18d5)[_0x162209(0x104)]);}}return _0x3a9177;}function valToString(_0x44e582,_0x21b9c4,_0x40a984){const _0x37b171=a0_0x20018c;let _0x3a5439;if(Array['isArray'](_0x44e582))_0x3a5439=parseFloat(_0x44e582[0x0][_0x37b171(0x4b3)](FORMAT_NUM_SIG_DIGITS))+'\x20+\x20'+(parseFloat(_0x44e582[0x1]['toFixed'](FORMAT_NUM_SIG_DIGITS))+'j');else{if(isString(_0x44e582))_0x3a5439='\x27'+_0x44e582+'\x27';else _0x40a984===_0x37b171(0x188)?_0x3a5439=boolNumToString(_0x44e582):_0x3a5439=parseFloat(_0x44e582[_0x37b171(0x4b3)](FORMAT_NUM_SIG_DIGITS))['toString']();}return rightPad(_0x3a5439,_0x21b9c4);}function boolNumToString(_0x89990d){const _0x419c9a=a0_0x20018c;return _0x89990d===0x0?'false':_0x419c9a(0x1b9);}function subTensorToString(_0x2c0cad,_0x1376c4,_0x4efdcb,_0x311ecc,_0x27e90c,_0x3aaca9=!![]){const _0x538764=a0_0x20018c,_0x1cb930=_0x4efdcb==='complex64'?0x2:0x1,_0x221716=_0x1376c4[0x0],_0x3014ac=_0x1376c4[_0x538764(0x104)];if(_0x3014ac===0x0){if(_0x4efdcb===_0x538764(0xe8)){const _0x36c3f5=createComplexTuples(_0x2c0cad);return[valToString(_0x36c3f5[0x0],0x0,_0x4efdcb)];}if(_0x4efdcb===_0x538764(0x188))return[boolNumToString(_0x2c0cad[0x0])];return[_0x2c0cad[0x0]['toString']()];}if(_0x3014ac===0x1){if(_0x221716>FORMAT_LIMIT_NUM_VALS){const _0x1b6ed7=FORMAT_NUM_FIRST_LAST_VALS*_0x1cb930;let _0x3ed872=Array['from'](_0x2c0cad['slice'](0x0,_0x1b6ed7)),_0x37925e=Array[_0x538764(0x530)](_0x2c0cad['slice']((_0x221716-FORMAT_NUM_FIRST_LAST_VALS)*_0x1cb930,_0x221716*_0x1cb930));return _0x4efdcb===_0x538764(0xe8)&&(_0x3ed872=createComplexTuples(_0x3ed872),_0x37925e=createComplexTuples(_0x37925e)),['['+_0x3ed872['map']((_0x324ee0,_0x38b7da)=>valToString(_0x324ee0,_0x27e90c[_0x38b7da],_0x4efdcb))[_0x538764(0x46d)](',\x20')+',\x20...,\x20'+_0x37925e[_0x538764(0x3ab)]((_0x257b08,_0x5bda17)=>valToString(_0x257b08,_0x27e90c[_0x221716-FORMAT_NUM_FIRST_LAST_VALS+_0x5bda17],_0x4efdcb))[_0x538764(0x46d)](',\x20')+']'];}const _0x2f09c4=_0x4efdcb===_0x538764(0xe8)?createComplexTuples(_0x2c0cad):Array[_0x538764(0x530)](_0x2c0cad);return['['+_0x2f09c4['map']((_0x403154,_0x5bf7cb)=>valToString(_0x403154,_0x27e90c[_0x5bf7cb],_0x4efdcb))[_0x538764(0x46d)](',\x20')+']'];}const _0x433bd7=_0x1376c4[_0x538764(0x2b0)](0x1),_0x5d8926=_0x311ecc['slice'](0x1),_0x14a22f=_0x311ecc[0x0]*_0x1cb930,_0x225e53=[];if(_0x221716>FORMAT_LIMIT_NUM_VALS){for(let _0x5891f5=0x0;_0x5891f5<FORMAT_NUM_FIRST_LAST_VALS;_0x5891f5++){const _0x590630=_0x5891f5*_0x14a22f,_0x30afd6=_0x590630+_0x14a22f;_0x225e53['push'](...subTensorToString(_0x2c0cad['slice'](_0x590630,_0x30afd6),_0x433bd7,_0x4efdcb,_0x5d8926,_0x27e90c,![]));}_0x225e53[_0x538764(0x30f)](_0x538764(0x2f2));for(let _0x30b112=_0x221716-FORMAT_NUM_FIRST_LAST_VALS;_0x30b112<_0x221716;_0x30b112++){const _0x17bda5=_0x30b112*_0x14a22f,_0x4d8817=_0x17bda5+_0x14a22f;_0x225e53[_0x538764(0x30f)](...subTensorToString(_0x2c0cad[_0x538764(0x2b0)](_0x17bda5,_0x4d8817),_0x433bd7,_0x4efdcb,_0x5d8926,_0x27e90c,_0x30b112===_0x221716-0x1));}}else for(let _0x43b245=0x0;_0x43b245<_0x221716;_0x43b245++){const _0x3ceb98=_0x43b245*_0x14a22f,_0x509fa8=_0x3ceb98+_0x14a22f;_0x225e53[_0x538764(0x30f)](...subTensorToString(_0x2c0cad[_0x538764(0x2b0)](_0x3ceb98,_0x509fa8),_0x433bd7,_0x4efdcb,_0x5d8926,_0x27e90c,_0x43b245===_0x221716-0x1));}const _0x1dc9a1=_0x3014ac===0x2?',':'';_0x225e53[0x0]='['+_0x225e53[0x0]+_0x1dc9a1;for(let _0x485856=0x1;_0x485856<_0x225e53[_0x538764(0x104)]-0x1;_0x485856++){_0x225e53[_0x485856]='\x20'+_0x225e53[_0x485856]+_0x1dc9a1;}let _0x32b7ae=',\x0a';for(let _0x2124ff=0x2;_0x2124ff<_0x3014ac;_0x2124ff++){_0x32b7ae+='\x0a';}return _0x225e53[_0x225e53[_0x538764(0x104)]-0x1]='\x20'+_0x225e53[_0x225e53[_0x538764(0x104)]-0x1]+']'+(_0x3aaca9?'':_0x32b7ae),_0x225e53;}function createComplexTuples(_0x5df5b6){const _0x1d1b64=a0_0x20018c,_0x17654c=[];for(let _0x29683a=0x0;_0x29683a<_0x5df5b6['length'];_0x29683a+=0x2){_0x17654c[_0x1d1b64(0x30f)]([_0x5df5b6[_0x29683a],_0x5df5b6[_0x29683a+0x1]]);}return _0x17654c;}/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class TensorBuffer{constructor(_0x5b46bc,_0x317fc3,_0x1b720e){const _0x2734e4=a0_0x20018c;this[_0x2734e4(0x51c)]=_0x317fc3,this[_0x2734e4(0x50f)]=_0x5b46bc[_0x2734e4(0x2b0)](),this[_0x2734e4(0x302)]=sizeFromShape(_0x5b46bc);if(_0x1b720e!=null){const _0xa9cd18=_0x1b720e[_0x2734e4(0x104)];assert(_0xa9cd18===this[_0x2734e4(0x302)],()=>'Length\x20of\x20values\x20\x27'+_0xa9cd18+_0x2734e4(0x3c8)+(_0x2734e4(0x55a)+this[_0x2734e4(0x302)]+'\x27.'));}if(_0x317fc3===_0x2734e4(0xe8))throw new Error('complex64\x20dtype\x20TensorBuffers\x20are\x20not\x20supported.\x20Please\x20create\x20'+_0x2734e4(0x3c1)+_0x2734e4(0x3ce));this[_0x2734e4(0x313)]=_0x1b720e||getArrayFromDType(_0x317fc3,this['size']),this[_0x2734e4(0x1b1)]=computeStrides(_0x5b46bc);}[a0_0x20018c(0x5a6)](_0x3b16b7,..._0x9c0dd){const _0x484007=a0_0x20018c;_0x9c0dd[_0x484007(0x104)]===0x0&&(_0x9c0dd=[0x0]);assert(_0x9c0dd[_0x484007(0x104)]===this['rank'],()=>_0x484007(0x2be)+_0x9c0dd['length']+_0x484007(0x102)+(_0x484007(0x58a)+this['rank']+')'));const _0xfd35c7=this[_0x484007(0x263)](_0x9c0dd);this['values'][_0xfd35c7]=_0x3b16b7;}[a0_0x20018c(0x40f)](..._0x47e068){const _0x494678=a0_0x20018c;_0x47e068[_0x494678(0x104)]===0x0&&(_0x47e068=[0x0]);let _0x5e7602=0x0;for(const _0x2b2d86 of _0x47e068){if(_0x2b2d86<0x0||_0x2b2d86>=this[_0x494678(0x50f)][_0x5e7602]){const _0x40cca8='Requested\x20out\x20of\x20range\x20element\x20at\x20'+_0x47e068+'.\x20'+(_0x494678(0x29b)+this[_0x494678(0x50f)]);throw new Error(_0x40cca8);}_0x5e7602++;}let _0x51815a=_0x47e068[_0x47e068['length']-0x1];for(let _0x3330cf=0x0;_0x3330cf<_0x47e068['length']-0x1;++_0x3330cf){_0x51815a+=this['strides'][_0x3330cf]*_0x47e068[_0x3330cf];}return this[_0x494678(0x313)][_0x51815a];}['locToIndex'](_0x4f0b0a){const _0x53dfce=a0_0x20018c;if(this[_0x53dfce(0x36e)]===0x0)return 0x0;else{if(this[_0x53dfce(0x36e)]===0x1)return _0x4f0b0a[0x0];}let _0x2d3098=_0x4f0b0a[_0x4f0b0a[_0x53dfce(0x104)]-0x1];for(let _0x397706=0x0;_0x397706<_0x4f0b0a[_0x53dfce(0x104)]-0x1;++_0x397706){_0x2d3098+=this[_0x53dfce(0x1b1)][_0x397706]*_0x4f0b0a[_0x397706];}return _0x2d3098;}[a0_0x20018c(0xe4)](_0x529df0){const _0x18940f=a0_0x20018c;if(this[_0x18940f(0x36e)]===0x0)return[];else{if(this[_0x18940f(0x36e)]===0x1)return[_0x529df0];}const _0x554366=new Array(this[_0x18940f(0x50f)][_0x18940f(0x104)]);for(let _0x847667=0x0;_0x847667<_0x554366[_0x18940f(0x104)]-0x1;++_0x847667){_0x554366[_0x847667]=Math[_0x18940f(0x476)](_0x529df0/this[_0x18940f(0x1b1)][_0x847667]),_0x529df0-=_0x554366[_0x847667]*this[_0x18940f(0x1b1)][_0x847667];}return _0x554366[_0x554366['length']-0x1]=_0x529df0,_0x554366;}get[a0_0x20018c(0x36e)](){const _0x343afe=a0_0x20018c;return this[_0x343afe(0x50f)][_0x343afe(0x104)];}[a0_0x20018c(0x21a)](){const _0x1a5ff5=a0_0x20018c;return trackerFn()[_0x1a5ff5(0x210)](this['values'],this['shape'],this[_0x1a5ff5(0x51c)]);}}let trackerFn=null,opHandler=null,deprecationWarningFn=null;[deprecationWarningFn];function setTensorTracker(_0x59cb30){trackerFn=_0x59cb30;}function setOpHandler(_0x4f5fa8){opHandler=_0x4f5fa8;}function setDeprecationWarningFn(_0x163570){deprecationWarningFn=_0x163570;}class Tensor{constructor(_0x311611,_0x2ad715,_0x46d421,_0x2bd5af){const _0x50777b=a0_0x20018c;this[_0x50777b(0x25d)]=![],this[_0x50777b(0x4fc)]=![],this[_0x50777b(0x50f)]=_0x311611['slice'](),this['dtype']=_0x2ad715||_0x50777b(0x28b),this['size']=sizeFromShape(_0x311611),this['strides']=computeStrides(_0x311611),this['dataId']=_0x46d421,this['id']=_0x2bd5af,this[_0x50777b(0x27e)]=this[_0x50777b(0x36e)]<0x5?this[_0x50777b(0x36e)]['toString']():_0x50777b(0x3c7);}get[a0_0x20018c(0x36e)](){const _0x37c97a=a0_0x20018c;return this[_0x37c97a(0x50f)][_0x37c97a(0x104)];}async[a0_0x20018c(0x4f1)](){const _0x177028=a0_0x20018c,_0x323243=await this[_0x177028(0x186)]();return opHandler['buffer'](this['shape'],this[_0x177028(0x51c)],_0x323243);}[a0_0x20018c(0x267)](){const _0x4d64d0=a0_0x20018c;return opHandler[_0x4d64d0(0x4f1)](this[_0x4d64d0(0x50f)],this[_0x4d64d0(0x51c)],this[_0x4d64d0(0x350)]());}async['array'](){const _0x3dc5a1=a0_0x20018c,_0x216186=await this[_0x3dc5a1(0x186)]();return toNestedArray(this[_0x3dc5a1(0x50f)],_0x216186,this[_0x3dc5a1(0x51c)]===_0x3dc5a1(0xe8));}[a0_0x20018c(0x105)](){const _0xcba98e=a0_0x20018c;return toNestedArray(this[_0xcba98e(0x50f)],this[_0xcba98e(0x350)](),this[_0xcba98e(0x51c)]==='complex64');}async['data'](){const _0x12f0c4=a0_0x20018c;this['throwIfDisposed']();const _0x142811=trackerFn()[_0x12f0c4(0x405)](this['dataId']);if(this[_0x12f0c4(0x51c)]===_0x12f0c4(0x5cf)){const _0x11df4e=await _0x142811;try{return _0x11df4e[_0x12f0c4(0x3ab)](_0x443674=>decodeString(_0x443674));}catch(_0x4bf0d7){throw new Error(_0x12f0c4(0x44f)+_0x12f0c4(0x219));}}return _0x142811;}[a0_0x20018c(0x350)](){const _0x540d82=a0_0x20018c;this[_0x540d82(0x39e)]();const _0x1c7edf=trackerFn()[_0x540d82(0x381)](this['dataId']);if(this['dtype']==='string')try{return _0x1c7edf[_0x540d82(0x3ab)](_0x299d14=>decodeString(_0x299d14));}catch(_0x1d3409){throw new Error(_0x540d82(0x44f)+_0x540d82(0x219));}return _0x1c7edf;}async[a0_0x20018c(0x1f5)](){const _0x4fa605=a0_0x20018c;this[_0x4fa605(0x39e)]();const _0x1d0bfb=await trackerFn()[_0x4fa605(0x405)](this['dataId']);return this['dtype']===_0x4fa605(0x5cf)?_0x1d0bfb:new Uint8Array(_0x1d0bfb['buffer']);}[a0_0x20018c(0x47d)](){const _0x35d9a6=a0_0x20018c;if(this[_0x35d9a6(0x11c)])return;trackerFn()[_0x35d9a6(0x101)](this),this['isDisposedInternal']=!![];}get[a0_0x20018c(0x11c)](){const _0x209d57=a0_0x20018c;return this[_0x209d57(0x4fc)];}[a0_0x20018c(0x39e)](){const _0x1bbf3e=a0_0x20018c;if(this[_0x1bbf3e(0x11c)])throw new Error(_0x1bbf3e(0x24c));}['print'](_0x1294d7=![]){const _0x5bbc4c=a0_0x20018c;return opHandler[_0x5bbc4c(0x37a)](this,_0x1294d7);}[a0_0x20018c(0x49d)](){const _0x42b95e=a0_0x20018c;return this[_0x42b95e(0x39e)](),opHandler['clone'](this);}[a0_0x20018c(0x499)](_0x2e0fee=![]){const _0x38d32b=a0_0x20018c,_0x5e898a=this[_0x38d32b(0x350)]();return tensorToString(_0x5e898a,this['shape'],this[_0x38d32b(0x51c)],_0x2e0fee);}['cast'](_0x27959e){const _0x1504a5=a0_0x20018c;return this[_0x1504a5(0x39e)](),opHandler['cast'](this,_0x27959e);}[a0_0x20018c(0x217)](_0x838963=!![],_0x26fa70,_0x1e97f4){return this['throwIfDisposed'](),trackerFn()['makeVariable'](this,_0x838963,_0x26fa70,_0x1e97f4);}}Object[a0_0x20018c(0x41d)](Tensor,Symbol['hasInstance'],{'value':_0x30c0fb=>{const _0x3fa1a9=a0_0x20018c;return!!_0x30c0fb&&_0x30c0fb[_0x3fa1a9(0x186)]!=null&&_0x30c0fb[_0x3fa1a9(0x350)]!=null&&_0x30c0fb[_0x3fa1a9(0x39e)]!=null;}});function getGlobalTensorClass(){const _0x5bce6a=a0_0x20018c;return getGlobal(_0x5bce6a(0xf3),()=>{return Tensor;});}getGlobalTensorClass();class Variable extends Tensor{constructor(_0x1dd4b4,_0x706022,_0x3a8953,_0x59c34c){const _0x2953e2=a0_0x20018c;super(_0x1dd4b4[_0x2953e2(0x50f)],_0x1dd4b4['dtype'],_0x1dd4b4[_0x2953e2(0x42c)],_0x59c34c),this[_0x2953e2(0x3f1)]=_0x706022,this['name']=_0x3a8953;}[a0_0x20018c(0xe3)](_0x474ea3){const _0x4b405c=a0_0x20018c;if(_0x474ea3[_0x4b405c(0x51c)]!==this[_0x4b405c(0x51c)])throw new Error(_0x4b405c(0x149)+_0x474ea3[_0x4b405c(0x51c)]+_0x4b405c(0x1b2)+(_0x4b405c(0x4af)+this[_0x4b405c(0x51c)]+_0x4b405c(0x4da)));if(!arraysEqual(_0x474ea3[_0x4b405c(0x50f)],this['shape']))throw new Error(_0x4b405c(0x314)+_0x474ea3[_0x4b405c(0x50f)]+')\x20and\x20'+(_0x4b405c(0x4af)+this[_0x4b405c(0x50f)]+_0x4b405c(0x4da)));trackerFn()[_0x4b405c(0x101)](this),this['dataId']=_0x474ea3['dataId'],trackerFn()['incRef'](this,null);}['dispose'](){const _0x278457=a0_0x20018c;trackerFn()[_0x278457(0x311)](this),this[_0x278457(0x4fc)]=!![];}}Object[a0_0x20018c(0x41d)](Variable,Symbol[a0_0x20018c(0x519)],{'value':_0x234f1b=>{const _0x2d96d9=a0_0x20018c;return _0x234f1b instanceof Tensor&&_0x234f1b[_0x2d96d9(0xe3)]!=null&&_0x234f1b[_0x2d96d9(0xe3)]instanceof Function;}});/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
var Rank;(function(_0x305d7e){_0x305d7e['R0']='R0',_0x305d7e['R1']='R1',_0x305d7e['R2']='R2',_0x305d7e['R3']='R3',_0x305d7e['R4']='R4',_0x305d7e['R5']='R5',_0x305d7e['R6']='R6';}(Rank||(Rank={})));var UpcastInt32AndMap;(function(_0x299789){const _0x1a0251=a0_0x20018c;_0x299789[_0x1a0251(0x28b)]='float32',_0x299789[_0x1a0251(0x4d1)]=_0x1a0251(0x4d1),_0x299789[_0x1a0251(0x188)]=_0x1a0251(0x4d1),_0x299789['complex64']='complex64';}(UpcastInt32AndMap||(UpcastInt32AndMap={})));var UpcastBoolAndMap;(function(_0x5790bb){const _0x5275ce=a0_0x20018c;_0x5790bb[_0x5275ce(0x28b)]=_0x5275ce(0x28b),_0x5790bb['int32']='int32',_0x5790bb[_0x5275ce(0x188)]=_0x5275ce(0x188),_0x5790bb[_0x5275ce(0xe8)]='complex64';}(UpcastBoolAndMap||(UpcastBoolAndMap={})));var UpcastFloat32AndMap;(function(_0x3b257f){const _0x299662=a0_0x20018c;_0x3b257f['float32']='float32',_0x3b257f['int32']=_0x299662(0x28b),_0x3b257f['bool']='float32',_0x3b257f[_0x299662(0xe8)]=_0x299662(0xe8);}(UpcastFloat32AndMap||(UpcastFloat32AndMap={})));var UpcastComplex64AndMap;(function(_0x5ad25e){const _0x1389dd=a0_0x20018c;_0x5ad25e[_0x1389dd(0x28b)]=_0x1389dd(0xe8),_0x5ad25e['int32']=_0x1389dd(0xe8),_0x5ad25e[_0x1389dd(0x188)]='complex64',_0x5ad25e[_0x1389dd(0xe8)]=_0x1389dd(0xe8);}(UpcastComplex64AndMap||(UpcastComplex64AndMap={})));const upcastTypeMap={'float32':UpcastFloat32AndMap,'int32':UpcastInt32AndMap,'bool':UpcastBoolAndMap,'complex64':UpcastComplex64AndMap};function upcastType(_0x389f16,_0x55fb18){const _0x2070fe=a0_0x20018c;if(_0x389f16===_0x2070fe(0x5cf)||_0x55fb18===_0x2070fe(0x5cf)){if(_0x389f16==='string'&&_0x55fb18==='string')return _0x2070fe(0x5cf);throw new Error(_0x2070fe(0x457)+_0x389f16+'\x20with\x20'+_0x55fb18);}return upcastTypeMap[_0x389f16][_0x55fb18];}function sumOutType(_0x1f93cb){const _0x58c39d=a0_0x20018c;return upcastType(_0x1f93cb,_0x58c39d(0x4d1));}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function makeTypesMatch(_0x424e68,_0x2af56a){const _0x10ccac=a0_0x20018c;if(_0x424e68[_0x10ccac(0x51c)]===_0x2af56a['dtype'])return[_0x424e68,_0x2af56a];const _0x324059=upcastType(_0x424e68[_0x10ccac(0x51c)],_0x2af56a[_0x10ccac(0x51c)]);return[_0x424e68['cast'](_0x324059),_0x2af56a[_0x10ccac(0x335)](_0x324059)];}function assertTypesMatch(_0x1d1d88,_0xbe88c6){const _0x2c8abe=a0_0x20018c;assert(_0x1d1d88[_0x2c8abe(0x51c)]===_0xbe88c6['dtype'],()=>_0x2c8abe(0x3a1)+_0x1d1d88[_0x2c8abe(0x51c)]+')\x20and'+(_0x2c8abe(0x41e)+_0xbe88c6[_0x2c8abe(0x51c)]+_0x2c8abe(0x309)));}function isTensorInList(_0x526e23,_0x20fca2){const _0x397442=a0_0x20018c;return _0x20fca2[_0x397442(0x128)](_0x4bfc10=>_0x4bfc10['id']===_0x526e23['id']);}function getTensorsInContainer(_0x2af13b){const _0x2d9728=[],_0x2c9d00=new Set();return walkTensorContainer(_0x2af13b,_0x2d9728,_0x2c9d00),_0x2d9728;}function walkTensorContainer(_0x3fecea,_0x2335a0,_0x3b6fef){const _0x42817f=a0_0x20018c;if(_0x3fecea==null)return;if(_0x3fecea instanceof Tensor){_0x2335a0[_0x42817f(0x30f)](_0x3fecea);return;}if(!isIterable(_0x3fecea))return;const _0x5410df=_0x3fecea;for(const _0x38697f in _0x5410df){const _0xb048fb=_0x5410df[_0x38697f];!_0x3b6fef[_0x42817f(0x18a)](_0xb048fb)&&(_0x3b6fef['add'](_0xb048fb),walkTensorContainer(_0xb048fb,_0x2335a0,_0x3b6fef));}}function isIterable(_0x525dc4){const _0x4ec9db=a0_0x20018c;return Array['isArray'](_0x525dc4)||typeof _0x525dc4===_0x4ec9db(0x130);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function isRegisteredKernelInvocation(_0x330305){const _0x26b62e=a0_0x20018c;return _0x330305[_0x26b62e(0x2b4)]!=null;}class EngineState{constructor(){const _0x16bac0=a0_0x20018c;this[_0x16bac0(0x52c)]={},this['nextTapeNodeId']=0x0,this[_0x16bac0(0x2b6)]=0x0,this[_0x16bac0(0x2a8)]=0x0,this[_0x16bac0(0x1db)]=0x0,this['numDataBuffers']=0x0,this[_0x16bac0(0x1c8)]=0x0,this['kernelDepth']=0x0,this[_0x16bac0(0x15b)]=[],this[_0x16bac0(0x383)]=[],this[_0x16bac0(0x179)]=0x0,this[_0x16bac0(0x55b)]=new WeakMap(),this[_0x16bac0(0x401)]=![],this['activeProfile']={'newBytes':0x0,'newTensors':0x0,'peakBytes':0x0,'kernels':[],'result':null,get 'kernelNames'(){const _0x567bd5=_0x16bac0;return Array[_0x567bd5(0x530)](new Set(this[_0x567bd5(0x580)][_0x567bd5(0x3ab)](_0x1ab97f=>_0x1ab97f[_0x567bd5(0x1aa)])));}};}[a0_0x20018c(0x47d)](){const _0x2cf1cb=a0_0x20018c;for(const _0x41940d in this['registeredVariables']){this[_0x2cf1cb(0x52c)][_0x41940d][_0x2cf1cb(0x47d)]();}}}class Engine{constructor(_0x19db6e){const _0x2e3321=a0_0x20018c;this[_0x2e3321(0x303)]=_0x19db6e,this[_0x2e3321(0x5b8)]={},this['registryFactory']={},this[_0x2e3321(0x4cc)]=0x0,this[_0x2e3321(0x23a)]=new EngineState();}async[a0_0x20018c(0x307)](){const _0x15698d=a0_0x20018c;if(this['pendingBackendInit']!=null)return this['pendingBackendInit'][_0x15698d(0x236)](()=>{});if(this[_0x15698d(0x5a3)]!=null)return;const _0x5c68e5=this[_0x15698d(0x1a5)]();for(let _0x2b62bd=0x0;_0x2b62bd<_0x5c68e5[_0x15698d(0x104)];_0x2b62bd++){const _0x3cfe9e=_0x5c68e5[_0x2b62bd],_0x38bf3b=await this[_0x15698d(0x347)](_0x3cfe9e)['success'];if(_0x38bf3b){await this['setBackend'](_0x3cfe9e);return;}}throw new Error(_0x15698d(0x556)+_0x15698d(0x20f));}get[a0_0x20018c(0x162)](){const _0x1ffdff=a0_0x20018c;if(this[_0x1ffdff(0x4d3)]!=null)throw new Error(_0x1ffdff(0x156)+this[_0x1ffdff(0x453)]+_0x1ffdff(0x1d6)+_0x1ffdff(0x1da)+'other\x20methods');if(this['backendInstance']==null){const {name:_0x2ed445,asyncInit:_0x4bed34}=this[_0x1ffdff(0x549)]();if(_0x4bed34)throw new Error(_0x1ffdff(0x18f)+_0x2ed445+_0x1ffdff(0x198)+'initialized.\x20Make\x20sure\x20to\x20await\x20tf.ready()\x20or\x20'+'await\x20tf.setBackend()\x20before\x20calling\x20other\x20methods');this[_0x1ffdff(0x544)](_0x2ed445);}return this[_0x1ffdff(0x5a3)];}[a0_0x20018c(0x151)](){const _0x4ebbf6=a0_0x20018c;return Object['keys'](this[_0x4ebbf6(0x362)]);}[a0_0x20018c(0x261)](_0x1a012f){const _0x86dc1d=a0_0x20018c;if(!(_0x1a012f in this[_0x86dc1d(0x5b8)])){if(_0x1a012f in this[_0x86dc1d(0x362)]){const {asyncInit:_0x1b557b}=this[_0x86dc1d(0x347)](_0x1a012f);if(_0x1b557b)return null;}else return null;}return this[_0x86dc1d(0x5b8)][_0x1a012f];}['findBackendFactory'](_0xa39dd4){const _0x525599=a0_0x20018c;if(!(_0xa39dd4 in this[_0x525599(0x362)]))return null;return this['registryFactory'][_0xa39dd4]['factory'];}[a0_0x20018c(0x357)](_0x1c8f35,_0x3609da,_0x100efa=0x1){const _0x40714e=a0_0x20018c;if(_0x1c8f35 in this[_0x40714e(0x362)])return warn(_0x1c8f35+_0x40714e(0x253)+_0x40714e(0x14d)),![];return this[_0x40714e(0x362)][_0x1c8f35]={'factory':_0x3609da,'priority':_0x100efa},!![];}async[a0_0x20018c(0x544)](_0x41fa1f){const _0x3b316e=a0_0x20018c;if(this[_0x3b316e(0x362)][_0x41fa1f]==null)throw new Error(_0x3b316e(0x2d7)+_0x41fa1f+_0x3b316e(0x145));this[_0x3b316e(0x453)]=_0x41fa1f;if(this[_0x3b316e(0x5b8)][_0x41fa1f]==null){this[_0x3b316e(0x5a3)]=null;const {success:_0x537319,asyncInit:_0x5fbb80}=this[_0x3b316e(0x347)](_0x41fa1f),_0x56a3b8=_0x5fbb80?await _0x537319:_0x537319;if(!_0x56a3b8)return![];}return this[_0x3b316e(0x5a3)]=this['registry'][_0x41fa1f],this[_0x3b316e(0x2f8)](),this[_0x3b316e(0x100)]=new Profiler(this[_0x3b316e(0x5a3)]),!![];}[a0_0x20018c(0x2f8)](){const _0x8bdca5=a0_0x20018c,_0x4d3681=getKernelsForBackend(this[_0x8bdca5(0x453)]);_0x4d3681['forEach'](_0x1116c7=>{const _0x348cfe=_0x8bdca5;_0x1116c7[_0x348cfe(0x35c)]!=null&&_0x1116c7[_0x348cfe(0x35c)](this['backendInstance']);});}[a0_0x20018c(0x36f)](_0x29632f){const _0x2875a9=a0_0x20018c,_0x414e2f=getKernelsForBackend(_0x29632f);_0x414e2f[_0x2875a9(0x1e4)](_0x1ad4d8=>{const _0x2fd995=_0x2875a9;_0x1ad4d8[_0x2fd995(0x526)]!=null&&_0x1ad4d8['disposeFunc'](this['registry'][_0x29632f]);});}[a0_0x20018c(0x347)](_0x36f3f7){const _0x4c820f=a0_0x20018c,_0x1b7649=this[_0x4c820f(0x362)][_0x36f3f7];if(_0x1b7649==null)throw new Error(_0x4c820f(0x345)+_0x36f3f7+_0x4c820f(0x33d));try{const _0x119d74=_0x1b7649['factory']();if(_0x119d74&&!(_0x119d74 instanceof KernelBackend)&&typeof _0x119d74[_0x4c820f(0x236)]==='function'){const _0x4c5a2b=++this[_0x4c820f(0x4cc)],_0xae189b=_0x119d74[_0x4c820f(0x236)](_0x44cbf8=>{const _0x21523f=_0x4c820f;if(_0x4c5a2b<this[_0x21523f(0x4cc)])return![];return this[_0x21523f(0x5b8)][_0x36f3f7]=_0x44cbf8,this['pendingBackendInit']=null,!![];})['catch'](_0x5ae36a=>{const _0x389d2d=_0x4c820f;if(_0x4c5a2b<this[_0x389d2d(0x4cc)])return![];return this['pendingBackendInit']=null,warn('Initialization\x20of\x20backend\x20'+_0x36f3f7+_0x389d2d(0x132)),warn(_0x5ae36a['stack']||_0x5ae36a['message']),![];});return this[_0x4c820f(0x4d3)]=_0xae189b,{'success':_0xae189b,'asyncInit':!![]};}else return this[_0x4c820f(0x5b8)][_0x36f3f7]=_0x119d74,{'success':!![],'asyncInit':![]};}catch(_0x13b3a9){return warn('Initialization\x20of\x20backend\x20'+_0x36f3f7+_0x4c820f(0x132)),warn(_0x13b3a9['stack']||_0x13b3a9[_0x4c820f(0x5c9)]),{'success':![],'asyncInit':![]};}}[a0_0x20018c(0x5a9)](_0x3da92b){const _0x52f99e=a0_0x20018c;if(!(_0x3da92b in this[_0x52f99e(0x362)]))throw new Error(_0x3da92b+_0x52f99e(0x15d));this[_0x52f99e(0x453)]===_0x3da92b&&this['pendingBackendInit']!=null&&this[_0x52f99e(0x4cc)]++,_0x3da92b in this['registry']&&(this[_0x52f99e(0x36f)](_0x3da92b),this[_0x52f99e(0x5b8)][_0x3da92b][_0x52f99e(0x47d)](),delete this[_0x52f99e(0x5b8)][_0x3da92b]),delete this['registryFactory'][_0x3da92b],this[_0x52f99e(0x453)]===_0x3da92b&&(this[_0x52f99e(0x4d3)]=null,this[_0x52f99e(0x453)]=null,this['backendInstance']=null);}[a0_0x20018c(0x1a5)](){const _0x136f8a=a0_0x20018c;if(Object[_0x136f8a(0x586)](this['registryFactory'])[_0x136f8a(0x104)]===0x0)throw new Error('No\x20backend\x20found\x20in\x20registry.');return Object[_0x136f8a(0x586)](this[_0x136f8a(0x362)])['sort']((_0x44492d,_0x78a081)=>{const _0x48532c=_0x136f8a;return this[_0x48532c(0x362)][_0x78a081][_0x48532c(0x448)]-this[_0x48532c(0x362)][_0x44492d][_0x48532c(0x448)];});}[a0_0x20018c(0x549)](){const _0xd4c802=a0_0x20018c,_0x3cbfdf=this[_0xd4c802(0x1a5)]();for(let _0x538fa1=0x0;_0x538fa1<_0x3cbfdf[_0xd4c802(0x104)];_0x538fa1++){const _0x564b60=_0x3cbfdf[_0x538fa1],{success:_0x4a8395,asyncInit:_0x1e68c1}=this[_0xd4c802(0x347)](_0x564b60);if(_0x1e68c1||_0x4a8395)return{'name':_0x564b60,'asyncInit':_0x1e68c1};}throw new Error(_0xd4c802(0x556)+_0xd4c802(0x20f));}[a0_0x20018c(0x447)](_0x4acda7,_0x5c53aa){const _0x477f58=a0_0x20018c,_0x2ea292=this['state']['tensorInfo'][_0x477f58(0x40f)](_0x5c53aa),_0x199ed6=_0x2ea292[_0x477f58(0x162)],_0x55ff96=this[_0x477f58(0x381)](_0x5c53aa),_0x4a682e=_0x199ed6[_0x477f58(0x595)](_0x5c53aa);_0x199ed6[_0x477f58(0x3f0)](_0x5c53aa,!![]),_0x2ea292[_0x477f58(0x162)]=_0x4acda7,_0x4acda7['move'](_0x5c53aa,_0x55ff96,_0x2ea292[_0x477f58(0x50f)],_0x2ea292['dtype'],_0x4a682e),this[_0x477f58(0x22c)]()&&this[_0x477f58(0x23a)]['numDataMovesStack'][this[_0x477f58(0x23a)]['numDataMovesStack']['length']-0x1]++;}['tidy'](_0x6c4857,_0x4472b0){const _0x20e9c1=a0_0x20018c;let _0x11c8eb=null;if(_0x4472b0==null){if(typeof _0x6c4857!=='function')throw new Error(_0x20e9c1(0x390));_0x4472b0=_0x6c4857;}else{if(typeof _0x6c4857!==_0x20e9c1(0x5cf)&&!(_0x6c4857 instanceof String))throw new Error(_0x20e9c1(0x129)+_0x20e9c1(0x131));if(typeof _0x4472b0!==_0x20e9c1(0x557))throw new Error(_0x20e9c1(0x109)+'to\x20tidy()\x20must\x20be\x20a\x20function');_0x11c8eb=_0x6c4857;}let _0x3a08e1;return this[_0x20e9c1(0x43c)](()=>this[_0x20e9c1(0x3d2)](_0x11c8eb),()=>this[_0x20e9c1(0xee)](_0x3a08e1),()=>{const _0x3ec916=_0x20e9c1;return _0x3a08e1=_0x4472b0(),_0x3a08e1 instanceof Promise&&console[_0x3ec916(0x2bb)](_0x3ec916(0x10d)),_0x3a08e1;});}['scopedRun'](_0x331a36,_0x1e0f7f,_0x2b7c8f){_0x331a36();try{const _0x352e4d=_0x2b7c8f();return _0x1e0f7f(),_0x352e4d;}catch(_0x26c9dd){_0x1e0f7f();throw _0x26c9dd;}}['nextTensorId'](){return Engine['nextTensorId']++;}[a0_0x20018c(0x14c)](){const _0x1ffbb1=a0_0x20018c;return Engine[_0x1ffbb1(0x14c)]++;}['clone'](_0x944ed2){const _0x589c5b=a0_0x20018c,_0x16a504=ENGINE[_0x589c5b(0x397)](Identity,{'x':_0x944ed2}),_0x4d637d={'x':_0x944ed2},_0x6f4345=_0x38a312=>({'x':()=>{const _0x3d3a72=_0x589c5b,_0xa0e3d3=_0x3d3a72(0x28b),_0x1f6611={'x':_0x38a312},_0x51634b={'dtype':_0xa0e3d3};return ENGINE[_0x3d3a72(0x397)](Cast,_0x1f6611,_0x51634b);}}),_0x5c098c=[];return this['addTapeNode'](this[_0x589c5b(0x23a)][_0x589c5b(0x1ce)][_0x589c5b(0x1aa)],_0x4d637d,[_0x16a504],_0x6f4345,_0x5c098c,{}),_0x16a504;}['runKernel'](_0x2a2a81,_0x4406d9,_0x151be9){const _0x10bae1=a0_0x20018c;this[_0x10bae1(0x453)]==null&&this[_0x10bae1(0x162)];const _0x316b67=getKernel(_0x2a2a81,this[_0x10bae1(0x453)])!=null;if(!_0x316b67)throw new Error(_0x10bae1(0x11b)+_0x2a2a81+_0x10bae1(0x505)+this[_0x10bae1(0x453)]+'\x27');return this[_0x10bae1(0x5a7)]({'kernelName':_0x2a2a81,'inputs':_0x4406d9,'attrs':_0x151be9});}[a0_0x20018c(0x22c)](){const _0x409c0a=a0_0x20018c;return this[_0x409c0a(0x303)][_0x409c0a(0x501)]('IS_TEST');}[a0_0x20018c(0x521)](_0x343fc8,_0x49c989,_0x413c97){const _0x355bdb=a0_0x20018c,_0x324faf=this['backend'][_0x355bdb(0x358)]();let _0x4614f4=0x0;_0x413c97['forEach'](_0xff8b0d=>{_0x4614f4+=_0xff8b0d['dtype']==='complex64'?0x3:0x1;});const _0x3f6661=this[_0x355bdb(0x23a)][_0x355bdb(0x383)][this[_0x355bdb(0x23a)][_0x355bdb(0x383)][_0x355bdb(0x104)]-0x1],_0x13307c=_0x324faf-_0x49c989-_0x4614f4-_0x3f6661;if(_0x13307c>0x0)throw new Error('Backend\x20\x27'+this[_0x355bdb(0x453)]+'\x27\x20has\x20an\x20internal\x20memory\x20leak\x20'+('('+_0x13307c+_0x355bdb(0x28a)+_0x343fc8+'\x27'));}[a0_0x20018c(0x5a7)](_0x1a0ef4){const _0x3192d3=a0_0x20018c;let _0x50a48e,_0x5e4e78=[];const _0x3c4549=this[_0x3192d3(0x11e)](),_0xb035ad=this[_0x3192d3(0x23a)][_0x3192d3(0x2b6)],_0x18a6bc=this['state'][_0x3192d3(0x2a8)];this[_0x3192d3(0x22c)]()&&this[_0x3192d3(0x23a)][_0x3192d3(0x383)][_0x3192d3(0x30f)](0x0);let _0x22551f;this[_0x3192d3(0x453)]==null&&this['backend'];let _0x1d1f99;const _0x2b8acb=isRegisteredKernelInvocation(_0x1a0ef4)?_0x1a0ef4[_0x3192d3(0x2b4)]:this['state'][_0x3192d3(0x1ce)]!=null?this['state'][_0x3192d3(0x1ce)][_0x3192d3(0x1aa)]:'';if(isRegisteredKernelInvocation(_0x1a0ef4)){const {kernelName:_0x362ff,inputs:_0x245e94,attrs:_0x24a91c}=_0x1a0ef4;this['backendName']==null&&this[_0x3192d3(0x162)];const _0xc1e100=getKernel(_0x362ff,this[_0x3192d3(0x453)]);assert(_0xc1e100!=null,()=>'Cannot\x20find\x20registered\x20kernel\x20\x27'+_0x362ff+_0x3192d3(0x320)+this[_0x3192d3(0x453)]+'\x27'),_0x22551f=()=>{const _0x5f243c=_0x3192d3,_0x37c4f9=this[_0x5f243c(0x162)]['numDataIds']();_0x1d1f99=_0xc1e100[_0x5f243c(0x37d)]({'inputs':_0x245e94,'attrs':_0x24a91c,'backend':this[_0x5f243c(0x162)]});const _0x13c14a=Array[_0x5f243c(0x576)](_0x1d1f99)?_0x1d1f99:[_0x1d1f99];this[_0x5f243c(0x22c)]()&&this['checkKernelForMemLeak'](_0x362ff,_0x37c4f9,_0x13c14a);const _0x5ba22e=_0x13c14a[_0x5f243c(0x3ab)](_0x441212=>{const _0xd0481b=_0x5f243c;if(_0x441212['rank']!=null)return _0x441212;const {dataId:_0x1e58b2,shape:_0x4ed305,dtype:_0x382811}=_0x441212;return this[_0xd0481b(0x14e)](_0x1e58b2,_0x4ed305,_0x382811);});if(_0x3c4549){const _0x5cc35b=this[_0x5f243c(0x3c2)](_0x362ff,_0x245e94,_0x5ba22e);_0x5e4e78=this[_0x5f243c(0x29a)](_0x5cc35b);}return _0x5ba22e;};}else{const {forwardFunc:_0x5c6f68}=_0x1a0ef4,_0x2baca5=_0xb30048=>{const _0x316fba=_0x3192d3;if(!_0x3c4549)return;_0x5e4e78=_0xb30048[_0x316fba(0x3ab)](_0xac3bbb=>this['keep'](this[_0x316fba(0x49d)](_0xac3bbb)));};_0x22551f=()=>{const _0x19419d=_0x3192d3,_0x397d4a=this[_0x19419d(0x162)][_0x19419d(0x358)]();_0x1d1f99=this[_0x19419d(0x50d)](()=>_0x5c6f68(this[_0x19419d(0x162)],_0x2baca5));const _0xd98c13=Array[_0x19419d(0x576)](_0x1d1f99)?_0x1d1f99:[_0x1d1f99];return this[_0x19419d(0x22c)]()&&this[_0x19419d(0x521)](_0x2b8acb,_0x397d4a,_0xd98c13),_0xd98c13;};}const {inputs:_0x4511bf,attrs:_0xc9b4d3}=_0x1a0ef4,_0x2372b5=isRegisteredKernelInvocation(_0x1a0ef4)?null:_0x1a0ef4[_0x3192d3(0x123)];let _0x4e5c8a;return this[_0x3192d3(0x43c)](()=>this[_0x3192d3(0x23a)][_0x3192d3(0x5cc)]++,()=>this['state'][_0x3192d3(0x5cc)]--,()=>{const _0x70bbc4=_0x3192d3;!this[_0x70bbc4(0x303)][_0x70bbc4(0x501)]('DEBUG')&&!this[_0x70bbc4(0x23a)]['profiling']?_0x50a48e=_0x22551f():(_0x4e5c8a=this[_0x70bbc4(0x100)][_0x70bbc4(0x23c)](_0x2b8acb,_0x4511bf,()=>_0x22551f()),this[_0x70bbc4(0x303)][_0x70bbc4(0x501)](_0x70bbc4(0x153))&&this[_0x70bbc4(0x100)][_0x70bbc4(0x430)](_0x4e5c8a),_0x50a48e=_0x4e5c8a[_0x70bbc4(0x1c9)]);}),_0x3c4549&&this[_0x3192d3(0xde)](_0x2b8acb,_0x4511bf,_0x50a48e,_0x2372b5,_0x5e4e78,_0xc9b4d3),this[_0x3192d3(0x23a)][_0x3192d3(0x401)]&&this[_0x3192d3(0x23a)][_0x3192d3(0x200)][_0x3192d3(0x580)]['push']({'name':_0x2b8acb,'bytesAdded':this[_0x3192d3(0x23a)]['numBytes']-_0xb035ad,'totalBytesSnapshot':this[_0x3192d3(0x23a)][_0x3192d3(0x2b6)],'tensorsAdded':this[_0x3192d3(0x23a)][_0x3192d3(0x2a8)]-_0x18a6bc,'totalTensorsSnapshot':this[_0x3192d3(0x23a)][_0x3192d3(0x2a8)],'inputShapes':Object[_0x3192d3(0x586)](_0x4511bf)[_0x3192d3(0x3ab)](_0x3da40f=>_0x4511bf[_0x3da40f]!=null?_0x4511bf[_0x3da40f][_0x3192d3(0x50f)]:null),'outputShapes':_0x50a48e[_0x3192d3(0x3ab)](_0x3d6a21=>_0x3d6a21[_0x3192d3(0x50f)]),'kernelTimeMs':_0x4e5c8a[_0x3192d3(0x510)],'extraInfo':_0x4e5c8a[_0x3192d3(0x414)]}),Array[_0x3192d3(0x576)](_0x1d1f99)?_0x50a48e:_0x50a48e[0x0];}['saveTensorsForBackwardMode'](_0x2f5445){const _0x2e071b=a0_0x20018c,_0x1de913=_0x2f5445[_0x2e071b(0x3ab)](_0x3a8046=>this[_0x2e071b(0x47f)](this[_0x2e071b(0x49d)](_0x3a8046)));return _0x1de913;}['getTensorsForGradient'](_0x1dc093,_0xa0ecd4,_0xeb3ef){const _0x27d854=a0_0x20018c,_0x332d43=getGradient(_0x1dc093);if(_0x332d43!=null){const _0x59137b=_0x332d43[_0x27d854(0x599)]||[],_0x5bd289=_0x332d43[_0x27d854(0x37f)]||[];let _0x1db624;_0x332d43[_0x27d854(0x5bd)]?(assert(Array[_0x27d854(0x576)](_0xa0ecd4),()=>_0x27d854(0x39f)),_0x1db624=Object[_0x27d854(0x586)](_0xa0ecd4)[_0x27d854(0x3ab)](_0x2f9131=>_0xa0ecd4[_0x2f9131])):_0x1db624=_0x59137b[_0x27d854(0x3ab)](_0x3776d=>_0xa0ecd4[_0x3776d]);const _0xc9919d=_0xeb3ef[_0x27d854(0x481)]((_0x158752,_0x514824)=>_0x5bd289[_0x514824]);return _0x1db624[_0x27d854(0x300)](_0xc9919d);}return[];}['makeTensor'](_0x4ff570,_0x2bda4a,_0x573622,_0x25c7b4){const _0x3dc33a=a0_0x20018c;if(_0x4ff570==null)throw new Error('Values\x20passed\x20to\x20engine.makeTensor()\x20are\x20null');_0x573622=_0x573622||_0x3dc33a(0x28b),_0x25c7b4=_0x25c7b4||this[_0x3dc33a(0x162)];let _0xacd6cc=_0x4ff570;_0x573622===_0x3dc33a(0x5cf)&&isString(_0x4ff570[0x0])&&(_0xacd6cc=_0x4ff570[_0x3dc33a(0x3ab)](_0x7a15c6=>encodeString(_0x7a15c6)));const _0x52b4f9=_0x25c7b4['write'](_0xacd6cc,_0x2bda4a,_0x573622),_0x1de1de=new Tensor(_0x2bda4a,_0x573622,_0x52b4f9,this[_0x3dc33a(0x3f4)]());this[_0x3dc33a(0x1c0)](_0x1de1de,_0x25c7b4);if(_0x573622===_0x3dc33a(0x5cf)){const _0x253aee=this[_0x3dc33a(0x23a)]['tensorInfo']['get'](_0x52b4f9),_0x4fa524=bytesFromStringArray(_0xacd6cc);this[_0x3dc33a(0x23a)][_0x3dc33a(0x2b6)]+=_0x4fa524-_0x253aee[_0x3dc33a(0x1f5)],_0x253aee[_0x3dc33a(0x1f5)]=_0x4fa524;}return _0x1de1de;}[a0_0x20018c(0x14e)](_0x316a6e,_0x42c003,_0x3a88f9,_0x5a2e7d){const _0x199e43=a0_0x20018c;_0x3a88f9=_0x3a88f9||_0x199e43(0x28b);const _0x100b6f=new Tensor(_0x42c003,_0x3a88f9,_0x316a6e,this['nextTensorId']());return this[_0x199e43(0x1c0)](_0x100b6f,_0x5a2e7d),_0x100b6f;}[a0_0x20018c(0x398)](_0x163152,_0x19530a=!![],_0x5060e9,_0x899355){const _0x2cce37=a0_0x20018c;_0x5060e9=_0x5060e9||this[_0x2cce37(0x14c)]()['toString']();_0x899355!=null&&_0x899355!==_0x163152['dtype']&&(_0x163152=_0x163152[_0x2cce37(0x335)](_0x899355));const _0x9b3633=new Variable(_0x163152,_0x19530a,_0x5060e9,this[_0x2cce37(0x3f4)]());if(this[_0x2cce37(0x23a)][_0x2cce37(0x52c)][_0x9b3633[_0x2cce37(0x1aa)]]!=null)throw new Error('Variable\x20with\x20name\x20'+_0x9b3633[_0x2cce37(0x1aa)]+_0x2cce37(0x365));return this['state'][_0x2cce37(0x52c)][_0x9b3633[_0x2cce37(0x1aa)]]=_0x9b3633,this['incRef'](_0x9b3633,this[_0x2cce37(0x162)]),_0x9b3633;}[a0_0x20018c(0x1c0)](_0x23e979,_0x5ee2d5){const _0x32ddf3=a0_0x20018c;this[_0x32ddf3(0x23a)][_0x32ddf3(0x2a8)]++;_0x23e979['dtype']===_0x32ddf3(0x5cf)&&this['state']['numStringTensors']++;let _0x4d2d0c=0x0;_0x23e979[_0x32ddf3(0x51c)]!==_0x32ddf3(0xe8)&&_0x23e979[_0x32ddf3(0x51c)]!==_0x32ddf3(0x5cf)&&(_0x4d2d0c=_0x23e979[_0x32ddf3(0x302)]*bytesPerElement(_0x23e979[_0x32ddf3(0x51c)])),this[_0x32ddf3(0x23a)][_0x32ddf3(0x2b6)]+=_0x4d2d0c,!this[_0x32ddf3(0x23a)][_0x32ddf3(0x55b)][_0x32ddf3(0x18a)](_0x23e979[_0x32ddf3(0x42c)])&&(this[_0x32ddf3(0x23a)]['numDataBuffers']++,this[_0x32ddf3(0x23a)][_0x32ddf3(0x55b)][_0x32ddf3(0x5a6)](_0x23e979[_0x32ddf3(0x42c)],{'backend':_0x5ee2d5||this[_0x32ddf3(0x162)],'dtype':_0x23e979[_0x32ddf3(0x51c)],'shape':_0x23e979[_0x32ddf3(0x50f)],'bytes':_0x4d2d0c})),!(_0x23e979 instanceof Variable)&&this['track'](_0x23e979);}[a0_0x20018c(0x437)](_0x4f4dbc,_0x3b8956){const _0x23b9a1=a0_0x20018c;this[_0x23b9a1(0x1c0)](_0x4f4dbc,_0x3b8956),this['backend'][_0x23b9a1(0x437)](_0x4f4dbc[_0x23b9a1(0x42c)]);}[a0_0x20018c(0x2d6)](_0x3b345d,_0x48b757){const _0x2addfb=a0_0x20018c;this[_0x2addfb(0x23a)][_0x2addfb(0x55b)][_0x2addfb(0x18a)](_0x3b345d)&&this[_0x2addfb(0x23a)][_0x2addfb(0x55b)][_0x2addfb(0x40f)](_0x3b345d)['backend']===_0x48b757&&(this[_0x2addfb(0x23a)][_0x2addfb(0x55b)][_0x2addfb(0x541)](_0x3b345d),this[_0x2addfb(0x23a)][_0x2addfb(0x1b8)]--);}['disposeTensor'](_0x26f953){const _0x135ae7=a0_0x20018c;if(!this[_0x135ae7(0x23a)][_0x135ae7(0x55b)][_0x135ae7(0x18a)](_0x26f953[_0x135ae7(0x42c)]))return;const _0xca25f0=this['state'][_0x135ae7(0x55b)][_0x135ae7(0x40f)](_0x26f953[_0x135ae7(0x42c)]);this[_0x135ae7(0x23a)][_0x135ae7(0x2a8)]--;_0x26f953[_0x135ae7(0x51c)]===_0x135ae7(0x5cf)&&(this[_0x135ae7(0x23a)]['numStringTensors']--,this['state']['numBytes']-=_0xca25f0[_0x135ae7(0x1f5)]);if(_0x26f953[_0x135ae7(0x51c)]!==_0x135ae7(0xe8)&&_0x26f953['dtype']!=='string'){const _0x5a2202=_0x26f953[_0x135ae7(0x302)]*bytesPerElement(_0x26f953[_0x135ae7(0x51c)]);this['state'][_0x135ae7(0x2b6)]-=_0x5a2202;}_0xca25f0[_0x135ae7(0x162)][_0x135ae7(0x3f0)](_0x26f953[_0x135ae7(0x42c)])&&this[_0x135ae7(0x2d6)](_0x26f953[_0x135ae7(0x42c)],_0xca25f0[_0x135ae7(0x162)]);}[a0_0x20018c(0x370)](){const _0xf43c49=a0_0x20018c;for(const _0x2a68c7 in this[_0xf43c49(0x23a)]['registeredVariables']){const _0xd7223d=this['state']['registeredVariables'][_0x2a68c7];this[_0xf43c49(0x311)](_0xd7223d);}}['disposeVariable'](_0x2783f4){const _0x3abe7f=a0_0x20018c;this[_0x3abe7f(0x101)](_0x2783f4),this[_0x3abe7f(0x23a)][_0x3abe7f(0x52c)][_0x2783f4[_0x3abe7f(0x1aa)]]!=null&&delete this['state'][_0x3abe7f(0x52c)][_0x2783f4['name']];}['memory'](){const _0x26032d=a0_0x20018c,_0x49aabe=this[_0x26032d(0x162)][_0x26032d(0x27f)]();return _0x49aabe[_0x26032d(0x2a8)]=this[_0x26032d(0x23a)][_0x26032d(0x2a8)],_0x49aabe[_0x26032d(0x1b8)]=this[_0x26032d(0x23a)][_0x26032d(0x1b8)],_0x49aabe[_0x26032d(0x2b6)]=this['state'][_0x26032d(0x2b6)],this['state'][_0x26032d(0x1db)]>0x0&&(_0x49aabe[_0x26032d(0x338)]=!![],_0x49aabe['reasons']==null&&(_0x49aabe[_0x26032d(0x56a)]=[]),_0x49aabe['reasons']['push'](_0x26032d(0x435)+'(2\x20bytes\x20per\x20character)')),_0x49aabe;}async[a0_0x20018c(0x32e)](_0x417410){const _0x1f9621=a0_0x20018c;this[_0x1f9621(0x23a)]['profiling']=!![];const _0x26f013=this['state'][_0x1f9621(0x2b6)],_0xa3b1ad=this[_0x1f9621(0x23a)][_0x1f9621(0x2a8)];this[_0x1f9621(0x23a)][_0x1f9621(0x200)][_0x1f9621(0x580)]=[],this[_0x1f9621(0x23a)][_0x1f9621(0x200)]['result']=await _0x417410(),this['state']['profiling']=![],this[_0x1f9621(0x23a)][_0x1f9621(0x200)][_0x1f9621(0x4db)]=Math['max'](...this['state'][_0x1f9621(0x200)][_0x1f9621(0x580)][_0x1f9621(0x3ab)](_0x5cdc8d=>_0x5cdc8d[_0x1f9621(0x41c)])),this['state'][_0x1f9621(0x200)][_0x1f9621(0x3e6)]=this[_0x1f9621(0x23a)][_0x1f9621(0x2b6)]-_0x26f013,this['state']['activeProfile'][_0x1f9621(0x5aa)]=this['state'][_0x1f9621(0x2a8)]-_0xa3b1ad;for(const _0x15370e of this['state'][_0x1f9621(0x200)]['kernels']){_0x15370e[_0x1f9621(0x57e)]=await _0x15370e['kernelTimeMs'],_0x15370e[_0x1f9621(0x414)]=await _0x15370e[_0x1f9621(0x414)];}return this[_0x1f9621(0x23a)][_0x1f9621(0x200)];}[a0_0x20018c(0x11e)](){const _0x2b13dd=a0_0x20018c;return this[_0x2b13dd(0x23a)][_0x2b13dd(0x1c8)]>0x0&&this[_0x2b13dd(0x23a)]['kernelDepth']===0x0;}[a0_0x20018c(0xde)](_0x3fe6d0,_0x552679,_0x4baebb,_0x34144e,_0x589a35,_0x39aaa0){const _0x5a7021=a0_0x20018c,_0x760a63={'id':this['state'][_0x5a7021(0x40a)]++,'kernelName':_0x3fe6d0,'inputs':_0x552679,'outputs':_0x4baebb,'saved':_0x589a35},_0x20fddd=getGradient(_0x3fe6d0);_0x20fddd!=null&&(_0x34144e=_0x20fddd[_0x5a7021(0xea)]),_0x34144e!=null&&(_0x760a63['gradient']=_0x511247=>{const _0x27a030=_0x5a7021;return _0x511247=_0x511247[_0x27a030(0x3ab)]((_0x5b8975,_0x2f974f)=>{const _0x2bd650=_0x27a030;if(_0x5b8975==null){const _0x585e49=_0x4baebb[_0x2f974f],_0x1f3548=makeZerosTypedArray(_0x585e49[_0x2bd650(0x302)],_0x585e49[_0x2bd650(0x51c)]);return this[_0x2bd650(0x210)](_0x1f3548,_0x585e49[_0x2bd650(0x50f)],_0x585e49['dtype']);}return _0x5b8975;}),_0x34144e(_0x511247['length']>0x1?_0x511247:_0x511247[0x0],_0x589a35,_0x39aaa0);}),this[_0x5a7021(0x23a)][_0x5a7021(0x54a)][_0x5a7021(0x30f)](_0x760a63);}['keep'](_0x4f76c7){const _0x2f14a2=a0_0x20018c;return _0x4f76c7[_0x2f14a2(0x25d)]=!![],_0x4f76c7;}['startTape'](){const _0xa7556d=a0_0x20018c;this[_0xa7556d(0x23a)]['gradientDepth']===0x0&&(this['state'][_0xa7556d(0x54a)]=[]),this[_0xa7556d(0x23a)]['gradientDepth']++;}[a0_0x20018c(0x547)](){const _0x27928d=a0_0x20018c;this['state'][_0x27928d(0x1c8)]--;}[a0_0x20018c(0x3d2)](_0x29fc5d){const _0x241824=a0_0x20018c,_0x4355cb={'track':[],'name':_0x241824(0x5d4),'id':this[_0x241824(0x23a)][_0x241824(0x179)]++};_0x29fc5d&&(_0x4355cb[_0x241824(0x1aa)]=_0x29fc5d),this['state'][_0x241824(0x15b)][_0x241824(0x30f)](_0x4355cb),this[_0x241824(0x23a)][_0x241824(0x1ce)]=_0x4355cb;}['endScope'](_0x22d4fb){const _0x1ab0d6=a0_0x20018c,_0x2368eb=getTensorsInContainer(_0x22d4fb),_0x3b3f1d=new Set(_0x2368eb[_0x1ab0d6(0x3ab)](_0x45fa76=>_0x45fa76['id']));for(let _0x56383e=0x0;_0x56383e<this[_0x1ab0d6(0x23a)][_0x1ab0d6(0x1ce)][_0x1ab0d6(0x48f)][_0x1ab0d6(0x104)];_0x56383e++){const _0xc677ca=this[_0x1ab0d6(0x23a)][_0x1ab0d6(0x1ce)]['track'][_0x56383e];!_0xc677ca[_0x1ab0d6(0x25d)]&&!_0x3b3f1d[_0x1ab0d6(0x18a)](_0xc677ca['id'])&&_0xc677ca[_0x1ab0d6(0x47d)]();}const _0x463322=this[_0x1ab0d6(0x23a)][_0x1ab0d6(0x15b)][_0x1ab0d6(0x1c2)]();this[_0x1ab0d6(0x23a)]['activeScope']=this[_0x1ab0d6(0x23a)][_0x1ab0d6(0x15b)][_0x1ab0d6(0x104)]===0x0?null:this[_0x1ab0d6(0x23a)][_0x1ab0d6(0x15b)][this[_0x1ab0d6(0x23a)][_0x1ab0d6(0x15b)][_0x1ab0d6(0x104)]-0x1],_0x2368eb[_0x1ab0d6(0x1e4)](_0x16c78e=>{const _0x52d905=_0x1ab0d6;!_0x16c78e[_0x52d905(0x25d)]&&_0x16c78e[_0x52d905(0x23e)]===_0x463322['id']&&this[_0x52d905(0x48f)](_0x16c78e);});}['gradients'](_0x1750bb,_0x43e682,_0x25c64c,_0x23a97b=![]){const _0x343d3e=a0_0x20018c;assert(_0x43e682['length']>0x0,()=>_0x343d3e(0x319));if(_0x25c64c!=null&&_0x25c64c[_0x343d3e(0x51c)]!==_0x343d3e(0x28b))throw new Error(_0x343d3e(0x475)+_0x25c64c[_0x343d3e(0x51c)]+'\x27');const _0x57b731=this['scopedRun'](()=>this['startTape'](),()=>this[_0x343d3e(0x547)](),()=>this[_0x343d3e(0x50d)](_0x343d3e(0xdd),_0x1750bb));assert(_0x57b731 instanceof Tensor,()=>_0x343d3e(0x4c4));const _0x2d6d21=getFilteredNodesXToY(this['state'][_0x343d3e(0x54a)],_0x43e682,_0x57b731);if(!_0x23a97b&&_0x2d6d21[_0x343d3e(0x104)]===0x0&&_0x43e682[_0x343d3e(0x104)]>0x0)throw new Error(_0x343d3e(0x2d0)+'that\x20the\x20f\x20you\x20passed\x20encloses\x20all\x20operations\x20that\x20lead\x20from\x20x\x20'+_0x343d3e(0x137));return this[_0x343d3e(0x50d)](_0x343d3e(0x182),()=>{const _0x258b33=_0x343d3e,_0x220ea7={};_0x220ea7[_0x57b731['id']]=_0x25c64c==null?ones(_0x57b731[_0x258b33(0x50f)]):_0x25c64c,backpropagateGradients(_0x220ea7,_0x2d6d21,_0x2908c5=>this[_0x258b33(0x50d)](_0x2908c5),add);const _0x3ef430=_0x43e682['map'](_0x3a4cef=>_0x220ea7[_0x3a4cef['id']]);return this['state'][_0x258b33(0x1c8)]===0x0&&(this[_0x258b33(0x23a)][_0x258b33(0x54a)][_0x258b33(0x1e4)](_0x1a97f5=>{const _0x1a4a4c=_0x258b33;for(const _0x48f81b of _0x1a97f5[_0x1a4a4c(0x315)]){_0x48f81b[_0x1a4a4c(0x47d)]();}}),this[_0x258b33(0x23a)][_0x258b33(0x54a)]=null),{'value':_0x57b731,'grads':_0x3ef430};});}[a0_0x20018c(0x2a1)](_0x358345){const _0x424851=a0_0x20018c;return assert(isFunction(_0x358345),()=>_0x424851(0x570)),(..._0x1b0d4e)=>{const _0x297789=_0x424851;assert(_0x1b0d4e[_0x297789(0x271)](_0x3c2e4e=>_0x3c2e4e instanceof Tensor),()=>_0x297789(0x136)+_0x297789(0x2d5));let _0x7d72e0;const _0x451f04={};_0x1b0d4e[_0x297789(0x1e4)]((_0x57d43e,_0x23825a)=>{_0x451f04[_0x23825a]=_0x57d43e;});const _0x55a8de=(_0x5d751f,_0x26eb74)=>{const _0x5b9c6d=_0x297789;return _0x7d72e0=_0x358345(...[..._0x1b0d4e,_0x26eb74]),assert(_0x7d72e0[_0x5b9c6d(0x238)]instanceof Tensor,()=>'The\x20function\x20f\x20passed\x20in\x20customGrad(f)\x20must\x20return\x20an\x20'+_0x5b9c6d(0x380)),assert(isFunction(_0x7d72e0[_0x5b9c6d(0xea)]),()=>_0x5b9c6d(0x139)+_0x5b9c6d(0x1c6)),_0x7d72e0[_0x5b9c6d(0x238)];},_0x1b8458=(_0x408a1a,_0x238bc9)=>{const _0x455516=_0x297789,_0x2805a1=_0x7d72e0[_0x455516(0xea)](_0x408a1a,_0x238bc9),_0x536457=Array[_0x455516(0x576)](_0x2805a1)?_0x2805a1:[_0x2805a1];assert(_0x536457[_0x455516(0x104)]===_0x1b0d4e[_0x455516(0x104)],()=>'The\x20function\x20f\x20passed\x20in\x20customGrad(f)\x20must\x20return\x20an\x20'+_0x455516(0x32d)+'the\x20same\x20number\x20of\x20tensors\x20as\x20inputs\x20passed\x20to\x20f(...).'),assert(_0x536457['every'](_0x4b9f10=>_0x4b9f10 instanceof Tensor),()=>_0x455516(0x139)+_0x455516(0x32d)+_0x455516(0x50b));const _0x2ee755={};return _0x536457['forEach']((_0x5c0343,_0x1dd50d)=>{_0x2ee755[_0x1dd50d]=()=>_0x5c0343;}),_0x2ee755;};return this[_0x297789(0x5a7)]({'forwardFunc':_0x55a8de,'backwardsFunc':_0x1b8458,'inputs':_0x451f04});};}[a0_0x20018c(0x381)](_0x149fbe){const _0x4718eb=a0_0x20018c,_0x5c445e=this[_0x4718eb(0x23a)][_0x4718eb(0x55b)][_0x4718eb(0x40f)](_0x149fbe);return _0x5c445e['backend']['readSync'](_0x149fbe);}[a0_0x20018c(0x405)](_0x3d6c64){const _0x3cb1a9=a0_0x20018c,_0x225288=this[_0x3cb1a9(0x23a)][_0x3cb1a9(0x55b)]['get'](_0x3d6c64);return _0x225288[_0x3cb1a9(0x162)][_0x3cb1a9(0x405)](_0x3d6c64);}async[a0_0x20018c(0x5d5)](_0x4c1ed0){const _0x7022bf=a0_0x20018c,_0x23ae8b=now(),_0x5b20ea=await this[_0x7022bf(0x162)][_0x7022bf(0x5d5)](_0x4c1ed0);return _0x5b20ea[_0x7022bf(0x2ad)]=now()-_0x23ae8b,_0x5b20ea;}[a0_0x20018c(0x48f)](_0x53ba4d){const _0x2e97ae=a0_0x20018c;return this[_0x2e97ae(0x23a)][_0x2e97ae(0x1ce)]!=null&&(_0x53ba4d['scopeId']=this[_0x2e97ae(0x23a)][_0x2e97ae(0x1ce)]['id'],this['state']['activeScope'][_0x2e97ae(0x48f)][_0x2e97ae(0x30f)](_0x53ba4d)),_0x53ba4d;}get['registeredVariables'](){const _0x25d9a0=a0_0x20018c;return this[_0x25d9a0(0x23a)][_0x25d9a0(0x52c)];}['reset'](){const _0x3c7240=a0_0x20018c;this[_0x3c7240(0x4cc)]++,this[_0x3c7240(0x23a)]['dispose'](),this[_0x3c7240(0x303)][_0x3c7240(0x12d)](),this[_0x3c7240(0x23a)]=new EngineState();for(const _0x5da9d3 in this[_0x3c7240(0x5b8)]){this['disposeRegisteredKernels'](_0x5da9d3),this[_0x3c7240(0x5b8)][_0x5da9d3]['dispose'](),delete this['registry'][_0x5da9d3];}this[_0x3c7240(0x453)]=null,this['backendInstance']=null,this[_0x3c7240(0x4d3)]=null;}}Engine['nextTensorId']=0x0,Engine[a0_0x20018c(0x14c)]=0x0;function ones(_0x309ae5){const _0x15a1c4=a0_0x20018c,_0x1ecc52=makeOnesTypedArray(sizeFromShape(_0x309ae5),'float32');return ENGINE['makeTensor'](_0x1ecc52,_0x309ae5,_0x15a1c4(0x28b));}function getOrMakeEngine(){const _0x4f2392=a0_0x20018c,_0x286833=getGlobalNamespace();if(_0x286833['_tfengine']==null){const _0x1e76c4=new Environment(_0x286833);_0x286833[_0x4f2392(0x51b)]=new Engine(_0x1e76c4);}return setEnvironmentGlobal(_0x286833[_0x4f2392(0x51b)]['ENV']),setTensorTracker(()=>_0x286833[_0x4f2392(0x51b)]),_0x286833[_0x4f2392(0x51b)];}const ENGINE=getOrMakeEngine();function add(_0xd2e35f,_0xbbd696){const _0x4086b4=a0_0x20018c,_0xce42f5={'a':_0xd2e35f,'b':_0xbbd696};return ENGINE[_0x4086b4(0x397)](Add,_0xce42f5);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function inferShape(_0x4cc705,_0x14783f){const _0x4345e1=a0_0x20018c;let _0x146622=_0x4cc705;if(isTypedArray(_0x4cc705))return _0x14783f===_0x4345e1(0x5cf)?[]:[_0x4cc705[_0x4345e1(0x104)]];if(!Array[_0x4345e1(0x576)](_0x4cc705))return[];const _0x35aa08=[];while(Array[_0x4345e1(0x576)](_0x146622)||isTypedArray(_0x146622)&&_0x14783f!==_0x4345e1(0x5cf)){_0x35aa08['push'](_0x146622[_0x4345e1(0x104)]),_0x146622=_0x146622[0x0];}return Array[_0x4345e1(0x576)](_0x4cc705)&&env()[_0x4345e1(0x501)]('TENSORLIKE_CHECK_SHAPE_CONSISTENCY')&&deepAssertShapeConsistency(_0x4cc705,_0x35aa08,[]),_0x35aa08;}function deepAssertShapeConsistency(_0x26719d,_0x3ad4f5,_0x3b4806){const _0x51f2ce=a0_0x20018c;_0x3b4806=_0x3b4806||[];if(!Array[_0x51f2ce(0x576)](_0x26719d)&&!isTypedArray(_0x26719d)){assert(_0x3ad4f5[_0x51f2ce(0x104)]===0x0,()=>'Element\x20arr['+_0x3b4806[_0x51f2ce(0x46d)]('][')+']\x20is\x20a\x20primitive,\x20'+(_0x51f2ce(0x3a6)+_0x3ad4f5[0x0]+_0x51f2ce(0x34a)));return;}assert(_0x3ad4f5[_0x51f2ce(0x104)]>0x0,()=>_0x51f2ce(0x243)+_0x3b4806[_0x51f2ce(0x46d)]('][')+_0x51f2ce(0x191)+(_0x51f2ce(0x2ec)+_0x26719d[_0x51f2ce(0x104)]+'\x20elements')),assert(_0x26719d[_0x51f2ce(0x104)]===_0x3ad4f5[0x0],()=>_0x51f2ce(0x243)+_0x3b4806[_0x51f2ce(0x46d)]('][')+']\x20should\x20have\x20'+_0x3ad4f5[0x0]+'\x20'+('elements,\x20but\x20has\x20'+_0x26719d[_0x51f2ce(0x104)]+_0x51f2ce(0x34a)));const _0x4f84ea=_0x3ad4f5['slice'](0x1);for(let _0x145b4b=0x0;_0x145b4b<_0x26719d[_0x51f2ce(0x104)];++_0x145b4b){deepAssertShapeConsistency(_0x26719d[_0x145b4b],_0x4f84ea,_0x3b4806[_0x51f2ce(0x300)](_0x145b4b));}}function assertDtype(_0x5b449c,_0xe41443,_0x4571d1,_0x441f3e){const _0x15e016=a0_0x20018c;if(_0x5b449c===_0x15e016(0x5c4))return;if(_0x5b449c==null)throw new Error(_0x15e016(0xeb));if(_0x5b449c!==_0x15e016(0x3a5)&&_0x5b449c!==_0xe41443||_0x5b449c==='numeric'&&_0xe41443==='string')throw new Error(_0x15e016(0x49b)+_0x4571d1+'\x27\x20passed\x20to\x20\x27'+_0x441f3e+_0x15e016(0x344)+('be\x20'+_0x5b449c+_0x15e016(0x45e)+_0xe41443+_0x15e016(0x353)));}function convertToTensor(_0x3dea14,_0x4ee7e1,_0x481c5b,_0x441638=a0_0x20018c(0x3a5)){const _0x126b09=a0_0x20018c;if(_0x3dea14 instanceof Tensor)return assertDtype(_0x441638,_0x3dea14[_0x126b09(0x51c)],_0x4ee7e1,_0x481c5b),_0x3dea14;let _0x1b942d=inferDtype(_0x3dea14);_0x1b942d!==_0x126b09(0x5cf)&&[_0x126b09(0x188),'int32','float32'][_0x126b09(0x12e)](_0x441638)>=0x0&&(_0x1b942d=_0x441638);assertDtype(_0x441638,_0x1b942d,_0x4ee7e1,_0x481c5b);if(_0x3dea14==null||!isTypedArray(_0x3dea14)&&!Array[_0x126b09(0x576)](_0x3dea14)&&typeof _0x3dea14!==_0x126b09(0x4ac)&&typeof _0x3dea14!==_0x126b09(0x4eb)&&typeof _0x3dea14!==_0x126b09(0x5cf)){const _0x49ac06=_0x3dea14==null?_0x126b09(0x2ca):_0x3dea14[_0x126b09(0x3ae)][_0x126b09(0x1aa)];throw new Error('Argument\x20\x27'+_0x4ee7e1+_0x126b09(0x2ed)+_0x481c5b+_0x126b09(0x346)+('Tensor\x20or\x20TensorLike,\x20but\x20got\x20\x27'+_0x49ac06+'\x27'));}const _0xf45622=inferShape(_0x3dea14,_0x1b942d);!isTypedArray(_0x3dea14)&&!Array[_0x126b09(0x576)](_0x3dea14)&&(_0x3dea14=[_0x3dea14]);const _0x2c3249=!![],_0x9fd9eb=_0x1b942d!=='string'?toTypedArray(_0x3dea14,_0x1b942d):flatten(_0x3dea14,[],_0x2c3249);return ENGINE['makeTensor'](_0x9fd9eb,_0xf45622,_0x1b942d);}function convertToTensorArray(_0x5d93c0,_0x4b1b76,_0xd6859b,_0xb4e7ab=a0_0x20018c(0x3a5)){const _0x4d7162=a0_0x20018c;if(!Array[_0x4d7162(0x576)](_0x5d93c0))throw new Error(_0x4d7162(0xf8)+_0x4b1b76+_0x4d7162(0x224)+_0xd6859b+'\x20must\x20be\x20a\x20'+_0x4d7162(0x20c));const _0x2324fb=_0x5d93c0;return _0x2324fb[_0x4d7162(0x3ab)]((_0x447282,_0x2440a7)=>convertToTensor(_0x447282,_0x4b1b76+'['+_0x2440a7+']',_0xd6859b,_0xb4e7ab));}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const OP_SCOPE_SUFFIX=a0_0x20018c(0x493);function op(_0x5bbc68){const _0x5cc76f=a0_0x20018c,_0x464cbb=Object[_0x5cc76f(0x586)](_0x5bbc68);if(_0x464cbb['length']!==0x1)throw new Error(_0x5cc76f(0x5cd)+_0x5cc76f(0x268)+(_0x464cbb[_0x5cc76f(0x104)]+_0x5cc76f(0x1ff)));let _0xadbf6a=_0x464cbb[0x0];const _0x1a88e=_0x5bbc68[_0xadbf6a];_0xadbf6a[_0x5cc76f(0x2ce)]('_')&&(_0xadbf6a=_0xadbf6a['substring'](0x0,_0xadbf6a['length']-0x1));_0xadbf6a=_0xadbf6a+OP_SCOPE_SUFFIX;const _0x1fde9c=(..._0x3b95b8)=>{const _0x1cbf4b=_0x5cc76f;ENGINE[_0x1cbf4b(0x3d2)](_0xadbf6a);try{const _0x4e9af1=_0x1a88e(..._0x3b95b8);return isPromise(_0x4e9af1)&&console[_0x1cbf4b(0x2bb)](_0x1cbf4b(0x10d)),ENGINE[_0x1cbf4b(0xee)](_0x4e9af1),_0x4e9af1;}catch(_0x438568){ENGINE[_0x1cbf4b(0xee)](null);throw _0x438568;}};return Object[_0x5cc76f(0x41d)](_0x1fde9c,_0x5cc76f(0x1aa),{'value':_0xadbf6a,'configurable':!![]}),_0x1fde9c;}/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function cast_(_0x439878,_0x1a15fe){const _0x16f075=a0_0x20018c,_0x5d9848=convertToTensor(_0x439878,'x',_0x16f075(0x335));if(!isValidDtype(_0x1a15fe))throw new Error(_0x16f075(0x44a)+_0x1a15fe);if(_0x1a15fe===_0x16f075(0x5cf)&&_0x5d9848[_0x16f075(0x51c)]!==_0x16f075(0x5cf)||_0x1a15fe!=='string'&&_0x5d9848[_0x16f075(0x51c)]===_0x16f075(0x5cf))throw new Error(_0x16f075(0x546));const _0x101314={'x':_0x5d9848},_0x1c2ca8={'dtype':_0x1a15fe};return ENGINE[_0x16f075(0x397)](Cast,_0x101314,_0x1c2ca8);}const cast=op({'cast_':cast_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function mul_(_0x4f306f,_0x5bade8){const _0x4a6104=a0_0x20018c;let _0x2fa404=convertToTensor(_0x4f306f,'a',_0x4a6104(0x1a0)),_0x3e6645=convertToTensor(_0x5bade8,'b',_0x4a6104(0x1a0));[_0x2fa404,_0x3e6645]=makeTypesMatch(_0x2fa404,_0x3e6645);const _0x1b649f={'a':_0x2fa404,'b':_0x3e6645};return ENGINE[_0x4a6104(0x397)](Multiply,_0x1b649f);}const mul=op({'mul_':mul_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function step_(_0xe3a5a2,_0x1b506d=0x0){const _0x5029df=a0_0x20018c,_0x3c7a35=convertToTensor(_0xe3a5a2,'x','step'),_0x55671c={'x':_0x3c7a35},_0x27ab52={'alpha':_0x1b506d};return ENGINE[_0x5029df(0x397)](Step,_0x55671c,_0x27ab52);}const step=op({'step_':step_}),absGradConfig={'kernelName':Abs,'inputsToSave':['x'],'gradFunc':(_0x23c86d,_0x10131b)=>{const _0x2c0269=a0_0x20018c,[_0x4983ae]=_0x10131b;return{'x':()=>mul(_0x23c86d,step(cast(_0x4983ae,_0x2c0269(0x28b)),-0x1))};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function floorDiv_(_0x5a058d,_0xbd530f){const _0x1cfa53=a0_0x20018c;let _0x2a7256=convertToTensor(_0x5a058d,'a','floorDiv'),_0x21957b=convertToTensor(_0xbd530f,'b',_0x1cfa53(0x50c));[_0x2a7256,_0x21957b]=makeTypesMatch(_0x2a7256,_0x21957b);const _0x49d11f={'a':_0x2a7256,'b':_0x21957b};return ENGINE[_0x1cfa53(0x397)](FloorDiv,_0x49d11f);}const floorDiv=op({'floorDiv_':floorDiv_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function div_(_0x24f0df,_0xc8543f){const _0x41792e=a0_0x20018c;let _0x43760e=convertToTensor(_0x24f0df,'a',_0x41792e(0xfd)),_0x3cbbed=convertToTensor(_0xc8543f,'b','div');[_0x43760e,_0x3cbbed]=makeTypesMatch(_0x43760e,_0x3cbbed);if(_0x43760e[_0x41792e(0x51c)]===_0x41792e(0x4d1)&&_0x3cbbed['dtype']===_0x41792e(0x4d1))return floorDiv(_0x43760e,_0x3cbbed);const _0x593989={'a':_0x43760e,'b':_0x3cbbed},_0x13b4c3={};return ENGINE[_0x41792e(0x397)](RealDiv,_0x593989,_0x13b4c3);}const div=op({'div_':div_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function neg_(_0x1406b3){const _0x55b1b7=a0_0x20018c,_0x3f9a4d=convertToTensor(_0x1406b3,'x','neg'),_0x4235ac={'x':_0x3f9a4d};return ENGINE[_0x55b1b7(0x397)](Neg,_0x4235ac);}const neg=op({'neg_':neg_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function makeTensor(_0x1708b3,_0x410eea,_0x537e37,_0x4435bf){const _0x30551f=a0_0x20018c;_0x4435bf==null&&(_0x4435bf=inferDtype(_0x1708b3));if(_0x4435bf===_0x30551f(0xe8))throw new Error(_0x30551f(0x291)+'Please\x20use\x20tf.complex(real,\x20imag).');if(!isTypedArray(_0x1708b3)&&!Array[_0x30551f(0x576)](_0x1708b3)&&typeof _0x1708b3!==_0x30551f(0x4ac)&&typeof _0x1708b3!==_0x30551f(0x4eb)&&typeof _0x1708b3!=='string')throw new Error(_0x30551f(0x4a2)+_0x30551f(0xe6));if(_0x410eea!=null){assertNonNegativeIntegerDimensions(_0x410eea);const _0x374a52=sizeFromShape(_0x410eea),_0x5b3dd6=sizeFromShape(_0x537e37);assert(_0x374a52===_0x5b3dd6,()=>_0x30551f(0x56e)+_0x410eea+_0x30551f(0x31b)+(_0x374a52+_0x30551f(0x205)+_0x5b3dd6));for(let _0x5920a0=0x0;_0x5920a0<_0x537e37[_0x30551f(0x104)];++_0x5920a0){const _0x4b8332=_0x537e37[_0x5920a0],_0x572e65=_0x5920a0===_0x537e37[_0x30551f(0x104)]-0x1?_0x4b8332!==sizeFromShape(_0x410eea[_0x30551f(0x2b0)](_0x5920a0)):!![];assert(_0x537e37[_0x5920a0]===_0x410eea[_0x5920a0]||!_0x572e65,()=>_0x30551f(0x4b2)+('('+_0x537e37+_0x30551f(0x1f3))+(_0x30551f(0x4fb)+_0x410eea+').\x20'));}}return!isTypedArray(_0x1708b3)&&!Array[_0x30551f(0x576)](_0x1708b3)&&(_0x1708b3=[_0x1708b3]),_0x410eea=_0x410eea||_0x537e37,_0x1708b3=_0x4435bf!==_0x30551f(0x5cf)?toTypedArray(_0x1708b3,_0x4435bf):flatten(_0x1708b3,[],!![]),ENGINE[_0x30551f(0x210)](_0x1708b3,_0x410eea,_0x4435bf);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function scalar(_0x41640f,_0x5c2f78){const _0x3ae3a8=a0_0x20018c;if((isTypedArray(_0x41640f)&&_0x5c2f78!==_0x3ae3a8(0x5cf)||Array[_0x3ae3a8(0x576)](_0x41640f))&&_0x5c2f78!==_0x3ae3a8(0xe8))throw new Error('Error\x20creating\x20a\x20new\x20Scalar:\x20value\x20must\x20be\x20a\x20primitive\x20'+'(number|boolean|string)');if(_0x5c2f78===_0x3ae3a8(0x5cf)&&isTypedArray(_0x41640f)&&!(_0x41640f instanceof Uint8Array))throw new Error(_0x3ae3a8(0x503)+'the\x20value\x20must\x20be\x20`Uint8Array`.');const _0x5f3441=[],_0x4ca627=[];return makeTensor(_0x41640f,_0x5f3441,_0x4ca627,_0x5c2f78);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sqrt_(_0x1097a0){const _0x102868=a0_0x20018c,_0x1b0f47=convertToTensor(_0x1097a0,'x',_0x102868(0x106)),_0x91e684={'x':_0x1b0f47};return ENGINE[_0x102868(0x397)](Sqrt,_0x91e684);}const sqrt=op({'sqrt_':sqrt_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function square_(_0x2fbaed){const _0x58b00e=a0_0x20018c,_0x41d58c=convertToTensor(_0x2fbaed,'x',_0x58b00e(0x3b0)),_0xc0656a={};return ENGINE[_0x58b00e(0x397)]('Square',{'x':_0x41d58c},_0xc0656a);}const square=op({'square_':square_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sub_(_0x2ac598,_0x4ddb0e){const _0x4d55dd=a0_0x20018c;let _0x3805b2=convertToTensor(_0x2ac598,'a','sub'),_0x30b4ae=convertToTensor(_0x4ddb0e,'b',_0x4d55dd(0x301));[_0x3805b2,_0x30b4ae]=makeTypesMatch(_0x3805b2,_0x30b4ae);const _0x2e795c={'a':_0x3805b2,'b':_0x30b4ae};return ENGINE[_0x4d55dd(0x397)](Sub,_0x2e795c);}const sub=op({'sub_':sub_}),acosGradConfig={'kernelName':Acos,'inputsToSave':['x'],'gradFunc':(_0x561104,_0x5cb2e7)=>{const [_0x2a7364]=_0x5cb2e7;return{'x':()=>{const _0x5e24fe=a0_0x367f,_0x148c05=square(cast(_0x2a7364,_0x5e24fe(0x28b))),_0x5e0145=sqrt(sub(scalar(0x1),_0x148c05));return neg(div(_0x561104,_0x5e0145));}};}},acoshGradConfig={'kernelName':Acosh,'inputsToSave':['x'],'gradFunc':(_0x573637,_0x3b6d0c)=>{const [_0x1c0c81]=_0x3b6d0c;return{'x':()=>{const _0x5c2873=a0_0x367f,_0x2cf02b=sqrt(sub(square(cast(_0x1c0c81,_0x5c2873(0x28b))),0x1));return div(_0x573637,_0x2cf02b);}};}};/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function getBroadcastDims(_0x5272fe,_0x5d3a7e){const _0x1d9063=a0_0x20018c,_0x7d7634=_0x5272fe[_0x1d9063(0x104)],_0xc67284=[];for(let _0x2a98f9=0x0;_0x2a98f9<_0x7d7634;_0x2a98f9++){const _0x4f7a45=_0x7d7634-0x1-_0x2a98f9,_0x507377=_0x5272fe[_0x4f7a45]||0x1,_0x4561f2=_0x5d3a7e[_0x5d3a7e['length']-0x1-_0x2a98f9]||0x1;_0x4561f2>0x1&&_0x507377===0x1&&_0xc67284[_0x1d9063(0x578)](_0x4f7a45);}return _0xc67284;}function getReductionAxes(_0xb8ec75,_0x25017c){const _0x1c79e6=a0_0x20018c,_0x52e9e4=[];for(let _0x15537c=0x0;_0x15537c<_0x25017c[_0x1c79e6(0x104)];_0x15537c++){const _0x190ba1=_0xb8ec75[_0xb8ec75['length']-_0x15537c-0x1],_0x29097c=_0x25017c[_0x1c79e6(0x104)]-_0x15537c-0x1,_0x43e6f5=_0x25017c[_0x29097c];(_0x190ba1==null||_0x190ba1===0x1&&_0x43e6f5>0x1)&&_0x52e9e4[_0x1c79e6(0x578)](_0x29097c);}return _0x52e9e4;}function assertAndGetBroadcastShape(_0x48856d,_0x4e3830){const _0x774f45=a0_0x20018c,_0x2d5788=[],_0x484a05=Math[_0x774f45(0x1e2)](_0x48856d[_0x774f45(0x104)],_0x4e3830['length']);for(let _0x352d67=0x0;_0x352d67<_0x484a05;_0x352d67++){let _0x1034ac=_0x48856d[_0x48856d[_0x774f45(0x104)]-_0x352d67-0x1];_0x1034ac==null&&(_0x1034ac=0x1);let _0x364cb0=_0x4e3830[_0x4e3830[_0x774f45(0x104)]-_0x352d67-0x1];_0x364cb0==null&&(_0x364cb0=0x1);if(_0x1034ac===0x1)_0x2d5788[_0x774f45(0x578)](_0x364cb0);else{if(_0x364cb0===0x1)_0x2d5788['unshift'](_0x1034ac);else{if(_0x1034ac!==_0x364cb0){const _0x39d132=_0x774f45(0x1ec)+(_0x48856d+'\x20and\x20'+_0x4e3830+'.');throw Error(_0x39d132);}else _0x2d5788[_0x774f45(0x578)](_0x1034ac);}}}return _0x2d5788;}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reshape_(_0x1b953a,_0x4038a9){const _0x409730=a0_0x20018c,_0x534abf=convertToTensor(_0x1b953a,'x',_0x409730(0x1cf),'string_or_numeric'),_0x4bb913={'x':_0x534abf},_0xd1f987={'shape':_0x4038a9};return ENGINE[_0x409730(0x397)](Reshape,_0x4bb913,_0xd1f987);}const reshape=op({'reshape_':reshape_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sum_(_0x35cde3,_0x3baff5=null,_0x547c83=![]){const _0x40bb2e=a0_0x20018c;let _0x53011f=convertToTensor(_0x35cde3,'x',_0x40bb2e(0x19e));_0x53011f['dtype']===_0x40bb2e(0x188)&&(_0x53011f=cast(_0x53011f,_0x40bb2e(0x4d1)));const _0x762613={'x':_0x53011f},_0x5c0542={'axis':_0x3baff5,'keepDims':_0x547c83};return ENGINE[_0x40bb2e(0x397)](Sum,_0x762613,_0x5c0542);}const sum$1=op({'sum_':sum_}),addGradConfig={'kernelName':Add,'inputsToSave':['a','b'],'gradFunc':(_0x2d58b7,_0x153f00)=>{const _0x2687cb=a0_0x20018c,[_0x3e85aa,_0x278762]=_0x153f00,_0x5aae18=assertAndGetBroadcastShape(_0x3e85aa[_0x2687cb(0x50f)],_0x278762['shape']),_0x2d0775=()=>{const _0x4619e3=_0x2687cb;let _0x46fa54=_0x2d58b7;const _0x2baffa=getReductionAxes(_0x3e85aa[_0x4619e3(0x50f)],_0x5aae18);return _0x2baffa[_0x4619e3(0x104)]>0x0&&(_0x46fa54=sum$1(_0x46fa54,_0x2baffa)),reshape(_0x46fa54,_0x3e85aa[_0x4619e3(0x50f)]);},_0xba50d6=()=>{const _0x408313=_0x2687cb;let _0x48d2ec=_0x2d58b7;const _0x57e017=getReductionAxes(_0x278762[_0x408313(0x50f)],_0x5aae18);return _0x57e017['length']>0x0&&(_0x48d2ec=sum$1(_0x48d2ec,_0x57e017)),reshape(_0x48d2ec,_0x278762[_0x408313(0x50f)]);};return{'a':_0x2d0775,'b':_0xba50d6};}},addNGradConfig={'kernelName':AddN,'saveAllInputs':!![],'gradFunc':(_0x5d0614,_0x2ebc06)=>{const _0x2c2426=a0_0x20018c,_0x3760de={};return _0x2ebc06[_0x2c2426(0x1e4)]((_0x5d6309,_0x1203cb)=>{_0x3760de[_0x1203cb]=()=>_0x5d0614['clone']();}),_0x3760de;}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function zerosLike_(_0x496c73){const _0x32bf13=a0_0x20018c,_0x2b1344=convertToTensor(_0x496c73,'x',_0x32bf13(0x1a8)),_0x5ab909={'x':_0x2b1344};return ENGINE['runKernel'](ZerosLike,_0x5ab909);}const zerosLike=op({'zerosLike_':zerosLike_}),argMaxGradConfig={'kernelName':ArgMax,'inputsToSave':['x'],'gradFunc':(_0x2b6da3,_0x1397c4)=>{const [_0x89a659]=_0x1397c4;return{'x':()=>zerosLike(_0x89a659)};}},argMinGradConfig={'kernelName':ArgMin,'inputsToSave':['x'],'gradFunc':(_0x351f2d,_0x43337f)=>{const [_0x431f7f]=_0x43337f;return{'x':()=>zerosLike(_0x431f7f)};}},asinGradConfig={'kernelName':Asin,'inputsToSave':['x'],'gradFunc':(_0x990db5,_0x316a09)=>{const _0x130121=a0_0x20018c,[_0x3b0185]=_0x316a09;return{'x':()=>div(_0x990db5,sqrt(sub(scalar(0x1),square(cast(_0x3b0185,_0x130121(0x28b))))))};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function add_(_0x37a7c8,_0x68ba53){const _0x5a7573=a0_0x20018c;let _0x5a0eef=convertToTensor(_0x37a7c8,'a',_0x5a7573(0x4ed)),_0x233dc3=convertToTensor(_0x68ba53,'b','add');[_0x5a0eef,_0x233dc3]=makeTypesMatch(_0x5a0eef,_0x233dc3);const _0x7134f={'a':_0x5a0eef,'b':_0x233dc3};return ENGINE[_0x5a7573(0x397)](Add,_0x7134f);}const add$1=op({'add_':add_}),asinhGradConfig={'kernelName':Asinh,'inputsToSave':['x'],'gradFunc':(_0x1edcaf,_0x339c3a)=>{const [_0x55b48e]=_0x339c3a;return{'x':()=>{const _0x54a9fb=a0_0x367f,_0x5eaa04=sqrt(add$1(scalar(0x1),square(cast(_0x55b48e,_0x54a9fb(0x28b)))));return div(_0x1edcaf,_0x5eaa04);}};}},atan2GradConfig={'kernelName':Atan2,'inputsToSave':['a','b'],'gradFunc':(_0x5870f1,_0x13b418)=>{const _0x662387=a0_0x20018c,[_0x220685,_0x5782a5]=_0x13b418,_0x50ef4c=assertAndGetBroadcastShape(_0x220685[_0x662387(0x50f)],_0x5782a5[_0x662387(0x50f)]),_0x17475e=()=>{const _0x4d7aa2=_0x662387,_0x593763=add$1(square(_0x220685),square(_0x5782a5));let _0x460ea6=mul(_0x5870f1,div(_0x5782a5,_0x593763));const _0x2bc148=getReductionAxes(_0x220685[_0x4d7aa2(0x50f)],_0x50ef4c);return _0x2bc148['length']>0x0&&(_0x460ea6=sum$1(_0x460ea6,_0x2bc148)),reshape(_0x460ea6,_0x220685[_0x4d7aa2(0x50f)]);},_0x3c68c1=()=>{const _0x542af9=add$1(square(_0x220685),square(_0x5782a5));let _0x40ccef=neg(mul(_0x5870f1,div(_0x220685,_0x542af9)));const _0x45574f=getReductionAxes(_0x5782a5['shape'],_0x50ef4c);return _0x45574f['length']>0x0&&(_0x40ccef=sum$1(_0x40ccef,_0x45574f)),reshape(_0x40ccef,_0x5782a5['shape']);};return{'a':_0x17475e,'b':_0x3c68c1};}},atanGradConfig={'kernelName':Atan,'inputsToSave':['x'],'gradFunc':(_0x1b7109,_0x3bf72b)=>{const _0x5e94ec=a0_0x20018c,[_0x34a62b]=_0x3bf72b;return{'x':()=>div(_0x1b7109,add$1(square(cast(_0x34a62b,_0x5e94ec(0x28b))),0x1))};}},atanhGradConfig={'kernelName':Atanh,'inputsToSave':['x'],'gradFunc':(_0x57e426,_0x1b998a)=>{const _0x4a65e9=a0_0x20018c,[_0x388e19]=_0x1b998a;return{'x':()=>div(_0x57e426,sub(scalar(0x1),square(cast(_0x388e19,_0x4a65e9(0x28b)))))};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function avgPool3dGrad_(_0x23ed1f,_0x286f5c,_0x24b94a,_0x49439c,_0x364588,_0x28256f){const _0x39abbc=a0_0x20018c,_0x403d4b=convertToTensor(_0x23ed1f,'dy',_0x39abbc(0x26a)),_0x3b9358=convertToTensor(_0x286f5c,_0x39abbc(0x333),_0x39abbc(0x26a));let _0x19401c=_0x403d4b,_0x4a36b4=_0x3b9358,_0x24b8e8=![];_0x3b9358[_0x39abbc(0x36e)]===0x4&&(_0x24b8e8=!![],_0x19401c=reshape(_0x403d4b,[0x1,_0x403d4b[_0x39abbc(0x50f)][0x0],_0x403d4b[_0x39abbc(0x50f)][0x1],_0x403d4b[_0x39abbc(0x50f)][0x2],_0x403d4b['shape'][0x3]]),_0x4a36b4=reshape(_0x3b9358,[0x1,_0x3b9358[_0x39abbc(0x50f)][0x0],_0x3b9358[_0x39abbc(0x50f)][0x1],_0x3b9358[_0x39abbc(0x50f)][0x2],_0x3b9358['shape'][0x3]]));assert(_0x19401c['rank']===0x5,()=>_0x39abbc(0x4dc)+(_0x19401c[_0x39abbc(0x36e)]+'.')),assert(_0x4a36b4['rank']===0x5,()=>_0x39abbc(0x221)+(_0x4a36b4[_0x39abbc(0x36e)]+'.'));_0x28256f!=null&&assert(isInt(_0x364588),()=>_0x39abbc(0x4c5)+(_0x39abbc(0x37e)+_0x28256f+_0x39abbc(0x27d)+_0x364588+'.'));const _0x8a3d82={'dy':_0x19401c,'input':_0x4a36b4},_0x13f4da={'filterSize':_0x24b94a,'strides':_0x49439c,'pad':_0x364588,'dimRoundingMode':_0x28256f},_0x56ee06=ENGINE[_0x39abbc(0x397)](AvgPool3DGrad,_0x8a3d82,_0x13f4da);if(_0x24b8e8)return reshape(_0x56ee06,[_0x56ee06['shape'][0x1],_0x56ee06[_0x39abbc(0x50f)][0x2],_0x56ee06[_0x39abbc(0x50f)][0x3],_0x56ee06[_0x39abbc(0x50f)][0x4]]);return _0x56ee06;}const avgPool3dGrad=op({'avgPool3dGrad_':avgPool3dGrad_}),avgPool3DGradConfig={'kernelName':AvgPool3D,'inputsToSave':['x'],'gradFunc':(_0xd616ca,_0x4b4d1d,_0x4088ee)=>{const [_0x356180]=_0x4b4d1d,{filterSize:_0x3e4ac3,strides:_0x30a4cb,pad:_0x5a7bca,dimRoundingMode:_0x478648}=_0x4088ee;return{'x':()=>avgPool3dGrad(_0xd616ca,_0x356180,_0x3e4ac3,_0x30a4cb,_0x5a7bca,_0x478648)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function avgPoolGrad_(_0x36ba7c,_0x59b76e,_0x506f07,_0x3a5352,_0x5d1e36){const _0x46c72f=a0_0x20018c,_0x210be1=convertToTensor(_0x36ba7c,'dy',_0x46c72f(0x318)),_0x997b4=convertToTensor(_0x59b76e,_0x46c72f(0x333),'avgPoolGrad');assert(_0x997b4['rank']===_0x210be1[_0x46c72f(0x36e)],()=>_0x46c72f(0x57a)+_0x997b4['rank']+_0x46c72f(0x5b7)+_0x210be1[_0x46c72f(0x36e)]+')');let _0x1d2768=_0x997b4,_0x45a621=_0x210be1,_0x59bcf2=![];_0x997b4[_0x46c72f(0x36e)]===0x3&&(_0x59bcf2=!![],_0x1d2768=reshape(_0x997b4,[0x1,_0x997b4[_0x46c72f(0x50f)][0x0],_0x997b4[_0x46c72f(0x50f)][0x1],_0x997b4[_0x46c72f(0x50f)][0x2]]),_0x45a621=reshape(_0x210be1,[0x1,_0x210be1[_0x46c72f(0x50f)][0x0],_0x210be1[_0x46c72f(0x50f)][0x1],_0x210be1[_0x46c72f(0x50f)][0x2]]));assert(_0x45a621[_0x46c72f(0x36e)]===0x4,()=>_0x46c72f(0x30d)+(_0x45a621[_0x46c72f(0x36e)]+'.')),assert(_0x1d2768[_0x46c72f(0x36e)]===0x4,()=>_0x46c72f(0x498)+(_0x1d2768[_0x46c72f(0x36e)]+'.'));const _0x4827e3={'dy':_0x45a621,'input':_0x1d2768},_0x38dac5={'filterSize':_0x506f07,'strides':_0x3a5352,'pad':_0x5d1e36},_0x175166=ENGINE[_0x46c72f(0x397)](AvgPoolGrad,_0x4827e3,_0x38dac5);if(_0x59bcf2)return reshape(_0x175166,[_0x175166['shape'][0x1],_0x175166[_0x46c72f(0x50f)][0x2],_0x175166[_0x46c72f(0x50f)][0x3]]);return _0x175166;}const avgPoolGrad=op({'avgPoolGrad_':avgPoolGrad_}),avgPoolGradConfig={'kernelName':AvgPool,'inputsToSave':['x'],'gradFunc':(_0x38f6c3,_0x303333,_0x346279)=>{const [_0x12e64b]=_0x303333,{filterSize:_0xf95302,strides:_0x4ae478,pad:_0x113ccd}=_0x346279;return{'x':()=>avgPoolGrad(_0x38f6c3,_0x12e64b,_0xf95302,_0x4ae478,_0x113ccd)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function matMul_(_0x3ac2f6,_0x4ff9d1,_0x309c4b=![],_0x3120f8=![]){const _0x5b323c=a0_0x20018c;let _0x58fc10=convertToTensor(_0x3ac2f6,'a',_0x5b323c(0x356)),_0x3051a9=convertToTensor(_0x4ff9d1,'b',_0x5b323c(0x356));[_0x58fc10,_0x3051a9]=makeTypesMatch(_0x58fc10,_0x3051a9);const _0x2f0974={'a':_0x58fc10,'b':_0x3051a9},_0x3b88f3={'transposeA':_0x309c4b,'transposeB':_0x3120f8};return ENGINE['runKernel'](BatchMatMul,_0x2f0974,_0x3b88f3);}const matMul=op({'matMul_':matMul_}),batchMatMulGradConfig={'kernelName':BatchMatMul,'inputsToSave':['a','b'],'gradFunc':(_0x35b297,_0x16a0f4,_0x5aa495)=>{const [_0x179a07,_0x2fbf78]=_0x16a0f4,{transposeA:_0x26eafc,transposeB:_0x562e7d}=_0x5aa495;if(!_0x26eafc&&!_0x562e7d)return{'a':()=>matMul(_0x35b297,_0x2fbf78,![],!![]),'b':()=>matMul(_0x179a07,_0x35b297,!![],![])};else{if(!_0x26eafc&&_0x562e7d)return{'a':()=>matMul(_0x35b297,_0x2fbf78,![],![]),'b':()=>matMul(_0x35b297,_0x179a07,!![],![])};else return _0x26eafc&&!_0x562e7d?{'a':()=>matMul(_0x2fbf78,_0x35b297,![],!![]),'b':()=>matMul(_0x179a07,_0x35b297,![],![])}:{'a':()=>matMul(_0x2fbf78,_0x35b297,!![],!![]),'b':()=>matMul(_0x35b297,_0x179a07,!![],!![])};}}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function spaceToBatchND_(_0x3a2856,_0x425594,_0xc604b5){const _0x2d8ec9=a0_0x20018c,_0x47247c=convertToTensor(_0x3a2856,'x',_0x2d8ec9(0x4ba));assert(_0x47247c[_0x2d8ec9(0x36e)]>=0x1+_0x425594[_0x2d8ec9(0x104)],()=>_0x2d8ec9(0x122)+_0x47247c[_0x2d8ec9(0x36e)]+'\x20should\x20be\x20>\x20than\x20[blockShape]\x20'+_0x425594[_0x2d8ec9(0x104)]),assert(_0xc604b5[_0x2d8ec9(0x104)]===_0x425594[_0x2d8ec9(0x104)],()=>_0x2d8ec9(0x304)+_0xc604b5[_0x2d8ec9(0x104)]+_0x2d8ec9(0x5ac)+_0x425594[_0x2d8ec9(0x104)]),assert(_0x47247c[_0x2d8ec9(0x50f)][_0x2d8ec9(0x48a)]((_0x9146a,_0x50a6ca,_0x381a82)=>{const _0x46746a=_0x2d8ec9;if(_0x381a82>0x0&&_0x381a82<=_0x425594[_0x46746a(0x104)])return _0x9146a&&(_0x50a6ca+_0xc604b5[_0x381a82-0x1][0x0]+_0xc604b5[_0x381a82-0x1][0x1])%_0x425594[_0x381a82-0x1]===0x0;return _0x9146a;},!![]),()=>_0x2d8ec9(0x5ab)+_0x47247c[_0x2d8ec9(0x50f)][_0x2d8ec9(0x2b0)](0x1)+'\x20with\x20paddings\x20'+_0xc604b5[_0x2d8ec9(0x499)]()+_0x2d8ec9(0x46a)+_0x425594[_0x2d8ec9(0x499)]());const _0x23588e={'x':_0x47247c},_0x3a6041={'blockShape':_0x425594,'paddings':_0xc604b5};return ENGINE[_0x2d8ec9(0x397)](SpaceToBatchND,_0x23588e,_0x3a6041);}const spaceToBatchND=op({'spaceToBatchND_':spaceToBatchND_}),batchToSpaceNDGradConfig={'kernelName':BatchToSpaceND,'gradFunc':(_0x2a2275,_0x325f53,_0x3f5d8f)=>{const {blockShape:_0x1d809e,crops:_0x16d0e7}=_0x3f5d8f;return{'x':()=>spaceToBatchND(_0x2a2275,_0x1d809e,_0x16d0e7)};}},broadcastToGradConfig={'kernelName':BroadcastTo,'gradFunc':(_0x558c48,_0x14862f,_0x3e15ea)=>{const _0x557c9a=a0_0x20018c,_0x5854f6=_0x3e15ea,_0x484feb=_0x5854f6[_0x557c9a(0x270)],_0x58c8a3=_0x5854f6[_0x557c9a(0x50f)],_0x9761e1=Array[_0x557c9a(0x530)](_0x58c8a3);for(let _0x3e7329=_0x484feb[_0x557c9a(0x104)]-0x1;_0x3e7329>=0x0;_0x3e7329--){if(_0x484feb[_0x3e7329]===_0x58c8a3[_0x3e7329])_0x9761e1[_0x3e7329]=0x1;else{if(_0x484feb[_0x3e7329]!==0x1)throw new Error('broadcastTo():\x20['+_0x484feb+']\x20cannot\x20be\x20broadcast\x20to\x20['+_0x58c8a3+'].');}}const _0x2c7260=[];for(let _0x519ca4=0x0;_0x519ca4<_0x9761e1['length'];_0x519ca4++){_0x9761e1[_0x519ca4]>0x1&&_0x2c7260[_0x557c9a(0x30f)](_0x519ca4);}return{'x':()=>sum$1(_0x558c48,_0x2c7260,!![])};}},castGradConfig={'kernelName':Cast,'gradFunc':_0x5b683c=>{const _0x51359c=a0_0x20018c;return{'x':()=>_0x5b683c[_0x51359c(0x49d)]()};}},ceilGradConfig={'kernelName':Ceil,'gradFunc':_0x268241=>{return{'x':()=>zerosLike(_0x268241)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function greaterEqual_(_0x59c9cc,_0x3e97bd){const _0x1e81f4=a0_0x20018c;let _0x2a8320=convertToTensor(_0x59c9cc,'a','greaterEqual',_0x1e81f4(0x5c4)),_0xc0ffb3=convertToTensor(_0x3e97bd,'b',_0x1e81f4(0x1dc),_0x1e81f4(0x5c4));[_0x2a8320,_0xc0ffb3]=makeTypesMatch(_0x2a8320,_0xc0ffb3),assertAndGetBroadcastShape(_0x2a8320['shape'],_0xc0ffb3[_0x1e81f4(0x50f)]);const _0x2e1704={'a':_0x2a8320,'b':_0xc0ffb3};return ENGINE[_0x1e81f4(0x397)](GreaterEqual,_0x2e1704);}const greaterEqual=op({'greaterEqual_':greaterEqual_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function lessEqual_(_0x4b2cb7,_0x4850c6){const _0x55bb1b=a0_0x20018c;let _0x1da6ea=convertToTensor(_0x4b2cb7,'a',_0x55bb1b(0x2a2),_0x55bb1b(0x5c4)),_0x27d2d8=convertToTensor(_0x4850c6,'b','lessEqual','string_or_numeric');[_0x1da6ea,_0x27d2d8]=makeTypesMatch(_0x1da6ea,_0x27d2d8),assertAndGetBroadcastShape(_0x1da6ea[_0x55bb1b(0x50f)],_0x27d2d8[_0x55bb1b(0x50f)]);const _0x210215={'a':_0x1da6ea,'b':_0x27d2d8};return ENGINE[_0x55bb1b(0x397)](LessEqual,_0x210215);}const lessEqual=op({'lessEqual_':lessEqual_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logicalAnd_(_0x53db11,_0x12300b){const _0x340d7f=a0_0x20018c,_0x5aaa14=convertToTensor(_0x53db11,'a','logicalAnd','bool'),_0x25f951=convertToTensor(_0x12300b,'b',_0x340d7f(0x2db),_0x340d7f(0x188));assertAndGetBroadcastShape(_0x5aaa14[_0x340d7f(0x50f)],_0x25f951[_0x340d7f(0x50f)]);const _0x3b9070={'a':_0x5aaa14,'b':_0x25f951};return ENGINE['runKernel'](LogicalAnd,_0x3b9070);}const logicalAnd=op({'logicalAnd_':logicalAnd_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function clone_(_0x4a4725){const _0x571610=a0_0x20018c,_0x59aeaa=convertToTensor(_0x4a4725,'x',_0x571610(0x49d),'string_or_numeric'),_0x5a8934={'x':_0x59aeaa};return ENGINE[_0x571610(0x397)](Identity,_0x5a8934);}const clone=op({'clone_':clone_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function broadcastTo_(_0x5d1d39,_0x4b1ea5){const _0x584aec=a0_0x20018c;let _0x2e60e0=convertToTensor(_0x5d1d39,_0x584aec(0x284),'x');const _0x69b6d7=_0x2e60e0[_0x584aec(0x50f)];if(_0x4b1ea5[_0x584aec(0x128)](_0x2de9d2=>!(_0x2de9d2>0x0)||_0x2de9d2%0x1!==0x0))throw new Error(_0x584aec(0x434)+_0x4b1ea5+'].');if(_0x4b1ea5[_0x584aec(0x104)]<_0x2e60e0[_0x584aec(0x36e)])throw new Error(_0x584aec(0x218)+_0x4b1ea5[_0x584aec(0x104)]+_0x584aec(0x540)+_0x2e60e0[_0x584aec(0x36e)]+'.');if(_0x4b1ea5[_0x584aec(0x104)]>_0x2e60e0[_0x584aec(0x36e)]){const _0x1dd6ea=_0x2e60e0[_0x584aec(0x50f)]['slice']();while(_0x1dd6ea[_0x584aec(0x104)]<_0x4b1ea5[_0x584aec(0x104)]){_0x1dd6ea[_0x584aec(0x578)](0x1);}_0x2e60e0=reshape(_0x2e60e0,_0x1dd6ea);}const _0x416845=_0x2e60e0[_0x584aec(0x50f)],_0x485cc9=Array[_0x584aec(0x530)](_0x4b1ea5);for(let _0x5086f6=_0x4b1ea5[_0x584aec(0x104)]-0x1;_0x5086f6>=0x0;_0x5086f6--){if(_0x416845[_0x5086f6]===_0x4b1ea5[_0x5086f6])_0x485cc9[_0x5086f6]=0x1;else{if(_0x2e60e0[_0x584aec(0x50f)][_0x5086f6]!==0x1)throw new Error(_0x584aec(0x26b)+_0x69b6d7+_0x584aec(0x5bf)+_0x4b1ea5+'].');}}const _0x24a95a=_0x485cc9['map']((_0x3f91c2,_0x5b5ade)=>_0x3f91c2>0x1?_0x5b5ade:-0x1)[_0x584aec(0x481)](_0x26bd97=>_0x26bd97>=0x0);if(_0x24a95a[_0x584aec(0x104)]===0x0)return clone(_0x2e60e0);const _0x28d63c={'x':_0x2e60e0},_0x46315a={'reps':_0x485cc9};return ENGINE[_0x584aec(0x397)](Tile,_0x28d63c,_0x46315a);}const broadcastTo=op({'broadcastTo_':broadcastTo_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function where_(_0x30a0d4,_0x479b6f,_0x217cf9){const _0x16658a=a0_0x20018c,_0x4a5061=convertToTensor(_0x479b6f,'a',_0x16658a(0x543)),_0x3f0a6f=convertToTensor(_0x217cf9,'b',_0x16658a(0x543)),_0x4fd6f0=convertToTensor(_0x30a0d4,'condition',_0x16658a(0x543),_0x16658a(0x188)),_0x4cfb9b=assertAndGetBroadcastShape(assertAndGetBroadcastShape(_0x4fd6f0[_0x16658a(0x50f)],_0x4a5061[_0x16658a(0x50f)]),_0x3f0a6f[_0x16658a(0x50f)]),_0x151a69=broadcastTo(_0x4fd6f0,_0x4cfb9b),_0xead27e=broadcastTo(_0x4a5061,_0x4cfb9b),_0x32df5d=broadcastTo(_0x3f0a6f,_0x4cfb9b),_0x524f9a={'condition':_0x151a69,'t':_0xead27e,'e':_0x32df5d};return ENGINE[_0x16658a(0x397)](Select,_0x524f9a);}const where=op({'where_':where_}),clipByValueGradConfig={'kernelName':ClipByValue,'inputsToSave':['x'],'gradFunc':(_0x7d88dc,_0x137864,_0x527e8e)=>{const [_0x259ad1]=_0x137864,{clipValueMin:_0x414cfe,clipValueMax:_0x16fdb9}=_0x527e8e;return{'x':()=>where(logicalAnd(greaterEqual(_0x259ad1,_0x414cfe),lessEqual(_0x259ad1,_0x16fdb9)),_0x7d88dc,zerosLike(_0x7d88dc))};}},complexAbsGradConfig={'kernelName':ComplexAbs,'inputsToSave':['x'],'gradFunc':absGradConfig[a0_0x20018c(0xea)]};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function split_(_0x5bd2f7,_0xff8a29,_0x1d86a7=0x0){const _0x421d67=a0_0x20018c,_0x5c1fc7=convertToTensor(_0x5bd2f7,'x',_0x421d67(0x45d)),_0x56df52={'x':_0x5c1fc7},_0xb630c2={'numOrSizeSplits':_0xff8a29,'axis':_0x1d86a7};return ENGINE[_0x421d67(0x397)](SplitV,_0x56df52,_0xb630c2);}const split=op({'split_':split_}),concatGradConfig={'kernelName':Concat,'saveAllInputs':!![],'gradFunc':(_0x316976,_0xe5c04,_0x3ed7e9)=>{const _0x197a71=a0_0x20018c,_0x1f48c1=_0xe5c04[_0x197a71(0x3ab)](_0x20ee29=>_0x20ee29[_0x197a71(0x50f)]),{axis:_0x52b8be}=_0x3ed7e9,_0x483477=parseAxisParam(_0x52b8be,_0xe5c04[0x0][_0x197a71(0x50f)])[0x0],_0x395c33=_0x1f48c1[_0x197a71(0x3ab)](_0x54793d=>_0x54793d[_0x483477]),_0x209d23=split(_0x316976,_0x395c33,_0x483477);return _0x209d23['map'](_0x111c59=>()=>_0x111c59);}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function conv2DBackpropFilter_(_0x3cf6f8,_0x5d499a,_0x3cca00,_0x5e95b6,_0x22794b,_0x6247cb=a0_0x20018c(0x4c9),_0x1a0375){const _0x3222c4=a0_0x20018c;let _0x16a86d=_0x3cf6f8;_0x3cf6f8['rank']===0x3&&(_0x16a86d=reshape(_0x3cf6f8,[0x1,_0x3cf6f8['shape'][0x0],_0x3cf6f8[_0x3222c4(0x50f)][0x1],_0x3cf6f8[_0x3222c4(0x50f)][0x2]]));let _0x3e2edd=_0x5d499a;_0x3e2edd[_0x3222c4(0x36e)]===0x3&&(_0x3e2edd=reshape(_0x5d499a,[0x1,_0x5d499a[_0x3222c4(0x50f)][0x0],_0x5d499a[_0x3222c4(0x50f)][0x1],_0x5d499a['shape'][0x2]]));assert(_0x16a86d[_0x3222c4(0x36e)]===0x4,()=>_0x3222c4(0x17f)+(_0x16a86d[_0x3222c4(0x50f)]+'.')),assert(_0x3e2edd[_0x3222c4(0x36e)]===0x4,()=>_0x3222c4(0x57b)+(_0x3e2edd[_0x3222c4(0x50f)]+'.')),assert(_0x3cca00[_0x3222c4(0x104)]===0x4,()=>_0x3222c4(0x2e6)+(_0x3cca00+'.'));const _0x26e8d7=_0x6247cb===_0x3222c4(0x4c9)?_0x16a86d[_0x3222c4(0x50f)][0x3]:_0x16a86d[_0x3222c4(0x50f)][0x1],_0x1026a6=_0x6247cb===_0x3222c4(0x4c9)?_0x3e2edd['shape'][0x3]:_0x3e2edd['shape'][0x1];assert(_0x26e8d7===_0x3cca00[0x2],()=>_0x3222c4(0x5be)+_0x26e8d7+_0x3222c4(0x102)+('match\x20input\x20depth\x20in\x20filter\x20('+_0x3cca00[0x2]+'.')),assert(_0x1026a6===_0x3cca00[0x3],()=>_0x3222c4(0x418)+_0x1026a6+_0x3222c4(0x102)+(_0x3222c4(0x1e9)+_0x3cca00[0x3]+').'));_0x1a0375!=null&&assert(isInt(_0x22794b),()=>_0x3222c4(0x4f3)+('dimRoundingMode\x20'+_0x1a0375+'\x20but\x20got\x20pad\x20'+_0x22794b+'.'));const _0x2bace4={'x':_0x16a86d,'dy':_0x3e2edd},_0x50a4be={'strides':_0x5e95b6,'pad':_0x22794b,'dataFormat':_0x6247cb,'dimRoundingMode':_0x1a0375,'filterShape':_0x3cca00};return ENGINE[_0x3222c4(0x397)](Conv2DBackpropFilter,_0x2bace4,_0x50a4be);}const conv2DBackpropFilter=op({'conv2DBackpropFilter_':conv2DBackpropFilter_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function conv2DBackpropInput_(_0x2a890b,_0x1bd008,_0x1d0031,_0x3bfb69,_0x55aaf8,_0x4276cd=a0_0x20018c(0x4c9),_0x3aed3f){const _0x315ffe=a0_0x20018c;assert(_0x2a890b['length']===_0x1bd008[_0x315ffe(0x36e)],()=>_0x315ffe(0x3d3)+('('+_0x2a890b['length']+_0x315ffe(0x235)+_0x1bd008[_0x315ffe(0x36e)]+_0x315ffe(0x4da)));let _0x51cc48=_0x2a890b,_0x22bd0e=_0x1bd008,_0x216b8d=![];_0x1bd008[_0x315ffe(0x36e)]===0x3&&(_0x216b8d=!![],_0x22bd0e=reshape(_0x1bd008,[0x1,_0x1bd008['shape'][0x0],_0x1bd008[_0x315ffe(0x50f)][0x1],_0x1bd008[_0x315ffe(0x50f)][0x2]]),_0x51cc48=[0x1,_0x2a890b[0x0],_0x2a890b[0x1],_0x2a890b[0x2]]);assert(_0x51cc48['length']===0x4,()=>'Error\x20in\x20conv2dDerInput:\x20inShape\x20must\x20be\x20length\x204,\x20but\x20got\x20length\x20'+(_0x51cc48[_0x315ffe(0x104)]+'.')),assert(_0x22bd0e[_0x315ffe(0x36e)]===0x4,()=>_0x315ffe(0x1a4)+(_0x315ffe(0x5b5)+_0x22bd0e['rank'])),assert(_0x1d0031['rank']===0x4,()=>_0x315ffe(0x5c6)+('rank\x20'+_0x1d0031[_0x315ffe(0x36e)]));const _0x337d6b=_0x4276cd==='NHWC'?_0x51cc48[0x3]:_0x51cc48[0x1],_0x375213=_0x4276cd===_0x315ffe(0x4c9)?_0x22bd0e[_0x315ffe(0x50f)][0x3]:_0x22bd0e['shape'][0x1];assert(_0x337d6b===_0x1d0031[_0x315ffe(0x50f)][0x2],()=>_0x315ffe(0x56f)+_0x337d6b+_0x315ffe(0x102)+('match\x20input\x20depth\x20for\x20filter\x20'+_0x1d0031[_0x315ffe(0x50f)][0x2]+'.')),assert(_0x375213===_0x1d0031['shape'][0x3],()=>'Error\x20in\x20conv2dDerInput:\x20depth\x20of\x20output\x20('+_0x375213+')\x20must\x20'+(_0x315ffe(0x386)+_0x1d0031[_0x315ffe(0x50f)][0x3]+'.'));_0x3aed3f!=null&&assert(isInt(_0x55aaf8),()=>_0x315ffe(0x2b2)+(_0x315ffe(0x51f)+_0x3aed3f+'\x20but\x20got\x20pad\x20'+_0x55aaf8+'.'));const _0x14231f={'dy':_0x22bd0e,'filter':_0x1d0031},_0x3f6545={'strides':_0x3bfb69,'pad':_0x55aaf8,'dataFormat':_0x4276cd,'dimRoundingMode':_0x3aed3f,'inputShape':_0x51cc48},_0x3c6e1a=ENGINE[_0x315ffe(0x397)](Conv2DBackpropInput,_0x14231f,_0x3f6545);if(_0x216b8d)return reshape(_0x3c6e1a,[_0x3c6e1a[_0x315ffe(0x50f)][0x1],_0x3c6e1a[_0x315ffe(0x50f)][0x2],_0x3c6e1a[_0x315ffe(0x50f)][0x3]]);return _0x3c6e1a;}const conv2DBackpropInput=op({'conv2DBackpropInput_':conv2DBackpropInput_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function computeDilation2DInfo(_0x504daf,_0x2b20d5,_0x6446ae,_0xf8b06d,_0x103f20=a0_0x20018c(0x4c9),_0x31eaf6){const _0x50dd7d=_0x504daf[0x3],_0x1e2d8d=[..._0x2b20d5,_0x50dd7d],_0xca7a04=convertConv2DDataFormat(_0x103f20);return computeConv2DInfo(_0x504daf,_0x1e2d8d,_0x6446ae,_0x31eaf6,_0xf8b06d,null,null,_0xca7a04);}function computePool2DInfo(_0x4e2878,_0x56af9b,_0x521818,_0x2f1c44,_0x468bc6,_0x228a17,_0x5244cc=a0_0x20018c(0x455)){const _0x43a05d=a0_0x20018c,[_0x4ad5c1,_0x4656b2]=parseTupleParam(_0x56af9b);let _0x52a072;if(_0x5244cc===_0x43a05d(0x455))_0x52a072=[_0x4ad5c1,_0x4656b2,_0x4e2878[0x3],_0x4e2878[0x3]];else{if(_0x5244cc===_0x43a05d(0x121))_0x52a072=[_0x4ad5c1,_0x4656b2,_0x4e2878[0x1],_0x4e2878[0x1]];else throw new Error('Unknown\x20dataFormat\x20'+_0x5244cc);}return computeConv2DInfo(_0x4e2878,_0x52a072,_0x521818,_0x2f1c44,_0x468bc6,_0x228a17,![],_0x5244cc);}function computePool3DInfo(_0x354d14,_0x1efb52,_0x53fa1e,_0x701f67,_0x547935,_0x19b487,_0x26dfaa='NDHWC'){const _0x5340ac=a0_0x20018c,[_0x24f907,_0xde0d34,_0xf61055]=parse3TupleParam(_0x1efb52);let _0x5acba3,_0x5834cf;if(_0x26dfaa==='NDHWC')_0x5834cf=_0x5340ac(0x455),_0x5acba3=[_0x24f907,_0xde0d34,_0xf61055,_0x354d14[0x4],_0x354d14[0x4]];else{if(_0x26dfaa===_0x5340ac(0x431))_0x5834cf=_0x5340ac(0x121),_0x5acba3=[_0x24f907,_0xde0d34,_0xf61055,_0x354d14[0x1],_0x354d14[0x1]];else throw new Error('Unknown\x20dataFormat\x20'+_0x26dfaa);}return computeConv3DInfo(_0x354d14,_0x5acba3,_0x53fa1e,_0x701f67,_0x547935,![],_0x5834cf,_0x19b487);}function computeConv2DInfo(_0x58da76,_0x2b9e3d,_0x27225b,_0x4dd4f7,_0x100dcd,_0x183697,_0x5e3746=![],_0x46e68c='channelsLast'){const _0x11341f=a0_0x20018c;let [_0x4fc06c,_0x39e077,_0x9ea946,_0x5692f1]=[-0x1,-0x1,-0x1,-0x1];if(_0x46e68c==='channelsLast')[_0x4fc06c,_0x39e077,_0x9ea946,_0x5692f1]=_0x58da76;else{if(_0x46e68c===_0x11341f(0x121))[_0x4fc06c,_0x5692f1,_0x39e077,_0x9ea946]=_0x58da76;else throw new Error(_0x11341f(0x3f3)+_0x46e68c);}const [_0x1e4337,_0xc53eb6,,_0x4ed0a5]=_0x2b9e3d,[_0x37f9a3,_0x494cac]=parseTupleParam(_0x27225b),[_0x4e892c,_0x90313f]=parseTupleParam(_0x4dd4f7),_0x24e91b=getEffectiveFilterSize(_0x1e4337,_0x4e892c),_0x580230=getEffectiveFilterSize(_0xc53eb6,_0x90313f),{padInfo:_0x47fd63,outHeight:_0xb09680,outWidth:_0x116a89}=getPadAndOutInfo(_0x100dcd,_0x39e077,_0x9ea946,_0x37f9a3,_0x494cac,_0x24e91b,_0x580230,_0x183697,_0x46e68c),_0x174366=_0x5e3746?_0x4ed0a5*_0x5692f1:_0x4ed0a5;let _0x5c75a9;if(_0x46e68c===_0x11341f(0x121))_0x5c75a9=[_0x4fc06c,_0x174366,_0xb09680,_0x116a89];else _0x46e68c===_0x11341f(0x455)&&(_0x5c75a9=[_0x4fc06c,_0xb09680,_0x116a89,_0x174366]);return{'batchSize':_0x4fc06c,'dataFormat':_0x46e68c,'inHeight':_0x39e077,'inWidth':_0x9ea946,'inChannels':_0x5692f1,'outHeight':_0xb09680,'outWidth':_0x116a89,'outChannels':_0x174366,'padInfo':_0x47fd63,'strideHeight':_0x37f9a3,'strideWidth':_0x494cac,'filterHeight':_0x1e4337,'filterWidth':_0xc53eb6,'effectiveFilterHeight':_0x24e91b,'effectiveFilterWidth':_0x580230,'dilationHeight':_0x4e892c,'dilationWidth':_0x90313f,'inShape':_0x58da76,'outShape':_0x5c75a9,'filterShape':_0x2b9e3d};}function computeConv3DInfo(_0x217d48,_0xbadf60,_0x5863d8,_0x4e01df,_0x330ac1,_0x4c2e39=![],_0x12e172=a0_0x20018c(0x455),_0x104e4f){const _0xd97dae=a0_0x20018c;let [_0x1ffc15,_0x2b85fb,_0x5d3182,_0x53d4f3,_0x425fc2]=[-0x1,-0x1,-0x1,-0x1,-0x1];if(_0x12e172===_0xd97dae(0x455))[_0x1ffc15,_0x2b85fb,_0x5d3182,_0x53d4f3,_0x425fc2]=_0x217d48;else{if(_0x12e172===_0xd97dae(0x121))[_0x1ffc15,_0x425fc2,_0x2b85fb,_0x5d3182,_0x53d4f3]=_0x217d48;else throw new Error(_0xd97dae(0x3f3)+_0x12e172);}const [_0x5e495b,_0x4a6978,_0x134b48,,_0x25baa2]=_0xbadf60,[_0x378275,_0xb241ac,_0x1bcc2a]=parse3TupleParam(_0x5863d8),[_0x1e444a,_0x11146d,_0x1ba625]=parse3TupleParam(_0x4e01df),_0x16a561=getEffectiveFilterSize(_0x5e495b,_0x1e444a),_0x337df8=getEffectiveFilterSize(_0x4a6978,_0x11146d),_0x184d01=getEffectiveFilterSize(_0x134b48,_0x1ba625),{padInfo:_0x2bb28a,outDepth:_0x336f5c,outHeight:_0x4412e3,outWidth:_0x21d1d6}=get3DPadAndOutInfo(_0x330ac1,_0x2b85fb,_0x5d3182,_0x53d4f3,_0x378275,_0xb241ac,_0x1bcc2a,_0x16a561,_0x337df8,_0x184d01,_0x104e4f),_0x1e4f36=_0x4c2e39?_0x25baa2*_0x425fc2:_0x25baa2;let _0x421cdc;if(_0x12e172===_0xd97dae(0x121))_0x421cdc=[_0x1ffc15,_0x1e4f36,_0x336f5c,_0x4412e3,_0x21d1d6];else _0x12e172===_0xd97dae(0x455)&&(_0x421cdc=[_0x1ffc15,_0x336f5c,_0x4412e3,_0x21d1d6,_0x1e4f36]);return{'batchSize':_0x1ffc15,'dataFormat':_0x12e172,'inDepth':_0x2b85fb,'inHeight':_0x5d3182,'inWidth':_0x53d4f3,'inChannels':_0x425fc2,'outDepth':_0x336f5c,'outHeight':_0x4412e3,'outWidth':_0x21d1d6,'outChannels':_0x1e4f36,'padInfo':_0x2bb28a,'strideDepth':_0x378275,'strideHeight':_0xb241ac,'strideWidth':_0x1bcc2a,'filterDepth':_0x5e495b,'filterHeight':_0x4a6978,'filterWidth':_0x134b48,'effectiveFilterDepth':_0x16a561,'effectiveFilterHeight':_0x337df8,'effectiveFilterWidth':_0x184d01,'dilationDepth':_0x1e444a,'dilationHeight':_0x11146d,'dilationWidth':_0x1ba625,'inShape':_0x217d48,'outShape':_0x421cdc,'filterShape':_0xbadf60};}function computeOutputShape2D(_0x1f1494,_0x192dae,_0x4d2d2d,_0x502b93,_0x352e22){_0x502b93==null&&(_0x502b93=computeDefaultPad(_0x1f1494,_0x192dae,_0x4d2d2d));const _0x507127=_0x1f1494[0x0],_0x469cdf=_0x1f1494[0x1],_0x4b4804=round((_0x507127-_0x192dae+0x2*_0x502b93)/_0x4d2d2d+0x1,_0x352e22),_0x3d36f1=round((_0x469cdf-_0x192dae+0x2*_0x502b93)/_0x4d2d2d+0x1,_0x352e22);return[_0x4b4804,_0x3d36f1];}function computeOutputShape4D(_0x51c12a,_0x2381b8,_0x5ebe14,_0x2b3808,_0x5eb8c4,_0x4b004c){_0x5eb8c4==null&&(_0x5eb8c4=computeDefaultPad(_0x51c12a,_0x2381b8,_0x2b3808));const _0x481d86=_0x51c12a[0x0],_0x47211d=_0x51c12a[0x1],_0x45e324=_0x51c12a[0x2],_0x2ccaaa=round((_0x481d86-_0x2381b8+0x2*_0x5eb8c4)/_0x2b3808+0x1,_0x4b004c),_0x3ab7ce=round((_0x47211d-_0x2381b8+0x2*_0x5eb8c4)/_0x2b3808+0x1,_0x4b004c),_0x3d22c9=round((_0x45e324-_0x2381b8+0x2*_0x5eb8c4)/_0x2b3808+0x1,_0x4b004c);return[_0x2ccaaa,_0x3ab7ce,_0x3d22c9,_0x5ebe14];}function computeDefaultPad(_0x3f0516,_0x4cc211,_0xa90f64,_0x59ec40=0x1){const _0x5268d5=a0_0x20018c,_0x50afbb=getEffectiveFilterSize(_0x4cc211,_0x59ec40);return Math[_0x5268d5(0x476)]((_0x3f0516[0x0]*(_0xa90f64-0x1)-_0xa90f64+_0x50afbb)/0x2);}function parseTupleParam(_0x5c4388){if(typeof _0x5c4388==='number')return[_0x5c4388,_0x5c4388,_0x5c4388];if(_0x5c4388['length']===0x2)return[_0x5c4388[0x0],_0x5c4388[0x1],0x1];return _0x5c4388;}function parse3TupleParam(_0xac8e57){const _0x2acdb6=a0_0x20018c;return typeof _0xac8e57===_0x2acdb6(0x4ac)?[_0xac8e57,_0xac8e57,_0xac8e57]:_0xac8e57;}function getEffectiveFilterSize(_0x37a538,_0x8a06aa){if(_0x8a06aa<=0x1)return _0x37a538;return _0x37a538+(_0x37a538-0x1)*(_0x8a06aa-0x1);}function getPadAndOutInfo(_0x270b36,_0x4b1326,_0x3fac5,_0x271df8,_0x2be6c7,_0x571bf6,_0x8f14f5,_0x44894c,_0x18e8a3){const _0x8fca06=a0_0x20018c;let _0x4962cf,_0x3e42dc,_0x20e434;if(typeof _0x270b36==='number'){const _0x78de6d=_0x270b36===0x0?_0x8fca06(0x229):_0x8fca06(0x2b7);_0x4962cf={'top':_0x270b36,'bottom':_0x270b36,'left':_0x270b36,'right':_0x270b36,'type':_0x78de6d};const _0x1aa313=computeOutputShape2D([_0x4b1326,_0x3fac5],_0x571bf6,_0x271df8,_0x270b36,_0x44894c);_0x3e42dc=_0x1aa313[0x0],_0x20e434=_0x1aa313[0x1];}else{if(_0x270b36===_0x8fca06(0x525)){_0x3e42dc=Math['ceil'](_0x4b1326/_0x271df8),_0x20e434=Math[_0x8fca06(0x4a7)](_0x3fac5/_0x2be6c7);const _0x330461=Math[_0x8fca06(0x1e2)](0x0,(_0x3e42dc-0x1)*_0x271df8+_0x571bf6-_0x4b1326),_0x2df2a7=Math['max'](0x0,(_0x20e434-0x1)*_0x2be6c7+_0x8f14f5-_0x3fac5),_0x285980=Math[_0x8fca06(0x476)](_0x330461/0x2),_0x3b885f=_0x330461-_0x285980,_0x352b83=Math[_0x8fca06(0x476)](_0x2df2a7/0x2),_0x14cfb5=_0x2df2a7-_0x352b83;_0x4962cf={'top':_0x285980,'bottom':_0x3b885f,'left':_0x352b83,'right':_0x14cfb5,'type':_0x8fca06(0x308)};}else{if(_0x270b36===_0x8fca06(0x5ca))_0x4962cf={'top':0x0,'bottom':0x0,'left':0x0,'right':0x0,'type':_0x8fca06(0x229)},_0x3e42dc=Math[_0x8fca06(0x4a7)]((_0x4b1326-_0x571bf6+0x1)/_0x271df8),_0x20e434=Math['ceil']((_0x3fac5-_0x8f14f5+0x1)/_0x2be6c7);else{if(typeof _0x270b36===_0x8fca06(0x130)){const _0xb63ecf=_0x18e8a3==='channelsLast'?_0x270b36[0x1][0x0]:_0x270b36[0x2][0x0],_0x209bd1=_0x18e8a3==='channelsLast'?_0x270b36[0x1][0x1]:_0x270b36[0x2][0x1],_0x4bc802=_0x18e8a3===_0x8fca06(0x455)?_0x270b36[0x2][0x0]:_0x270b36[0x3][0x0],_0x346d09=_0x18e8a3==='channelsLast'?_0x270b36[0x2][0x1]:_0x270b36[0x3][0x1],_0x28c290=_0xb63ecf===0x0&&_0x209bd1===0x0&&_0x4bc802===0x0&&_0x346d09===0x0?_0x8fca06(0x229):_0x8fca06(0x175);_0x4962cf={'top':_0xb63ecf,'bottom':_0x209bd1,'left':_0x4bc802,'right':_0x346d09,'type':_0x28c290},_0x3e42dc=round((_0x4b1326-_0x571bf6+_0xb63ecf+_0x209bd1)/_0x271df8+0x1,_0x44894c),_0x20e434=round((_0x3fac5-_0x8f14f5+_0x4bc802+_0x346d09)/_0x2be6c7+0x1,_0x44894c);}else throw Error(_0x8fca06(0x165)+_0x270b36);}}}return{'padInfo':_0x4962cf,'outHeight':_0x3e42dc,'outWidth':_0x20e434};}function get3DPadAndOutInfo(_0x1a166d,_0x5bea32,_0xb1076a,_0x4298c3,_0x574935,_0x14f979,_0xa82bcb,_0x5be5a5,_0x3cb9e0,_0x283fe9,_0x40b49f){const _0xcbb7=a0_0x20018c;let _0x6e06e1,_0x28d6c1,_0x18b308,_0x8e9c9;if(typeof _0x1a166d===_0xcbb7(0x4ac)){const _0x30f58a=_0x1a166d===0x0?_0xcbb7(0x229):_0xcbb7(0x2b7);_0x6e06e1={'top':_0x1a166d,'bottom':_0x1a166d,'left':_0x1a166d,'right':_0x1a166d,'front':_0x1a166d,'back':_0x1a166d,'type':_0x30f58a};const _0xc523fd=computeOutputShape4D([_0x5bea32,_0xb1076a,_0x4298c3,0x1],_0x5be5a5,0x1,_0x574935,_0x1a166d,_0x40b49f);_0x28d6c1=_0xc523fd[0x0],_0x18b308=_0xc523fd[0x1],_0x8e9c9=_0xc523fd[0x2];}else{if(_0x1a166d===_0xcbb7(0x525)){_0x28d6c1=Math['ceil'](_0x5bea32/_0x574935),_0x18b308=Math[_0xcbb7(0x4a7)](_0xb1076a/_0x14f979),_0x8e9c9=Math[_0xcbb7(0x4a7)](_0x4298c3/_0xa82bcb);const _0x2c1c4a=(_0x28d6c1-0x1)*_0x574935+_0x5be5a5-_0x5bea32,_0xf1807a=(_0x18b308-0x1)*_0x14f979+_0x3cb9e0-_0xb1076a,_0x3b55d6=(_0x8e9c9-0x1)*_0xa82bcb+_0x283fe9-_0x4298c3,_0x12163b=Math[_0xcbb7(0x476)](_0x2c1c4a/0x2),_0x40fa3f=_0x2c1c4a-_0x12163b,_0x300cfa=Math['floor'](_0xf1807a/0x2),_0x57ce7f=_0xf1807a-_0x300cfa,_0x3d8bf4=Math[_0xcbb7(0x476)](_0x3b55d6/0x2),_0x2967af=_0x3b55d6-_0x3d8bf4;_0x6e06e1={'top':_0x300cfa,'bottom':_0x57ce7f,'left':_0x3d8bf4,'right':_0x2967af,'front':_0x12163b,'back':_0x40fa3f,'type':_0xcbb7(0x308)};}else{if(_0x1a166d===_0xcbb7(0x5ca))_0x6e06e1={'top':0x0,'bottom':0x0,'left':0x0,'right':0x0,'front':0x0,'back':0x0,'type':_0xcbb7(0x229)},_0x28d6c1=Math[_0xcbb7(0x4a7)]((_0x5bea32-_0x5be5a5+0x1)/_0x574935),_0x18b308=Math[_0xcbb7(0x4a7)]((_0xb1076a-_0x3cb9e0+0x1)/_0x14f979),_0x8e9c9=Math['ceil']((_0x4298c3-_0x283fe9+0x1)/_0xa82bcb);else throw Error(_0xcbb7(0x165)+_0x1a166d);}}return{'padInfo':_0x6e06e1,'outDepth':_0x28d6c1,'outHeight':_0x18b308,'outWidth':_0x8e9c9};}function round(_0x268987,_0x206a41){const _0x19fcff=a0_0x20018c;if(!_0x206a41)return Math[_0x19fcff(0x369)](_0x268987);switch(_0x206a41){case _0x19fcff(0x1f8):return Math[_0x19fcff(0x1f8)](_0x268987);case _0x19fcff(0x4a7):return Math[_0x19fcff(0x4a7)](_0x268987);case'floor':return Math[_0x19fcff(0x476)](_0x268987);default:throw new Error('Unknown\x20roundingMode\x20'+_0x206a41);}}function tupleValuesAreOne(_0x424716){const [_0x24be52,_0x557bb5,_0x248fa5]=parseTupleParam(_0x424716);return _0x24be52===0x1&&_0x557bb5===0x1&&_0x248fa5===0x1;}function eitherStridesOrDilationsAreOne(_0x40c268,_0x73aab8){return tupleValuesAreOne(_0x40c268)||tupleValuesAreOne(_0x73aab8);}function convertConv2DDataFormat(_0x26367a){const _0x41b919=a0_0x20018c;if(_0x26367a===_0x41b919(0x4c9))return _0x41b919(0x455);else{if(_0x26367a===_0x41b919(0x452))return _0x41b919(0x121);else throw new Error(_0x41b919(0x3f3)+_0x26367a);}}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const conv2DGradConfig={'kernelName':Conv2D,'inputsToSave':['x','filter'],'gradFunc':(_0xce66c0,_0x28a238,_0x3af43b)=>{const _0x4f746c=a0_0x20018c,[_0x5a1353,_0x59d915]=_0x28a238,{dilations:_0xcad034,strides:_0xe5a735,pad:_0x37854d,dataFormat:_0x5cdb3a}=_0x3af43b;return assert(tupleValuesAreOne(_0xcad034),()=>'Error\x20in\x20gradient\x20of\x20conv2D:\x20dilation\x20rates\x20greater\x20than\x201\x20'+(_0x4f746c(0x349)+_0xcad034+'\x27')),{'x':()=>conv2DBackpropInput(_0x5a1353[_0x4f746c(0x50f)],_0xce66c0,_0x59d915,_0xe5a735,_0x37854d,_0x5cdb3a),'filter':()=>conv2DBackpropFilter(_0x5a1353,_0xce66c0,_0x59d915['shape'],_0xe5a735,_0x37854d,_0x5cdb3a)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function conv2d_(_0x411268,_0x3a2b6a,_0x18f98f,_0x3ce378,_0x4d118e='NHWC',_0x35c17e=[0x1,0x1],_0x5ef7e7){const _0x8413fc=a0_0x20018c,_0x5bd36e=convertToTensor(_0x411268,'x',_0x8413fc(0x1a1)),_0x5140b4=convertToTensor(_0x3a2b6a,_0x8413fc(0x481),'conv2d');let _0x4d2047=_0x5bd36e,_0x3f3116=![];_0x5bd36e[_0x8413fc(0x36e)]===0x3&&(_0x3f3116=!![],_0x4d2047=reshape(_0x5bd36e,[0x1,_0x5bd36e['shape'][0x0],_0x5bd36e[_0x8413fc(0x50f)][0x1],_0x5bd36e[_0x8413fc(0x50f)][0x2]]));assert(_0x4d2047['rank']===0x4,()=>_0x8413fc(0x4e5)+_0x4d2047[_0x8413fc(0x36e)]+'.'),assert(_0x5140b4[_0x8413fc(0x36e)]===0x4,()=>'Error\x20in\x20conv2d:\x20filter\x20must\x20be\x20rank\x204,\x20but\x20got\x20rank\x20'+(_0x5140b4['rank']+'.'));_0x5ef7e7!=null&&assert(isInt(_0x3ce378),()=>_0x8413fc(0x3b6)+(_0x8413fc(0x51f)+_0x5ef7e7+'\x20but\x20got\x20pad\x20'+_0x3ce378+'.'));const _0x129c78=_0x4d118e===_0x8413fc(0x4c9)?_0x4d2047['shape'][0x3]:_0x4d2047['shape'][0x1];assert(_0x129c78===_0x5140b4[_0x8413fc(0x50f)][0x2],()=>'Error\x20in\x20conv2d:\x20depth\x20of\x20input\x20('+_0x129c78+_0x8413fc(0x4e3)+('input\x20depth\x20for\x20filter\x20'+_0x5140b4['shape'][0x2]+'.')),assert(eitherStridesOrDilationsAreOne(_0x18f98f,_0x35c17e),()=>'Error\x20in\x20conv2D:\x20Either\x20strides\x20or\x20dilations\x20must\x20be\x201.\x20'+(_0x8413fc(0x54f)+_0x18f98f+'\x20and\x20dilations\x20\x27'+_0x35c17e+'\x27'));const _0x506e06={'x':_0x4d2047,'filter':_0x5140b4},_0x1097bd={'strides':_0x18f98f,'pad':_0x3ce378,'dataFormat':_0x4d118e,'dilations':_0x35c17e,'dimRoundingMode':_0x5ef7e7},_0x28b5db=ENGINE[_0x8413fc(0x397)](Conv2D,_0x506e06,_0x1097bd);if(_0x3f3116)return reshape(_0x28b5db,[_0x28b5db[_0x8413fc(0x50f)][0x1],_0x28b5db[_0x8413fc(0x50f)][0x2],_0x28b5db[_0x8413fc(0x50f)][0x3]]);return _0x28b5db;}const conv2d=op({'conv2d_':conv2d_}),conv2DBackpropInputGradConfig={'kernelName':Conv2DBackpropInput,'inputsToSave':['dy',a0_0x20018c(0x481)],'gradFunc':(_0x4f300e,_0x5c3bc6,_0x24b62d)=>{const [_0xc06649,_0x47de63]=_0x5c3bc6,{strides:_0x30bb1b,pad:_0x4a163a,dataFormat:_0x4a073f,dimRoundingMode:_0x18125a}=_0x24b62d;return{'dy':()=>conv2d(_0x4f300e,_0x47de63,_0x30bb1b,_0x4a163a,_0x4a073f,0x1,_0x18125a),'filter':()=>conv2DBackpropFilter(_0x4f300e,_0xc06649,_0x47de63['shape'],_0x30bb1b,_0x4a163a,_0x4a073f,_0x18125a)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function conv3DBackpropFilter_(_0x15e3ba,_0xb4ce13,_0x51197e,_0x1d5ff9,_0x1d337b){const _0x3ea134=a0_0x20018c;let _0x1d0fcc=_0x15e3ba;_0x15e3ba[_0x3ea134(0x36e)]===0x4&&(_0x1d0fcc=reshape(_0x15e3ba,[0x1,_0x15e3ba[_0x3ea134(0x50f)][0x0],_0x15e3ba[_0x3ea134(0x50f)][0x1],_0x15e3ba['shape'][0x2],_0x15e3ba[_0x3ea134(0x50f)][0x3]]));let _0x4abe28=_0xb4ce13;_0x4abe28[_0x3ea134(0x36e)]===0x4&&(_0x4abe28=reshape(_0xb4ce13,[0x1,_0xb4ce13[_0x3ea134(0x50f)][0x0],_0xb4ce13[_0x3ea134(0x50f)][0x1],_0xb4ce13[_0x3ea134(0x50f)][0x2],_0xb4ce13[_0x3ea134(0x50f)][0x3]]));assert(_0x1d0fcc[_0x3ea134(0x36e)]===0x5,()=>_0x3ea134(0x2b9)+(_0x1d0fcc['shape']+'.')),assert(_0x4abe28[_0x3ea134(0x36e)]===0x5,()=>_0x3ea134(0x2c8)+(_0x4abe28[_0x3ea134(0x50f)]+'.')),assert(_0x51197e[_0x3ea134(0x104)]===0x5,()=>_0x3ea134(0x1cc)+(_0x51197e+'.')),assert(_0x1d0fcc[_0x3ea134(0x50f)][0x4]===_0x51197e[0x3],()=>'Error\x20in\x20conv3dDerFilter:\x20depth\x20of\x20input\x20'+_0x1d0fcc[_0x3ea134(0x50f)][0x4]+_0x3ea134(0x102)+(_0x3ea134(0x491)+_0x51197e[0x3]+'.')),assert(_0x4abe28[_0x3ea134(0x50f)][0x4]===_0x51197e[0x4],()=>_0x3ea134(0x1e7)+_0x4abe28[_0x3ea134(0x50f)][0x4]+_0x3ea134(0x102)+(_0x3ea134(0x1e9)+_0x51197e[0x4]+').'));const _0x2616fb={'x':_0x1d0fcc,'dy':_0x4abe28},_0x2c0ffe={'strides':_0x1d5ff9,'pad':_0x1d337b,'filterShape':_0x51197e};return ENGINE[_0x3ea134(0x397)](Conv3DBackpropFilterV2,_0x2616fb,_0x2c0ffe);}const conv3DBackpropFilter=op({'conv3DBackpropFilter_':conv3DBackpropFilter_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function conv3DBackpropInput_(_0x29fcc0,_0x15334d,_0x462525,_0x5a1936,_0x3851f1){const _0x4fe129=a0_0x20018c;assert(_0x29fcc0[_0x4fe129(0x104)]===_0x15334d[_0x4fe129(0x36e)],()=>_0x4fe129(0x3d3)+('('+_0x29fcc0[_0x4fe129(0x104)]+_0x4fe129(0x235)+_0x15334d[_0x4fe129(0x36e)]+_0x4fe129(0x4da)));let _0x233d73=_0x29fcc0,_0x123d1a=_0x15334d,_0x144f61=![];_0x15334d['rank']===0x4&&(_0x144f61=!![],_0x123d1a=reshape(_0x15334d,[0x1,_0x15334d[_0x4fe129(0x50f)][0x0],_0x15334d[_0x4fe129(0x50f)][0x1],_0x15334d[_0x4fe129(0x50f)][0x2],_0x15334d[_0x4fe129(0x50f)][0x3]]),_0x233d73=[0x1,_0x29fcc0[0x0],_0x29fcc0[0x1],_0x29fcc0[0x2],_0x29fcc0[0x3]]);const _0x1bd284=_0x233d73[0x4],_0x3aa3ce=_0x123d1a['shape'][0x4];assert(_0x233d73['length']===0x5,()=>'Error\x20in\x20conv3dDerInput:\x20inShape\x20must\x20be\x20length\x205,\x20but\x20got\x20length\x20'+(_0x233d73[_0x4fe129(0x104)]+'.')),assert(_0x123d1a['rank']===0x5,()=>_0x4fe129(0x5c7)+(_0x4fe129(0x5b5)+_0x123d1a[_0x4fe129(0x36e)])),assert(_0x462525[_0x4fe129(0x36e)]===0x5,()=>_0x4fe129(0x257)+(_0x4fe129(0x5b5)+_0x462525[_0x4fe129(0x36e)])),assert(_0x1bd284===_0x462525[_0x4fe129(0x50f)][0x3],()=>_0x4fe129(0x4f9)+_0x1bd284+_0x4fe129(0x102)+('match\x20input\x20depth\x20for\x20filter\x20'+_0x462525[_0x4fe129(0x50f)][0x3]+'.')),assert(_0x3aa3ce===_0x462525[_0x4fe129(0x50f)][0x4],()=>_0x4fe129(0x46b)+_0x3aa3ce+')\x20must\x20'+(_0x4fe129(0x386)+_0x462525['shape'][0x4]+'.'));const _0x2a876f={'dy':_0x123d1a,'filter':_0x462525},_0x38b16f={'pad':_0x3851f1,'strides':_0x5a1936,'inputShape':_0x233d73},_0x54178f=ENGINE[_0x4fe129(0x397)](Conv3DBackpropInputV2,_0x2a876f,_0x38b16f);if(_0x144f61)return reshape(_0x54178f,[_0x54178f['shape'][0x1],_0x54178f['shape'][0x2],_0x54178f[_0x4fe129(0x50f)][0x3],_0x54178f['shape'][0x4]]);return _0x54178f;}const conv3DBackpropInput=op({'conv3DBackpropInput_':conv3DBackpropInput_}),conv3DGradConfig={'kernelName':Conv3D,'inputsToSave':['x','filter'],'gradFunc':(_0x3b18b0,_0x263831,_0x50ea9e)=>{const _0x1c6572=a0_0x20018c,{dilations:_0x48eba6,strides:_0x1319c9,pad:_0x39b9b7}=_0x50ea9e;assert(tupleValuesAreOne(_0x48eba6),()=>_0x1c6572(0x39b)+(_0x1c6572(0x2cb)+_0x48eba6+'\x27'));const [_0x17d497,_0xc1df4d]=_0x263831;return{'x':()=>conv3DBackpropInput(_0x17d497['shape'],_0x3b18b0,_0xc1df4d,_0x1319c9,_0x39b9b7),'filter':()=>conv3DBackpropFilter(_0x17d497,_0x3b18b0,_0xc1df4d[_0x1c6572(0x50f)],_0x1319c9,_0x39b9b7)};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sin_(_0x4690aa){const _0x56895e=a0_0x20018c,_0x4926d2=convertToTensor(_0x4690aa,'x','sin'),_0x21de89={'x':_0x4926d2};return ENGINE[_0x56895e(0x397)](Sin,_0x21de89);}const sin=op({'sin_':sin_}),cosGradConfig={'kernelName':Cos,'inputsToSave':['x'],'gradFunc':(_0x397338,_0x4620cf)=>{const _0x3ba9b9=a0_0x20018c,[_0x2c4a78]=_0x4620cf;return{'x':()=>mul(neg(sin(cast(_0x2c4a78,_0x3ba9b9(0x28b)))),_0x397338)};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sinh_(_0x50e814){const _0x4737e4=a0_0x20018c,_0x1064f4=convertToTensor(_0x50e814,'x','sinh'),_0x38ca20={'x':_0x1064f4};return ENGINE[_0x4737e4(0x397)](Sinh,_0x38ca20);}const sinh=op({'sinh_':sinh_}),coshGradConfig={'kernelName':Cosh,'inputsToSave':['x'],'gradFunc':(_0x385129,_0x5cc78e)=>{const [_0x580514]=_0x5cc78e;return{'x':()=>mul(sinh(cast(_0x580514,'float32')),_0x385129)};}};/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function axesAreInnerMostDims(_0x32bed8,_0x1b26b1){const _0x27aef2=a0_0x20018c;for(let _0x57dfc4=0x0;_0x57dfc4<_0x32bed8[_0x27aef2(0x104)];++_0x57dfc4){if(_0x32bed8[_0x32bed8[_0x27aef2(0x104)]-_0x57dfc4-0x1]!==_0x1b26b1-0x1-_0x57dfc4)return![];}return!![];}function combineLocations(_0x33773b,_0x3482ce,_0x48c747){const _0x561302=a0_0x20018c,_0x587e4b=_0x33773b[_0x561302(0x104)]+_0x3482ce[_0x561302(0x104)],_0x1f39a6=[];let _0x4ca8d6=0x0,_0x2a0065=0x0;for(let _0x1f7c7d=0x0;_0x1f7c7d<_0x587e4b;_0x1f7c7d++){_0x48c747[_0x561302(0x12e)](_0x1f7c7d)===-0x1?_0x1f39a6[_0x561302(0x30f)](_0x33773b[_0x4ca8d6++]):_0x1f39a6['push'](_0x3482ce[_0x2a0065++]);}return _0x1f39a6;}function computeOutAndReduceShapes(_0x59e56b,_0x78b682){const _0x3f3fe8=a0_0x20018c,_0x984e93=[],_0x34c690=_0x59e56b[_0x3f3fe8(0x104)];for(let _0x4f2c77=0x0;_0x4f2c77<_0x34c690;_0x4f2c77++){_0x78b682[_0x3f3fe8(0x12e)](_0x4f2c77)===-0x1&&_0x984e93[_0x3f3fe8(0x30f)](_0x59e56b[_0x4f2c77]);}const _0x34f389=_0x78b682['map'](_0x2f89b6=>_0x59e56b[_0x2f89b6]);return[_0x984e93,_0x34f389];}function expandShapeToKeepDim(_0x3b3217,_0x35274f){const _0x393ec2=a0_0x20018c,_0x2fc297=_0x35274f[_0x393ec2(0x3ab)](_0x4a2ee5=>0x1);return combineLocations(_0x3b3217,_0x2fc297,_0x35274f);}function assertAxesAreInnerMostDims(_0xcb87f9,_0x4f2e08,_0x1aa004){const _0x2f788c=a0_0x20018c;assert(axesAreInnerMostDims(_0x4f2e08,_0x1aa004),()=>_0xcb87f9+_0x2f788c(0x3c3)+(_0x2f788c(0x2f0)+_0x4f2e08+'\x20and\x20rank-'+_0x1aa004+_0x2f788c(0x2a5)));}function getAxesPermutation(_0x84a438,_0x2e3581){const _0x38e8fb=a0_0x20018c;if(axesAreInnerMostDims(_0x84a438,_0x2e3581))return null;const _0x551ca8=[];for(let _0x57db7c=0x0;_0x57db7c<_0x2e3581;++_0x57db7c){_0x84a438[_0x38e8fb(0x12e)](_0x57db7c)===-0x1&&_0x551ca8[_0x38e8fb(0x30f)](_0x57db7c);}return _0x84a438[_0x38e8fb(0x1e4)](_0xcc7b67=>_0x551ca8['push'](_0xcc7b67)),_0x551ca8;}function getUndoAxesPermutation(_0x5bed5f){const _0x79d05f=a0_0x20018c;return _0x5bed5f[_0x79d05f(0x3ab)]((_0x406db4,_0x32be8c)=>[_0x32be8c,_0x406db4])['sort']((_0x503f7e,_0x3fe07e)=>_0x503f7e[0x1]-_0x3fe07e[0x1])['map'](_0x3d402c=>_0x3d402c[0x0]);}function getInnerMostAxes(_0x37f8f3,_0x5a64f1){const _0x217599=a0_0x20018c,_0x4b67c6=[];for(let _0x8bb4d2=_0x5a64f1-_0x37f8f3;_0x8bb4d2<_0x5a64f1;++_0x8bb4d2){_0x4b67c6[_0x217599(0x30f)](_0x8bb4d2);}return _0x4b67c6;}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function cumsum_(_0x15d1f2,_0x58f1a9=0x0,_0x528b46=![],_0x319342=![]){const _0x5f03d3=a0_0x20018c,_0x4d2529=convertToTensor(_0x15d1f2,'x','cumsum'),_0x15bae6={'x':_0x4d2529},_0x3eeff6={'axis':_0x58f1a9,'exclusive':_0x528b46,'reverse':_0x319342};return ENGINE[_0x5f03d3(0x397)](Cumsum,_0x15bae6,_0x3eeff6);}const cumsum=op({'cumsum_':cumsum_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function transpose_(_0xd783d1,_0x5272e0){const _0x4e15be=a0_0x20018c,_0x11eea1=convertToTensor(_0xd783d1,'x',_0x4e15be(0x4e0));_0x5272e0==null&&(_0x5272e0=_0x11eea1['shape'][_0x4e15be(0x3ab)]((_0x411ef2,_0x7df351)=>_0x7df351)[_0x4e15be(0x48d)]());assert(_0x11eea1[_0x4e15be(0x36e)]===_0x5272e0[_0x4e15be(0x104)],()=>_0x4e15be(0x45c)+_0x11eea1[_0x4e15be(0x36e)]+'\x20'+(_0x4e15be(0x155)+_0x5272e0+'.')),_0x5272e0['forEach'](_0x29040d=>{const _0x37e199=_0x4e15be;assert(_0x29040d>=0x0&&_0x29040d<_0x11eea1['rank'],()=>_0x37e199(0xed)+(_0x11eea1[_0x37e199(0x36e)]-0x1)+(_0x37e199(0x2c7)+_0x5272e0));});if(_0x11eea1['rank']<=0x1)return _0x11eea1[_0x4e15be(0x49d)]();const _0x29b3ed={'x':_0x11eea1},_0x5f0857={'perm':_0x5272e0};return ENGINE[_0x4e15be(0x397)](Transpose,_0x29b3ed,_0x5f0857);}const transpose=op({'transpose_':transpose_}),cumsumGradConfig={'kernelName':Cumsum,'inputsToSave':['x'],'gradFunc':(_0xf22c5f,_0xf0b2ea,_0x5334f0)=>{const [_0x481515]=_0xf0b2ea,{axis:_0x1e6c6a,exclusive:_0x11bf76,reverse:_0x49cb53}=_0x5334f0;return{'x':()=>{const _0x3bf77b=a0_0x367f,_0x36730b=getAxesPermutation([_0x1e6c6a],_0x481515[_0x3bf77b(0x36e)]);let _0x5cc650=cumsum(_0xf22c5f,_0x1e6c6a,_0x11bf76,!_0x49cb53);return _0x36730b!=null&&(_0x5cc650=transpose(_0x5cc650,_0x36730b)),_0x5cc650;}};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function depthwiseConv2dNativeBackpropFilter_(_0x356fbc,_0x113a37,_0x2272c2,_0x5dfdd6,_0x321e25,_0x575fd6=[0x1,0x1],_0x823cde){const _0x3f1519=a0_0x20018c;let _0x156c70=_0x356fbc;_0x356fbc['rank']===0x3&&(_0x156c70=reshape(_0x356fbc,[0x1,_0x356fbc[_0x3f1519(0x50f)][0x0],_0x356fbc[_0x3f1519(0x50f)][0x1],_0x356fbc[_0x3f1519(0x50f)][0x2]]));let _0x3425b6=_0x113a37;_0x3425b6[_0x3f1519(0x36e)]===0x3&&(_0x3425b6=reshape(_0x113a37,[0x1,_0x113a37[_0x3f1519(0x50f)][0x0],_0x113a37[_0x3f1519(0x50f)][0x1],_0x113a37[_0x3f1519(0x50f)][0x2]]));const _0x4b4e60={'x':_0x156c70,'dy':_0x3425b6},_0x264a22={'strides':_0x5dfdd6,'pad':_0x321e25,'dimRoundingMode':_0x823cde,'dilations':_0x575fd6,'filterShape':_0x2272c2};return ENGINE[_0x3f1519(0x397)](DepthwiseConv2dNativeBackpropFilter,_0x4b4e60,_0x264a22);}const depthwiseConv2dNativeBackpropFilter=op({'depthwiseConv2dNativeBackpropFilter_':depthwiseConv2dNativeBackpropFilter_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function depthwiseConv2dNativeBackpropInput_(_0x22acf2,_0x28d17e,_0x33d3c1,_0x442722,_0x4ef79b,_0xc7ffcf=[0x1,0x1],_0x554eb7){const _0x5cf7b1=a0_0x20018c;let _0xd5afed=_0x28d17e,_0x2a676b=![];_0x28d17e[_0x5cf7b1(0x36e)]===0x3&&(_0x2a676b=!![],_0xd5afed=reshape(_0x28d17e,[0x1,_0x28d17e[_0x5cf7b1(0x50f)][0x0],_0x28d17e[_0x5cf7b1(0x50f)][0x1],_0x28d17e['shape'][0x2]]));const _0x47389f={'dy':_0xd5afed,'filter':_0x33d3c1},_0x1cff76={'strides':_0x442722,'pad':_0x4ef79b,'dimRoundingMode':_0x554eb7,'dilations':_0xc7ffcf,'inputShape':_0x22acf2},_0x5c51da=ENGINE[_0x5cf7b1(0x397)](DepthwiseConv2dNativeBackpropInput,_0x47389f,_0x1cff76);if(_0x2a676b)return reshape(_0x5c51da,[_0x5c51da['shape'][0x1],_0x5c51da[_0x5cf7b1(0x50f)][0x2],_0x5c51da[_0x5cf7b1(0x50f)][0x3]]);return _0x5c51da;}const depthwiseConv2dNativeBackpropInput=op({'depthwiseConv2dNativeBackpropInput_':depthwiseConv2dNativeBackpropInput_}),depthwiseConv2dNativeGradConfig={'kernelName':DepthwiseConv2dNative,'inputsToSave':['x','filter'],'gradFunc':(_0x3a8925,_0x24140f,_0x14e922)=>{const _0x3224e1=a0_0x20018c,{dilations:_0x2041f1,strides:_0x59f3db,pad:_0x31723f,dimRoundingMode:_0x2f3bd0}=_0x14e922,_0x2cfcdb=_0x2041f1==null?[0x1,0x1]:_0x2041f1;assert(tupleValuesAreOne(_0x2cfcdb),()=>'Error\x20in\x20gradient\x20of\x20depthwiseConv2dNative:\x20dilation\x20rates\x20'+_0x3224e1(0x138)+('\x27'+_0x2cfcdb+'\x27'));const [_0xf4c228,_0x10daaf]=_0x24140f;return assert(_0xf4c228[_0x3224e1(0x36e)]===0x4,()=>_0x3224e1(0x3ca)+(_0x3224e1(0x21d)+_0xf4c228[_0x3224e1(0x36e)]+'.')),assert(_0x10daaf[_0x3224e1(0x36e)]===0x4,()=>_0x3224e1(0x424)+(_0x3224e1(0x21d)+_0x10daaf[_0x3224e1(0x36e)]+'.')),assert(_0xf4c228[_0x3224e1(0x50f)][0x3]===_0x10daaf['shape'][0x2],()=>_0x3224e1(0x272)+(_0x3224e1(0x5ad)+_0xf4c228[_0x3224e1(0x50f)][0x3]+')\x20must\x20match\x20the\x20inChannels\x20dimension\x20')+('in\x20filter\x20'+_0x10daaf[_0x3224e1(0x50f)][0x2]+'.')),assert(eitherStridesOrDilationsAreOne(_0x59f3db,_0x2cfcdb),()=>_0x3224e1(0x364)+(_0x3224e1(0x532)+_0x59f3db+_0x3224e1(0x550))+('\x27'+_0x2cfcdb+'\x27.')),_0x2f3bd0!=null&&assert(isInt(_0x31723f),()=>_0x3224e1(0x38e)+('dimRoundingMode\x20'+_0x2f3bd0+_0x3224e1(0x27d)+_0x31723f+'.')),{'x':()=>depthwiseConv2dNativeBackpropInput(_0xf4c228['shape'],_0x3a8925,_0x10daaf,_0x59f3db,_0x31723f,_0x2cfcdb,_0x2f3bd0),'filter':()=>depthwiseConv2dNativeBackpropFilter(_0xf4c228,_0x3a8925,_0x10daaf[_0x3224e1(0x50f)],_0x59f3db,_0x31723f,_0x2cfcdb,_0x2f3bd0)};}},dilation2dGradConfig={'kernelName':Dilation2D,'inputsToSave':['x',a0_0x20018c(0x481)],'gradFunc':(_0x52b864,_0x2d9950,_0x683a62)=>{const _0x497f9d=a0_0x20018c,[_0x24407a,_0x2d954a]=_0x2d9950,_0x35b5c4={'x':_0x24407a,'filter':_0x2d954a,'dy':_0x52b864},_0x1328a5={'x':_0x24407a,'filter':_0x2d954a,'dy':_0x52b864};return{'x':()=>ENGINE[_0x497f9d(0x397)](Dilation2DBackpropInput,_0x35b5c4,_0x683a62),'filter':()=>ENGINE[_0x497f9d(0x397)](Dilation2DBackpropFilter,_0x1328a5,_0x683a62)};}},eluGradConfig={'kernelName':Elu,'outputsToSave':[!![]],'gradFunc':(_0x55a9c7,_0x5a75a5)=>{const _0x3d4c74=a0_0x20018c,[_0x347908]=_0x5a75a5,_0x50f5c0={'dy':_0x55a9c7,'y':_0x347908};return{'x':()=>ENGINE[_0x3d4c74(0x397)](EluGrad,_0x50f5c0)};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function exp_(_0x5bb394){const _0x290071=a0_0x20018c,_0x5c131f=convertToTensor(_0x5bb394,'x',_0x290071(0x57c)),_0x4da033={'x':_0x5c131f};return ENGINE[_0x290071(0x397)](Exp,_0x4da033);}const exp=op({'exp_':exp_}),erfGradConfig={'kernelName':Erf,'inputsToSave':['x'],'gradFunc':(_0x5c3ac6,_0x3864e9)=>{const _0x2d494a=a0_0x20018c,[_0x3c8158]=_0x3864e9,_0x109ecd=mul(exp(neg(square(_0x3c8158))),0x2/Math[_0x2d494a(0x106)](Math['PI']));return{'x':()=>mul(_0x5c3ac6,_0x109ecd)};}},expGradConfig={'kernelName':Exp,'outputsToSave':[!![]],'gradFunc':(_0x153c37,_0x5bbdc4)=>{const [_0x264099]=_0x5bbdc4;return{'x':()=>mul(_0x153c37,_0x264099)};}},expandDimsGradConfig={'kernelName':ExpandDims,'inputsToSave':['input'],'gradFunc':(_0x43f5a7,_0x3732d8)=>{const [_0x161ddd]=_0x3732d8;return{'input':()=>reshape(_0x43f5a7,_0x161ddd['shape'])};}},expm1GradConfig={'kernelName':Expm1,'inputsToSave':['x'],'gradFunc':(_0x4c4d20,_0x47589d)=>{const [_0x1b5c99]=_0x47589d;return{'x':()=>mul(_0x4c4d20,exp(_0x1b5c99))};}},floorGradConfig={'kernelName':Floor,'gradFunc':_0xf2ab43=>{return{'x':()=>zerosLike(_0xf2ab43)};}},floorDivGradConfig={'kernelName':FloorDiv,'inputsToSave':['a','b'],'gradFunc':(_0x58190e,_0x1900de)=>{const _0x43f3a0=a0_0x20018c,[_0x13ed98,_0xa8ce60]=_0x1900de,_0x358e18=assertAndGetBroadcastShape(_0x13ed98[_0x43f3a0(0x50f)],_0xa8ce60[_0x43f3a0(0x50f)]),_0x486ce8=()=>{const _0x2062c0=_0x43f3a0,_0x22033e=div(_0x58190e,cast(_0xa8ce60,_0x2062c0(0x28b))),_0x39efb8=getReductionAxes(_0x13ed98['shape'],_0x358e18);if(_0x39efb8['length']>0x0)return reshape(sum$1(_0x22033e,_0x39efb8),_0x13ed98[_0x2062c0(0x50f)]);return _0x22033e;},_0x44b647=()=>{const _0x32525c=_0x43f3a0;let _0x32c184=mul(_0x58190e,cast(_0x13ed98,'float32'));const _0x5ee621=getReductionAxes(_0xa8ce60[_0x32525c(0x50f)],_0x358e18);_0x5ee621[_0x32525c(0x104)]>0x0&&(_0x32c184=reshape(sum$1(_0x32c184,_0x5ee621),_0xa8ce60[_0x32525c(0x50f)]));const _0x1bc691=square(_0xa8ce60);return neg(div(_0x32c184,cast(_0x1bc691,'float32')));};return{'a':_0x486ce8,'b':_0x44b647};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function rsqrt_(_0x30300c){const _0x469626=a0_0x20018c,_0x34f587=convertToTensor(_0x30300c,'x',_0x469626(0x31d)),_0x40d16f={'x':_0x34f587};return ENGINE['runKernel'](Rsqrt,_0x40d16f);}const rsqrt=op({'rsqrt_':rsqrt_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tile_(_0x387573,_0x22a683){const _0x575dc3=a0_0x20018c,_0x374fbf=convertToTensor(_0x387573,'x',_0x575dc3(0x147),_0x575dc3(0x5c4));assert(_0x374fbf[_0x575dc3(0x36e)]===_0x22a683[_0x575dc3(0x104)],()=>'Error\x20in\x20transpose:\x20rank\x20of\x20input\x20'+_0x374fbf[_0x575dc3(0x36e)]+'\x20'+(_0x575dc3(0x118)+_0x22a683+'.'));const _0x15715e={'x':_0x374fbf},_0x37b459={'reps':_0x22a683};return ENGINE[_0x575dc3(0x397)](Tile,_0x15715e,_0x37b459);}const tile=op({'tile_':tile_}),fusedBatchNormGradConfig={'kernelName':FusedBatchNorm,'inputsToSave':['x','mean',a0_0x20018c(0x3e2),a0_0x20018c(0x5b4)],'gradFunc':(_0x7fe06e,_0x3a2ed2,_0x323752)=>{const _0x32c780=a0_0x20018c,{varianceEpsilon:_0x3a031a}=_0x323752,[_0x4098aa,_0x5c60c8,_0x48f081,_0x209c4b]=_0x3a2ed2,_0x341bed=_0x209c4b==null?scalar(0x1):_0x209c4b,_0x2d7cc6=getReductionAxes(_0x5c60c8[_0x32c780(0x50f)],_0x4098aa[_0x32c780(0x50f)]),_0x5bd841=[];if(_0x5c60c8['rank']===0x1){for(let _0x2629dc=0x0;_0x2629dc<_0x4098aa[_0x32c780(0x50f)][_0x32c780(0x104)]-0x1;++_0x2629dc){_0x5bd841[_0x32c780(0x30f)](_0x4098aa[_0x32c780(0x50f)][_0x2629dc]);}_0x5bd841[_0x32c780(0x30f)](0x1);}const _0xccc278=sub(_0x4098aa,_0x5c60c8),_0x48da7c=mul(_0x7fe06e,_0x341bed),_0x145ab9=rsqrt(add$1(_0x48f081,scalar(_0x3a031a))),_0x4d4ace=mul(mul(mul(_0x145ab9,_0x145ab9),_0x145ab9),scalar(-0.5)),_0x1c3681=()=>{const _0x2bbf45=_0x32c780;return _0x5c60c8[_0x2bbf45(0x36e)]===0x1?reshape(mul(mul(_0x7fe06e,tile(reshape(_0x145ab9,[0x1,0x1,0x1,_0x5c60c8['shape'][0x0]]),_0x5bd841)),_0x341bed),_0x4098aa[_0x2bbf45(0x50f)]):reshape(mul(mul(_0x7fe06e,_0x145ab9),_0x341bed),_0x4098aa[_0x2bbf45(0x50f)]);},_0x5a4ace=()=>{const _0x5c5868=_0x32c780;let _0x2f186a=mul(mul(_0x145ab9,scalar(-0x1)),_0x48da7c);return _0x5c60c8[_0x5c5868(0x36e)]===0x1&&(_0x2f186a=sum$1(_0x2f186a,_0x2d7cc6)),reshape(_0x2f186a,_0x5c60c8[_0x5c5868(0x50f)]);},_0x42a4c0=()=>{const _0x2d3810=_0x32c780;let _0x5d7e81=mul(mul(_0x4d4ace,_0xccc278),_0x48da7c);return _0x5c60c8[_0x2d3810(0x36e)]===0x1&&(_0x5d7e81=sum$1(_0x5d7e81,_0x2d7cc6)),reshape(_0x5d7e81,_0x5c60c8[_0x2d3810(0x50f)]);},_0x4a91bd=()=>{const _0x2f9f82=_0x32c780,_0x305c4f=mul(_0xccc278,_0x145ab9);let _0x95a5f1=mul(_0x7fe06e,_0x305c4f);return _0x5c60c8[_0x2f9f82(0x36e)]===0x1&&(_0x95a5f1=sum$1(_0x95a5f1,_0x2d7cc6)),reshape(_0x95a5f1,_0x5c60c8[_0x2f9f82(0x50f)]);},_0x449130=()=>{const _0x3d2f00=_0x32c780;let _0x1a9d59=_0x7fe06e;return _0x5c60c8[_0x3d2f00(0x36e)]===0x1&&(_0x1a9d59=sum$1(_0x1a9d59,_0x2d7cc6)),reshape(_0x1a9d59,_0x5c60c8[_0x3d2f00(0x50f)]);};return{'x':_0x1c3681,'mean':_0x5a4ace,'variance':_0x42a4c0,'scale':_0x4a91bd,'offset':_0x449130};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function unsortedSegmentSum_(_0x1f2ca8,_0x47af2c,_0x2c397a){const _0x3b1a5f=a0_0x20018c,_0x384ce2=convertToTensor(_0x1f2ca8,'x',_0x3b1a5f(0x4f7)),_0x3d2836=convertToTensor(_0x47af2c,_0x3b1a5f(0x157),_0x3b1a5f(0x4f7),_0x3b1a5f(0x4d1));assert(isInt(_0x2c397a),()=>_0x3b1a5f(0x25c));const _0x1d4176={'x':_0x384ce2,'segmentIds':_0x3d2836},_0x476b9f={'numSegments':_0x2c397a};return ENGINE[_0x3b1a5f(0x397)](UnsortedSegmentSum,_0x1d4176,_0x476b9f);}const unsortedSegmentSum=op({'unsortedSegmentSum_':unsortedSegmentSum_}),gatherGradConfig={'kernelName':GatherV2,'inputsToSave':['x',a0_0x20018c(0x402)],'gradFunc':(_0x1705fa,_0x4f129b,_0x53f871)=>{const _0x67db28=a0_0x20018c,[_0x18391c,_0x2dadc4]=_0x4f129b,{axis:_0x2507c4}=_0x53f871,_0x5905e7=parseAxisParam(_0x2507c4,_0x18391c[_0x67db28(0x50f)])[0x0],_0x53b317=()=>{const _0x1e66b3=_0x67db28,_0x44ec19=_0x18391c[_0x1e66b3(0x50f)],_0x115481=_0x2dadc4[_0x1e66b3(0x302)],_0x2b9892=_0x44ec19['slice'](0x0,_0x5905e7),_0x36897c=_0x2b9892[_0x1e66b3(0x104)],_0x847717=_0x44ec19['slice'](_0x2507c4,_0x44ec19[_0x1e66b3(0x104)])[_0x1e66b3(0x2b0)](0x1),_0x422273=_0x847717[_0x1e66b3(0x104)],_0x43c9e2=arrayRange(0x0,_0x36897c),_0x2fdc88=arrayRange(_0x36897c+0x1,_0x36897c+0x1+_0x422273),_0x40bf69=arrayConcat([_0x2b9892,[_0x115481],_0x847717]),_0x41ee41=reshape(_0x1705fa,_0x40bf69),_0x3f5690=reshape(_0x2dadc4,[_0x115481]),_0x437ab5=arrayConcat([[_0x36897c],_0x43c9e2,_0x2fdc88]),_0x459e56=transpose(_0x41ee41,_0x437ab5);let _0xa5d37e=unsortedSegmentSum(_0x459e56,_0x3f5690,_0x18391c[_0x1e66b3(0x50f)][_0x5905e7]);const _0x2a260a=getUndoAxesPermutation(_0x437ab5);return _0xa5d37e=transpose(_0xa5d37e,_0x2a260a),_0xa5d37e;};return{'x':_0x53b317,'indices':()=>_0x2dadc4};}};function arrayRange(_0x1078ad,_0x560133){const _0x38d9d8=[];for(let _0x1839fb=_0x1078ad;_0x1839fb<_0x560133;++_0x1839fb){_0x38d9d8['push'](_0x1839fb);}return _0x38d9d8;}function arrayConcat(_0x35160e){const _0xb7c373=a0_0x20018c,_0x3f76d3=[];for(let _0x255346=0x0;_0x255346<_0x35160e[_0xb7c373(0x104)];++_0x255346){for(let _0x43003e=0x0;_0x43003e<_0x35160e[_0x255346][_0xb7c373(0x104)];++_0x43003e){_0x3f76d3['push'](_0x35160e[_0x255346][_0x43003e]);}}return _0x3f76d3;}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const greaterEqualGradConfig={'kernelName':GreaterEqual,'inputsToSave':['a','b'],'gradFunc':(_0x3dc9b6,_0x14c41f)=>{const [_0x6f1724,_0x116387]=_0x14c41f;return{'a':()=>zerosLike(_0x6f1724),'b':()=>zerosLike(_0x116387)};}},identityGradConfig={'kernelName':Identity,'gradFunc':_0x24d0d0=>{const _0x4bf129=a0_0x20018c;return{'x':()=>cast(_0x24d0d0,_0x4bf129(0x28b))};}},isFiniteGradConfig={'kernelName':IsFinite,'gradFunc':_0x1c9a6f=>{return{'x':()=>zerosLike(_0x1c9a6f)};}},isInfGradConfig={'kernelName':IsInf,'gradFunc':_0x477567=>{return{'x':()=>zerosLike(_0x477567)};}},isNanGradConfig={'kernelName':IsNan,'gradFunc':_0x43e0f4=>{return{'x':()=>zerosLike(_0x43e0f4)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function greater_(_0x328805,_0x3f60ff){const _0x2fb2da=a0_0x20018c;let _0x510341=convertToTensor(_0x328805,'a',_0x2fb2da(0x2dd),_0x2fb2da(0x5c4)),_0x19dd81=convertToTensor(_0x3f60ff,'b',_0x2fb2da(0x2dd),'string_or_numeric');[_0x510341,_0x19dd81]=makeTypesMatch(_0x510341,_0x19dd81),assertAndGetBroadcastShape(_0x510341[_0x2fb2da(0x50f)],_0x19dd81[_0x2fb2da(0x50f)]);const _0x1ca59a={'a':_0x510341,'b':_0x19dd81};return ENGINE[_0x2fb2da(0x397)](Greater,_0x1ca59a);}const greater=op({'greater_':greater_}),leakyReluGradConfig={'kernelName':LeakyRelu,'inputsToSave':['x'],'gradFunc':(_0x399fa5,_0x11b2e7,_0x1c9de5)=>{const [_0x3ab9d7]=_0x11b2e7,{alpha:_0x8047c}=_0x1c9de5,_0x369e42=greater(_0x3ab9d7,0x0);return{'x':()=>where(_0x369e42,_0x399fa5,mul(_0x399fa5,_0x8047c))};}},log1pGradConfig={'kernelName':Log1p,'inputsToSave':['x'],'gradFunc':(_0x305f69,_0x56801b)=>{const [_0x4d12bd]=_0x56801b;return{'x':()=>div(_0x305f69,add$1(_0x4d12bd,0x1))};}},logGradConfig={'kernelName':Log,'inputsToSave':['x'],'gradFunc':(_0x1adeb5,_0x298fe9)=>{const _0x1c5432=a0_0x20018c,[_0x1663cc]=_0x298fe9;return{'x':()=>div(_0x1adeb5,cast(_0x1663cc,_0x1c5432(0x28b)))};}},logSoftmaxGradConfig={'kernelName':LogSoftmax,'inputsToSave':[],'outputsToSave':[!![]],'gradFunc':(_0x59c891,_0x18a0f6,_0x55b416)=>{const [_0x565329]=_0x18a0f6,{axis:_0x4f5bbb}=_0x55b416;return{'logits':()=>{const _0x3286bc=!![],_0x405861=exp(_0x565329);return sub(_0x59c891,mul(sum$1(_0x59c891,_0x4f5bbb,_0x3286bc),_0x405861));}};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function localResponseNormalizationBackprop_(_0x965e85,_0x31da83,_0x57e16a,_0x249892=0x5,_0x47f89c=0x1,_0x1b2e2d=0x1,_0x5868fd=0.5){const _0x2d0661=a0_0x20018c,_0x5321c1={'x':_0x965e85,'y':_0x31da83,'dy':_0x57e16a},_0x1de70e={'depthRadius':_0x249892,'bias':_0x47f89c,'alpha':_0x1b2e2d,'beta':_0x5868fd};return ENGINE[_0x2d0661(0x397)](LRNGrad,_0x5321c1,_0x1de70e);}const localResponseNormalizationBackprop=op({'localResponseNormalizationBackprop_':localResponseNormalizationBackprop_}),lrnGradConfig={'kernelName':LRN,'inputsToSave':['x'],'outputsToSave':[!![]],'gradFunc':(_0x10b778,_0x143eec,_0x553837)=>{const [_0x4ffb20,_0x2f6059]=_0x143eec,{depthRadius:_0x3403b1,bias:_0x4a3e6c,alpha:_0x482d12,beta:_0x5569b1}=_0x553837;return{'x':()=>localResponseNormalizationBackprop(_0x4ffb20,_0x2f6059,_0x10b778,_0x3403b1,_0x4a3e6c,_0x482d12,_0x5569b1)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function equal_(_0x142911,_0x4db0b4){const _0xcc0911=a0_0x20018c;let _0x28faba=convertToTensor(_0x142911,'a',_0xcc0911(0x168),_0xcc0911(0x5c4)),_0x1ac038=convertToTensor(_0x4db0b4,'b','equal',_0xcc0911(0x5c4));[_0x28faba,_0x1ac038]=makeTypesMatch(_0x28faba,_0x1ac038),assertAndGetBroadcastShape(_0x28faba['shape'],_0x1ac038[_0xcc0911(0x50f)]);const _0x5ba315={'a':_0x28faba,'b':_0x1ac038};return ENGINE[_0xcc0911(0x397)](Equal,_0x5ba315);}const equal=op({'equal_':equal_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function gradForMinAndMax(_0x5a5562,_0xb348cd,_0x4988d2,_0x53fc1f){const _0xc63b72=a0_0x20018c;return _0xb348cd[_0xc63b72(0x36e)]<_0x4988d2[_0xc63b72(0x36e)]&&(_0xb348cd=reshape(_0xb348cd,expandShapeToKeepDim(_0xb348cd['shape'],_0x53fc1f))),_0x5a5562[_0xc63b72(0x36e)]<_0x4988d2[_0xc63b72(0x36e)]&&(_0x5a5562=reshape(_0x5a5562,expandShapeToKeepDim(_0x5a5562[_0xc63b72(0x50f)],_0x53fc1f))),{'x':()=>{const _0x10b48e=_0xc63b72,_0x329c89=mul(_0x5a5562,cast(equal(_0x4988d2,_0xb348cd),_0x5a5562[_0x10b48e(0x51c)]));return _0x329c89;}};}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const maxGradConfig={'kernelName':Max,'inputsToSave':['x'],'outputsToSave':[!![]],'gradFunc':(_0xd86da0,_0x5bb541,_0x3ae5d6)=>{const _0x1c8455=a0_0x20018c,_0x5333ef=_0x3ae5d6,{reductionIndices:_0x36dd4f}=_0x5333ef,_0x3cff83=_0x5bb541[0x0],_0x2a1d42=_0x5bb541[0x1],_0x160f9f=parseAxisParam(_0x36dd4f,_0x3cff83[_0x1c8455(0x50f)]),_0x1ba398=gradForMinAndMax(_0xd86da0,_0x2a1d42,_0x3cff83,_0x160f9f);return{'x':()=>{return _0x1ba398['x']();}};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function less_(_0x417651,_0x5b6cb9){const _0x2b7c76=a0_0x20018c;let _0x2b83cc=convertToTensor(_0x417651,'a',_0x2b7c76(0x18d),_0x2b7c76(0x5c4)),_0x1dee3e=convertToTensor(_0x5b6cb9,'b',_0x2b7c76(0x18d),_0x2b7c76(0x5c4));[_0x2b83cc,_0x1dee3e]=makeTypesMatch(_0x2b83cc,_0x1dee3e),assertAndGetBroadcastShape(_0x2b83cc['shape'],_0x1dee3e[_0x2b7c76(0x50f)]);const _0x21935b={'a':_0x2b83cc,'b':_0x1dee3e};return ENGINE['runKernel'](Less,_0x21935b);}const less=op({'less_':less_}),maximumGradConfig={'kernelName':Maximum,'inputsToSave':['a','b'],'gradFunc':(_0x7e3587,_0x386235)=>{const _0x4a10ba=a0_0x20018c,[_0x3aece3,_0x5c52b4]=_0x386235,_0x2ada04=()=>mul(_0x7e3587,cast(greaterEqual(_0x3aece3,_0x5c52b4),_0x4a10ba(0x28b))),_0x581004=()=>mul(_0x7e3587,cast(less(_0x3aece3,_0x5c52b4),_0x4a10ba(0x28b)));return{'a':_0x2ada04,'b':_0x581004};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function maxPool3dGrad_(_0x653dbd,_0x2edb0d,_0x55c197,_0x35924d,_0xbd919e,_0x19cb7c,_0x2ebd22){const _0x25c67d=a0_0x20018c,_0x2c08b8=convertToTensor(_0x653dbd,'dy',_0x25c67d(0x4c2)),_0x5ac57d=convertToTensor(_0x2edb0d,_0x25c67d(0x333),_0x25c67d(0x4c2)),_0x39ccb1=convertToTensor(_0x55c197,'output',_0x25c67d(0x4c2));let _0x37e93d=_0x2c08b8,_0x30eb04=_0x5ac57d,_0x177a5c=_0x39ccb1,_0x34f6b7=![];_0x5ac57d[_0x25c67d(0x36e)]===0x4&&(_0x34f6b7=!![],_0x37e93d=reshape(_0x2c08b8,[0x1,_0x2c08b8[_0x25c67d(0x50f)][0x0],_0x2c08b8[_0x25c67d(0x50f)][0x1],_0x2c08b8[_0x25c67d(0x50f)][0x2],_0x2c08b8[_0x25c67d(0x50f)][0x3]]),_0x30eb04=reshape(_0x5ac57d,[0x1,_0x5ac57d[_0x25c67d(0x50f)][0x0],_0x5ac57d[_0x25c67d(0x50f)][0x1],_0x5ac57d['shape'][0x2],_0x5ac57d[_0x25c67d(0x50f)][0x3]]),_0x177a5c=reshape(_0x39ccb1,[0x1,_0x39ccb1[_0x25c67d(0x50f)][0x0],_0x39ccb1[_0x25c67d(0x50f)][0x1],_0x39ccb1[_0x25c67d(0x50f)][0x2],_0x39ccb1[_0x25c67d(0x50f)][0x3]]));assert(_0x37e93d[_0x25c67d(0x36e)]===0x5,()=>_0x25c67d(0x112)+(_0x37e93d['rank']+'.')),assert(_0x30eb04[_0x25c67d(0x36e)]===0x5,()=>'Error\x20in\x20maxPool3dGrad:\x20input\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20'+(_0x30eb04['rank']+'.')),assert(_0x177a5c['rank']===0x5,()=>_0x25c67d(0x3e9)+(_0x177a5c[_0x25c67d(0x36e)]+'.'));_0x2ebd22!=null&&assert(isInt(_0x19cb7c),()=>_0x25c67d(0x531)+('using,\x20dimRoundingMode\x20'+_0x2ebd22+_0x25c67d(0x27d)+_0x19cb7c+'.'));const _0x14a2d3={'dy':_0x37e93d,'input':_0x30eb04,'output':_0x177a5c},_0xe739ad={'filterSize':_0x35924d,'strides':_0xbd919e,'pad':_0x19cb7c,'dimRoundingMode':_0x2ebd22},_0x5d0012=ENGINE[_0x25c67d(0x397)](MaxPool3DGrad,_0x14a2d3,_0xe739ad);if(_0x34f6b7)return reshape(_0x5d0012,[_0x5d0012[_0x25c67d(0x50f)][0x1],_0x5d0012['shape'][0x2],_0x5d0012[_0x25c67d(0x50f)][0x3],_0x5d0012[_0x25c67d(0x50f)][0x4]]);return _0x5d0012;}const maxPool3dGrad=op({'maxPool3dGrad_':maxPool3dGrad_}),maxPool3DGradConfig={'kernelName':MaxPool3D,'inputsToSave':['x'],'outputsToSave':[!![]],'gradFunc':(_0x4ac885,_0x18f8e6,_0x221973)=>{const [_0xd441c3,_0x14496b]=_0x18f8e6,{filterSize:_0x13254e,strides:_0x4dedd9,pad:_0x4c5c99,dimRoundingMode:_0xc2ac4b}=_0x221973;return{'x':()=>maxPool3dGrad(_0x4ac885,_0xd441c3,_0x14496b,_0x13254e,_0x4dedd9,_0x4c5c99,_0xc2ac4b)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function maxPoolGrad_(_0x4515f3,_0x27f9ed,_0x19c38b,_0x5269aa,_0x5c5c63,_0xf94103,_0x3194c2){const _0x3a135f=a0_0x20018c,_0x54447a=convertToTensor(_0x4515f3,'dy',_0x3a135f(0x3a3)),_0x1daf7b=convertToTensor(_0x27f9ed,_0x3a135f(0x333),'maxPoolGrad'),_0x38cb57=convertToTensor(_0x19c38b,_0x3a135f(0x249),'maxPoolGrad');assert(_0x1daf7b['rank']===_0x54447a[_0x3a135f(0x36e)],()=>_0x3a135f(0x57a)+_0x1daf7b[_0x3a135f(0x36e)]+')\x20does\x20not\x20match\x20rank\x20of\x20dy\x20'+('('+_0x54447a[_0x3a135f(0x36e)]+')')),assert(_0x54447a['rank']===0x4,()=>_0x3a135f(0x30a)+(_0x54447a['rank']+'.')),assert(_0x1daf7b[_0x3a135f(0x36e)]===0x4,()=>_0x3a135f(0x361)+(_0x1daf7b[_0x3a135f(0x36e)]+'.'));_0x3194c2!=null&&assert(isInt(_0xf94103),()=>_0x3a135f(0x5d2)+('dimRoundingMode\x20'+_0x3194c2+_0x3a135f(0x27d)+_0xf94103+'.'));const _0x5681db={'dy':_0x54447a,'input':_0x1daf7b,'output':_0x38cb57},_0x4b9a41={'filterSize':_0x5269aa,'strides':_0x5c5c63,'pad':_0xf94103,'dimRoundingMode':_0x3194c2};return ENGINE[_0x3a135f(0x397)](MaxPoolGrad,_0x5681db,_0x4b9a41);}const maxPoolGrad=op({'maxPoolGrad_':maxPoolGrad_}),maxPoolGradConfig={'kernelName':MaxPool,'inputsToSave':['x'],'outputsToSave':[!![]],'gradFunc':(_0x1b9fcb,_0x4ba006,_0x3ce7af)=>{const [_0x22503d,_0x3be3ff]=_0x4ba006,{filterSize:_0x3f2ee0,strides:_0x4e7559,pad:_0x41d740}=_0x3ce7af;return{'x':()=>maxPoolGrad(_0x1b9fcb,_0x22503d,_0x3be3ff,_0x3f2ee0,_0x4e7559,_0x41d740)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function complex_(_0x3267f6,_0x1876cf){const _0xe96a23=a0_0x20018c,_0x81cd34=convertToTensor(_0x3267f6,_0xe96a23(0x420),'complex'),_0x391b21=convertToTensor(_0x1876cf,'imag',_0xe96a23(0x3fb));assertShapesMatch(_0x81cd34['shape'],_0x391b21[_0xe96a23(0x50f)],_0xe96a23(0x589)+_0x81cd34[_0xe96a23(0x50f)]+_0xe96a23(0x1de)+_0x391b21[_0xe96a23(0x50f)]+',\x20'+_0xe96a23(0xec));const _0x1911c9={'real':_0x81cd34,'imag':_0x391b21};return ENGINE[_0xe96a23(0x397)](Complex,_0x1911c9);}const complex=op({'complex_':complex_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function zeros(_0x25db06,_0x3e3b3b=a0_0x20018c(0x28b)){const _0x31364c=a0_0x20018c;if(_0x3e3b3b===_0x31364c(0xe8)){const _0x36cb50=zeros(_0x25db06,_0x31364c(0x28b)),_0xa571d0=zeros(_0x25db06,_0x31364c(0x28b));return complex(_0x36cb50,_0xa571d0);}const _0x44b765=makeZerosTypedArray(sizeFromShape(_0x25db06),_0x3e3b3b);return ENGINE['makeTensor'](_0x44b765,_0x25db06,_0x3e3b3b);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function ones$1(_0x1aa080,_0x1d816a=a0_0x20018c(0x28b)){const _0x576cc4=a0_0x20018c;if(_0x1d816a===_0x576cc4(0xe8)){const _0x253746=ones$1(_0x1aa080,_0x576cc4(0x28b)),_0x5432ec=zeros(_0x1aa080,_0x576cc4(0x28b));return complex(_0x253746,_0x5432ec);}const _0x394c93=makeOnesTypedArray(sizeFromShape(_0x1aa080),_0x1d816a);return ENGINE[_0x576cc4(0x210)](_0x394c93,_0x1aa080,_0x1d816a);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const meanGradConfig={'kernelName':Mean,'inputsToSave':['x'],'gradFunc':(_0x27d3c5,_0x4a57bc,_0x3e0547)=>{const _0x1b1c42=a0_0x20018c,[_0x5b92d9]=_0x4a57bc,{axis:_0x49f176}=_0x3e0547,_0x3e8446=parseAxisParam(_0x49f176,_0x5b92d9['shape']),_0x2ce30d=computeOutAndReduceShapes(_0x5b92d9[_0x1b1c42(0x50f)],_0x3e8446),_0x33dc34=_0x2ce30d[0x1],_0x254c25=sizeFromShape(_0x33dc34),_0x5d7875=()=>{const _0x184688=_0x1b1c42,_0x592ab2=_0x5b92d9['shape'][_0x184688(0x2b0)]();_0x3e8446[_0x184688(0x1e4)](_0x1a169e=>{_0x592ab2[_0x1a169e]=0x1;});const _0x33bd37=reshape(_0x27d3c5,_0x592ab2),_0x1eabbf=div(mul(_0x33bd37,ones$1(_0x5b92d9[_0x184688(0x50f)],_0x184688(0x28b))),_0x254c25);return _0x1eabbf;};return{'x':_0x5d7875};}},minGradConfig={'kernelName':Min,'inputsToSave':['x'],'outputsToSave':[!![]],'gradFunc':(_0x7d5235,_0x6eb2c3,_0x47212d)=>{const _0x8a54e2=a0_0x20018c,_0x10a1dc=_0x47212d,{axis:_0x465704}=_0x10a1dc,[_0x23564e,_0x33c0a1]=_0x6eb2c3,_0x2e5cb=parseAxisParam(_0x465704,_0x23564e[_0x8a54e2(0x50f)]),_0x322aaa=gradForMinAndMax(_0x7d5235,_0x33c0a1,_0x23564e,_0x2e5cb);return{'x':()=>{return _0x322aaa['x']();}};}},minimumGradConfig={'kernelName':Minimum,'inputsToSave':['a','b'],'gradFunc':(_0x38646e,_0x2547fb)=>{const _0x480e6c=a0_0x20018c,[_0x406ef8,_0x42175b]=_0x2547fb,_0x3c906a=()=>mul(_0x38646e,cast(lessEqual(_0x406ef8,_0x42175b),'float32')),_0x5a5d18=()=>mul(_0x38646e,cast(greater(_0x406ef8,_0x42175b),_0x480e6c(0x28b)));return{'a':_0x3c906a,'b':_0x5a5d18};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function slice_(_0x10e5fa,_0x5f809a,_0x27c434){const _0x1656e1=a0_0x20018c,_0x5b0dc9=convertToTensor(_0x10e5fa,'x',_0x1656e1(0x2b0),_0x1656e1(0x5c4));if(_0x5b0dc9['rank']===0x0)throw new Error(_0x1656e1(0x3e4));const _0x2108fa={'x':_0x5b0dc9},_0x44a3d7={'begin':_0x5f809a,'size':_0x27c434};return ENGINE['runKernel'](Slice,_0x2108fa,_0x44a3d7);}const slice=op({'slice_':slice_}),mirrorPadGradConfig={'kernelName':MirrorPad,'inputsToSave':['x'],'gradFunc':(_0x38cbf4,_0x1c3fe1,_0x4bbd90)=>{const _0x480aef=a0_0x20018c,_0x4ccdae=_0x1c3fe1[0x0],{paddings:_0xdfd24c}=_0x4bbd90,_0x2296ca=_0xdfd24c[_0x480aef(0x3ab)](_0x3c39bf=>_0x3c39bf[0x0]);return{'x':()=>slice(_0x38cbf4,_0x2296ca,_0x4ccdae[_0x480aef(0x50f)])};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function floor_(_0x231232){const _0x32841d=a0_0x20018c,_0x373854=convertToTensor(_0x231232,'x',_0x32841d(0x476)),_0x1a124b={'x':_0x373854};return ENGINE['runKernel'](Floor,_0x1a124b);}const floor=op({'floor_':floor_}),modGradConfig={'kernelName':Mod,'inputsToSave':['a','b'],'gradFunc':(_0x2c922b,_0x553a98)=>{const _0x2ec28a=a0_0x20018c,[_0x17c5a4,_0x7d73e7]=_0x553a98,_0x4b952a=assertAndGetBroadcastShape(_0x17c5a4['shape'],_0x7d73e7[_0x2ec28a(0x50f)]),_0x51a153=()=>{const _0x17ef29=_0x2ec28a,_0x1e6ac9=getReductionAxes(_0x17c5a4[_0x17ef29(0x50f)],_0x4b952a);if(_0x1e6ac9[_0x17ef29(0x104)]>0x0)return reshape(sum$1(_0x2c922b,_0x1e6ac9),_0x17c5a4['shape']);return _0x2c922b;},_0x4368ca=()=>{const _0xf11eae=_0x2ec28a,_0x1e3bde=mul(_0x2c922b,neg(floor(div(_0x17c5a4,_0x7d73e7)))),_0x49b90b=getReductionAxes(_0x7d73e7[_0xf11eae(0x50f)],_0x4b952a);if(_0x49b90b[_0xf11eae(0x104)]>0x0)return reshape(sum$1(_0x1e3bde,_0x49b90b),_0x7d73e7['shape']);return _0x1e3bde;};return{'a':_0x51a153,'b':_0x4368ca};}},multiplyGradConfig={'kernelName':Multiply,'inputsToSave':['a','b'],'gradFunc':(_0x3997cf,_0x4422c5)=>{const [_0x3a49a8,_0x2dcd73]=_0x4422c5,_0x11f2a3=assertAndGetBroadcastShape(_0x3a49a8['shape'],_0x2dcd73['shape']),_0x4f2062=()=>{const _0x2ff5a8=a0_0x367f,_0x3b2d95=mul(_0x3997cf,cast(_0x2dcd73,_0x2ff5a8(0x28b))),_0x4aeecb=getReductionAxes(_0x3a49a8[_0x2ff5a8(0x50f)],_0x11f2a3);if(_0x4aeecb['length']>0x0)return reshape(sum$1(_0x3b2d95,_0x4aeecb),_0x3a49a8[_0x2ff5a8(0x50f)]);return _0x3b2d95;},_0x17c5f9=()=>{const _0x51494d=a0_0x367f,_0x18ad4d=mul(_0x3997cf,cast(_0x3a49a8,_0x51494d(0x28b))),_0x8dd9e9=getReductionAxes(_0x2dcd73[_0x51494d(0x50f)],_0x11f2a3);if(_0x8dd9e9[_0x51494d(0x104)]>0x0)return reshape(sum$1(_0x18ad4d,_0x8dd9e9),_0x2dcd73['shape']);return _0x18ad4d;};return{'a':_0x4f2062,'b':_0x17c5f9};}},negGradConfig={'kernelName':Neg,'gradFunc':_0x175df3=>{return{'x':()=>neg(_0x175df3)};}},oneHotGradConfig={'kernelName':OneHot,'inputsToSave':[a0_0x20018c(0x402)],'gradFunc':(_0x9c86c,_0x573eb9)=>{const _0x3df73a=a0_0x20018c,_0x57cd5e=_0x573eb9[0x0];return{'indices':()=>zeros(_0x57cd5e[_0x3df73a(0x50f)],_0x3df73a(0x28b))};}},onesLikeGradConfig={'kernelName':OnesLike,'gradFunc':_0x1f635d=>{return{'x':()=>zerosLike(_0x1f635d)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function unstack_(_0x13ddd4,_0x5d4782=0x0){const _0xc1c354=a0_0x20018c,_0x41c3bc=convertToTensor(_0x13ddd4,'x','unstack',_0xc1c354(0x5c4));assert(_0x5d4782>=-_0x41c3bc['shape'][_0xc1c354(0x104)]&&_0x5d4782<_0x41c3bc[_0xc1c354(0x50f)]['length'],()=>_0xc1c354(0x52b)+_0x5d4782+_0xc1c354(0x280)+_0x41c3bc[_0xc1c354(0x50f)][_0xc1c354(0x104)]+',\x20'+_0x41c3bc[_0xc1c354(0x50f)][_0xc1c354(0x104)]+')');const _0x4904bb={'value':_0x41c3bc},_0x17fa09={'axis':_0x5d4782};return ENGINE[_0xc1c354(0x397)](Unpack,_0x4904bb,_0x17fa09);}const unstack=op({'unstack_':unstack_}),packGradConfig={'kernelName':Pack,'saveAllInputs':!![],'gradFunc':(_0x5af2bc,_0x26ba4a,_0x51c875)=>{const _0x5565f9=a0_0x20018c,{axis:_0x118158}=_0x51c875,_0xd1ae1=unstack(_0x5af2bc,_0x118158);return _0xd1ae1[_0x5565f9(0x3ab)](_0x103c29=>()=>_0x103c29);}},padV2GradConfig={'kernelName':PadV2,'inputsToSave':['x'],'gradFunc':(_0x45f002,_0x3da1ca,_0x68e948)=>{const _0x3b8405=a0_0x20018c,_0x322a69=_0x3da1ca[0x0],{paddings:_0x5b1e41}=_0x68e948,_0x409801=_0x5b1e41[_0x3b8405(0x3ab)](_0x46cf2e=>_0x46cf2e[0x0]);return{'x':()=>slice(_0x45f002,_0x409801,_0x322a69[_0x3b8405(0x50f)])};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function log_(_0x590390){const _0x145d7f=a0_0x20018c,_0x477ca4=convertToTensor(_0x590390,'x',_0x145d7f(0x4d2)),_0x50a639={'x':_0x477ca4};return ENGINE[_0x145d7f(0x397)](Log,_0x50a639);}const log$1=op({'log_':log_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function pow_(_0x4e3cd7,_0x593c39){const _0x30ffa0=a0_0x20018c;let _0x58d784=convertToTensor(_0x4e3cd7,_0x30ffa0(0x43a),_0x30ffa0(0xdb)),_0x53bf85=convertToTensor(_0x593c39,_0x30ffa0(0x57c),_0x30ffa0(0xdb));[_0x58d784,_0x53bf85]=makeTypesMatch(_0x58d784,_0x53bf85);const _0x14998d={'a':_0x58d784,'b':_0x53bf85};return ENGINE[_0x30ffa0(0x397)](Pow,_0x14998d);}const pow=op({'pow_':pow_}),powGradConfig={'kernelName':Pow,'inputsToSave':['a','b'],'outputsToSave':[!![]],'gradFunc':(_0x36fd53,_0x3a4383)=>{const _0x3cd550=a0_0x20018c,[_0x40c627,_0x4135b2,_0x80fcd3]=_0x3a4383,_0x501022=_0x40c627,_0x32fab4=_0x4135b2,_0x3e92f5=assertAndGetBroadcastShape(_0x501022[_0x3cd550(0x50f)],_0x32fab4[_0x3cd550(0x50f)]),_0x195a70=()=>{const _0x1b1b3a=_0x3cd550,_0xf48d4b=cast(_0x32fab4,_0x1b1b3a(0x28b));let _0x1a42a0=mul(_0x36fd53,mul(_0xf48d4b,pow(_0x501022,sub(_0xf48d4b,scalar(0x1)))));const _0x3da35e=getReductionAxes(_0x501022['shape'],_0x3e92f5);return _0x3da35e[_0x1b1b3a(0x104)]>0x0&&(_0x1a42a0=sum$1(_0x1a42a0,_0x3da35e)),reshape(_0x1a42a0,_0x501022[_0x1b1b3a(0x50f)]);},_0x49748d=()=>{const _0x158218=_0x3cd550,_0x2103ec=greater(_0x501022,0x0),_0x5cfb57=where(_0x2103ec,log$1(_0x501022),zerosLike(_0x501022));let _0x2391f3=mul(_0x36fd53,mul(_0x80fcd3,_0x5cfb57));const _0x420cce=getReductionAxes(_0x32fab4[_0x158218(0x50f)],_0x3e92f5);return _0x420cce[_0x158218(0x104)]>0x0&&(_0x2391f3=sum$1(_0x2391f3,_0x420cce)),reshape(_0x2391f3,_0x32fab4[_0x158218(0x50f)]);};return{'a':_0x195a70,'b':_0x49748d};}},preluGradConfig={'kernelName':Prelu,'inputsToSave':['x','alpha'],'gradFunc':(_0x51b474,_0x324040)=>{const [_0x52a285,_0x1ea80b]=_0x324040,_0x1cce58=greater(_0x52a285,0x0);return{'x':()=>where(_0x1cce58,_0x51b474,mul(_0x51b474,_0x1ea80b)),'alpha':()=>{const _0x120b34=a0_0x367f;let _0xa97845=where(_0x1cce58,zerosLike(_0x51b474),mul(_0x51b474,_0x52a285));const _0x11b23a=getReductionAxes(_0x1ea80b['shape'],_0x51b474[_0x120b34(0x50f)]);return _0x11b23a['length']>0x0&&(_0xa97845=sum$1(_0xa97845,_0x11b23a)),reshape(_0xa97845,_0x1ea80b[_0x120b34(0x50f)]);}};}},divGradConfig={'kernelName':RealDiv,'inputsToSave':['a','b'],'gradFunc':(_0x1588d4,_0xcba67f)=>{const _0x7b6702=a0_0x20018c,[_0x2c5953,_0x2959d3]=_0xcba67f,_0x511cab=assertAndGetBroadcastShape(_0x2c5953[_0x7b6702(0x50f)],_0x2959d3[_0x7b6702(0x50f)]),_0x66e1f8=()=>{const _0x1c10ce=_0x7b6702,_0x5b4684=div(_0x1588d4,cast(_0x2959d3,_0x1c10ce(0x28b))),_0x7f9c94=getReductionAxes(_0x2c5953[_0x1c10ce(0x50f)],_0x511cab);if(_0x7f9c94[_0x1c10ce(0x104)]>0x0)return reshape(sum$1(_0x5b4684,_0x7f9c94),_0x2c5953['shape']);return _0x5b4684;},_0xc09809=()=>{const _0x2840e4=_0x7b6702;let _0x143abc=mul(_0x1588d4,cast(_0x2c5953,_0x2840e4(0x28b)));const _0x34991f=getReductionAxes(_0x2959d3['shape'],_0x511cab);_0x34991f[_0x2840e4(0x104)]>0x0&&(_0x143abc=reshape(sum$1(_0x143abc,_0x34991f),_0x2959d3[_0x2840e4(0x50f)]));const _0x28dbdb=square(_0x2959d3);return neg(div(_0x143abc,cast(_0x28dbdb,_0x2840e4(0x28b))));};return{'a':_0x66e1f8,'b':_0xc09809};}},reciprocalGradConfig={'kernelName':Reciprocal,'inputsToSave':['x'],'gradFunc':(_0x353d41,_0x5dc2d9)=>{const [_0x6506d5]=_0x5dc2d9;return{'x':()=>div(_0x353d41,neg(square(_0x6506d5)))};}},relu6GradConfig={'kernelName':Relu6,'inputsToSave':['x'],'gradFunc':(_0x6cf867,_0x4057e4)=>{const _0x43b618=a0_0x20018c,[_0x215ca4]=_0x4057e4,_0x224c65=mul(lessEqual(_0x215ca4,0x6),step(_0x215ca4));return{'x':()=>mul(_0x6cf867,cast(_0x224c65,_0x43b618(0x28b)))};}},reluGradConfig={'kernelName':Relu,'inputsToSave':['x'],'gradFunc':(_0xdb109f,_0x51f144)=>{const _0x20c9ac=a0_0x20018c,[_0xdc8bf5]=_0x51f144;return{'x':()=>mul(_0xdb109f,cast(step(_0xdc8bf5),_0x20c9ac(0x28b)))};}},reshapeGradConfig={'kernelName':Reshape,'inputsToSave':['x'],'gradFunc':(_0x3aaa6b,_0x16cbe4)=>{const [_0x2379cd]=_0x16cbe4;return{'x':()=>reshape(_0x3aaa6b,_0x2379cd['shape'])};}},resizeBilinearGradConfig={'kernelName':ResizeBilinear,'inputsToSave':[a0_0x20018c(0x171)],'gradFunc':(_0x44c917,_0x1d6d6c,_0x5f5134)=>{const _0xaaecc9=a0_0x20018c,[_0x38f991]=_0x1d6d6c,_0x932a5b={'dy':_0x44c917,'images':_0x38f991},_0x1c40b8=()=>ENGINE[_0xaaecc9(0x397)](ResizeBilinearGrad,_0x932a5b,_0x5f5134);return{'images':_0x1c40b8};}},resizeNearestNeighborGradConfig={'kernelName':ResizeNearestNeighbor,'inputsToSave':[a0_0x20018c(0x171)],'gradFunc':(_0x7cd053,_0x21f675,_0x10b4e9)=>{const _0x5430b1=a0_0x20018c,[_0x557ec2]=_0x21f675,_0x2ee9a5={'dy':_0x7cd053,'images':_0x557ec2},_0x1c0484=()=>ENGINE[_0x5430b1(0x397)](ResizeNearestNeighborGrad,_0x2ee9a5,_0x10b4e9);return{'images':_0x1c0484};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reverse_(_0x2e6498,_0xfaef60){const _0x5d023c=a0_0x20018c,_0x49835b=convertToTensor(_0x2e6498,'x',_0x5d023c(0x48d)),_0x348825={'x':_0x49835b},_0x16693a={'dims':_0xfaef60};return ENGINE[_0x5d023c(0x397)](Reverse,_0x348825,_0x16693a);}const reverse=op({'reverse_':reverse_}),reverseGradConfig={'kernelName':Reverse,'gradFunc':(_0x2167f9,_0x59af2f,_0x4f4e82)=>{const {dims:_0x2c12fb}=_0x4f4e82,_0x5752cc=parseAxisParam(_0x2c12fb,_0x2167f9['shape']);return{'x':()=>reverse(_0x2167f9,_0x5752cc)};}},roundGradConfig={'kernelName':Round,'gradFunc':_0x51f589=>{return{'x':()=>zerosLike(_0x51f589)};}},rsqrtGradConfig={'kernelName':Rsqrt,'inputsToSave':['x'],'gradFunc':(_0x8d3fdc,_0x51c731)=>{const [_0x29e4e3]=_0x51c731;return{'x':()=>neg(div(_0x8d3fdc,mul(pow(_0x29e4e3,1.5),0x2)))};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logicalNot_(_0x11b05e){const _0x28def3=a0_0x20018c,_0x5d400e=convertToTensor(_0x11b05e,'x',_0x28def3(0x4d4),'bool'),_0x4f6347={'x':_0x5d400e};return ENGINE['runKernel'](LogicalNot,_0x4f6347);}const logicalNot=op({'logicalNot_':logicalNot_}),selectGradConfig={'kernelName':Select,'inputsToSave':[a0_0x20018c(0x1a2)],'gradFunc':(_0x3b5e6c,_0x1bacbf)=>{const _0x22b4e7=a0_0x20018c,[_0x447558]=_0x1bacbf;return{'condition':()=>cast(zerosLike(_0x447558),'float32'),'t':()=>mul(_0x3b5e6c,cast(_0x447558,_0x3b5e6c['dtype'])),'e':()=>mul(_0x3b5e6c,cast(logicalNot(_0x447558),_0x3b5e6c[_0x22b4e7(0x51c)]))};}},SELU_SCALEALPHA=1.7580993408473768,SELU_SCALE=1.0507009873554805,seluGradConfig={'kernelName':Selu,'inputsToSave':['x'],'gradFunc':(_0x4caca4,_0x5d5089)=>{const [_0x17432a]=_0x5d5089;return{'x':()=>{const _0x19e47b=a0_0x367f,_0x556505=greater(_0x17432a,scalar(0x0)),_0x1015f2=scalar(SELU_SCALEALPHA),_0xa7a16e=scalar(SELU_SCALE),_0x464cea=mul(_0x4caca4,_0xa7a16e),_0x57a667=mul(mul(_0x4caca4,_0x1015f2),exp(cast(_0x17432a,_0x19e47b(0x28b))));return where(_0x556505,_0x464cea,_0x57a667);}};}},sigmoidGradConfig={'kernelName':Sigmoid,'outputsToSave':[!![]],'gradFunc':(_0x526d19,_0x1d1c4c)=>{const [_0x114173]=_0x1d1c4c;return{'x':()=>mul(_0x526d19,mul(_0x114173,sub(scalar(0x1),_0x114173)))};}},signGradConfig={'kernelName':Sign,'gradFunc':_0x533a8c=>{return{'x':()=>zerosLike(_0x533a8c)};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function cos_(_0xb2a83a){const _0x41a362=a0_0x20018c,_0x5c979d=convertToTensor(_0xb2a83a,'x','cos'),_0x204729={'x':_0x5c979d};return ENGINE[_0x41a362(0x397)](Cos,_0x204729);}const cos=op({'cos_':cos_}),sinGradConfig={'kernelName':Sin,'inputsToSave':['x'],'gradFunc':(_0x853b2b,_0x4dde75)=>{const _0x324f2c=a0_0x20018c,[_0x50c4b5]=_0x4dde75;return{'x':()=>mul(cos(cast(_0x50c4b5,_0x324f2c(0x28b))),_0x853b2b)};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function cosh_(_0x55b413){const _0x2ff09f=a0_0x20018c,_0x33d46a=convertToTensor(_0x55b413,'x',_0x2ff09f(0x239)),_0x4a79d8={'x':_0x33d46a};return ENGINE[_0x2ff09f(0x397)](Cosh,_0x4a79d8);}const cosh=op({'cosh_':cosh_}),sinhGradConfig={'kernelName':Sinh,'inputsToSave':['x'],'gradFunc':(_0x9ee928,_0x4068e0)=>{const [_0x53df3d]=_0x4068e0;return{'x':()=>mul(cosh(cast(_0x53df3d,'float32')),_0x9ee928)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function pad_(_0x37d977,_0x4d87fb,_0x434453=0x0){const _0x134562=a0_0x20018c,_0x324a15=convertToTensor(_0x37d977,'x',_0x134562(0x15c));if(_0x324a15['rank']===0x0)throw new Error(_0x134562(0x411));const _0x1fc55b={'paddings':_0x4d87fb,'constantValue':_0x434453},_0x1c2950={'x':_0x324a15};return ENGINE['runKernel'](PadV2,_0x1c2950,_0x1fc55b);}const pad=op({'pad_':pad_});/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function assertParamsValid(_0x4e5a18,_0x349666,_0x39127b){const _0x3aab8d=a0_0x20018c,_0x2f5f6a=_0x4e5a18[_0x3aab8d(0x50f)]['length'];assert(_0x2f5f6a===_0x349666['length'],()=>_0x3aab8d(0x120)+_0x2f5f6a+_0x3aab8d(0x59c)+_0x349666+_0x3aab8d(0x276)+(_0x3aab8d(0x46c)+_0x2f5f6a+').')),assert(_0x2f5f6a===_0x39127b['length'],()=>_0x3aab8d(0x120)+_0x2f5f6a+_0x3aab8d(0x423)+_0x39127b+'\x20must\x20'+('match\x20the\x20rank\x20of\x20the\x20array\x20('+_0x2f5f6a+').'));for(let _0x490197=0x0;_0x490197<_0x2f5f6a;++_0x490197){assert(_0x349666[_0x490197]+_0x39127b[_0x490197]<=_0x4e5a18[_0x3aab8d(0x50f)][_0x490197],()=>_0x3aab8d(0x120)+_0x2f5f6a+_0x3aab8d(0x1af)+_0x490197+_0x3aab8d(0xe5)+_0x490197+']\x20'+('('+(_0x349666[_0x490197]+_0x39127b[_0x490197])+_0x3aab8d(0x305)+_0x490197+_0x3aab8d(0x16a)+_0x4e5a18[_0x3aab8d(0x50f)][_0x490197]+')'));}}function maskToAxes(_0x246334){const _0x211184=[];let _0x19281b=0x0;while(_0x246334>0x0){_0x246334&0x1&&_0x211184['push'](_0x19281b),_0x246334/=0x2,_0x19281b++;}return _0x211184;}function computeOutShape(_0x14fdeb,_0x51e5eb,_0x5c5a7c){const _0x35345d=a0_0x20018c,_0x2aa5c=[];for(let _0x283310=0x0;_0x283310<_0x14fdeb[_0x35345d(0x104)];_0x283310++){_0x2aa5c[_0x283310]=Math[_0x35345d(0x4a7)]((_0x51e5eb[_0x283310]-_0x14fdeb[_0x283310])/_0x5c5a7c[_0x283310]);}return _0x2aa5c;}function stridesWithElidedDims(_0x49f0f8,_0x2fd9c2,_0x338200,_0x4ef9b6){const _0x50258f=a0_0x20018c,_0x1e140f=[..._0x49f0f8];for(let _0x4dd4f2=_0x1e140f[_0x50258f(0x104)];_0x4dd4f2<_0x4ef9b6[_0x50258f(0x104)];_0x4dd4f2++){_0x1e140f['push'](0x1);}for(let _0x7b5502=0x0;_0x7b5502<_0x338200;_0x7b5502++){_0x7b5502===0x0?_0x1e140f[_0x2fd9c2]=0x1:(_0x1e140f[_0x50258f(0x24d)](_0x2fd9c2,0x0,0x1),_0x1e140f[_0x50258f(0x1c2)]());}return _0x1e140f;}function unnormalizeAxis(_0x5d87a5,_0x59e8e6,_0x136f24){if(_0x136f24<=_0x5d87a5)return _0x136f24;return _0x136f24-(_0x59e8e6-0x1);}function getElidedAxes(_0x235bb8,_0x4e9f36){const _0xdd15a5=[];for(let _0x39165f=0x0;_0x39165f<_0x235bb8;_0x39165f++){_0xdd15a5['push'](_0x4e9f36+_0x39165f);}return _0xdd15a5;}function getNormalizedAxes(_0x368d5c,_0x16edac,_0x23efc6,_0x37d7f0,_0x447789,_0x5c5950,_0x11df25,_0x2a09ca,_0x347ebf){const _0x5481e2=a0_0x20018c,_0x5ccb27=_0x368d5c[_0x5481e2(0x104)];let _0x4a1892=new Array(_0x5ccb27),_0x470b27=new Array(_0x5ccb27),_0x2b6b72=new Array(_0x5ccb27);if(_0x16edac[_0x5481e2(0x104)]&&_0x23efc6>0x0){const _0x19822a=_0x16edac[0x0],_0x200374=_0x23efc6+0x1;_0x4a1892=startIndicesWithElidedDims(_0x11df25,_0x19822a,_0x200374,_0x37d7f0,_0x368d5c),_0x470b27=stopIndicesWithElidedDims(_0x2a09ca,_0x19822a,_0x200374,_0x447789,_0x368d5c),_0x2b6b72=stridesWithElidedDims(_0x5c5950,_0x19822a,_0x200374,_0x368d5c);}else for(let _0x133495=0x0;_0x133495<_0x5ccb27;_0x133495++){_0x4a1892[_0x133495]=startForAxis(_0x11df25,_0x37d7f0,_0x5c5950,_0x368d5c,_0x133495,_0x347ebf),_0x470b27[_0x133495]=stopForAxis(_0x2a09ca,_0x447789,_0x5c5950,_0x368d5c,_0x133495,_0x347ebf),_0x2b6b72[_0x133495]=stridesForAxis(_0x5c5950,_0x133495,_0x347ebf);}return{'begin':_0x4a1892,'end':_0x470b27,'strides':_0x2b6b72};}function startIndicesWithElidedDims(_0x35e1e1,_0x409b63,_0x953cb5,_0x40fd91,_0x2010e2){const _0x302695=a0_0x20018c,_0x37a3f8=[..._0x2010e2],_0x344fd5=getElidedAxes(_0x953cb5,_0x409b63);for(let _0xef8354=0x0;_0xef8354<_0x37a3f8[_0x302695(0x104)];_0xef8354++){if(_0x344fd5['indexOf'](_0xef8354)>-0x1)_0x37a3f8[_0xef8354]=0x0;else{const _0x206ef1=unnormalizeAxis(_0x409b63,_0x953cb5,_0xef8354);let _0x303247=_0x40fd91[_0x206ef1];_0x35e1e1&0x1<<_0x206ef1&&(_0x303247=0x0),_0x37a3f8[_0xef8354]=_0x303247;}}return _0x37a3f8;}function stopIndicesWithElidedDims(_0x3eddf6,_0x38beda,_0x303f05,_0x363eab,_0x414c2b){const _0x1f854e=a0_0x20018c,_0x106480=[..._0x414c2b],_0xc3a05=getElidedAxes(_0x303f05,_0x38beda);for(let _0x27ec46=0x0;_0x27ec46<_0x106480[_0x1f854e(0x104)];_0x27ec46++){if(_0xc3a05[_0x1f854e(0x12e)](_0x27ec46)>-0x1)_0x106480[_0x27ec46]=Number[_0x1f854e(0x38b)];else{const _0xe4076f=unnormalizeAxis(_0x38beda,_0x303f05,_0x27ec46);let _0x2683a0=_0x363eab[_0xe4076f];_0x3eddf6&0x1<<_0xe4076f&&(_0x2683a0=Number[_0x1f854e(0x38b)]),_0x106480[_0x27ec46]=_0x2683a0;}}for(let _0x45a42a=0x0;_0x45a42a<_0x106480[_0x1f854e(0x104)];_0x45a42a++){const _0x39fa76=_0x414c2b[_0x45a42a];_0x106480[_0x45a42a]<0x0&&(_0x106480[_0x45a42a]+=_0x39fa76),_0x106480[_0x45a42a]=clamp(0x0,_0x106480[_0x45a42a],_0x414c2b[_0x45a42a]);}return _0x106480;}function stridesForAxis(_0x5013fa,_0x5173cb,_0x31816a){let _0x2453a9=_0x5013fa[_0x5173cb];return(_0x31816a&0x1<<_0x5173cb||_0x2453a9==null)&&(_0x2453a9=0x1),_0x2453a9;}function startForAxis(_0x2285db,_0x4a2e54,_0x56405b,_0x56a3b1,_0x45a1df,_0x1cc7ec){const _0x5f4d25=a0_0x20018c;let _0x327704=_0x4a2e54[_0x45a1df];const _0x1e12a7=_0x56405b[_0x45a1df]||0x1;(_0x2285db&0x1<<_0x45a1df||_0x1cc7ec&0x1<<_0x45a1df||_0x327704==null)&&(_0x1e12a7>0x0?_0x327704=Number[_0x5f4d25(0x460)]:_0x327704=Number[_0x5f4d25(0x38b)]);const _0x2f0b1b=_0x56a3b1[_0x45a1df];return _0x327704<0x0&&(_0x327704+=_0x2f0b1b),_0x327704=clamp(0x0,_0x327704,_0x2f0b1b-0x1),_0x327704;}function stopForAxis(_0x30a1ba,_0x128214,_0x580738,_0x38cce4,_0x4b4a3f,_0x5ef668){const _0x2266f0=a0_0x20018c;let _0x93a0d=_0x128214[_0x4b4a3f];const _0x1b6beb=_0x580738[_0x4b4a3f]||0x1;(_0x30a1ba&0x1<<_0x4b4a3f||_0x5ef668&0x1<<_0x4b4a3f||_0x93a0d==null)&&(_0x1b6beb>0x0?_0x93a0d=Number[_0x2266f0(0x38b)]:_0x93a0d=Number[_0x2266f0(0x460)]);const _0x597066=_0x38cce4[_0x4b4a3f];return _0x93a0d<0x0&&(_0x93a0d+=_0x597066),_0x1b6beb>0x0?_0x93a0d=clamp(0x0,_0x93a0d,_0x597066):_0x93a0d=clamp(-0x1,_0x93a0d,_0x597066-0x1),_0x93a0d;}function isSliceContinous(_0xc97630,_0xb75640,_0x3f55ed){const _0x40f34a=a0_0x20018c;let _0x19fb67=_0x3f55ed[_0x40f34a(0x104)];for(let _0x1b907f=0x0;_0x1b907f<_0x3f55ed[_0x40f34a(0x104)];_0x1b907f++){if(_0x3f55ed[_0x1b907f]>0x1){_0x19fb67=_0x1b907f;break;}}for(let _0x46dde3=_0x19fb67+0x1;_0x46dde3<_0x3f55ed[_0x40f34a(0x104)];_0x46dde3++){if(_0xb75640[_0x46dde3]>0x0||_0x3f55ed[_0x46dde3]!==_0xc97630[_0x46dde3])return![];}return!![];}function computeFlatOffset(_0x23e367,_0x525998){const _0x1a24b5=a0_0x20018c;let _0x23b123=_0x23e367[_0x1a24b5(0x104)]>0x0?_0x23e367[_0x23e367[_0x1a24b5(0x104)]-0x1]:0x1;for(let _0x15a524=0x0;_0x15a524<_0x23e367[_0x1a24b5(0x104)]-0x1;_0x15a524++){_0x23b123+=_0x23e367[_0x15a524]*_0x525998[_0x15a524];}return _0x23b123;}function parseSliceParams(_0x2a07de,_0x36e61c,_0x2fc9a8){const _0x496b1c=a0_0x20018c;let _0x464e7;const _0x49d7f6=_0x2a07de[_0x496b1c(0x50f)][_0x496b1c(0x104)];if(typeof _0x36e61c===_0x496b1c(0x4ac))_0x464e7=[_0x36e61c,...new Array(_0x49d7f6-0x1)['fill'](0x0)];else _0x36e61c[_0x496b1c(0x104)]<_0x49d7f6?_0x464e7=_0x36e61c[_0x496b1c(0x300)](new Array(_0x49d7f6-_0x36e61c['length'])[_0x496b1c(0x233)](0x0)):_0x464e7=_0x36e61c[_0x496b1c(0x2b0)]();_0x464e7[_0x496b1c(0x1e4)](_0x4e7e99=>{assert(_0x4e7e99!==-0x1,()=>'slice()\x20does\x20not\x20support\x20negative\x20begin\x20indexing.');});let _0x4bd8fe;if(_0x2fc9a8==null)_0x4bd8fe=new Array(_0x49d7f6)['fill'](-0x1);else{if(typeof _0x2fc9a8==='number')_0x4bd8fe=[_0x2fc9a8,...new Array(_0x49d7f6-0x1)[_0x496b1c(0x233)](-0x1)];else _0x2fc9a8[_0x496b1c(0x104)]<_0x49d7f6?_0x4bd8fe=_0x2fc9a8[_0x496b1c(0x300)](new Array(_0x49d7f6-_0x2fc9a8[_0x496b1c(0x104)])[_0x496b1c(0x233)](-0x1)):_0x4bd8fe=_0x2fc9a8;}return _0x4bd8fe=_0x4bd8fe[_0x496b1c(0x3ab)]((_0x395d7c,_0x2d0e5b)=>{const _0x542e5d=_0x496b1c;return _0x395d7c>=0x0?_0x395d7c:(assert(_0x395d7c===-0x1,()=>_0x542e5d(0x42e)+(_0x395d7c+_0x542e5d(0x187)+_0x2d0e5b+'.')),_0x2a07de[_0x542e5d(0x50f)][_0x2d0e5b]-_0x464e7[_0x2d0e5b]);}),[_0x464e7,_0x4bd8fe];}function sliceInfo(_0x2b595c,_0x3778a9,_0x2e44ba,_0x339bd0,_0x3bacc9,_0x545d71,_0x17e108,_0x2a39b5,_0x2b99fc){const _0x3b800e=a0_0x20018c;let _0x2cb20e=_0x3778a9['slice'](),_0x2d99c3=_0x2e44ba[_0x3b800e(0x2b0)](),_0x9a1042=_0x339bd0;_0x339bd0==null&&(_0x9a1042=new Array(_0x2cb20e[_0x3b800e(0x104)]));const _0x556ec5=maskToAxes(_0x17e108);if(_0x556ec5[_0x3b800e(0x104)]>0x1)throw new Error(_0x3b800e(0x1b4));if(_0x17e108!==0x0&&_0x2a39b5!==0x0)throw new Error(_0x3b800e(0x17e));if(_0x17e108!==0x0&&_0x2b99fc!==0x0)throw new Error('Using\x20both\x20ellipsisMask\x20and\x20shrinkAxisMask\x20is\x20not\x20yet\x20supported.');const _0x413411=_0x2b595c[_0x3b800e(0x104)]-_0x2cb20e[_0x3b800e(0x104)],_0x253e6e=maskToAxes(_0x2a39b5),_0x4f5eb0=_0x2b595c['slice']();_0x253e6e[_0x3b800e(0x1e4)](_0xe6d664=>{const _0x10fc58=_0x3b800e;_0x2cb20e[_0xe6d664]=0x0,_0x2d99c3[_0xe6d664]=0x1,_0x4f5eb0[_0x10fc58(0x24d)](_0xe6d664,0x0,0x1);});const {begin:_0x2a2bf4,end:_0x501525,strides:_0x36c680}=getNormalizedAxes(_0x4f5eb0,_0x556ec5,_0x413411,_0x2cb20e,_0x2d99c3,_0x9a1042,_0x3bacc9,_0x545d71,_0x17e108);_0x2cb20e=_0x2a2bf4,_0x2d99c3=_0x501525,_0x9a1042=_0x36c680;const _0x430c47=maskToAxes(_0x2b99fc);_0x430c47[_0x3b800e(0x1e4)](_0x5aa8d6=>{_0x2d99c3[_0x5aa8d6]=_0x2cb20e[_0x5aa8d6]+0x1,_0x9a1042[_0x5aa8d6]=0x1;});const _0x33f0ac=computeOutShape(_0x2cb20e,_0x2d99c3,_0x9a1042),_0x34990a=_0x33f0ac[_0x3b800e(0x481)]((_0x45324c,_0xb1abbe)=>_0x430c47['indexOf'](_0xb1abbe)===-0x1),_0x4f06b0=_0x9a1042[_0x3b800e(0x271)](_0x4dc904=>_0x4dc904===0x1);return{'nonStrided':_0x4f06b0,'$begin':_0x2cb20e,'$end':_0x2d99c3,'$strides':_0x9a1042,'size':_0x33f0ac,'newShape':_0x4f5eb0,'outShape':_0x34990a};}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const sliceGradConfig={'kernelName':Slice,'inputsToSave':['x'],'gradFunc':(_0x2e8c27,_0x5e3e6d,_0xa05d85)=>{const _0x7649bd=a0_0x20018c,[_0x533d15]=_0x5e3e6d,{begin:_0xa0a884,size:_0x343f5c}=_0xa05d85,_0x56cffe=_0x533d15[_0x7649bd(0x50f)],[_0x202793,_0x245ccd]=parseSliceParams(_0x533d15,_0xa0a884,_0x343f5c),_0x4dfe39=[];for(let _0x8ac3f=0x0;_0x8ac3f<_0x2e8c27[_0x7649bd(0x36e)];_0x8ac3f++){_0x4dfe39[_0x7649bd(0x30f)]([_0x202793[_0x8ac3f],_0x56cffe[_0x8ac3f]-_0x202793[_0x8ac3f]-_0x245ccd[_0x8ac3f]]);}return{'x':()=>pad(_0x2e8c27,_0x4dfe39)};}},softmaxGradConfig={'kernelName':Softmax,'outputsToSave':[!![]],'gradFunc':(_0x3d70a3,_0xf627cc,_0x49d61b)=>{const [_0x3c77f1]=_0xf627cc,{dim:_0x47d8f1}=_0x49d61b,_0x3ddeab=!![],_0x171230=mul(_0x3d70a3,_0x3c77f1);return{'logits':()=>sub(_0x171230,mul(sum$1(_0x171230,[_0x47d8f1],_0x3ddeab),_0x3c77f1))};}};/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sigmoid_(_0x285511){const _0x53bdc9=a0_0x20018c,_0x329123=convertToTensor(_0x285511,'x',_0x53bdc9(0x41f)),_0x558022={'x':_0x329123};return ENGINE[_0x53bdc9(0x397)](Sigmoid,_0x558022);}const sigmoid=op({'sigmoid_':sigmoid_}),softplusGradConfig={'kernelName':Softplus,'inputsToSave':['x'],'gradFunc':(_0x51668d,_0x5107e7)=>{const [_0x537dcb]=_0x5107e7;return{'x':()=>mul(_0x51668d,sigmoid(_0x537dcb))};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function batchToSpaceND_(_0x61ca7a,_0x43b56c,_0x1d7dba){const _0x4a635b=a0_0x20018c,_0x258359=convertToTensor(_0x61ca7a,'x','batchToSpaceND'),_0x495fc4=_0x43b56c[_0x4a635b(0x48a)]((_0x4954ee,_0x4b124e)=>_0x4954ee*_0x4b124e);assert(_0x258359[_0x4a635b(0x36e)]>=0x1+_0x43b56c[_0x4a635b(0x104)],()=>_0x4a635b(0x38a)+_0x258359[_0x4a635b(0x36e)]+'\x20but\x20should\x20be\x20>\x20than\x20blockShape.length\x20'+_0x43b56c[_0x4a635b(0x104)]),assert(_0x1d7dba[_0x4a635b(0x104)]===_0x43b56c[_0x4a635b(0x104)],()=>'crops.length\x20is\x20'+_0x1d7dba[_0x4a635b(0x104)]+'\x20but\x20should\x20be\x20equal\x20to\x20blockShape.length\x20\x20'+_0x43b56c[_0x4a635b(0x104)]),assert(_0x258359['shape'][0x0]%_0x495fc4===0x0,()=>_0x4a635b(0x237)+_0x258359[_0x4a635b(0x50f)][0x0]+_0x4a635b(0x150)+(_0x4a635b(0x3c0)+_0x43b56c[_0x4a635b(0x46d)]('\x20*\x20')+_0x4a635b(0x107)+_0x495fc4));const _0x411cb2={'x':_0x258359},_0x3b593a={'blockShape':_0x43b56c,'crops':_0x1d7dba};return ENGINE['runKernel'](BatchToSpaceND,_0x411cb2,_0x3b593a);}const batchToSpaceND=op({'batchToSpaceND_':batchToSpaceND_}),spaceToBatchNDGradConfig={'kernelName':SpaceToBatchND,'gradFunc':(_0x884990,_0x2de7d7,_0x31dcc1)=>{const {blockShape:_0x46eb29,paddings:_0x1543f3}=_0x31dcc1;return{'x':()=>batchToSpaceND(_0x884990,_0x46eb29,_0x1543f3)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function concat_(_0x596e43,_0x1b0e67=0x0){const _0x2d7189=a0_0x20018c;assert(_0x596e43['length']>=0x1,()=>_0x2d7189(0x395));const _0x5881b1=convertToTensorArray(_0x596e43,_0x2d7189(0x2d5),_0x2d7189(0x300),_0x2d7189(0x5c4));_0x5881b1[0x0][_0x2d7189(0x51c)]===_0x2d7189(0xe8)&&_0x5881b1[_0x2d7189(0x1e4)](_0x74912b=>{const _0x2152c3=_0x2d7189;if(_0x74912b[_0x2152c3(0x51c)]!==_0x2152c3(0xe8))throw new Error(_0x2152c3(0x2fa)+_0x74912b[_0x2152c3(0x51c)]+'.\x20');});if(_0x5881b1[_0x2d7189(0x104)]===0x1)return clone(_0x5881b1[0x0]);const _0x2edf70=_0x5881b1,_0x3cec5b={'axis':_0x1b0e67};return ENGINE[_0x2d7189(0x397)](Concat,_0x2edf70,_0x3cec5b);}const concat=op({'concat_':concat_}),splitVGradConfig={'kernelName':SplitV,'gradFunc':(_0x8200f9,_0x4d5bf8,_0x1d9cc2)=>{const {axis:_0x374fac}=_0x1d9cc2;return{'x':()=>concat(_0x8200f9,_0x374fac)};}},sqrtGradConfig={'kernelName':Sqrt,'inputsToSave':['x'],'gradFunc':(_0x3648aa,_0xd87f38)=>{const _0x29afa9=a0_0x20018c,[_0x583fcb]=_0xd87f38;return{'x':()=>div(_0x3648aa,mul(sqrt(cast(_0x583fcb,_0x29afa9(0x28b))),0x2))};}},squareGradConfig={'kernelName':Square,'inputsToSave':['x'],'gradFunc':(_0xfab497,_0x3566f6)=>{const _0xbe8fd5=a0_0x20018c,[_0x2d20ac]=_0x3566f6;return{'x':()=>mul(_0xfab497,mul(cast(_0x2d20ac,_0xbe8fd5(0x28b)),0x2))};}},squaredDifferenceGradConfig={'kernelName':SquaredDifference,'inputsToSave':['a','b'],'gradFunc':(_0x45a3ed,_0x1ed14d)=>{const [_0x4d7ff5,_0xad69f3]=_0x1ed14d,_0xbb3ab1=scalar(0x2),_0xecf732=()=>mul(_0x45a3ed,mul(_0xbb3ab1,sub(_0x4d7ff5,_0xad69f3))),_0x711681=()=>mul(_0x45a3ed,mul(_0xbb3ab1,sub(_0xad69f3,_0x4d7ff5)));return{'a':_0xecf732,'b':_0x711681};}},stepGradConfig={'kernelName':Step,'gradFunc':_0x19592a=>{return{'x':()=>zerosLike(_0x19592a)};}},subGradConfig={'kernelName':Sub,'inputsToSave':['a','b'],'gradFunc':(_0x2ac717,_0x379750)=>{const _0x57daaf=a0_0x20018c,[_0x7a000e,_0x56b27d]=_0x379750,_0x4d87e7=assertAndGetBroadcastShape(_0x7a000e[_0x57daaf(0x50f)],_0x56b27d['shape']),_0x495150=()=>{const _0x4289ed=_0x57daaf;let _0x443017=_0x2ac717;const _0x541ac2=getReductionAxes(_0x7a000e[_0x4289ed(0x50f)],_0x4d87e7);return _0x541ac2[_0x4289ed(0x104)]>0x0&&(_0x443017=sum$1(_0x443017,_0x541ac2)),reshape(_0x443017,_0x7a000e['shape']);},_0x115944=()=>{const _0x2ec091=_0x57daaf;let _0xe66b98=_0x2ac717;const _0x1116b1=getReductionAxes(_0x56b27d[_0x2ec091(0x50f)],_0x4d87e7);return _0x1116b1[_0x2ec091(0x104)]>0x0&&(_0xe66b98=sum$1(_0xe66b98,_0x1116b1)),reshape(neg(_0xe66b98),_0x56b27d['shape']);};return{'a':_0x495150,'b':_0x115944};}},sumGradConfig={'kernelName':Sum,'inputsToSave':['x'],'gradFunc':(_0x5ddf29,_0xbdb3fb,_0x496860)=>{const _0x37162a=a0_0x20018c,[_0x546cd1]=_0xbdb3fb,_0x1952ac=_0x546cd1[_0x37162a(0x50f)]['slice'](),{axis:_0x1a2224}=_0x496860,_0x506fe1=parseAxisParam(_0x1a2224,_0x546cd1[_0x37162a(0x50f)]);_0x506fe1['forEach'](_0x2f3e63=>{_0x1952ac[_0x2f3e63]=0x1;});const _0x4c404b=reshape(_0x5ddf29,_0x1952ac),_0x36e71c=mul(_0x4c404b,ones$1(_0x546cd1[_0x37162a(0x50f)],'float32'));return{'x':()=>_0x36e71c};}},tanGradConfig={'kernelName':Tan,'inputsToSave':['x'],'gradFunc':(_0x9a5406,_0x18a7ae)=>{const [_0x426a42]=_0x18a7ae;return{'x':()=>div(_0x9a5406,square(cos(_0x426a42)))};}},tanhGradConfig={'kernelName':Tanh,'outputsToSave':[!![]],'gradFunc':(_0x7dce40,_0x45ee87)=>{const [_0x4189e7]=_0x45ee87;return{'x':()=>mul(sub(scalar(0x1),square(_0x4189e7)),_0x7dce40)};}},tileGradConfig={'kernelName':Tile,'inputsToSave':['x'],'gradFunc':(_0x205f24,_0x1f04a5,_0x17f8fc)=>{const [_0xa0c1e3]=_0x1f04a5,{reps:_0x371d33}=_0x17f8fc,_0x3a3383=()=>{const _0x359294=a0_0x367f;let _0x5ad870=zerosLike(_0xa0c1e3);if(_0xa0c1e3[_0x359294(0x36e)]===0x1)for(let _0x1468bc=0x0;_0x1468bc<_0x371d33[0x0];++_0x1468bc){_0x5ad870=add$1(_0x5ad870,slice(_0x205f24,[_0x1468bc*_0xa0c1e3[_0x359294(0x50f)][0x0]],[_0xa0c1e3[_0x359294(0x50f)][0x0]]));}else{if(_0xa0c1e3[_0x359294(0x36e)]===0x2)for(let _0x3c2ba4=0x0;_0x3c2ba4<_0x371d33[0x0];++_0x3c2ba4){for(let _0x4d26a7=0x0;_0x4d26a7<_0x371d33[0x1];++_0x4d26a7){_0x5ad870=add$1(_0x5ad870,slice(_0x205f24,[_0x3c2ba4*_0xa0c1e3[_0x359294(0x50f)][0x0],_0x4d26a7*_0xa0c1e3['shape'][0x1]],[_0xa0c1e3[_0x359294(0x50f)][0x0],_0xa0c1e3[_0x359294(0x50f)][0x1]]));}}else{if(_0xa0c1e3['rank']===0x3)for(let _0x5ccd9b=0x0;_0x5ccd9b<_0x371d33[0x0];++_0x5ccd9b){for(let _0x3afa6e=0x0;_0x3afa6e<_0x371d33[0x1];++_0x3afa6e){for(let _0x5640e3=0x0;_0x5640e3<_0x371d33[0x2];++_0x5640e3){_0x5ad870=add$1(_0x5ad870,slice(_0x205f24,[_0x5ccd9b*_0xa0c1e3[_0x359294(0x50f)][0x0],_0x3afa6e*_0xa0c1e3['shape'][0x1],_0x5640e3*_0xa0c1e3[_0x359294(0x50f)][0x2]],[_0xa0c1e3['shape'][0x0],_0xa0c1e3['shape'][0x1],_0xa0c1e3[_0x359294(0x50f)][0x2]]));}}}else{if(_0xa0c1e3[_0x359294(0x36e)]===0x4)for(let _0x1e8f7b=0x0;_0x1e8f7b<_0x371d33[0x0];++_0x1e8f7b){for(let _0x5c6475=0x0;_0x5c6475<_0x371d33[0x1];++_0x5c6475){for(let _0xa36fee=0x0;_0xa36fee<_0x371d33[0x2];++_0xa36fee){for(let _0x5586a6=0x0;_0x5586a6<_0x371d33[0x3];++_0x5586a6){_0x5ad870=add$1(_0x5ad870,slice(_0x205f24,[_0x1e8f7b*_0xa0c1e3[_0x359294(0x50f)][0x0],_0x5c6475*_0xa0c1e3[_0x359294(0x50f)][0x1],_0xa36fee*_0xa0c1e3['shape'][0x2],_0x5586a6*_0xa0c1e3['shape'][0x3]],[_0xa0c1e3[_0x359294(0x50f)][0x0],_0xa0c1e3[_0x359294(0x50f)][0x1],_0xa0c1e3[_0x359294(0x50f)][0x2],_0xa0c1e3['shape'][0x3]]));}}}}else throw new Error(_0x359294(0x1ac)+(_0xa0c1e3['rank']+_0x359294(0x486)));}}}return _0x5ad870;};return{'x':_0x3a3383};}},transposeGradConfig={'kernelName':Transpose,'gradFunc':(_0x388787,_0x3d375b,_0x37bfa0)=>{const _0x3029b0=_0x37bfa0,{perm:_0x1cbe37}=_0x3029b0,_0x8b4ea9=getUndoAxesPermutation(_0x1cbe37);return{'x':()=>transpose(_0x388787,_0x8b4ea9)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function stack_(_0x29e95d,_0x460f2b=0x0){const _0x5ea5a1=a0_0x20018c,_0x4d19e4=convertToTensorArray(_0x29e95d,_0x5ea5a1(0x2d5),_0x5ea5a1(0x30e),_0x5ea5a1(0x5c4));assert(_0x4d19e4[_0x5ea5a1(0x104)]>=0x1,()=>'Pass\x20at\x20least\x20one\x20tensor\x20to\x20tf.stack');_0x4d19e4['length']>0x0&&assert(_0x460f2b<=_0x4d19e4[0x0][_0x5ea5a1(0x36e)],()=>_0x5ea5a1(0x332));const _0x49e0fb=_0x4d19e4,_0x54f65c={'axis':_0x460f2b};return ENGINE[_0x5ea5a1(0x397)](Pack,_0x49e0fb,_0x54f65c);}const stack=op({'stack_':stack_}),unpackGradConfig={'kernelName':Unpack,'gradFunc':(_0x2b94fa,_0x2aa1b1,_0x490432)=>{const _0x2ba31d=_0x490432,{axis:_0x386e70}=_0x2ba31d;return{'value':()=>stack(_0x2b94fa,_0x386e70)};}};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function expandDims_(_0x812dc,_0x6f0164=0x0){const _0x234438=a0_0x20018c,_0x41fe1c=convertToTensor(_0x812dc,'x',_0x234438(0x54c),'string_or_numeric');assert(_0x6f0164<=_0x41fe1c[_0x234438(0x36e)],()=>_0x234438(0x332));const _0x3b9a79={'input':_0x41fe1c},_0x377a3c={'dim':_0x6f0164};return ENGINE[_0x234438(0x397)](ExpandDims,_0x3b9a79,_0x377a3c);}const expandDims=op({'expandDims_':expandDims_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function gather_(_0x28cb25,_0xd7a8dc,_0x3ba52c=0x0,_0xb9d028=0x0){const _0x38628b=a0_0x20018c,_0x17b39a=convertToTensor(_0x28cb25,'x','gather'),_0x308c6a=convertToTensor(_0xd7a8dc,_0x38628b(0x402),_0x38628b(0x400),_0x38628b(0x4d1)),_0x171121={'x':_0x17b39a,'indices':_0x308c6a},_0x4376e1={'axis':_0x3ba52c,'batchDims':_0xb9d028};return ENGINE[_0x38628b(0x397)](GatherV2,_0x171121,_0x4376e1);}const gather=op({'gather_':gather_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function maximum_(_0x7f1e7e,_0x57ee90){const _0x33e69d=a0_0x20018c;let _0x1604b3=convertToTensor(_0x7f1e7e,'a',_0x33e69d(0x38c)),_0x29e9d9=convertToTensor(_0x57ee90,'b',_0x33e69d(0x38c));[_0x1604b3,_0x29e9d9]=makeTypesMatch(_0x1604b3,_0x29e9d9);_0x1604b3[_0x33e69d(0x51c)]==='bool'&&(_0x1604b3=cast(_0x1604b3,_0x33e69d(0x4d1)),_0x29e9d9=cast(_0x29e9d9,_0x33e69d(0x4d1)));assertAndGetBroadcastShape(_0x1604b3[_0x33e69d(0x50f)],_0x29e9d9[_0x33e69d(0x50f)]);const _0x29a2ca={'a':_0x1604b3,'b':_0x29e9d9};return ENGINE[_0x33e69d(0x397)](Maximum,_0x29a2ca);}const maximum=op({'maximum_':maximum_}),unsortedSegmentSumGradConfig={'kernelName':UnsortedSegmentSum,'inputsToSave':[a0_0x20018c(0x157)],'gradFunc':(_0x217765,_0x6cf8bd)=>{const [_0x5445d5]=_0x6cf8bd,_0x35f5ef=()=>{return gatherDropNegatives(_0x217765,_0x5445d5);};return{'x':_0x35f5ef};}};function gatherDropNegatives(_0x1a9041,_0x5c1dd8){const _0x1a5d69=a0_0x20018c,_0x1a3b78=maximum(_0x5c1dd8,zerosLike(_0x5c1dd8)),_0x39142e=gather(_0x1a9041,_0x1a3b78);let _0x32c545=greaterEqual(_0x5c1dd8,scalar(0x0,_0x1a5d69(0x4d1)));const _0x2d688f=_0x39142e['rank']-_0x32c545[_0x1a5d69(0x36e)];for(let _0x3aa9dc=0x0;_0x3aa9dc<_0x2d688f;++_0x3aa9dc){_0x32c545=expandDims(_0x32c545,_0x3aa9dc+0x1);}_0x32c545=logicalAnd(_0x32c545,ones$1(_0x39142e[_0x1a5d69(0x50f)],_0x1a5d69(0x188)));const _0x8f6827=zerosLike(_0x39142e);return where(_0x32c545,_0x39142e,_0x8f6827);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const zerosLikeGradConfig={'kernelName':ZerosLike,'gradFunc':_0x3808d9=>{return{'x':()=>zerosLike(_0x3808d9)};}},gradConfigs=[absGradConfig,acosGradConfig,acoshGradConfig,addGradConfig,addNGradConfig,argMaxGradConfig,argMinGradConfig,asinGradConfig,asinhGradConfig,atan2GradConfig,atanGradConfig,atanhGradConfig,avgPool3DGradConfig,avgPoolGradConfig,batchMatMulGradConfig,batchToSpaceNDGradConfig,broadcastToGradConfig,castGradConfig,ceilGradConfig,clipByValueGradConfig,complexAbsGradConfig,concatGradConfig,conv2DBackpropInputGradConfig,conv2DGradConfig,conv3DGradConfig,cosGradConfig,coshGradConfig,cumsumGradConfig,depthwiseConv2dNativeGradConfig,dilation2dGradConfig,divGradConfig,eluGradConfig,erfGradConfig,expGradConfig,expandDimsGradConfig,expm1GradConfig,floorDivGradConfig,floorGradConfig,fusedBatchNormGradConfig,gatherGradConfig,greaterEqualGradConfig,identityGradConfig,isFiniteGradConfig,isInfGradConfig,isNanGradConfig,leakyReluGradConfig,log1pGradConfig,logGradConfig,logSoftmaxGradConfig,lrnGradConfig,maxGradConfig,maxGradConfig,maximumGradConfig,maxPool3DGradConfig,maxPoolGradConfig,meanGradConfig,minGradConfig,minimumGradConfig,mirrorPadGradConfig,modGradConfig,multiplyGradConfig,negGradConfig,oneHotGradConfig,onesLikeGradConfig,packGradConfig,padV2GradConfig,padV2GradConfig,powGradConfig,preluGradConfig,reciprocalGradConfig,relu6GradConfig,reluGradConfig,reshapeGradConfig,resizeBilinearGradConfig,resizeNearestNeighborGradConfig,reverseGradConfig,roundGradConfig,rsqrtGradConfig,selectGradConfig,seluGradConfig,sigmoidGradConfig,signGradConfig,sinGradConfig,sinhGradConfig,sliceGradConfig,softmaxGradConfig,softplusGradConfig,spaceToBatchNDGradConfig,spaceToBatchNDGradConfig,splitVGradConfig,splitVGradConfig,sqrtGradConfig,squaredDifferenceGradConfig,squareGradConfig,stepGradConfig,subGradConfig,sumGradConfig,tanGradConfig,tanhGradConfig,tileGradConfig,transposeGradConfig,unpackGradConfig,unsortedSegmentSumGradConfig,zerosLikeGradConfig];for(const gradientConfig of gradConfigs){registerGradient(gradientConfig);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function abs_(_0x216a8a){const _0x2a279c=a0_0x20018c,_0x157b2c=convertToTensor(_0x216a8a,'x',_0x2a279c(0x596));if(_0x157b2c['dtype']===_0x2a279c(0xe8)){const _0x37c7ae={'x':_0x157b2c};return ENGINE[_0x2a279c(0x397)](ComplexAbs,_0x37c7ae);}else{const _0x3b5d0b={'x':_0x157b2c};return ENGINE[_0x2a279c(0x397)](Abs,_0x3b5d0b);}}const abs=op({'abs_':abs_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function acos_(_0x153d0c){const _0x304b86=a0_0x20018c,_0xe38a01=convertToTensor(_0x153d0c,'x',_0x304b86(0x48c)),_0x2d1724={'x':_0xe38a01};return ENGINE[_0x304b86(0x397)](Acos,_0x2d1724);}const acos=op({'acos_':acos_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function acosh_(_0x281af8){const _0x448f92=a0_0x20018c,_0x498130=convertToTensor(_0x281af8,'x',_0x448f92(0x212)),_0x5934b4={'x':_0x498130};return ENGINE[_0x448f92(0x397)](Acosh,_0x5934b4);}const acosh=op({'acosh_':acosh_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function addN_(_0x9d0c9b){const _0x310ce8=a0_0x20018c;assert(Array[_0x310ce8(0x576)](_0x9d0c9b),()=>_0x310ce8(0x458)),assert(_0x9d0c9b[_0x310ce8(0x104)]>=0x1,()=>'Must\x20pass\x20at\x20least\x20one\x20tensor\x20to\x20tf.addN(),\x20but\x20got\x20'+(''+_0x9d0c9b[_0x310ce8(0x104)]));const _0x122cbb=_0x9d0c9b[_0x310ce8(0x3ab)]((_0x92bf81,_0x4d63da)=>convertToTensor(_0x92bf81,_0x310ce8(0x2d5)+_0x4d63da,_0x310ce8(0x425))),_0xbfb1e0=_0x122cbb[0x0];_0x122cbb[_0x310ce8(0x1e4)](_0xfe1fa6=>{const _0x3d0bb6=_0x310ce8;if(_0xfe1fa6[_0x3d0bb6(0x51c)]!==_0xbfb1e0[_0x3d0bb6(0x51c)])throw new Error(_0x3d0bb6(0x47e));}),_0x122cbb[_0x310ce8(0x1e4)](_0x49995d=>{const _0x555785=_0x310ce8;if(!arraysEqual(_0x49995d[_0x555785(0x50f)],_0xbfb1e0[_0x555785(0x50f)]))throw new Error(_0x555785(0x20b));});const _0x34f1a4=_0x122cbb;return ENGINE[_0x310ce8(0x397)](AddN,_0x34f1a4);}const addN=op({'addN_':addN_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function all_(_0x2ac38b,_0x4a6bdb=null,_0x4703c9=![]){const _0x250fde=a0_0x20018c,_0x20d726=convertToTensor(_0x2ac38b,'x','all',_0x250fde(0x188)),_0x17536c={'x':_0x20d726},_0x425ad7={'axis':_0x4a6bdb,'keepDims':_0x4703c9};return ENGINE[_0x250fde(0x397)](All,_0x17536c,_0x425ad7);}const all=op({'all_':all_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function any_(_0xe26b3f,_0x2bdb3e=null,_0x35bd4d=![]){const _0x175b6b=a0_0x20018c,_0x5eeb22=convertToTensor(_0xe26b3f,'x',_0x175b6b(0x322),_0x175b6b(0x188)),_0x37de00={'x':_0x5eeb22},_0x4995ed={'axis':_0x2bdb3e,'keepDims':_0x35bd4d};return ENGINE[_0x175b6b(0x397)](Any,_0x37de00,_0x4995ed);}const any=op({'any_':any_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function argMax_(_0x2c56ad,_0xcfabec=0x0){const _0x239b0f=a0_0x20018c,_0x10915a=convertToTensor(_0x2c56ad,'x',_0x239b0f(0x354)),_0x51b901={'x':_0x10915a},_0x8c212e={'axis':_0xcfabec};return ENGINE['runKernel'](ArgMax,_0x51b901,_0x8c212e);}const argMax=op({'argMax_':argMax_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function argMin_(_0x35bbe7,_0x43b131=0x0){const _0x1c4478=a0_0x20018c,_0xd78179=convertToTensor(_0x35bbe7,'x',_0x1c4478(0x1ef)),_0xdc397f={'x':_0xd78179},_0xb54e4e={'axis':_0x43b131};return ENGINE['runKernel'](ArgMin,_0xdc397f,_0xb54e4e);}const argMin=op({'argMin_':argMin_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function asin_(_0x305298){const _0x3d2f3c=a0_0x20018c,_0x23fd90=convertToTensor(_0x305298,'x',_0x3d2f3c(0x1a9)),_0x259358={'x':_0x23fd90};return ENGINE['runKernel'](Asin,_0x259358);}const asin=op({'asin_':asin_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function asinh_(_0x32d63e){const _0x14f2a2=a0_0x20018c,_0x511650=convertToTensor(_0x32d63e,'x',_0x14f2a2(0x4f0)),_0x371cb0={'x':_0x511650};return ENGINE[_0x14f2a2(0x397)](Asinh,_0x371cb0);}const asinh=op({'asinh_':asinh_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function atan_(_0x456ee1){const _0x39f3b0=a0_0x20018c,_0x2489d1=convertToTensor(_0x456ee1,'x',_0x39f3b0(0x3ba)),_0x321ac6={'x':_0x2489d1};return ENGINE[_0x39f3b0(0x397)](Atan,_0x321ac6);}const atan=op({'atan_':atan_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function atan2_(_0x557067,_0x461a3e){const _0x4203a2=a0_0x20018c;let _0x33ed9a=convertToTensor(_0x557067,'a','atan2'),_0x236dae=convertToTensor(_0x461a3e,'b',_0x4203a2(0x4fa));[_0x33ed9a,_0x236dae]=makeTypesMatch(_0x33ed9a,_0x236dae);const _0x4933ac={'a':_0x33ed9a,'b':_0x236dae};return ENGINE[_0x4203a2(0x397)](Atan2,_0x4933ac);}const atan2=op({'atan2_':atan2_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function atanh_(_0x2b62b0){const _0x5d0aec=a0_0x20018c,_0x598bf6=convertToTensor(_0x2b62b0,'x',_0x5d0aec(0x49c)),_0x3dfbd6={'x':_0x598bf6};return ENGINE['runKernel'](Atanh,_0x3dfbd6);}const atanh=op({'atanh_':atanh_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function avgPool_(_0x582753,_0x1238d2,_0x3b4a2f,_0xcd4300,_0x3eb840){const _0x5f4d88=a0_0x20018c,_0x4d5d79=convertToTensor(_0x582753,'x',_0x5f4d88(0x4a1),_0x5f4d88(0x28b)),_0xc5a130=0x1;assert(eitherStridesOrDilationsAreOne(_0x3b4a2f,_0xc5a130),()=>'Error\x20in\x20avgPool:\x20Either\x20strides\x20or\x20dilations\x20must\x20be\x201.\x20'+(_0x5f4d88(0x54f)+_0x3b4a2f+'\x20and\x20dilations\x20\x27'+_0xc5a130+'\x27'));let _0x1e1441=_0x4d5d79,_0x31221b=![];_0x4d5d79[_0x5f4d88(0x36e)]===0x3&&(_0x31221b=!![],_0x1e1441=reshape(_0x4d5d79,[0x1,_0x4d5d79[_0x5f4d88(0x50f)][0x0],_0x4d5d79[_0x5f4d88(0x50f)][0x1],_0x4d5d79[_0x5f4d88(0x50f)][0x2]]));assert(_0x1e1441[_0x5f4d88(0x36e)]===0x4,()=>_0x5f4d88(0x31c)+_0x1e1441[_0x5f4d88(0x36e)]+'.');_0x3eb840!=null&&assert(isInt(_0xcd4300),()=>'Error\x20in\x20avgPool:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20'+(_0x5f4d88(0x51f)+_0x3eb840+'\x20but\x20got\x20pad\x20'+_0xcd4300+'.'));const _0x421b6e={'x':_0x1e1441},_0xa201e8={'filterSize':_0x1238d2,'strides':_0x3b4a2f,'pad':_0xcd4300,'dimRoundingMode':_0x3eb840};let _0x5bb477=ENGINE[_0x5f4d88(0x397)](AvgPool,_0x421b6e,_0xa201e8);_0x5bb477=cast(_0x5bb477,_0x4d5d79[_0x5f4d88(0x51c)]);if(_0x31221b)return reshape(_0x5bb477,[_0x5bb477[_0x5f4d88(0x50f)][0x1],_0x5bb477[_0x5f4d88(0x50f)][0x2],_0x5bb477[_0x5f4d88(0x50f)][0x3]]);return _0x5bb477;}const avgPool=op({'avgPool_':avgPool_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function avgPool3d_(_0x23f46e,_0x7355f4,_0x52c89a,_0x4e04cb,_0xbee009,_0x69e355=a0_0x20018c(0x454)){const _0x7b5c9e=a0_0x20018c,_0x21b7b5=convertToTensor(_0x23f46e,'x',_0x7b5c9e(0x259),_0x7b5c9e(0x28b));let _0x426734=_0x21b7b5,_0x2b3055=![];_0x21b7b5[_0x7b5c9e(0x36e)]===0x4&&(_0x2b3055=!![],_0x426734=reshape(_0x21b7b5,[0x1,_0x21b7b5['shape'][0x0],_0x21b7b5[_0x7b5c9e(0x50f)][0x1],_0x21b7b5[_0x7b5c9e(0x50f)][0x2],_0x21b7b5[_0x7b5c9e(0x50f)][0x3]]));assert(_0x426734[_0x7b5c9e(0x36e)]===0x5,()=>_0x7b5c9e(0x296)+_0x426734[_0x7b5c9e(0x36e)]+'.'),assert(_0x69e355===_0x7b5c9e(0x454),()=>_0x7b5c9e(0x27c)+(_0x7b5c9e(0x4b8)+_0x69e355));_0xbee009!=null&&assert(isInt(_0x4e04cb),()=>_0x7b5c9e(0x292)+(_0x7b5c9e(0x51f)+_0xbee009+_0x7b5c9e(0x27d)+_0x4e04cb+'.'));const _0x116a3b={'x':_0x426734},_0x2145c2={'filterSize':_0x7355f4,'strides':_0x52c89a,'pad':_0x4e04cb,'dimRoundingMode':_0xbee009,'dataFormat':_0x69e355};let _0x5c0f59=ENGINE[_0x7b5c9e(0x397)](AvgPool3D,_0x116a3b,_0x2145c2);_0x5c0f59=cast(_0x5c0f59,_0x426734[_0x7b5c9e(0x51c)]);if(_0x2b3055)return reshape(_0x5c0f59,[_0x5c0f59[_0x7b5c9e(0x50f)][0x1],_0x5c0f59[_0x7b5c9e(0x50f)][0x2],_0x5c0f59['shape'][0x3],_0x5c0f59[_0x7b5c9e(0x50f)][0x4]]);return _0x5c0f59;}const avgPool3d=op({'avgPool3d_':avgPool3d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tanh_(_0x388df6){const _0x533490=a0_0x20018c,_0xda4e3e=convertToTensor(_0x388df6,'x',_0x533490(0x564)),_0x18513a={'x':_0xda4e3e};return ENGINE['runKernel'](Tanh,_0x18513a);}const tanh$1=op({'tanh_':tanh_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function basicLSTMCell_(_0x261e1d,_0x57c096,_0x291e2d,_0x1056ea,_0x48b233,_0x3ea84e){const _0xa7d7be=a0_0x20018c,_0x503aff=convertToTensor(_0x261e1d,_0xa7d7be(0x36d),_0xa7d7be(0x554)),_0x5d6ee6=convertToTensor(_0x57c096,_0xa7d7be(0x142),_0xa7d7be(0x554)),_0x497526=convertToTensor(_0x291e2d,_0xa7d7be(0x10c),_0xa7d7be(0x554)),_0x29c65e=convertToTensor(_0x1056ea,_0xa7d7be(0x186),_0xa7d7be(0x554)),_0x5de6e1=convertToTensor(_0x48b233,'c',_0xa7d7be(0x554)),_0x407c70=convertToTensor(_0x3ea84e,'h',_0xa7d7be(0x554)),_0x7f9208=concat([_0x29c65e,_0x407c70],0x1),_0x64fadb=matMul(_0x7f9208,_0x5d6ee6),_0x41ee81=add$1(_0x64fadb,_0x497526),_0x5bcd9e=_0x41ee81['shape'][0x0],_0x4b087b=_0x41ee81[_0xa7d7be(0x50f)][0x1]/0x4,_0xccc621=[_0x5bcd9e,_0x4b087b],_0x2cce39=slice(_0x41ee81,[0x0,0x0],_0xccc621),_0x1b91f2=slice(_0x41ee81,[0x0,_0x4b087b],_0xccc621),_0xcd096c=slice(_0x41ee81,[0x0,_0x4b087b*0x2],_0xccc621),_0x335aa2=slice(_0x41ee81,[0x0,_0x4b087b*0x3],_0xccc621),_0x393227=add$1(mul(sigmoid(_0x2cce39),tanh$1(_0x1b91f2)),mul(_0x5de6e1,sigmoid(add$1(_0x503aff,_0xcd096c)))),_0x408894=mul(tanh$1(_0x393227),sigmoid(_0x335aa2));return[_0x393227,_0x408894];}const basicLSTMCell=op({'basicLSTMCell_':basicLSTMCell_});function xAs4D(_0x5d9d07){const _0x14f632=a0_0x20018c;let _0x194acf;if(_0x5d9d07['rank']===0x0||_0x5d9d07['rank']===0x1)_0x194acf=reshape(_0x5d9d07,[0x1,0x1,0x1,_0x5d9d07['size']]);else{if(_0x5d9d07['rank']===0x2)_0x194acf=reshape(_0x5d9d07,[0x1,0x1,_0x5d9d07[_0x14f632(0x50f)][0x0],_0x5d9d07[_0x14f632(0x50f)][0x1]]);else _0x5d9d07[_0x14f632(0x36e)]===0x3?_0x194acf=reshape(_0x5d9d07,[0x1,_0x5d9d07[_0x14f632(0x50f)][0x0],_0x5d9d07[_0x14f632(0x50f)][0x1],_0x5d9d07[_0x14f632(0x50f)][0x2]]):_0x194acf=_0x5d9d07;}return _0x194acf;}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function batchNorm_(_0x7d06ad,_0x4f47c6,_0x2be845,_0x4aa2fc,_0x12d04e,_0x23665e){const _0x443ce7=a0_0x20018c;_0x23665e==null&&(_0x23665e=0.001);const _0x276f45=convertToTensor(_0x7d06ad,'x','batchNorm'),_0x15cb42=convertToTensor(_0x4f47c6,_0x443ce7(0x51e),'batchNorm'),_0x56003c=convertToTensor(_0x2be845,_0x443ce7(0x3e2),_0x443ce7(0x316));let _0x950849;_0x12d04e!=null&&(_0x950849=convertToTensor(_0x12d04e,_0x443ce7(0x5b4),'batchNorm'));let _0x2405c2;_0x4aa2fc!=null&&(_0x2405c2=convertToTensor(_0x4aa2fc,'offset',_0x443ce7(0x316)));assert(_0x15cb42[_0x443ce7(0x36e)]===_0x56003c['rank'],()=>'Batch\x20normalization\x20gradient\x20requires\x20mean\x20and\x20variance\x20to\x20have\x20'+'equal\x20ranks.'),assert(_0x2405c2==null||_0x15cb42[_0x443ce7(0x36e)]===_0x2405c2[_0x443ce7(0x36e)],()=>_0x443ce7(0x39a)+_0x443ce7(0x500)),assert(_0x950849==null||_0x15cb42[_0x443ce7(0x36e)]===_0x950849[_0x443ce7(0x36e)],()=>_0x443ce7(0x388)+_0x443ce7(0x500));const _0x45496a=xAs4D(_0x276f45),_0x4ab938={'x':_0x45496a,'scale':_0x950849,'offset':_0x2405c2,'mean':_0x15cb42,'variance':_0x56003c},_0x266bf7={'varianceEpsilon':_0x23665e},_0x165792=ENGINE[_0x443ce7(0x397)](FusedBatchNorm,_0x4ab938,_0x266bf7);return reshape(_0x165792,_0x276f45[_0x443ce7(0x50f)]);}const batchNorm=op({'batchNorm_':batchNorm_});function batchNorm2d_(_0x499624,_0x9c2de2,_0x38020e,_0x292454,_0xe8b534,_0x107c4e){const _0x437e9e=a0_0x20018c,_0x12aed4=convertToTensor(_0x499624,'x',_0x437e9e(0x316)),_0x4b2a76=convertToTensor(_0x9c2de2,'mean','batchNorm'),_0x5e808a=convertToTensor(_0x38020e,_0x437e9e(0x3e2),_0x437e9e(0x316));let _0x31243a;_0xe8b534!=null&&(_0x31243a=convertToTensor(_0xe8b534,_0x437e9e(0x5b4),'batchNorm'));let _0x4f442d;return _0x292454!=null&&(_0x4f442d=convertToTensor(_0x292454,'offset',_0x437e9e(0x316))),assert(_0x12aed4['rank']===0x2,()=>_0x437e9e(0x3e0)+(_0x12aed4[_0x437e9e(0x36e)]+'.')),assert(_0x4b2a76[_0x437e9e(0x36e)]===0x2||_0x4b2a76[_0x437e9e(0x36e)]===0x1,()=>_0x437e9e(0x275)+(_0x437e9e(0x4ff)+_0x4b2a76[_0x437e9e(0x36e)]+'.')),assert(_0x5e808a[_0x437e9e(0x36e)]===0x2||_0x5e808a[_0x437e9e(0x36e)]===0x1,()=>_0x437e9e(0x39d)+(_0x437e9e(0x283)+_0x5e808a[_0x437e9e(0x36e)]+'.')),_0x31243a!=null&&assert(_0x31243a[_0x437e9e(0x36e)]===0x2||_0x31243a[_0x437e9e(0x36e)]===0x1,()=>_0x437e9e(0x470)+(_0x437e9e(0x283)+_0x31243a[_0x437e9e(0x36e)]+'.')),_0x4f442d!=null&&assert(_0x4f442d['rank']===0x2||_0x4f442d[_0x437e9e(0x36e)]===0x1,()=>'Error\x20in\x20batchNorm2D:\x20offset\x20must\x20be\x20rank\x202\x20or\x20rank\x201\x20'+(_0x437e9e(0x283)+_0x4f442d[_0x437e9e(0x36e)]+'.')),batchNorm(_0x12aed4,_0x4b2a76,_0x5e808a,_0x4f442d,_0x31243a,_0x107c4e);}const batchNorm2d=op({'batchNorm2d_':batchNorm2d_});function batchNorm3d_(_0x12e663,_0x534e49,_0x27c065,_0x4a3a53,_0x58c574,_0x510c91){const _0x2eabad=a0_0x20018c,_0x246bbb=convertToTensor(_0x12e663,'x','batchNorm'),_0x50b09d=convertToTensor(_0x534e49,_0x2eabad(0x51e),_0x2eabad(0x316)),_0xd2fe20=convertToTensor(_0x27c065,'variance','batchNorm');let _0xe39d54;_0x58c574!=null&&(_0xe39d54=convertToTensor(_0x58c574,'scale',_0x2eabad(0x316)));let _0x1f313f;return _0x4a3a53!=null&&(_0x1f313f=convertToTensor(_0x4a3a53,'offset','batchNorm')),assert(_0x246bbb['rank']===0x3,()=>_0x2eabad(0x581)+(_0x246bbb[_0x2eabad(0x36e)]+'.')),assert(_0x50b09d['rank']===0x3||_0x50b09d[_0x2eabad(0x36e)]===0x1,()=>_0x2eabad(0x571)+(_0x2eabad(0x4ff)+_0x50b09d[_0x2eabad(0x36e)]+'.')),assert(_0xd2fe20[_0x2eabad(0x36e)]===0x3||_0xd2fe20['rank']===0x1,()=>_0x2eabad(0x48b)+(_0x2eabad(0x283)+_0xd2fe20[_0x2eabad(0x36e)]+'.')),_0xe39d54!=null&&assert(_0xe39d54[_0x2eabad(0x36e)]===0x3||_0xe39d54[_0x2eabad(0x36e)]===0x1,()=>_0x2eabad(0x597)+('but\x20got\x20rank\x20'+_0xe39d54['rank']+'.')),_0x1f313f!=null&&assert(_0x1f313f[_0x2eabad(0x36e)]===0x3||_0x1f313f[_0x2eabad(0x36e)]===0x1,()=>_0x2eabad(0x201)+(_0x2eabad(0x283)+_0x1f313f['rank']+'.')),batchNorm(_0x246bbb,_0x50b09d,_0xd2fe20,_0x1f313f,_0xe39d54,_0x510c91);}const batchNorm3d=op({'batchNorm3d_':batchNorm3d_});function batchNorm4d_(_0x50b77c,_0x4ebfc6,_0x87f09a,_0x4a8d4d,_0x1a2ca4,_0x1bf80f){const _0x57deb2=a0_0x20018c,_0x13cef8=convertToTensor(_0x50b77c,'x',_0x57deb2(0x316)),_0x3f36a3=convertToTensor(_0x4ebfc6,_0x57deb2(0x51e),_0x57deb2(0x316)),_0x4e4da8=convertToTensor(_0x87f09a,_0x57deb2(0x3e2),_0x57deb2(0x316));let _0x56f06e;_0x1a2ca4!=null&&(_0x56f06e=convertToTensor(_0x1a2ca4,'scale',_0x57deb2(0x316)));let _0x3e6454;return _0x4a8d4d!=null&&(_0x3e6454=convertToTensor(_0x4a8d4d,_0x57deb2(0x45f),_0x57deb2(0x316))),assert(_0x13cef8['rank']===0x4,()=>_0x57deb2(0x10f)+(_0x13cef8['rank']+'.')),assert(_0x3f36a3[_0x57deb2(0x36e)]===0x4||_0x3f36a3[_0x57deb2(0x36e)]===0x1,()=>_0x57deb2(0x575)+(_0x57deb2(0x4ff)+_0x3f36a3[_0x57deb2(0x36e)]+'.')),assert(_0x4e4da8[_0x57deb2(0x36e)]===0x4||_0x4e4da8[_0x57deb2(0x36e)]===0x1,()=>_0x57deb2(0x10e)+('but\x20got\x20rank\x20'+_0x4e4da8[_0x57deb2(0x36e)]+'.')),_0x56f06e!=null&&assert(_0x56f06e['rank']===0x4||_0x56f06e[_0x57deb2(0x36e)]===0x1,()=>'Error\x20in\x20batchNorm4D:\x20scale\x20must\x20be\x20rank\x204\x20or\x20rank\x201\x20'+(_0x57deb2(0x283)+_0x56f06e[_0x57deb2(0x36e)]+'.')),_0x3e6454!=null&&assert(_0x3e6454[_0x57deb2(0x36e)]===0x4||_0x3e6454[_0x57deb2(0x36e)]===0x1,()=>'Error\x20in\x20batchNorm4D:\x20offset\x20must\x20be\x20rank\x204\x20or\x20rank\x201\x20'+(_0x57deb2(0x283)+_0x3e6454[_0x57deb2(0x36e)]+'.')),batchNorm(_0x13cef8,_0x3f36a3,_0x4e4da8,_0x3e6454,_0x56f06e,_0x1bf80f);}const batchNorm4d=op({'batchNorm4d_':batchNorm4d_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function bincount_(_0x4148e6,_0x1bb4dc,_0x5db2cb){const _0x15cd6d=a0_0x20018c,_0x5297b8=convertToTensor(_0x4148e6,'x','bincount'),_0x40301a=convertToTensor(_0x1bb4dc,_0x15cd6d(0x5d6),'bincount');assert(_0x5297b8['dtype']===_0x15cd6d(0x4d1),()=>'Error\x20in\x20bincount:\x20input\x20'+(_0x15cd6d(0x4d6)+_0x5297b8[_0x15cd6d(0x51c)])),assert(_0x5db2cb>=0x0,()=>_0x15cd6d(0x282)+_0x5db2cb+'.'),assert(_0x40301a['size']===_0x5297b8['size']||_0x40301a['size']===0x0,()=>'Error\x20in\x20bincount:\x20weights\x20must\x20have\x20the\x20same\x20size\x20as\x20input\x20or'+(_0x15cd6d(0x4bc)+_0x5297b8[_0x15cd6d(0x50f)]+',\x20weights\x20shape:\x20')+(_0x40301a[_0x15cd6d(0x50f)]+'.'));const _0x10f0b5={'x':_0x5297b8,'weights':_0x40301a},_0x41e192={'size':_0x5db2cb};return ENGINE[_0x15cd6d(0x397)](Bincount,_0x10f0b5,_0x41e192);}const bincount=op({'bincount_':bincount_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function broadcastArgs_(_0x51e197,_0x30eb34){const _0x3b0942=a0_0x20018c,_0xa4fa63=convertToTensor(_0x51e197,'s0',_0x3b0942(0x3d8),_0x3b0942(0x4d1)),_0x3b5305=convertToTensor(_0x30eb34,'s1',_0x3b0942(0x3d8),_0x3b0942(0x4d1));if(_0xa4fa63[_0x3b0942(0x36e)]!==0x1)throw new Error(_0x3b0942(0x45a)+('Has\x20rank\x20'+_0xa4fa63[_0x3b0942(0x36e)]));if(_0x3b5305[_0x3b0942(0x36e)]!==0x1)throw new Error(_0x3b0942(0x511)+('Has\x20rank\x20'+_0x3b5305[_0x3b0942(0x36e)]));const _0x565e19={'s0':_0xa4fa63,'s1':_0x3b5305};return ENGINE[_0x3b0942(0x397)](BroadcastArgs,_0x565e19);}const broadcastArgs=op({'broadcastArgs_':broadcastArgs_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function buffer(_0x27a1df,_0x744d99=a0_0x20018c(0x28b),_0x47d5b0){const _0x2f08eb=a0_0x20018c;return _0x744d99=_0x744d99||_0x2f08eb(0x28b),assertNonNegativeIntegerDimensions(_0x27a1df),new TensorBuffer(_0x27a1df,_0x744d99,_0x47d5b0);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function ceil_(_0x35b517){const _0x4d9723=a0_0x20018c,_0x4016fe=convertToTensor(_0x35b517,'x','ceil'),_0xee7f02={'x':_0x4016fe};return ENGINE[_0x4d9723(0x397)](Ceil,_0xee7f02);}const ceil=op({'ceil_':ceil_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function clipByValue_(_0x1c00ff,_0x1ed473,_0x4a09b8){const _0x162eaa=a0_0x20018c,_0x141614=convertToTensor(_0x1c00ff,'x',_0x162eaa(0x11d));assert(_0x1ed473<=_0x4a09b8,()=>_0x162eaa(0x279)+_0x1ed473+_0x162eaa(0x24b)+(_0x162eaa(0x4dd)+_0x4a09b8+').'));const _0xdd96ef={'x':_0x141614},_0x6f341f={'clipValueMin':_0x1ed473,'clipValueMax':_0x4a09b8};return ENGINE['runKernel'](ClipByValue,_0xdd96ef,_0x6f341f);}const clipByValue=op({'clipByValue_':clipByValue_});function concat1d_(_0x8be97){return concat(_0x8be97,0x0);}const concat1d=op({'concat1d_':concat1d_});function concat2d_(_0x39c491,_0x5a1d2){return concat(_0x39c491,_0x5a1d2);}const concat2d=op({'concat2d_':concat2d_});function concat3d_(_0x127e2c,_0x440165){return concat(_0x127e2c,_0x440165);}const concat3d=op({'concat3d_':concat3d_});function a0_0x8a45(){const _0x53e12d=['Acos','Softmax','DepthToSpace','Based\x20on\x20the\x20provided\x20shape,\x20[','Error\x20in\x20conv2dDerInput:\x20depth\x20of\x20input\x20(','The\x20f\x20passed\x20in\x20customGrad(f)\x20must\x20be\x20a\x20function.','Error\x20in\x20batchNorm3D:\x20mean\x20must\x20be\x20rank\x203\x20or\x20rank\x201\x20but\x20','The\x20dy\x20passed\x20in\x20valueAndGrads(f)(args,\x20dy)\x20must\x20be\x20a\x20tensor','logger','softNmsSigma\x20must\x20be\x20in\x20[0,\x201],\x20but\x20was\x20\x27','Error\x20in\x20batchNorm4D:\x20mean\x20must\x20be\x20rank\x204\x20or\x20rank\x201\x20but\x20','isArray','ComplexAbs','unshift','The\x20difference\x20between\x20','Rank\x20of\x20input\x20(','Error\x20in\x20conv2dDerFilter:\x20dy\x20must\x20be\x20rank\x204,\x20but\x20got\x20shape\x20','exp','dilationWidth','kernelTimeMs','Sqrt','kernels','Error\x20in\x20batchNorm3D:\x20x\x20must\x20be\x20rank\x203\x20but\x20got\x20rank\x20','flagRegistry','The\x20f\x20passed\x20in\x20valueAndGrad(f)\x20must\x20be\x20a\x20function','xor128','\x20must\x20not\x20be\x20greater\x20than\x20the\x20number\x20of\x20rows\x20(','keys','least\x202,\x20got\x20ranks\x20','Error\x20in\x20maxPool:\x20input\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','real\x20and\x20imag\x20shapes,\x20','match\x20the\x20rank\x20(','min','ResizeNearestNeighborGrad','conv3dTranspose','Error\x20in\x20norm:\x20invalid\x20ord\x20value:\x20','Equal','First\x20array\x20length\x20was\x20','fused\x20matMul','boxIndex','leakyRelu','write','refCount','abs','Error\x20in\x20batchNorm3D:\x20scale\x20must\x20be\x20rank\x203\x20or\x20rank\x201\x20','Shape\x20mismatch\x20in\x20v\x20and\x20x','inputsToSave','range','utf-8','D:\x20Length\x20of\x20begin\x20','charCodeAt','ResizeBilinearGrad','as5D','relu6','\x27k\x27\x20passed\x20to\x20topk()\x20must\x20be\x20>=\x200\x20but\x20got\x20','\x20cannot\x20be\x20synchronously\x20evaluated.\x20','backendInstance','Data\x20should\x20be\x20at\x20least\x201\x20dimensional\x20but\x20received\x20scalar','DenseBincount','set','runKernelFunc','decode','removeBackend','newTensors','input\x20spatial\x20dimensions\x20','\x20must\x20be\x20equal\x20to\x20[blockShape]\x20','channels\x20(','call','xorwow','depthToSpace','huberLoss','but\x20got\x20','labels','scale','rank\x20','\x20<=\x201\x20and\x20dtype\x20is\x20not\x20float',')\x20does\x20not\x20match\x20rank\x20of\x20dy\x20(','registry','logits','Tan','version_cpu','prelu\x20weights','saveAllInputs','Error\x20in\x20conv2dDerFilter:\x20depth\x20of\x20input\x20',']\x20cannot\x20be\x20broadcast\x20to\x20[','Array\x20sizes\x20must\x20match\x20to\x20be\x20shuffled\x20together\x20','Atan2','canReturnFloat','SparseReshape','string_or_numeric','nextVal','Error\x20in\x20conv2dDerInput:\x20filter\x20must\x20be\x20rank\x204,\x20but\x20got\x20','Error\x20in\x20conv3dDerInput:\x20dy\x20must\x20be\x20rank\x205,\x20but\x20got\x20','MaxPool3D','message','valid','Error\x20in\x20reverse3D:\x20x\x20must\x20be\x20rank\x203\x20but\x20got\x20rank\x20','kernelDepth','Please\x20provide\x20an\x20object\x20with\x20a\x20single\x20key\x20','The\x20shape\x20of\x20dy\x20passed\x20in\x20valueAndGrads(f)([x1,...],\x20dy)\x20must\x20','string','Bincount','tensor6d()\x20requires\x20shape\x20to\x20be\x20provided\x20when\x20`values`\x20','Error\x20in\x20maxPoolGrad:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','LogicalAnd','unnamed\x20scope','time','weights','pow','softmax','forward','addTapeNode','bandPart():\x20Rank\x20must\x20be\x20at\x20least\x202,\x20got\x20','_tfGlobals','hasOwnProperty','All','assign','indexToLoc',']\x20+\x20size[','an\x20array\x20of\x20numbers/booleans/strings,\x20or\x20a\x20TypedArray','.\x20The\x20gradient\x20of\x20input\x20','complex64','NotEqual','gradFunc','Expected\x20dtype\x20cannot\x20be\x20null.','must\x20match\x20in\x20call\x20to\x20tf.complex().','All\x20entries\x20in\x20\x27perm\x27\x20must\x20be\x20between\x200\x20and\x20','endScope','pointwiseFilter','Please\x20use\x20getAsync()\x20instead.','squeeze','long','Tensor','Actual:\x20\x20\x20','_FusedMatMul','207OpAypl','The\x20dtype\x20for\x20tf.spectral.fft()\x20must\x20be\x20complex64\x20','Argument\x20','selu','FusedConv2D','Error\x20in\x20gradient\x20of\x20fused\x20depthwiseConv2d:\x20dilation\x20rates\x20','tensor3d()\x20requires\x20values\x20to\x20be\x20number[][][]\x20or\x20flat/TypedArray','div','Conv3DBackpropFilterV2','Overwriting\x20the\x20platform\x20with\x20','profiler','disposeTensor',')\x20must\x20','notEqual','length','arraySync','sqrt','\x20===\x20','global','When\x20calling\x20with\x20two\x20arguments,\x20the\x202nd\x20argument\x20','FusedDepthwiseConv2D','mask\x20cannot\x20be\x20scalar','lstmBias','Cannot\x20return\x20a\x20Promise\x20inside\x20of\x20tidy.','Error\x20in\x20batchNorm4D:\x20variance\x20must\x20be\x20rank\x204\x20or\x20rank\x201\x20','Error\x20in\x20batchNorm4D:\x20x\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20',']\x20when\x20','ClipByValue','Error\x20in\x20maxPool3dGrad:\x20dy\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20','\x20for\x20flag\x20','Method\x20must\x20be\x20binary\x20or\x20otsu,\x20but\x20was\x20','gradient','dataMover','Error\x20in\x20grayscaleToRGB:\x20last\x20dimension\x20of\x20a\x20grayscale\x20image\x20','must\x20match\x20length\x20of\x20reps\x20','Error\x20in\x20oneHot:\x20depth\x20must\x20be\x20>=2,\x20but\x20it\x20is\x20','Error\x20in\x20fused\x20depthwiseConv2d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20','Kernel\x20\x27','isDisposed','clipByValue','isTapeOn','The\x20f\x20passed\x20in\x20grad(f)\x20must\x20be\x20a\x20function','Error\x20in\x20slice','channelsFirst','input\x20rank\x20','backwardsFunc','\x20but\x20only\x20NHWC\x20is\x20currently\x20supported.','depthwiseConv2d','Cannot\x20compute\x20gradient:\x20gradient\x20function\x20not\x20found\x20','Available\x20gradients\x20found:\x20','some','When\x20calling\x20with\x20two\x20arguments,\x20the\x20first\x20argument\x20','resolve','Error\x20in\x20separableConv2d:\x20the\x20first\x20dimension\x20of\x20pointwise\x20filter\x20','Log1p','reset','indexOf','Error\x20in\x20depthwiseConv2d:\x20input\x20must\x20be\x20rank\x204,\x20but\x20got\x20','object','to\x20tidy()\x20must\x20be\x20a\x20string','\x20failed','SplitV','Error\x20in\x20conv3d:\x20depth\x20of\x20input\x20(','rotateWithOffset','The\x20args\x20passed\x20in\x20customGrad(f)(x1,\x20x2,...)\x20must\x20all\x20be\x20','to\x20y.','greater\x20than\x201\x20are\x20not\x20yet\x20supported.\x20Got\x20dilations\x20','The\x20function\x20f\x20passed\x20in\x20customGrad(f)\x20must\x20return\x20an\x20','Error\x20in\x20cropAndResize:\x20boxes\x20must\x20be\x20have\x20size\x20[','repeat','Dense\x20shape\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x20','ScatterNd','Relu6','Dimension\x20size\x20must\x20be\x20evenly\x20divisible\x20by\x20','timerAvailable','1220VKuXRC','lstmKernel','alignCorners\x20must\x20be\x20false.','Any','\x27\x20not\x20found\x20in\x20registry','stringSplit','tile','StringNGrams','dtype\x20of\x20the\x20new\x20value\x20(','Softmax\x20cross\x20entropy\x20along\x20a\x20non-last\x20dimension\x20is\x20not\x20yet\x20','\x20since\x20its\x20dim\x20\x27','nextVariableId','Reusing\x20existing\x20backend\x20factory.','makeTensorFromDataId','Imag','\x20but\x20is\x20not\x20divisible\x20by\x20the\x20product\x20of\x20','backendNames','DepthwiseConv2dNative','DEBUG','Data\x20splits\x20must\x20be\x20of\x20datatype\x20int32','must\x20match\x20length\x20of\x20perm\x20','Backend\x20\x27','segmentIds','Transform','Error\x20in\x20norm:\x20invalid\x20axis:\x20','Logits\x20was\x20rank\x20','scopeStack','pad','\x20backend\x20not\x20found\x20in\x20registry',']\x20=\x20','DepthwiseConv2dNativeBackpropInput','toInt','as4D','backend','floatPrecision','Error\x20in\x20denseBincount:\x20input\x20must\x20be\x20at\x20most\x20rank\x202,\x20but\x20got\x20','Unknown\x20padding\x20parameter:\x20','Error\x20in\x20hingeLoss:\x20','Values\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x20','equal','targets\x20rank,\x20but\x20got\x20predictions\x20rank\x20',']\x20(','search','denseBincount','xor','The\x20kernel\x20\x27','\x20variables\x20is\x20','version_data','images','Minimum','`images`\x20must\x20have\x20`int32`\x20or\x20`float32`\x20as\x20dtype','color:\x20green','EXPLICIT','slice1d','pool','eye()\x20currently\x20supports\x20only\x201D\x20and\x202D\x20','nextScopeId','Gram-Schmidt:\x20Number\x20of\x20vectors\x20(','shape[sliceDim:],\x20got\x20updates.shape:\x20','Cannot\x20set\x20flag\x20','randomBytes','Using\x20both\x20ellipsisMask\x20and\x20newAxisMask\x20is\x20not\x20yet\x20supported.','Error\x20in\x20conv2dDerFilter:\x20input\x20must\x20be\x20rank\x204,\x20but\x20got\x20shape\x20','lower','),\x20but\x20got\x20','backward','crypto','predictions','to\x20','data','\x20for\x20the\x20slice()\x20size\x20at\x20index\x20','bool','\x09%c','has','Error\x20in\x20gradient\x20of\x20fused\x20conv2D:\x20',')\x20exceeds\x20','less','platform','The\x20highest\x20priority\x20backend\x20\x27','Data\x20must\x20be\x20a\x20vector,\x20saw:\x20',']\x20should\x20be\x20a\x20primitive,\x20','grads','\x20in\x20the\x20result\x20of\x20\x27','Cannot\x20convert\x20a\x20string[]\x20to\x20a\x20TypedArray','cropAndResize','tensor4d()\x20requires\x20shape\x20to\x20have\x20four\x20numbers','shru','\x27\x20has\x20not\x20yet\x20been\x20','AddN','\x20but\x20the\x20dtype\x20was\x20','tensor6d()\x20requires\x20shape\x20to\x20have\x20six\x20numbers','got\x20axis\x20','Unpack','sum',')\x20!=\x20indices.shape[','mul','conv2d','condition','exports','Error\x20in\x20conv2dDerInput:\x20dy\x20must\x20be\x20rank\x204,\x20but\x20got\x20','getSortedBackends','shape\x20[','Platform\x20','zerosLike','asin','name','Error\x20in\x20cropAndResize:\x20boxInd\x20must\x20be\x20have\x20size\x20[','Gradient\x20for\x20tile\x20operation\x20is\x20not\x20implemented\x20for\x20rank-','Error\x20in\x20fused\x20depthwiseConv2d:\x20input\x20must\x20be\x20rank\x204,\x20but\x20got\x20','but\x20had\x20shape\x20','D:\x20begin[','reflect','strides',')\x20and\x20','resizeNearestNeighbor','Multiple\x20ellipses\x20in\x20slice\x20is\x20not\x20allowed.','Error\x20in\x20conv1d:\x20input\x20must\x20be\x20rank\x203,\x20but\x20got\x20rank\x20','logicalOr','NonMaxSuppressionV3','numDataBuffers','true','Error\x20in\x20sigmoidCrossEntropyWithLogits:\x20','number[][][][][]\x20or\x20flat/TypedArray','fromBytes','AvgPool3DGrad','subarray','quick','trackTensor','Error\x20in\x20threshold:\x20image\x20must\x20be\x20rank\x203,','pop','inHeight','Error\x20in\x20flipLeftRight:\x20image\x20must\x20be\x20rank\x204,','Abs','object\x20where\x20`obj.gradFunc`\x20is\x20a\x20function.','Sigmoid','gradientDepth','outputs','Error\x20in\x20conv1d:\x20got\x20dataFormat\x20of\x20','SparseSegmentSum','Error\x20in\x20conv3dDerFilter:\x20filterShape\x20must\x20be\x20length\x205,\x20but\x20got\x20','Error\x20in\x20cosineDistance:\x20','activeScope','reshape','double','Error\x20in\x20dilation2d:\x20Only\x20NHWC\x20is\x20currently\x20supported,\x20','entries','Actual:\x20[','Cosh','binary','\x27\x20has\x20not\x20yet\x20been\x20initialized.\x20Make\x20','\x27\x20is\x20already\x20registered','Error\x20in\x20resizeNearestNeighbor:\x20x\x20must\x20be\x20rank\x203\x20or\x204,\x20but\x20got\x20','platformName','sure\x20to\x20await\x20tf.ready()\x20or\x20await\x20tf.setBackend()\x20before\x20calling\x20','numStringTensors','greaterEqual','movingAverage','\x20and\x20','The\x20number\x20of\x20values\x20should\x20be\x20positive.','Selu','132859FfNQdB','max','rate\x20must\x20be\x20a\x20float\x20in\x20the\x20range\x20[0,\x201),\x20but\x20got\x20','forEach','\x20You\x20can\x20disable\x20deprecation\x20warnings\x20with\x20','evaluateFlag','Error\x20in\x20conv3dDerFilter:\x20depth\x20of\x20dy\x20(','tf.scatterND()\x20expects\x20the\x20indices\x20to\x20be\x20rank\x201\x20or\x20higher,','match\x20output\x20depth\x20for\x20filter\x20(','MaxPoolGrad','Invalid\x20p-value\x20for\x20JB:\x20','Operands\x20could\x20not\x20be\x20broadcast\x20together\x20with\x20shapes\x20','stringNGrams','Error\x20in\x20depthwiseConv2d:\x20number\x20of\x20input\x20channels\x20','argMin','Multinomial','gradRegistry','boxes',')\x20does\x20not\x20match\x20the\x20provided\x20','\x20or\x20less\x20than\x200\x20for\x20input\x20of\x20','bytes','nonMaxSuppression','sparseValues.dtype\x20must\x20match\x20defaultValues.dtype','round','move','The\x20f\x20passed\x20in\x20grads(f)\x20must\x20be\x20a\x20function','Error\x20in\x20grayscaleToRGB:\x20images\x20must\x20be\x20at\x20least\x20rank\x202,\x20','elu','Error\x20in\x20separableConv2d:\x20pointwise\x20filter\x20must\x20be\x20rank\x204,\x20but\x20','but\x20was\x20','\x20keys.','activeProfile','Error\x20in\x20batchNorm3D:\x20offset\x20must\x20be\x20rank\x203\x20or\x20rank\x201\x20','conv1d','Error\x20in\x20separableConv2d:\x20the\x20second\x20dimension\x20of\x20pointwise\x20','Error\x20in\x20resizeBilinear:\x20If\x20halfPixelCenters\x20is\x20true,\x20','\x20values\x20but\x20has\x20','Overriding\x20the\x20gradient\x20for\x20\x27','\x20for\x20depthToSpace\x20with\x20input\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20','\x20\x20values:','@tensorflow/tfjs-backend-cpu','match\x20the\x20shape\x20returned\x20by\x20f([x1,...])','All\x20tensors\x20passed\x20to\x20tf.addN()\x20must\x20have\x20the\x20same\x20shape','`Tensor[]`\x20or\x20`TensorLike[]`','norm','expm1','failed.','makeTensor','boxes\x20must\x20be\x20a\x202D\x20tensor,\x20but\x20was\x20of\x20rank\x20\x27','acosh','ifft','Round','Cannot\x20have\x20a\x20step\x20of\x20zero','multiClassLabels','variable','broadcastTo():\x20shape.length=','To\x20get\x20the\x20original\x20bytes,\x20call\x20tensor.bytes().','toTensor','inTopK','image','rank\x204,\x20but\x20got\x20rank\x20',',\x20shape:\x20','all',',\x20should\x20be:\x20','Error\x20in\x20avgPool3dGrad:\x20input\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20','All\x20values\x20in\x20axis\x20param\x20must\x20be\x20integers\x20but\x20','mask\x27s\x20shape\x20must\x20match\x20the\x20first\x20K\x20dimensions\x20of\x20tensor\x27s\x20shape,','\x20passed\x20to\x20','Error\x20in\x20fused\x20matMul:\x20outer\x20dimensions\x20(','Error\x20in\x20dilation2d:\x20filter\x20must\x20be\x20rank\x203,\x20but\x20got\x20rank\x20','encode','The\x20dtype\x20for\x20rfft()\x20must\x20be\x20real\x20value\x20but\x20got\x20','VALID','tensor5d()\x20requires\x20shape\x20to\x20be\x20provided\x20when\x20`values`\x20','\x20must\x20have\x20\x27float32\x27\x20dtype,\x20but\x20has\x20\x27','shouldCheckForMemLeaks','Error\x20in\x20separableConv2d:\x20the\x20third\x20dimension\x20of\x20pointwise\x20filter\x20','Flag\x20','softNmsSigma','\x20\x20dtype:\x20','Unique','sign','fill','StridedSlice',')\x20and\x20rank\x20of\x20dy\x20(','then','input\x20tensor\x20batch\x20is\x20','value','cosh','state','Shapes\x20can\x20only\x20have\x201\x20implicit\x20size.\x20','profileKernel','LRN','scopeId','All\x20values\x20in\x20axis\x20param\x20must\x20be\x20in\x20range\x20[-','losses','suppressBeginIndex','asType','Element\x20arr[','are\x20a\x20flat/TypedArray','The\x20dtype\x20for\x20tf.spectral.ifft()\x20must\x20be\x20complex64\x20','gradients','The\x20f\x20passed\x20in\x20variableGrads(f)\x20must\x20return\x20a\x20scalar,\x20but\x20it\x20','\x20must\x20match','output','Cannot\x20find\x20a\x20connection\x20between\x20any\x20variable\x20and\x20the\x20result\x20of\x20',')\x20must\x20be\x20','Tensor\x20is\x20disposed.','splice','BroadcastTo','NHWC\x20is\x20supported','unstack','dilation2d','PROD','\x20backend\x20was\x20already\x20registered.\x20','scores\x20must\x20be\x20a\x201D\x20tensor','UnsortedSegmentSum','Gram-Schmidt:\x20Non-unique\x20lengths\x20found\x20in\x20the\x20input\x20vectors:\x20','Error\x20in\x20conv3dDerInput:\x20filter\x20must\x20be\x20rank\x205,\x20but\x20got\x20','entropy','avgPool3d','Error\x20in\x20gradient\x20for\x20op\x20','Error\x20in\x20resizeBilinear:\x20new\x20shape\x20must\x202D,\x20but\x20got\x20shape\x20','numSegments\x20must\x20be\x20of\x20dtype\x20int','kept','transform','Error\x20in\x20conv3d:\x20input\x20must\x20be\x20rank\x205,\x20but\x20got\x20rank\x20','Cannot\x20infer\x20the\x20missing\x20size\x20in\x20[','findBackend','Shapes\x20can\x20not\x20be\x20<\x200.\x20Found\x20','locToIndex','Arrays\x20differ:\x20actual[','relu','DepthwiseConv2dNativeBackpropFilter','bufferSync','(operation\x20name)\x20mapping\x20to\x20a\x20function.\x20Got\x20an\x20object\x20with\x20','Error\x20in\x20resizeNearestNeighbor:\x20If\x20halfPixelCenters\x20is\x20true,\x20','avgPool3dGrad','broadcastTo():\x20[','Error\x20in\x20huberLoss:\x20','linear','SparseSegmentMean','shl','inputShape','every','Error\x20in\x20gradient\x20of\x20depthwiseConv2d:\x20number\x20of\x20input\x20','divNoNan','tychei','Error\x20in\x20batchNorm2D:\x20mean\x20must\x20be\x20rank\x202\x20or\x20rank\x201\x20but\x20','\x20must\x20','102550ZlyyZd','sparseIndices','Error\x20in\x20clip:\x20min\x20(','TopK','FromPixels','Error\x20in\x20avgPool3d:\x20Only\x20NDHWC\x20is\x20currently\x20supported,\x20','\x20but\x20got\x20pad\x20','rankType','memory','\x20is\x20not\x20in\x20[-','Mod','size\x20must\x20be\x20non-negative,\x20but\x20got\x20','but\x20got\x20rank\x20','broadcastTo','NWC','Neg','Indices\x20specified\x20for\x20empty\x20output.\x20indices\x20shape:\x20','irfft','length\x20','\x20data\x20ids)\x20after\x20running\x20\x27','float32','Prod','bilinear','GatherNd','\x27\x20is\x20not\x20registered',')\x20!=\x20shape[','Cannot\x20construct\x20a\x20complex64\x20tensor\x20directly.\x20','Error\x20in\x20avgPool3d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','IsNan','BroadcastArgs','urlFlags','Error\x20in\x20avgPool3d:\x20x\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20','warn','Error\x20in\x20resizeNearestNeighbor:\x20new\x20shape\x20must\x202D,\x20but\x20got\x20shape\x20','The\x20dtype\x20of\x20\x27indices\x27\x20should\x20be\x20int32,\x20but\x20got\x20dtype:\x20','saveTensorsForBackwardMode','\x20\x20Buffer\x20shape=','imag','defaultValue','The\x20implicit\x20shape\x20can\x27t\x20be\x20a\x20fractional\x20number.\x20','tf.grad','setdiff1d','customGrad','lessEqual','fro','\x20and\x20transposeB=','\x20input.','prod','Cannot\x20compute\x20gradient\x20of\x20y=f(x)\x20with\x20respect\x20to\x20x.\x20Make\x20sure\x20that\x0a\x20\x20\x20\x20the\x20f\x20you\x20passed\x20encloses\x20all\x20operations\x20that\x20lead\x20from\x20x\x20to\x20y.','numTensors','Max','\x20updates.shape[','Error\x20in\x20conv1d:\x20filter\x20must\x20be\x20rank\x203,\x20but\x20got\x20rank\x20','scatterND','wallMs','Number\x20of\x20buckets\x20must\x20be\x20at\x20least\x201','fused\x20depthwiseConv2d','slice','IS_TEST','Error\x20in\x20conv2dDerInput:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','Cannot\x20compute\x20gradient\x20for\x20fused\x20activation\x20','kernelName','The\x20shape\x20of\x20dy\x20passed\x20in\x20grads(f)([x1,...],\x20dy)\x20must\x20','numBytes','NUMBER','populateURLFlags','Error\x20in\x20conv3dDerFilter:\x20input\x20must\x20be\x20rank\x205,\x20but\x20got\x20shape\x20','Acosh','error','qr2d()\x20requires\x20a\x202D\x20Tensor,\x20but\x20got\x20a\x20','isNaN','The\x20number\x20of\x20provided\x20coordinates\x20(','Error\x20in\x20conv3d:\x20got\x20dataFormat\x20of\x20','bias','sparseIndices\x20should\x20be\x20a\x20scalar,\x20vector,\x20or\x20matrix,','upper','Error\x20in\x20reverse1D:\x20x\x20must\x20be\x20rank\x201\x20but\x20got\x20rank\x20',']\x20does\x20not\x20match\x20the\x20input\x20size\x20','LogSoftmax','Indices\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20','\x20but\x20got\x20','Error\x20in\x20conv3dDerFilter:\x20dy\x20must\x20be\x20rank\x205,\x20but\x20got\x20shape\x20','returned\x20by\x20f(x)','null','not\x20yet\x20supported\x20in\x20gradients.\x20Got\x20dilations\x20\x27','NEGATIVE_INFINITY','\x27\x20for\x20backend\x20','endsWith',',\x20high:\x20','Cannot\x20compute\x20gradient\x20of\x20y=f(x)\x20with\x20respect\x20to\x20x.\x20Make\x20sure\x20','flags','Setting\x20feature\x20override\x20from\x20URL\x20','msCrypto','9ae16a3b2f90404f','tensors','removeDataId','Backend\x20name\x20\x27','mirrorPad','toFloat','MirrorPad','logicalAnd','\x20update.rank\x20!=\x20','greater','\x20for\x20depthToSpace\x20with\x20input\x20shape\x20','log1p','sparseValues\x20has\x20incorrect\x20shape\x20','findBackendFactory','@tensorflow/tfjs-data','plugins','Error\x20in\x20conv1d:\x20depth\x20of\x20input\x20(','location','Error\x20in\x20conv2dDerFilter:\x20filterShape\x20must\x20be\x20length\x204,\x20but\x20got\x20','denseShape','Conv3DBackpropInputV2','Asinh','meshgrid','sparseSegmentSum','but\x20is\x20an\x20array\x20of\x20','\x27\x20passed\x20to\x20\x27','replace','SUM_BY_NONZERO_WEIGHTS','Got\x20axes\x20','UZERO','...','setHook','Error\x20in\x20outerProduct:\x20inputs\x20must\x20be\x20rank\x201,\x20but\x20got\x20ranks\x20','input\x20depth\x20for\x20filter\x20','sort','Cannot\x20evaluate\x20flag\x20\x27','setupRegisteredKernels','logSigmoid','Cannot\x20concatenate\x20complex64\x20tensors\x20with\x20a\x20tensor\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20with\x20dtype\x20','maxPool','features','be\x20trainable,\x20but\x20none\x20of\x20the\x20','Cos','logLoss','concat','sub','size','ENV','paddings.shape[0]\x20',')\x20would\x20overflow\x20input.shape[','SpaceToBatchND','ready','SAME',')\x20input\x20must\x20match','Error\x20in\x20maxPoolGrad:\x20dy\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','2144475giMHnp','nextValue','Error\x20in\x20avgPoolGrad:\x20dy\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','stack','push','resizeBilinear','disposeVariable','undefined','values','shape\x20of\x20the\x20new\x20value\x20(','saved','batchNorm','bandPart():\x20numUpper\x20(','avgPoolGrad','gradients()\x20received\x20an\x20empty\x20list\x20of\x20xs.','fromString','],\x20the\x20tensor\x20should\x20have\x20','Error\x20in\x20avgPool:\x20x\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','rsqrt','IsInf','Ceil','\x27\x20for\x20backend\x20\x27','alpha','any','except\x20the\x20last\x20dimension.','tensor','Padding\x20in\x20dimension\x20','getAsync','slice4d\x20expects\x20a\x20rank-4\x20tensor,\x20but\x20got\x20a\x20rank-','truncated','toEqual','Got\x20','the\x20loss\x20function\x20y=f(x).\x20Please\x20make\x20sure\x20the\x20operations\x20that\x20','maxPool3d','object\x20where\x20`obj.gradFunc`\x20is\x20a\x20function\x20that\x20returns\x20','profile','sparseToDense','squaredDifference','rfft','Axis\x20must\x20be\x20<=\x20rank\x20of\x20the\x20tensor','input','The\x20input\x20to\x20the\x20tensor\x20constructor\x20must\x20be\x20a\x20non-null\x20value.','cast','Input\x20dtype\x20must\x20be\x20`int32`\x20or\x20`float32`.','prelu','unreliable','The\x20array\x20must\x20have\x20only\x201\x20element.','tensor6d()\x20requires\x20values\x20to\x20be\x20number[][][][][][]\x20or\x20','isInf','seed',',\x20no\x20registration\x20found.','Unsupported\x20data\x20type\x20$\x20{\x20dtype\x20}','cos','sparseFillEmptyRows','cropSize\x20must\x20be\x20atleast\x20[1,1],\x20but\x20was\x20','\x27,\x20which\x20does\x20not\x20match\x20','decay','\x27\x20must\x20','Cannot\x20initialize\x20backend\x20','\x27\x20must\x20be\x20a\x20','initializeBackend','LinSpace','are\x20not\x20yet\x20supported\x20in\x20gradients.\x20Got\x20dilations\x20\x27','\x20elements','version_layers','Cannot\x20backprop\x20through\x20input\x20','FFT','slice3d',',4]\x20','dataSync','randn','FusedBatchNorm','\x20tensor','argMax','integer\x20but\x20got\x20depthRadius\x20','matMul','registerBackend','numDataIds','CHECK_COMPUTATION_FOR_ERRORS','there\x20are\x200\x20elements','xorshift7','setupFunc','must\x20be\x20','Error\x20in\x20conv1D:\x20Either\x20stride\x20or\x20dilation\x20must\x20be\x201.\x20','Error\x20in\x20localResponseNormalization:\x20x\x20must\x20be\x20rank\x203\x20or\x204\x20but\x20got\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20rank\x20','next','Error\x20in\x20maxPoolGrad:\x20input\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','registryFactory','absoluteDifference','Error\x20in\x20gradient\x20of\x20depthwiseConv2d:\x20Either\x20strides\x20or\x20','\x20was\x20already\x20registered','DEPRECATION_WARNINGS_ENABLED','@tensorflow/tfjs-backend-webgl','Softplus','trunc','isValidTruncated','Error\x20in\x20maxPool3d:\x20Only\x20NDHWC\x20is\x20currently\x20supported,\x20','Error\x20in\x20threshold:\x20','forgetBias','rank','disposeRegisteredKernels','disposeVariables','Unsupported\x20data\x20type\x20','alea','be\x201.\x20Got\x20strides\x20','Size(','isFinite','tan','getQueryParams','Softmax\x20along\x20a\x20non-last\x20dimension\x20is\x20not\x20yet\x20supported.\x20','Segment\x20ids\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20','print','Error\x20in\x20resizeBilinear:\x20x\x20must\x20be\x20rank\x203\x20or\x204,\x20but\x20got\x20','softmaxCrossEntropy','kernelFunc','using,\x20dimRoundingMode\x20','outputsToSave','object\x20where\x20`obj.value`\x20is\x20a\x20tensor','readSync','setFlags','numDataMovesStack','empty','index','match\x20output\x20depth\x20for\x20filter\x20','isInteger','Batch\x20normalization\x20gradient\x20requires\x20mean\x20and\x20scale\x20to\x20have\x20','but\x20got\x20dtype\x20','input\x20rank\x20is\x20','MAX_SAFE_INTEGER','maximum','Mean','Error\x20in\x20depthwiseConv2d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','@tensorflow/tfjs-converter','Please\x20provide\x20a\x20function\x20to\x20tidy()','40MUhhpe','The\x20f\x20passed\x20in\x20valueAndGrads(f)\x20must\x20be\x20a\x20function','Error\x20in\x20logLoss:\x20','updates','Pass\x20at\x20least\x20one\x20tensor\x20to\x20concat','ExpandDims','runKernel','makeVariable','Input\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x20','Batch\x20normalization\x20gradient\x20requires\x20mean\x20and\x20offset\x20to\x20have\x20','Error\x20in\x20gradient\x20of\x20conv3D:\x20dilation\x20rates\x20greater\x20than\x201\x20are\x20','Error\x20in\x20dot:\x20inputs\x20must\x20all\x20be\x20rank\x201\x20or\x202,\x20but\x20got\x20ranks\x20','Error\x20in\x20batchNorm2D:\x20variance\x20must\x20be\x20rank\x202\x20or\x20rank\x201\x20','throwIfDisposed','saveAllInputs\x20is\x20true,\x20expected\x20inputs\x20to\x20be\x20an\x20array.','version','The\x20dtypes\x20of\x20the\x20first(','moments','maxPoolGrad','transforms','numeric','but\x20should\x20be\x20an\x20array/TypedArray\x20of\x20','Error\x20in\x20conv2D:\x20Either\x20strides\x20or\x20dilations\x20must\x20be\x201.\x20','\x27\x20is\x20not\x201','navigator','version_webgl','map','Error\x20in\x20conv1d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','GreaterEqual','constructor','Updates\x20specified\x20for\x20empty\x20output.\x20updates\x20shape:\x20','square','as1D','Sin','sigmoidCrossEntropy','color:\x20steelblue','Error\x20in\x20reverse4D:\x20x\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','Error\x20in\x20conv2d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','backendTimer','iouThreshold\x20must\x20be\x20in\x20[0,\x201],\x20but\x20was\x20\x27','BatchToSpaceND','atan','Conv2D','\x20being\x20uploaded\x20contains\x20','Expm1','CropAndResize','randu','the\x20elements\x20of\x20blockShape\x20','a\x20TensorBuffer\x20for\x20the\x20real\x20and\x20imaginary\x20parts\x20separately\x20and\x20','getTensorsForGradient','\x20supports\x20only\x20inner-most\x20axes\x20for\x20now.\x20','Error\x20in\x20maxPool3d:\x20x\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20','selectedScores','RealDiv','higher','\x27\x20does\x20not\x20match\x20the\x20size\x20','\x20Shapes\x20','Error\x20in\x20gradient\x20of\x20depthwiseConv2dNative:\x20input\x20must\x20be\x20','prototype','maxPoolWithArgmax','\x20tensor\x20instead.','call\x20tf.complex(real,\x20imag).','OneHot','Got\x20stride\x20','cosineDistance','startScope','Length\x20of\x20inShape\x20','now','Cumsum','Dilation2DBackpropFilter','hingeLoss','broadcastArgs','MaxPool3DGrad','\x20at\x20dim\x20','apply','leakyrelu','erf','boolMask','kernelMs','Error\x20in\x20batchNorm2D:\x20x\x20must\x20be\x20rank\x202\x20but\x20got\x20rank\x20','PadV2','variance','271047azXOfR','Slicing\x20scalar\x20is\x20not\x20possible','toBool','newBytes','slice3d\x20expects\x20a\x20rank-3\x20tensor,\x20but\x20got\x20a\x20rank-','stringToHashBucketFast','Error\x20in\x20maxPool3dGrad:\x20output\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20','SparseToDense','Reshape','trainable.','Input\x20shape\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x20','bandPart','\x20/\x20','disposeData','trainable','flipLeftRight','Unknown\x20dataFormat\x20','nextTensorId','0-length,\x20but\x20got\x20x\x20shape:\x20','iouThreshold','\x20and\x20axis\x20was\x20','step','Padding\x20doesn\x27t\x20match\x20input.\x20Must\x20be\x20','Error\x20in\x20transform:\x20outputShape\x20must\x20be\x20[height,\x20width]\x20or\x20null,\x20','complex','Dilation2DBackpropInput','Conv2DBackpropFilter','filterHeight','separableConv2d','gather','profiling','indices','SUM','Unknown\x20data\x20type\x20','read','version_converter',')\x20must\x20match\x20the\x20inChannels\x20dimension\x20in\x20','The\x20input\x20tensor\x20must\x20be\x20at\x20least\x201D','should\x20be\x20size\x201,\x20but\x20got\x20size\x20','nextTapeNodeId','Tensor\x20must\x20have\x20a\x20shape\x20comprised\x20of\x20positive\x20integers\x20but\x20got\x20','neg','dataSplits','\x20must\x20match.','get','LogicalOr','pad(scalar)\x20is\x20not\x20defined.\x20Pass\x20non-scalar\x20to\x20pad','Error\x20in\x20fused\x20depthwiseConv2d:\x20number\x20of\x20input\x20channels\x20','version_core','extraInfo','tensor5d()\x20requires\x20shape\x20to\x20have\x20five\x20numbers','The\x20args\x20passed\x20in\x20grads(f)(args)\x20must\x20be\x20an\x20array\x20','qr()\x20requires\x20input\x20tensor\x20to\x20have\x20a\x20rank\x20>=\x202,\x20but\x20got\x20rank\x20','Error\x20in\x20conv2dDerFilter:\x20depth\x20of\x20dy\x20(','Step','logicalXor','4502748ekshjo','totalBytesSnapshot','defineProperty','\x20second(','sigmoid','real','logSumExp','sigmoidCrossEntropyWithLogits','D:\x20Length\x20of\x20size\x20','Error\x20in\x20gradient\x20of\x20depthwiseConv2dNative:\x20filter\x20must\x20be\x20','addN','Could\x20not\x20parse\x20value\x20flag\x20value\x20','Error\x20in\x20fused\x20conv2d:\x20filter\x20must\x20be\x20rank\x204,\x20but\x20got\x20rank\x20',')\x20of\x20Tensors\x20with\x20shapes\x20','softplus','Reciprocal','expected:\x20','dataId','multiRNNCell','Negative\x20size\x20values\x20should\x20be\x20exactly\x20-1\x20but\x20got\x20','\x20but\x20the\x20rank\x20was\x20','logKernelProfile','NCDHW','fft','amd','broadcastTo():\x20Invalid\x20broadcast\x20shape\x20[','Memory\x20usage\x20by\x20string\x20tensors\x20is\x20approximate\x20','Arrays\x20are\x20of\x20different\x20type.\x20Actual:\x20','incRef','Second\x20array\x20length\x20was\x20','Sign','base','as3D','scopedRun','fetch','Unknown\x20fused\x20activation\x20','tf.disableDeprecationWarnings().','12419hzGYUo','StringSplit','\x27\x20not\x20yet\x20implemented\x20or\x20not\x20found\x20in\x20the\x20registry.\x20','\x20but\x20only\x20NDHWC\x20is\x20currently\x20supported.','Elu','tensor1d()\x20requires\x20values\x20to\x20be\x20a\x20flat/TypedArray','AvgPool3D','moveData','priority','Conv2DBackpropInput','Failed\x20to\x20cast\x20to\x20unknown\x20dtype\x20','\x20and\x20targets\x20rank\x20','Min','Invalid\x20mode.\x20Mode\x20must\x20be\x20either\x20reflect\x20or\x20symmetric.\x20','tensor3d()\x20requires\x20shape\x20to\x20have\x20three\x20numbers','Failed\x20to\x20decode\x20the\x20string\x20bytes\x20into\x20utf-8.\x20','Arrays\x20have\x20different\x20shapes.\x20','conv3d','NCHW','backendName','NDHWC','channelsLast','kernelRegistry','Can\x20not\x20upcast\x20','The\x20argument\x20passed\x20to\x20tf.addN()\x20must\x20be\x20a\x20list\x20of\x20tensors','Pass\x20non-scalar\x20to\x20mirrorPad','broadcastArgs():\x20first\x20input\x20must\x20be\x20a\x20vector\x20(rank=1).\x20','Cast','Error\x20in\x20transpose:\x20rank\x20of\x20input\x20','split','\x20tensor,\x20but\x20got\x20','offset','MIN_SAFE_INTEGER','sparseValues','inputs','Reverse','MEAN','are\x20a\x20flat\x20array','nearest','Error\x20in\x20fused\x20conv2d:\x20input\x20must\x20be\x20rank\x204,\x20but\x20got\x20rank\x20','Add','maxOutputSize','\x20must\x20be\x20divisible\x20by\x20blockShapes\x20','Error\x20in\x20conv3dDerInput:\x20depth\x20of\x20output\x20(','match\x20the\x20rank\x20of\x20the\x20array\x20(','join','mod','@tensorflow/tfjs-core','Error\x20in\x20batchNorm2D:\x20scale\x20must\x20be\x20rank\x202\x20or\x20rank\x201\x20','\x20\x20for\x20depthToSpace\x20with\x20input\x20shape\x0a\x20\x20\x20\x20',')\x20and\x20(',',\x20should\x20be\x20[]\x20or\x20[','tf.scatterND()\x20expects\x20the\x20updates\x20to\x20be\x20rank\x201\x20or\x20higher,','dy\x20must\x20have\x20\x27float32\x27\x20dtype,\x20but\x20has\x20\x27','floor','Complex','Error\x20in\x20maxPool:\x20Either\x20strides\x20or\x20dilations\x20must\x20be\x201.\x20','\x20\x20shape:\x20[','FlipLeftRight','outerProduct','Invalid\x20number\x20of\x20paddings.\x20Must\x20be\x20length\x20of\x202\x20each.','dispose','All\x20tensors\x20passed\x20to\x20tf.addN()\x20must\x20have\x20the\x20same\x20dtype','keep','filterWidth','filter','RotateWithOffset','topk()\x20expects\x20the\x20input\x20to\x20be\x20of\x20rank\x201\x20or\x20higher','fused\x20conv2d','\x20must\x20be\x201,\x20but\x20got\x20','\x20tensors\x20yet.','inTopK()\x20expects\x20the\x20predictions\x20to\x20be\x20of\x20rank\x202\x20or\x20higher,\x20','Pool','\x20and\x20transposeA=','reduce','Error\x20in\x20batchNorm3D:\x20variance\x20must\x20be\x20rank\x203\x20or\x20rank\x201\x20','acos','reverse','x\x20and\x20y\x20should\x20have\x20the\x20same\x20dtype,\x20but\x20got\x20x\x20(','track','SquaredDifference','match\x20input\x20depth\x20in\x20filter\x20(','MaxPool','__op','of\x20`Tensor`s\x20or\x20`TensorLike`s','60vbnMKI','dimension\x20(','Fill','Error\x20in\x20avgPoolGrad:\x20input\x20must\x20be\x20rank\x204\x20but\x20got\x20rank\x20','toString','Error\x20in\x20conv2d:\x20got\x20dataFormat\x20of\x20','Argument\x20\x27','atanh','clone','dot','StringToHashBucketFast','logSoftmax','avgPool','values\x20passed\x20to\x20tensor(values)\x20must\x20be\x20a\x20number/boolean/string\x20or\x20','Error\x20in\x20sigmoidCrossEntropy:\x20','false','IFFT','avg','ceil','x\x20should\x20be\x201D\x20tensor,\x20but\x20got\x20x\x20(','stridedSlice','AvgPoolGrad','color:red','number','localResponseNormalization','fromCharCode','previous\x20value\x20(','slice2d','scores\x20has\x20incompatible\x20shape\x20with\x20boxes.\x20Expected\x20','Error\x20creating\x20a\x20new\x20Tensor.\x20Inferred\x20shape\x20','toFixed','color:blue','stdDev','Negative\x20dimension\x20size\x20caused\x20by\x20overflow\x20when\x20multiplying\x0a\x20\x20\x20\x20','asScalar','but\x20got\x20dataFormat\x20of\x20','\x20and\x20dilations\x20\x27','spaceToBatchND','score','0-length,\x20but\x20got\x20input\x20shape:\x20','and','euclidean','newShape','Multiply','15724LUsTsy','maxPool3dGrad','Error\x20in\x20softmaxCrossEntropy:\x20','The\x20result\x20y\x20returned\x20by\x20f()\x20must\x20be\x20a\x20tensor.','Error\x20in\x20avgPool3dGrad:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20','slice2d\x20expects\x20a\x20rank-2\x20tensor,\x20but\x20got\x20a\x20rank-','variableGrads()\x20expects\x20at\x20least\x20one\x20of\x20the\x20input\x20variables\x20to\x20','Conv3D','NHWC','conv2dTranspose','Error\x20in\x20multinomial:\x20you\x20need\x20at\x20least\x202\x20outcomes,\x20but\x20got\x20','pendingBackendInitId','Error\x20in\x20dot:\x20inner\x20dimensions\x20of\x20inputs\x20must\x20match,\x20but\x20got\x20','random','The\x20varList\x20passed\x20in\x20variableGrads(f,\x20varList)\x20must\x20be\x20an\x20array\x20','method\x20must\x20be\x20bilinear\x20or\x20nearest,\x20but\x20was\x20','int32','log','pendingBackendInit','logicalNot','9ddfea08eb382d69','dtype\x20must\x20be\x20int32,\x20but\x20got\x20','convertValue',',\x20expected[','A\x20tensor\x20of\x20type\x20',')\x20must\x20match','peakBytes','Error\x20in\x20avgPool3dGrad:\x20dy\x20must\x20be\x20rank\x205\x20but\x20got\x20rank\x20','less\x20than\x20or\x20equal\x20to\x20max\x20(','4vrpxBp','unique','transpose','sparseReshape','whereAsync',')\x20must\x20match\x20','tensor4d()\x20requires\x20values\x20to\x20be\x20number[][][][]\x20or\x20flat/TypedArray','Error\x20in\x20conv2d:\x20input\x20must\x20be\x20rank\x204,\x20but\x20got\x20rank\x20','meanSquaredError','\x20but\x20is\x20','ArgMin','Indices\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20','minimum','boolean','scores','add','slice1d\x20expects\x20a\x20rank-1\x20tensor,\x20but\x20got\x20a\x20rank-','Default\x20value\x20should\x20be\x20a\x20scalar\x20but\x20received\x20shape\x20','asinh','buffer','__esModule','Error\x20in\x20conv2dDerFilter:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','getFlags','NonMaxSuppressionV5','Maximum','unsortedSegmentSum','ResizeBilinear','Error\x20in\x20conv3dDerInput:\x20depth\x20of\x20input\x20(','atan2','shape\x20(','isDisposedInternal','onesLike','Indices\x20should\x20be\x20Tensor2D\x20but\x20received\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20','got\x20rank\x20','equal\x20ranks.','getBool','Tanh','When\x20making\x20a\x20scalar\x20from\x20encoded\x20string,\x20','supported.\x20Labels\x20/\x20logits\x20was\x20rank\x20','\x27\x20not\x20registered\x20for\x20backend\x20\x27','\x20is\x20not\x20a\x20valid\x20third\x20argument\x20to\x20meshgrid','Delimiter\x20should\x20be\x20a\x20scalar\x20but\x20received\x20shape\x20','Must\x20have\x20updates.shape\x20=\x20indices.shape[:batchDim]\x20+\x20','mirrorPad(scalar)\x20is\x20not\x20defined.\x20','Error\x20in\x20fused\x20depthwiseConv2d:\x20Either\x20strides\x20or\x20dilations\x20must\x20','a\x20list\x20of\x20only\x20tensors.','floorDiv','tidy','default','shape','timeMs','broadcastArgs():\x20second\x20input\x20must\x20be\x20a\x20vector\x20(rank=1).\x20','pass','evaluationFn','dataIdsCount',',\x20weights\x20shape:\x20','Expected:\x20','Error\x20in\x20maxPool3d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20','Arrays\x20have\x20different\x20lengths\x20actual:\x20','hasInstance','LeakyRelu','_tfengine','dtype','\x27\x20has\x20shape\x20\x27','mean','dimRoundingMode\x20','number\x20of\x20dimensions\x20(','checkKernelForMemLeak','Can\x27t\x20squeeze\x20axis\x20','\x20but\x20got\x20shape\x20','Unknown\x20dtype\x20','same','disposeFunc','Log\x20Softmax\x20along\x20a\x20non-last\x20dimension\x20is\x20not\x20yet\x20supported.\x20','\x20and\x20dim\x20was\x20','depthwiseFilter','Sinh','Axis\x20=\x20','registeredVariables','tensor5d()\x20requires\x20values\x20to\x20be\x20','flatten','filter\x20','from','Error\x20in\x20maxPool3dGrad:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20','dilations\x20must\x20be\x20\x201.\x20Got\x20strides\x20','for\x20','Error\x20in\x20cropAndResize:\x20cropSize\x20must\x20be\x20of\x20length\x202,\x20but\x20got\x20','TensorFlow.js\x20deprecation\x20warnings\x20have\x20been\x20disabled.','ResizeNearestNeighbor','otsu',',\x20indices.shape:\x20','Dynamic\x20requires\x20are\x20not\x20currently\x20supported\x20by\x20@rollup/plugin-commonjs','tensor4d()\x20requires\x20shape\x20to\x20be\x20provided\x20when\x20`values`\x20','image\x20color\x20channel\x20must\x20be\x20equal\x20to\x203\x20or\x201','Error\x20in\x20pool:\x20Either\x20strides\x20or\x20dilations\x20must\x20be\x201.\x20',',\x20sliceDim:\x20','LessEqual','topk','\x20<\x20input.rank=','delete','\x20as\x20it\x20has\x20not\x20been\x20registered.','where','setBackend','Could\x20not\x20find\x20a\x20global\x20object','Only\x20strings\x20can\x20be\x20casted\x20to\x20strings','endTape','oneHot','initializeBackendsAndReturnBest','activeTape','D\x20Tensor.','expandDims','dilation\x20rates\x20greater\x20than\x201\x20','Sum','Got\x20strides\x20','\x20and\x20dilations\x20','\x20must\x20not\x20be\x20greater\x20than\x20the\x20number\x20of\x20columns\x20(','dilationHeight','getRandomValues','basicLSTMCell','tf.grads','Could\x20not\x20initialize\x20any\x20backends,\x20all\x20backend\x20initializations\x20','function','sparseSegmentMean','\x27\x20for\x20backend\x20is\x20not\x20registered','inferred\x20by\x20the\x20shape\x20\x27','tensorInfo','epsilon','Error\x20in\x20fused\x20matMul:\x20inputs\x20must\x20have\x20the\x20same\x20rank\x20of\x20at\x20','Error\x20in\x20fused\x20matMul:\x20inner\x20shapes\x20(','computeWeightedLoss','inWidth','NonMaxSuppressionV4','scoreThreshold','tfjsflags','tanh','The\x20gradient\x20\x27','Pow','nonMaxSuppressionAsync','beta','constant','reasons'];a0_0x8a45=function(){return _0x53e12d;};return a0_0x8a45();}function concat4d_(_0x167b75,_0x4432e7){return concat(_0x167b75,_0x4432e7);}const concat4d=op({'concat4d_':concat4d_});function conv1d_(_0x33fda5,_0x4b067a,_0x26c23a,_0x536b13,_0x59c0e8=a0_0x20018c(0x285),_0x23edc1=0x1,_0x47f232){const _0x4d39b9=a0_0x20018c,_0x405078=convertToTensor(_0x33fda5,'x','conv1d'),_0x4258a6=convertToTensor(_0x4b067a,_0x4d39b9(0x481),'conv1d');let _0x1fb435=_0x405078,_0x58edac=![];_0x405078['rank']===0x2&&(_0x58edac=!![],_0x1fb435=reshape(_0x405078,[0x1,_0x405078['shape'][0x0],_0x405078[_0x4d39b9(0x50f)][0x1]]));assert(_0x1fb435['rank']===0x3,()=>_0x4d39b9(0x1b5)+_0x1fb435[_0x4d39b9(0x36e)]+'.'),assert(_0x4258a6[_0x4d39b9(0x36e)]===0x3,()=>_0x4d39b9(0x2ab)+(_0x4258a6['rank']+'.'));_0x47f232!=null&&assert(isInt(_0x536b13),()=>_0x4d39b9(0x3ac)+('dimRoundingMode\x20'+_0x47f232+'\x20but\x20got\x20pad\x20'+_0x536b13+'.'));assert(_0x1fb435[_0x4d39b9(0x50f)][0x2]===_0x4258a6[_0x4d39b9(0x50f)][0x1],()=>_0x4d39b9(0x2e4)+_0x1fb435['shape'][0x2]+_0x4d39b9(0x4e3)+('input\x20depth\x20for\x20filter\x20'+_0x4258a6['shape'][0x1]+'.')),assert(eitherStridesOrDilationsAreOne(_0x26c23a,_0x23edc1),()=>_0x4d39b9(0x35e)+(_0x4d39b9(0x3d0)+_0x26c23a+'\x20and\x20dilation\x20\x27'+_0x23edc1+'\x27')),assert(_0x59c0e8==='NWC',()=>_0x4d39b9(0x1ca)+_0x59c0e8+'\x20but\x20only\x20NWC\x20is\x20currently\x20supported.');const _0x49923f=reshape(_0x4258a6,[0x1,_0x4258a6[_0x4d39b9(0x50f)][0x0],_0x4258a6[_0x4d39b9(0x50f)][0x1],_0x4258a6['shape'][0x2]]),_0x593509=reshape(_0x1fb435,[_0x1fb435[_0x4d39b9(0x50f)][0x0],0x1,_0x1fb435[_0x4d39b9(0x50f)][0x1],_0x1fb435[_0x4d39b9(0x50f)][0x2]]),_0x5eb651=[0x1,_0x26c23a],_0x388762=[0x1,_0x23edc1],_0x207815=_0x4d39b9(0x4c9),_0x319975=conv2d(_0x593509,_0x49923f,_0x5eb651,_0x536b13,_0x207815,_0x388762,_0x47f232);if(_0x58edac)return reshape(_0x319975,[_0x319975['shape'][0x2],_0x319975[_0x4d39b9(0x50f)][0x3]]);return reshape(_0x319975,[_0x319975[_0x4d39b9(0x50f)][0x0],_0x319975['shape'][0x2],_0x319975['shape'][0x3]]);}const conv1d=op({'conv1d_':conv1d_});function conv2dTranspose_(_0x24ede,_0x16e439,_0x26550f,_0x4d8b0a,_0x4e5a74,_0x558e60){const _0x461a41=a0_0x20018c,_0x2bdcfe=convertToTensor(_0x24ede,'x',_0x461a41(0x4ca)),_0x442b5a=convertToTensor(_0x16e439,_0x461a41(0x481),_0x461a41(0x4ca));return conv2DBackpropInput(_0x26550f,_0x2bdcfe,_0x442b5a,_0x4d8b0a,_0x4e5a74,_0x461a41(0x4c9),_0x558e60);}const conv2dTranspose=op({'conv2dTranspose_':conv2dTranspose_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function conv3d_(_0x514e63,_0x3dfec3,_0x22509c,_0x1d5271,_0x2a94da='NDHWC',_0x512bc7=[0x1,0x1,0x1]){const _0x3572c9=a0_0x20018c,_0x499cfc=convertToTensor(_0x514e63,'x',_0x3572c9(0x451)),_0x3100a4=convertToTensor(_0x3dfec3,_0x3572c9(0x481),_0x3572c9(0x451));let _0x1b10e4=_0x499cfc,_0x5bcfff=![];_0x499cfc['rank']===0x4&&(_0x5bcfff=!![],_0x1b10e4=reshape(_0x499cfc,[0x1,_0x499cfc[_0x3572c9(0x50f)][0x0],_0x499cfc['shape'][0x1],_0x499cfc[_0x3572c9(0x50f)][0x2],_0x499cfc[_0x3572c9(0x50f)][0x3]]));assert(_0x1b10e4[_0x3572c9(0x36e)]===0x5,()=>_0x3572c9(0x25f)+_0x1b10e4[_0x3572c9(0x36e)]+'.'),assert(_0x3100a4['rank']===0x5,()=>'Error\x20in\x20conv3d:\x20filter\x20must\x20be\x20rank\x205,\x20but\x20got\x20rank\x20'+(_0x3100a4[_0x3572c9(0x36e)]+'.')),assert(_0x1b10e4['shape'][0x4]===_0x3100a4[_0x3572c9(0x50f)][0x3],()=>_0x3572c9(0x134)+_0x1b10e4[_0x3572c9(0x50f)][0x4]+')\x20must\x20match\x20'+(_0x3572c9(0x2f5)+_0x3100a4[_0x3572c9(0x50f)][0x3]+'.')),assert(eitherStridesOrDilationsAreOne(_0x22509c,_0x512bc7),()=>'Error\x20in\x20conv3D:\x20Either\x20strides\x20or\x20dilations\x20must\x20be\x201.\x20'+(_0x3572c9(0x54f)+_0x22509c+'\x20and\x20dilations\x20\x27'+_0x512bc7+'\x27')),assert(_0x2a94da==='NDHWC',()=>_0x3572c9(0x2bf)+_0x2a94da+_0x3572c9(0x443));const _0x86ccb4={'x':_0x1b10e4,'filter':_0x3100a4},_0x284e12={'strides':_0x22509c,'pad':_0x1d5271,'dataFormat':_0x2a94da,'dilations':_0x512bc7},_0x3b9be3=ENGINE[_0x3572c9(0x397)](Conv3D,_0x86ccb4,_0x284e12);if(_0x5bcfff)return reshape(_0x3b9be3,[_0x3b9be3[_0x3572c9(0x50f)][0x1],_0x3b9be3[_0x3572c9(0x50f)][0x2],_0x3b9be3['shape'][0x3],_0x3b9be3[_0x3572c9(0x50f)][0x4]]);return _0x3b9be3;}const conv3d=op({'conv3d_':conv3d_});function conv3dTranspose_(_0x37e49d,_0x45b7e0,_0x260096,_0xe3a1db,_0x3b7228){const _0x105894=a0_0x20018c,_0x5578d1=convertToTensor(_0x37e49d,'x',_0x105894(0x58d)),_0x3ce78d=convertToTensor(_0x45b7e0,_0x105894(0x481),_0x105894(0x58d));return conv3DBackpropInput(_0x260096,_0x5578d1,_0x3ce78d,_0xe3a1db,_0x3b7228);}const conv3dTranspose=op({'conv3dTranspose_':conv3dTranspose_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function denseBincount_(_0x2912c8,_0x5cfbfe,_0x2e7056,_0x3188bb=![]){const _0x19591a=a0_0x20018c,_0x240fe3=convertToTensor(_0x2912c8,'x',_0x19591a(0x16c)),_0x3e51e7=convertToTensor(_0x5cfbfe,'weights','denseBincount');assert(_0x240fe3['dtype']===_0x19591a(0x4d1),()=>'Error\x20in\x20denseBincount:\x20input\x20'+(_0x19591a(0x4d6)+_0x240fe3[_0x19591a(0x51c)])),assert(_0x240fe3[_0x19591a(0x36e)]<=0x2,()=>_0x19591a(0x164)+(_0x19591a(0x5b5)+_0x240fe3['rank']+'.')),assert(_0x2e7056>=0x0,()=>_0x19591a(0x282)+_0x2e7056+'.'),assert(_0x3e51e7[_0x19591a(0x302)]===_0x240fe3[_0x19591a(0x302)]||_0x3e51e7[_0x19591a(0x302)]===0x0,()=>'Error\x20in\x20denseBincount:\x20weights\x20must\x20have\x20the\x20same\x20shape\x20as\x20x\x20or\x20'+(_0x19591a(0x3f5)+_0x240fe3[_0x19591a(0x50f)]+_0x19591a(0x515))+(_0x3e51e7[_0x19591a(0x50f)]+'.'));const _0x5a4a34={'x':_0x240fe3,'weights':_0x3e51e7},_0x3de7c4={'size':_0x2e7056,'binaryOutput':_0x3188bb};return ENGINE[_0x19591a(0x397)](DenseBincount,_0x5a4a34,_0x3de7c4);}const denseBincount=op({'denseBincount_':denseBincount_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function depthToSpace_(_0x439302,_0x4eaaa6,_0x41c2bc=a0_0x20018c(0x4c9)){const _0x24913b=a0_0x20018c,_0x299cfe=convertToTensor(_0x439302,'x','depthToSpace'),_0x2303b3=_0x41c2bc==='NHWC'?_0x299cfe[_0x24913b(0x50f)][0x1]:_0x299cfe[_0x24913b(0x50f)][0x2],_0x1bd972=_0x41c2bc===_0x24913b(0x4c9)?_0x299cfe[_0x24913b(0x50f)][0x2]:_0x299cfe[_0x24913b(0x50f)][0x3],_0x46fa60=_0x41c2bc===_0x24913b(0x4c9)?_0x299cfe[_0x24913b(0x50f)][0x3]:_0x299cfe['shape'][0x1];assert(_0x2303b3*_0x4eaaa6>=0x0,()=>'Negative\x20dimension\x20size\x20caused\x20by\x20overflow\x20when\x20multiplying\x0a\x20\x20\x20\x20'+_0x2303b3+_0x24913b(0x1de)+_0x4eaaa6+_0x24913b(0x471)+_0x299cfe[_0x24913b(0x50f)]),assert(_0x1bd972*_0x4eaaa6>=0x0,()=>_0x24913b(0x4b6)+_0x1bd972+_0x24913b(0x1de)+_0x4eaaa6+_0x24913b(0x207)+_0x299cfe[_0x24913b(0x50f)]),assert(_0x46fa60%(_0x4eaaa6*_0x4eaaa6)===0x0,()=>_0x24913b(0x13f)+_0x4eaaa6*_0x4eaaa6+_0x24913b(0x4e7)+_0x46fa60+_0x24913b(0x2de)+_0x299cfe['shape']);const _0x5d1621={'x':_0x299cfe},_0x1d89eb={'blockSize':_0x4eaaa6,'dataFormat':_0x41c2bc};return ENGINE[_0x24913b(0x397)](DepthToSpace,_0x5d1621,_0x1d89eb);}const depthToSpace=op({'depthToSpace_':depthToSpace_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function depthwiseConv2d_(_0x24e40a,_0x23d6e9,_0x6f10ad,_0x22332d,_0x4f1750=a0_0x20018c(0x4c9),_0x3b7bee=[0x1,0x1],_0x136577){const _0x508d7a=a0_0x20018c,_0x1a8543=convertToTensor(_0x24e40a,'x','depthwiseConv2d'),_0x531051=convertToTensor(_0x23d6e9,_0x508d7a(0x481),_0x508d7a(0x125));let _0x4e2570=_0x1a8543,_0x257b18=![];_0x1a8543['rank']===0x3&&(_0x257b18=!![],_0x4e2570=reshape(_0x1a8543,[0x1,_0x1a8543[_0x508d7a(0x50f)][0x0],_0x1a8543[_0x508d7a(0x50f)][0x1],_0x1a8543[_0x508d7a(0x50f)][0x2]]));assert(_0x4e2570[_0x508d7a(0x36e)]===0x4,()=>_0x508d7a(0x12f)+(_0x508d7a(0x5b5)+_0x4e2570[_0x508d7a(0x36e)]+'.')),assert(_0x531051[_0x508d7a(0x36e)]===0x4,()=>'Error\x20in\x20depthwiseConv2d:\x20filter\x20must\x20be\x20rank\x204,\x20but\x20got\x20rank\x20'+(_0x531051[_0x508d7a(0x36e)]+'.')),assert(_0x4e2570[_0x508d7a(0x50f)][0x3]===_0x531051['shape'][0x2],()=>_0x508d7a(0x1ee)+('('+_0x4e2570[_0x508d7a(0x50f)][0x3]+_0x508d7a(0x407))+(_0x508d7a(0x52f)+_0x531051[_0x508d7a(0x50f)][0x2]+'.'));_0x136577!=null&&assert(isInt(_0x22332d),()=>'Error\x20in\x20depthwiseConv2d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20'+(_0x508d7a(0x51f)+_0x136577+'\x20but\x20got\x20pad\x20'+_0x22332d+'.'));const _0x5b0b90={'x':_0x4e2570,'filter':_0x531051},_0xbff6e3={'strides':_0x6f10ad,'pad':_0x22332d,'dataFormat':_0x4f1750,'dilations':_0x3b7bee,'dimRoundingMode':_0x136577},_0x1c95e1=ENGINE[_0x508d7a(0x397)](DepthwiseConv2dNative,_0x5b0b90,_0xbff6e3);if(_0x257b18)return reshape(_0x1c95e1,[_0x1c95e1[_0x508d7a(0x50f)][0x1],_0x1c95e1['shape'][0x2],_0x1c95e1[_0x508d7a(0x50f)][0x3]]);return _0x1c95e1;}const depthwiseConv2d=op({'depthwiseConv2d_':depthwiseConv2d_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function diag_(_0x2a78fb){const _0x4fe14a=a0_0x20018c,_0x3f7971=convertToTensor(_0x2a78fb,'x','diag'),_0x6c13ab={'x':_0x3f7971};return ENGINE[_0x4fe14a(0x397)](Diag,_0x6c13ab);}const diag=op({'diag_':diag_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function dilation2d_(_0x5c22b7,_0x143da1,_0x65178f,_0x2999f6,_0x127234=[0x1,0x1],_0x43107f=a0_0x20018c(0x4c9)){const _0x315e13=a0_0x20018c,_0x2214f3=convertToTensor(_0x5c22b7,'x',_0x315e13(0x251)),_0x1ce85d=convertToTensor(_0x143da1,'filter',_0x315e13(0x251));assert(_0x2214f3['rank']===0x3||_0x2214f3[_0x315e13(0x36e)]===0x4,()=>'Error\x20in\x20dilation2d:\x20input\x20must\x20be\x20rank\x203\x20or\x204,\x20but\x20got\x20rank\x20'+(_0x2214f3[_0x315e13(0x36e)]+'.')),assert(_0x1ce85d['rank']===0x3,()=>_0x315e13(0x226)+(_0x1ce85d[_0x315e13(0x36e)]+'.')),assert(_0x43107f===_0x315e13(0x4c9),()=>_0x315e13(0x1d1)+('but\x20got\x20dataFormat\x20of\x20'+_0x43107f));let _0x499a59=_0x2214f3,_0x5f51d5=![];_0x2214f3[_0x315e13(0x36e)]===0x3&&(_0x499a59=reshape(_0x2214f3,[0x1,_0x2214f3[_0x315e13(0x50f)][0x0],_0x2214f3[_0x315e13(0x50f)][0x1],_0x2214f3[_0x315e13(0x50f)][0x2]]),_0x5f51d5=!![]);const _0x19bc82={'x':_0x499a59,'filter':_0x1ce85d},_0x58abf9={'strides':_0x65178f,'pad':_0x2999f6,'dilations':_0x127234},_0x2614a1=ENGINE[_0x315e13(0x397)](Dilation2D,_0x19bc82,_0x58abf9);if(_0x5f51d5)return reshape(_0x2614a1,[_0x2614a1[_0x315e13(0x50f)][0x1],_0x2614a1[_0x315e13(0x50f)][0x2],_0x2614a1['shape'][0x3]]);return _0x2614a1;}const dilation2d=op({'dilation2d_':dilation2d_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function divNoNan_(_0x4b7e60,_0x37306f){const _0x5d20cd=a0_0x20018c;let _0x4e7595=convertToTensor(_0x4b7e60,'a',_0x5d20cd(0xfd)),_0x4fd6d0=convertToTensor(_0x37306f,'b',_0x5d20cd(0xfd));[_0x4e7595,_0x4fd6d0]=makeTypesMatch(_0x4e7595,_0x4fd6d0);const _0x13a29e=div(_0x4e7595,_0x4fd6d0),_0xc30aa4=zerosLike(_0x13a29e),_0x56709b=equal(_0x4fd6d0,_0xc30aa4);return where(_0x56709b,_0xc30aa4,_0x13a29e);}const divNoNan=op({'divNoNan_':divNoNan_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function dot_(_0x15edab,_0x111c6a){const _0x5bf82f=a0_0x20018c,_0x572791=convertToTensor(_0x15edab,'t1',_0x5bf82f(0x49e)),_0x2d6f56=convertToTensor(_0x111c6a,'t2',_0x5bf82f(0x49e));assert((_0x572791[_0x5bf82f(0x36e)]===0x1||_0x572791[_0x5bf82f(0x36e)]===0x2)&&(_0x2d6f56[_0x5bf82f(0x36e)]===0x1||_0x2d6f56[_0x5bf82f(0x36e)]===0x2),()=>_0x5bf82f(0x39c)+(_0x572791[_0x5bf82f(0x36e)]+'\x20and\x20'+_0x2d6f56[_0x5bf82f(0x36e)]+'.'));const _0xbf3163=_0x572791[_0x5bf82f(0x36e)]===0x1?_0x572791[_0x5bf82f(0x302)]:_0x572791[_0x5bf82f(0x50f)][0x1],_0x5b64b1=_0x2d6f56[_0x5bf82f(0x36e)]===0x1?_0x2d6f56[_0x5bf82f(0x302)]:_0x2d6f56[_0x5bf82f(0x50f)][0x0];assert(_0xbf3163===_0x5b64b1,()=>_0x5bf82f(0x4cd)+(_0xbf3163+_0x5bf82f(0x1de)+_0x5b64b1+'.'));if(_0x572791[_0x5bf82f(0x36e)]===0x1&&_0x2d6f56[_0x5bf82f(0x36e)]===0x1){const _0x1282a3=reshape(_0x572791,[0x1,-0x1]),_0x14f71=reshape(_0x2d6f56,[-0x1,0x1]),_0x4de1b8=matMul(_0x1282a3,_0x14f71);return reshape(_0x4de1b8,[]);}else{if(_0x572791['rank']===0x1&&_0x2d6f56[_0x5bf82f(0x36e)]===0x2){const _0x243673=reshape(_0x572791,[0x1,-0x1]),_0x175034=reshape(_0x2d6f56,[_0x2d6f56[_0x5bf82f(0x50f)][0x0],_0x2d6f56[_0x5bf82f(0x50f)][0x1]]),_0x1fb962=matMul(_0x243673,_0x175034);return reshape(_0x1fb962,[_0x1fb962[_0x5bf82f(0x302)]]);}else{if(_0x572791['rank']===0x2&&_0x2d6f56[_0x5bf82f(0x36e)]===0x1){const _0x2c2e86=reshape(_0x2d6f56,[-0x1,0x1]),_0x402b87=matMul(_0x572791,_0x2c2e86);return reshape(_0x402b87,[_0x402b87[_0x5bf82f(0x302)]]);}else{const _0x513254=reshape(_0x2d6f56,[_0x2d6f56[_0x5bf82f(0x50f)][0x0],_0x2d6f56[_0x5bf82f(0x50f)][0x1]]),_0x250785=matMul(_0x572791,_0x513254);return _0x250785;}}}}const dot=op({'dot_':dot_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function einsum_(_0x1855fe,..._0x5687cf){const _0x4fca02=a0_0x20018c,_0x328954=_0x5687cf[_0x4fca02(0x3ab)]((_0x27edb8,_0x48bd19)=>convertToTensor(_0x27edb8,_0x4fca02(0x2d5)+_0x48bd19,'einsum')),_0x3a1079={'equation':_0x1855fe};return ENGINE[_0x4fca02(0x397)](Einsum,_0x328954,_0x3a1079);}const einsum=op({'einsum_':einsum_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function elu_(_0x1bfe39){const _0x3450d4=a0_0x20018c,_0x3c96c7=convertToTensor(_0x1bfe39,'x',_0x3450d4(0x1fc)),_0xe1c061={'x':_0x3c96c7};return ENGINE[_0x3450d4(0x397)](Elu,_0xe1c061);}const elu=op({'elu_':elu_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function erf_(_0x5e8a7f){const _0x22662c=a0_0x20018c;let _0x16cfe9=convertToTensor(_0x5e8a7f,'x',_0x22662c(0x3dd));assert(_0x16cfe9['dtype']===_0x22662c(0x4d1)||_0x16cfe9[_0x22662c(0x51c)]==='float32',()=>_0x22662c(0x336));_0x16cfe9[_0x22662c(0x51c)]==='int32'&&(_0x16cfe9=cast(_0x16cfe9,_0x22662c(0x28b)));const _0x3d9bcc={'x':_0x16cfe9};return ENGINE[_0x22662c(0x397)](Erf,_0x3d9bcc);}const erf=op({'erf_':erf_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function expm1_(_0xd55179){const _0x18cc79=a0_0x20018c,_0xf73a2a=convertToTensor(_0xd55179,'x',_0x18cc79(0x20e)),_0x2f5358={'x':_0xf73a2a};return ENGINE['runKernel'](Expm1,_0x2f5358);}const expm1=op({'expm1_':expm1_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function eye_(_0xa31950,_0x256b23,_0x5baf41,_0x1907da=a0_0x20018c(0x28b)){const _0xc7bbf0=a0_0x20018c;_0x256b23==null&&(_0x256b23=_0xa31950);const _0x8b8c97=buffer([_0xa31950,_0x256b23],_0x1907da),_0x57684d=_0xa31950<=_0x256b23?_0xa31950:_0x256b23;for(let _0x250110=0x0;_0x250110<_0x57684d;++_0x250110){_0x8b8c97[_0xc7bbf0(0x5a6)](0x1,_0x250110,_0x250110);}const _0x497760=reshape(_0x8b8c97[_0xc7bbf0(0x21a)](),[_0xa31950,_0x256b23]);if(_0x5baf41==null)return _0x497760;else{if(_0x5baf41[_0xc7bbf0(0x104)]===0x1)return tile(expandDims(_0x497760,0x0),[_0x5baf41[0x0],0x1,0x1]);else{if(_0x5baf41[_0xc7bbf0(0x104)]===0x2)return tile(expandDims(expandDims(_0x497760,0x0),0x0),[_0x5baf41[0x0],_0x5baf41[0x1],0x1,0x1]);else{if(_0x5baf41['length']===0x3)return tile(expandDims(expandDims(expandDims(_0x497760,0x0),0x0),0x0),[_0x5baf41[0x0],_0x5baf41[0x1],_0x5baf41[0x2],0x1,0x1]);else throw new Error(_0xc7bbf0(0x178)+('batchShapes,\x20but\x20received\x20'+_0x5baf41[_0xc7bbf0(0x104)]+'D.'));}}}}const eye=op({'eye_':eye_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function fill(_0x4f050e,_0x4a1778,_0x14d808){const _0x34a257=a0_0x20018c,_0x43683d={'shape':_0x4f050e,'value':_0x4a1778,'dtype':_0x14d808};return ENGINE[_0x34a257(0x397)](Fill,{},_0x43683d);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function imag_(_0x2b7492){const _0x5d415b=a0_0x20018c,_0x1c9778=convertToTensor(_0x2b7492,'input',_0x5d415b(0x29c)),_0x1e19c1={'input':_0x1c9778};return ENGINE[_0x5d415b(0x397)](Imag,_0x1e19c1);}const imag=op({'imag_':imag_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function isFinite_(_0x246daa){const _0x5ce03e=a0_0x20018c,_0x248027=convertToTensor(_0x246daa,'x',_0x5ce03e(0x375)),_0x331044={'x':_0x248027};return ENGINE[_0x5ce03e(0x397)](IsFinite,_0x331044);}const isFinite$1=op({'isFinite_':isFinite_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function isInf_(_0x379d97){const _0x11796b=a0_0x20018c,_0x4af145=convertToTensor(_0x379d97,'x',_0x11796b(0x33b)),_0x3adca1={'x':_0x4af145};return ENGINE[_0x11796b(0x397)](IsInf,_0x3adca1);}const isInf=op({'isInf_':isInf_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function isNaN_(_0x37f3a1){const _0x741a4d=a0_0x20018c,_0x2f0a81=convertToTensor(_0x37f3a1,'x','isNaN'),_0x2685bb={'x':_0x2f0a81};return ENGINE[_0x741a4d(0x397)](IsNan,_0x2685bb);}const isNaN$1=op({'isNaN_':isNaN_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function leakyRelu_(_0xaaa400,_0x3bf3a2=0.2){const _0x294f8b=a0_0x20018c,_0x188a4c=convertToTensor(_0xaaa400,'x',_0x294f8b(0x593)),_0x3cb5b9={'x':_0x188a4c},_0x3a6059={'alpha':_0x3bf3a2};return ENGINE['runKernel'](LeakyRelu,_0x3cb5b9,_0x3a6059);}const leakyRelu=op({'leakyRelu_':leakyRelu_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function linspace(_0x18e4b1,_0x2576b5,_0xb6a453){const _0x2412a4=a0_0x20018c;if(_0xb6a453<=0x0)throw new Error(_0x2412a4(0x1df));const _0xa0ba70={'start':_0x18e4b1,'stop':_0x2576b5,'num':_0xb6a453};return ENGINE[_0x2412a4(0x397)](LinSpace,{},_0xa0ba70);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function localResponseNormalization_(_0x2e24a3,_0x363bfc=0x5,_0x1dd8df=0x1,_0x457275=0x1,_0x574551=0.5){const _0xcc8165=a0_0x20018c,_0x3ada56=convertToTensor(_0x2e24a3,'x',_0xcc8165(0x4ad));assert(_0x3ada56[_0xcc8165(0x36e)]===0x4||_0x3ada56['rank']===0x3,()=>_0xcc8165(0x35f)+_0x3ada56[_0xcc8165(0x36e)]+'.'),assert(isInt(_0x363bfc),()=>'Error\x20in\x20localResponseNormalization:\x20depthRadius\x20must\x20be\x20an\x20'+(_0xcc8165(0x355)+_0x363bfc+'.'));let _0x1cdf9a=_0x3ada56,_0xf72029=![];_0x3ada56[_0xcc8165(0x36e)]===0x3&&(_0xf72029=!![],_0x1cdf9a=reshape(_0x3ada56,[0x1,_0x3ada56[_0xcc8165(0x50f)][0x0],_0x3ada56['shape'][0x1],_0x3ada56[_0xcc8165(0x50f)][0x2]]));const _0xf3d8cc={'x':_0x1cdf9a},_0x2954af={'depthRadius':_0x363bfc,'bias':_0x1dd8df,'alpha':_0x457275,'beta':_0x574551},_0x8d0f31=ENGINE[_0xcc8165(0x397)](LRN,_0xf3d8cc,_0x2954af);return _0xf72029?reshape(_0x8d0f31,[_0x8d0f31[_0xcc8165(0x50f)][0x1],_0x8d0f31[_0xcc8165(0x50f)][0x2],_0x8d0f31[_0xcc8165(0x50f)][0x3]]):_0x8d0f31;}const localResponseNormalization=op({'localResponseNormalization_':localResponseNormalization_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function log1p_(_0x15fd28){const _0x293954=convertToTensor(_0x15fd28,'x','log1p'),_0x1d43c9={'x':_0x293954};return ENGINE['runKernel'](Log1p,_0x1d43c9);}const log1p=op({'log1p_':log1p_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function grad(_0x47b381){const _0x521516=a0_0x20018c;return assert(isFunction(_0x47b381),()=>_0x521516(0x11f)),(_0x24b396,_0x11d0e1)=>{const _0x5354a9=_0x521516,_0x4d1b20=convertToTensor(_0x24b396,'x',_0x5354a9(0x29f),_0x5354a9(0x5c4)),_0x378bc0=_0x11d0e1!=null?convertToTensor(_0x11d0e1,'dy',_0x5354a9(0x29f)):null;return ENGINE[_0x5354a9(0x50d)](()=>{const _0x4c0b01=_0x5354a9,{value:_0x1c77b2,grads:_0x2823da}=ENGINE[_0x4c0b01(0x246)](()=>_0x47b381(_0x4d1b20),[_0x4d1b20],_0x378bc0);return _0x378bc0!=null&&assertShapesMatch(_0x1c77b2[_0x4c0b01(0x50f)],_0x378bc0[_0x4c0b01(0x50f)],'The\x20shape\x20of\x20dy\x20passed\x20in\x20grad(f)(x,\x20dy)\x20must\x20match\x20the\x20shape\x20'+_0x4c0b01(0x2c9)),checkGrads(_0x2823da),_0x2823da[0x0];});};}function grads(_0x10b807){const _0x3a1da7=a0_0x20018c;return assert(isFunction(_0x10b807),()=>_0x3a1da7(0x1fa)),(_0x321770,_0x47e6f2)=>{const _0x10c9f2=_0x3a1da7;assert(Array[_0x10c9f2(0x576)](_0x321770),()=>_0x10c9f2(0x416)+_0x10c9f2(0x494));const _0xc3a294=convertToTensorArray(_0x321770,'args',_0x10c9f2(0x555),'string_or_numeric'),_0x3bbd95=_0x47e6f2!=null?convertToTensor(_0x47e6f2,'dy',_0x10c9f2(0x555)):null;return ENGINE['tidy'](()=>{const _0x21e0da=_0x10c9f2,{value:_0x13afb5,grads:_0x13ab96}=ENGINE[_0x21e0da(0x246)](()=>_0x10b807(..._0xc3a294),_0xc3a294,_0x3bbd95);return _0x3bbd95!=null&&assertShapesMatch(_0x13afb5[_0x21e0da(0x50f)],_0x3bbd95[_0x21e0da(0x50f)],_0x21e0da(0x2b5)+_0x21e0da(0x20a)),checkGrads(_0x13ab96),_0x13ab96;});};}function valueAndGrad(_0x221fb0){const _0x752181=a0_0x20018c;return assert(isFunction(_0x221fb0),()=>_0x752181(0x583)),(_0x30b568,_0x34f2fc)=>{const _0x56b8c1=_0x752181;assert(_0x30b568 instanceof Tensor,()=>'The\x20x\x20passed\x20in\x20valueAndGrad(f)(x)\x20must\x20be\x20a\x20tensor'),assert(_0x34f2fc==null||_0x34f2fc instanceof Tensor,()=>'The\x20dy\x20passed\x20in\x20valueAndGrad(f)(x,\x20dy)\x20must\x20be\x20a\x20tensor');const {grads:_0x563beb,value:_0x809d61}=ENGINE[_0x56b8c1(0x246)](()=>_0x221fb0(_0x30b568),[_0x30b568],_0x34f2fc);return checkGrads(_0x563beb),{'grad':_0x563beb[0x0],'value':_0x809d61};};}function valueAndGrads(_0x59174e){const _0x23bc9f=a0_0x20018c;return assert(isFunction(_0x59174e),()=>_0x23bc9f(0x392)),(_0x38cd01,_0x377a3f)=>{const _0x538d16=_0x23bc9f;assert(Array[_0x538d16(0x576)](_0x38cd01)&&_0x38cd01[_0x538d16(0x271)](_0x355cb9=>_0x355cb9 instanceof Tensor),()=>'The\x20args\x20passed\x20in\x20valueAndGrads(f)(args)\x20must\x20be\x20array\x20of\x20'+'tensors'),assert(_0x377a3f==null||_0x377a3f instanceof Tensor,()=>_0x538d16(0x572));const _0x4557ea=ENGINE['gradients'](()=>_0x59174e(..._0x38cd01),_0x38cd01,_0x377a3f);return _0x377a3f!=null&&assertShapesMatch(_0x4557ea['value'][_0x538d16(0x50f)],_0x377a3f[_0x538d16(0x50f)],_0x538d16(0x5ce)+_0x538d16(0x20a)),checkGrads(_0x4557ea[_0x538d16(0x192)]),_0x4557ea;};}function variableGrads(_0x29ca6b,_0x114e57){const _0x2d0345=a0_0x20018c;assert(isFunction(_0x29ca6b),()=>'The\x20f\x20passed\x20in\x20variableGrads(f)\x20must\x20be\x20a\x20function'),assert(_0x114e57==null||Array[_0x2d0345(0x576)](_0x114e57)&&_0x114e57[_0x2d0345(0x271)](_0x21acf7=>_0x21acf7 instanceof Variable),()=>_0x2d0345(0x4cf)+'of\x20variables');const _0x8b4f16=_0x114e57!=null;if(!_0x8b4f16){_0x114e57=[];for(const _0x162eb2 in ENGINE[_0x2d0345(0x52c)]){_0x114e57[_0x2d0345(0x30f)](ENGINE['registeredVariables'][_0x162eb2]);}}const _0x42f188=_0x8b4f16?_0x114e57['filter'](_0x31ea6a=>!_0x31ea6a[_0x2d0345(0x3f1)]):null,_0x5579bb=_0x114e57[_0x2d0345(0x104)];_0x114e57=_0x114e57[_0x2d0345(0x481)](_0x46c764=>_0x46c764[_0x2d0345(0x3f1)]),assert(_0x114e57[_0x2d0345(0x104)]>0x0,()=>_0x2d0345(0x4c7)+(_0x2d0345(0x2fd)+_0x5579bb+_0x2d0345(0x16f))+_0x2d0345(0x3ec));const _0x9644ef=!![],{value:_0x445217,grads:_0x392222}=ENGINE[_0x2d0345(0x246)](_0x29ca6b,_0x114e57,null,_0x9644ef);assert(_0x392222['some'](_0x400173=>_0x400173!=null),()=>_0x2d0345(0x24a)+_0x2d0345(0x32b)+'use\x20variables\x20are\x20inside\x20the\x20function\x20f\x20passed\x20to\x20minimize().'),assert(_0x445217[_0x2d0345(0x36e)]===0x0,()=>_0x2d0345(0x247)+('returned\x20a\x20rank-'+_0x445217[_0x2d0345(0x36e)]+'\x20tensor'));const _0x17fea0={};return _0x114e57[_0x2d0345(0x1e4)]((_0x3a5c32,_0x263b3c)=>{const _0x3ba8a9=_0x2d0345;_0x392222[_0x263b3c]!=null&&(_0x17fea0[_0x3a5c32[_0x3ba8a9(0x1aa)]]=_0x392222[_0x263b3c]);}),_0x42f188!=null&&_0x42f188['forEach'](_0x126cf9=>_0x17fea0[_0x126cf9[_0x2d0345(0x1aa)]]=null),{'value':_0x445217,'grads':_0x17fea0};}function customGrad(_0x38075e){const _0x378786=a0_0x20018c;return ENGINE[_0x378786(0x2a1)](_0x38075e);}function checkGrads(_0x344f4c){const _0x24dc51=a0_0x20018c,_0x2bcbfe=_0x344f4c[_0x24dc51(0x481)](_0x40fb78=>_0x40fb78==null)[_0x24dc51(0x104)];if(_0x2bcbfe>0x0)throw new Error(_0x24dc51(0x2a7));}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function softplus_(_0xbcb2c4){const _0x4fc3cd=a0_0x20018c,_0x2027d2=convertToTensor(_0xbcb2c4,'x',_0x4fc3cd(0x429)),_0x4618e5={'x':_0x2027d2};return ENGINE[_0x4fc3cd(0x397)](Softplus,_0x4618e5);}const softplus=op({'softplus_':softplus_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logSigmoid_(_0x3b046f){const _0x43355c=a0_0x20018c,_0x572859=convertToTensor(_0x3b046f,'x',_0x43355c(0x2f9)),_0x4e6bdd=customGrad(_0x3167fd=>{const _0x5b41b6=neg(softplus(neg(_0x3167fd))),_0x42a4c6=_0xd52a27=>{const _0x57a7df=mul(_0xd52a27,sigmoid(neg(_0x3167fd)));return _0x57a7df;};return{'value':_0x5b41b6,'gradFunc':_0x42a4c6};});return _0x4e6bdd(_0x572859);}const logSigmoid=op({'logSigmoid_':logSigmoid_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function max_(_0x4c8f59,_0x2363b2=null,_0x39d0a1=![]){const _0x40c15c=convertToTensor(_0x4c8f59,'x','max'),_0x5de938={'x':_0x40c15c},_0x6338a3={'reductionIndices':_0x2363b2,'keepDims':_0x39d0a1};return ENGINE['runKernel'](Max,_0x5de938,_0x6338a3);}const max=op({'max_':max_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logSoftmax_(_0x15014f,_0x2918fa=-0x1){const _0x19c00b=a0_0x20018c,_0x2994e5=convertToTensor(_0x15014f,'logits',_0x19c00b(0x4a0));_0x2918fa===-0x1&&(_0x2918fa=_0x2994e5['rank']-0x1);if(_0x2918fa!==_0x2994e5[_0x19c00b(0x36e)]-0x1)throw Error(_0x19c00b(0x527)+(_0x19c00b(0x15a)+_0x2994e5[_0x19c00b(0x36e)]+_0x19c00b(0x3f7)+_0x2918fa));const _0x2b7351=customGrad((_0x452b6f,_0x32d927)=>{const _0x3870e5=_0x19c00b,_0x327b24=!![],_0x16e87b=max(_0x452b6f,_0x2918fa,!![]),_0x190f17=sub(_0x452b6f,_0x16e87b),_0x3bd47a=sub(cast(_0x190f17,_0x3870e5(0x28b)),log$1(sum$1(exp(_0x190f17),_0x2918fa,_0x327b24)));_0x32d927([_0x3bd47a]);const _0x17f02f=(_0x1db982,_0x58acc3)=>{const [_0x250c89]=_0x58acc3,_0x47fa1a=!![],_0x264f44=exp(_0x250c89);return sub(_0x1db982,mul(sum$1(_0x1db982,_0x2918fa,_0x47fa1a),_0x264f44));};return{'value':_0x3bd47a,'gradFunc':_0x17f02f};});return _0x2b7351(_0x2994e5);}const logSoftmax=op({'logSoftmax_':logSoftmax_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logSumExp_(_0x4dff14,_0x586ba2=null,_0x23ce27=![]){const _0x353219=a0_0x20018c,_0x1456bc=convertToTensor(_0x4dff14,'x',_0x353219(0x421)),_0x1586fd=parseAxisParam(_0x586ba2,_0x1456bc[_0x353219(0x50f)]),_0x372bae=max(_0x1456bc,_0x1586fd,!![]),_0x2dd232=sub(_0x1456bc,_0x372bae),_0x3ae768=exp(_0x2dd232),_0x53f1ea=sum$1(_0x3ae768,_0x1586fd),_0x4c7ccd=log$1(_0x53f1ea),_0x589325=add$1(reshape(_0x372bae,_0x4c7ccd[_0x353219(0x50f)]),_0x4c7ccd);if(_0x23ce27){const _0x160783=expandShapeToKeepDim(_0x589325[_0x353219(0x50f)],_0x1586fd);return reshape(_0x589325,_0x160783);}return _0x589325;}const logSumExp=op({'logSumExp_':logSumExp_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logicalOr_(_0x240c4c,_0x421270){const _0x376451=a0_0x20018c,_0x179d6e=convertToTensor(_0x240c4c,'a',_0x376451(0x1b6),_0x376451(0x188)),_0x3da997=convertToTensor(_0x421270,'b',_0x376451(0x1b6),_0x376451(0x188));assertAndGetBroadcastShape(_0x179d6e[_0x376451(0x50f)],_0x3da997['shape']);const _0x6ed73f={'a':_0x179d6e,'b':_0x3da997};return ENGINE['runKernel'](LogicalOr,_0x6ed73f);}const logicalOr=op({'logicalOr_':logicalOr_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logicalXor_(_0xe368b4,_0x14f08e){const _0x3b70ec=a0_0x20018c,_0x44b9ab=convertToTensor(_0xe368b4,'a',_0x3b70ec(0x41a),_0x3b70ec(0x188)),_0x16315b=convertToTensor(_0x14f08e,'b',_0x3b70ec(0x41a),'bool');return assertAndGetBroadcastShape(_0x44b9ab['shape'],_0x16315b[_0x3b70ec(0x50f)]),logicalAnd(logicalOr(_0xe368b4,_0x14f08e),logicalNot(logicalAnd(_0xe368b4,_0x14f08e)));}const logicalXor=op({'logicalXor_':logicalXor_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function maxPool_(_0x4bfcb7,_0x16bf88,_0x10db92,_0x168d7b,_0x4efd47){const _0x74e19a=a0_0x20018c,_0x4c0e1a=convertToTensor(_0x4bfcb7,'x',_0x74e19a(0x2fb)),_0x2de907=0x1;let _0x4ad872=_0x4c0e1a,_0x1d85a9=![];_0x4c0e1a[_0x74e19a(0x36e)]===0x3&&(_0x1d85a9=!![],_0x4ad872=reshape(_0x4c0e1a,[0x1,_0x4c0e1a[_0x74e19a(0x50f)][0x0],_0x4c0e1a[_0x74e19a(0x50f)][0x1],_0x4c0e1a[_0x74e19a(0x50f)][0x2]]));assert(_0x4ad872[_0x74e19a(0x36e)]===0x4,()=>_0x74e19a(0x588)+_0x4ad872[_0x74e19a(0x36e)]+'.'),assert(eitherStridesOrDilationsAreOne(_0x10db92,_0x2de907),()=>_0x74e19a(0x478)+(_0x74e19a(0x54f)+_0x10db92+_0x74e19a(0x4b9)+_0x2de907+'\x27'));_0x4efd47!=null&&assert(isInt(_0x168d7b),()=>'Error\x20in\x20maxPool:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20'+(_0x74e19a(0x51f)+_0x4efd47+'\x20but\x20got\x20pad\x20'+_0x168d7b+'.'));const _0x340ed6={'x':_0x4ad872},_0x11e94a={'filterSize':_0x16bf88,'strides':_0x10db92,'pad':_0x168d7b,'dimRoundingMode':_0x4efd47},_0x4500f2=ENGINE[_0x74e19a(0x397)](MaxPool,_0x340ed6,_0x11e94a);if(_0x1d85a9)return reshape(_0x4500f2,[_0x4500f2[_0x74e19a(0x50f)][0x1],_0x4500f2['shape'][0x2],_0x4500f2[_0x74e19a(0x50f)][0x3]]);return _0x4500f2;}const maxPool=op({'maxPool_':maxPool_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function maxPool3d_(_0x5af596,_0x4f2973=[0x1,0x1,0x1],_0xd05ead,_0x196d73,_0x485bfb,_0x241bb8=a0_0x20018c(0x454)){const _0x40e7a9=a0_0x20018c,_0x5c0d69=convertToTensor(_0x5af596,'x',_0x40e7a9(0x32c));let _0x53b860=_0x5c0d69,_0x1a5fd3=![];_0x5c0d69['rank']===0x4&&(_0x1a5fd3=!![],_0x53b860=reshape(_0x5c0d69,[0x1,_0x5c0d69['shape'][0x0],_0x5c0d69['shape'][0x1],_0x5c0d69[_0x40e7a9(0x50f)][0x2],_0x5c0d69[_0x40e7a9(0x50f)][0x3]]));assert(_0x53b860[_0x40e7a9(0x36e)]===0x5,()=>_0x40e7a9(0x3c4)+_0x53b860[_0x40e7a9(0x36e)]+'.'),assert(_0x241bb8==='NDHWC',()=>_0x40e7a9(0x36b)+(_0x40e7a9(0x4b8)+_0x241bb8));_0x485bfb!=null&&assert(isInt(_0x196d73),()=>_0x40e7a9(0x517)+(_0x40e7a9(0x51f)+_0x485bfb+_0x40e7a9(0x27d)+_0x196d73+'.'));const _0x26016d={'x':_0x53b860},_0x1bbacb={'filterSize':_0x4f2973,'strides':_0xd05ead,'pad':_0x196d73,'dimRoundingMode':_0x485bfb,'dataFormat':_0x241bb8},_0x49f985=ENGINE[_0x40e7a9(0x397)](MaxPool3D,_0x26016d,_0x1bbacb);if(_0x1a5fd3)return reshape(_0x49f985,[_0x49f985[_0x40e7a9(0x50f)][0x1],_0x49f985['shape'][0x2],_0x49f985[_0x40e7a9(0x50f)][0x3],_0x49f985[_0x40e7a9(0x50f)][0x4]]);return _0x49f985;}const maxPool3d=op({'maxPool3d_':maxPool3d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function maxPoolWithArgmax_(_0x49f401,_0x4a232f,_0x4216cc,_0x129ed1,_0x38878f=![]){const _0x4af7ef=a0_0x20018c,_0x2693ad=convertToTensor(_0x49f401,'x',_0x4af7ef(0x3cc)),_0x55b1f8={'x':_0x2693ad},_0x277195={'filterSize':_0x4a232f,'strides':_0x4216cc,'pad':_0x129ed1,'includeBatchInIndex':_0x38878f},_0x3c350f=ENGINE[_0x4af7ef(0x397)](MaxPoolWithArgmax,_0x55b1f8,_0x277195);return{'result':_0x3c350f[0x0],'indexes':_0x3c350f[0x1]};}const maxPoolWithArgmax=op({'maxPoolWithArgmax_':maxPoolWithArgmax_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function mean_(_0x1816c3,_0x11e75e=null,_0x114e4c=![]){const _0x4aa4a4=a0_0x20018c,_0x485e4e=convertToTensor(_0x1816c3,'x',_0x4aa4a4(0x51e)),_0x2d26f7={'x':_0x485e4e},_0x471d06={'axis':_0x11e75e,'keepDims':_0x114e4c};return ENGINE[_0x4aa4a4(0x397)](Mean,_0x2d26f7,_0x471d06);}const mean=op({'mean_':mean_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function meshgrid(_0x338af2,_0x244bae,{indexing:indexing='xy'}={}){const _0x28dcf5=a0_0x20018c;if(indexing!=='xy'&&indexing!=='ij')throw new TypeError(indexing+_0x28dcf5(0x506));if(_0x338af2===undefined)return[];let _0x4b8a2b=convertToTensor(_0x338af2,'x',_0x28dcf5(0x2ea),_0x338af2 instanceof Tensor?_0x338af2[_0x28dcf5(0x51c)]:'float32');if(_0x244bae===undefined)return[_0x4b8a2b];let _0x3e3730=convertToTensor(_0x244bae,'y','meshgrid',_0x244bae instanceof Tensor?_0x244bae[_0x28dcf5(0x51c)]:_0x28dcf5(0x28b));const _0x380fdc=sizeFromShape(_0x4b8a2b[_0x28dcf5(0x50f)]),_0x29629e=sizeFromShape(_0x3e3730['shape']);if(indexing==='xy')return _0x4b8a2b=reshape(_0x4b8a2b,[0x1,-0x1]),_0x3e3730=reshape(_0x3e3730,[-0x1,0x1]),[matMul(ones$1([_0x29629e,0x1],_0x4b8a2b[_0x28dcf5(0x51c)]),_0x4b8a2b),matMul(_0x3e3730,ones$1([0x1,_0x380fdc],_0x3e3730['dtype']))];return _0x4b8a2b=reshape(_0x4b8a2b,[-0x1,0x1]),_0x3e3730=reshape(_0x3e3730,[0x1,-0x1]),[matMul(_0x4b8a2b,ones$1([0x1,_0x29629e],_0x4b8a2b[_0x28dcf5(0x51c)])),matMul(ones$1([_0x380fdc,0x1],_0x3e3730[_0x28dcf5(0x51c)]),_0x3e3730)];}/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function min_(_0x38c7c8,_0x116f5d=null,_0x3c8979=![]){const _0x546991=a0_0x20018c,_0x32ea52=convertToTensor(_0x38c7c8,'x',_0x546991(0x58b)),_0x4ff0d5={'x':_0x32ea52},_0x5eff1a={'axis':_0x116f5d,'keepDims':_0x3c8979};return ENGINE[_0x546991(0x397)](Min,_0x4ff0d5,_0x5eff1a);}const min=op({'min_':min_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function minimum_(_0x4ff4f3,_0x4d6935){const _0x552b7b=a0_0x20018c;let _0x237bce=convertToTensor(_0x4ff4f3,'a',_0x552b7b(0x4ea)),_0x2f6a21=convertToTensor(_0x4d6935,'b',_0x552b7b(0x4ea));[_0x237bce,_0x2f6a21]=makeTypesMatch(_0x237bce,_0x2f6a21);_0x237bce[_0x552b7b(0x51c)]===_0x552b7b(0x188)&&(_0x237bce=cast(_0x237bce,_0x552b7b(0x4d1)),_0x2f6a21=cast(_0x2f6a21,_0x552b7b(0x4d1)));assertAndGetBroadcastShape(_0x237bce[_0x552b7b(0x50f)],_0x2f6a21['shape']);const _0x19cb4c={'a':_0x237bce,'b':_0x2f6a21};return ENGINE[_0x552b7b(0x397)](Minimum,_0x19cb4c);}const minimum=op({'minimum_':minimum_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function mirrorPad_(_0xd580d2,_0x450be0,_0x251626){const _0x2db6fd=a0_0x20018c;assert(_0x251626===_0x2db6fd(0x1b0)||_0x251626==='symmetric',()=>_0x2db6fd(0x44d)+('Got\x20'+_0x251626+'.'));const _0x516994=convertToTensor(_0xd580d2,'x',_0x2db6fd(0x2d8));if(_0x516994['rank']===0x0)throw new Error(_0x2db6fd(0x509)+_0x2db6fd(0x459));assert(_0x450be0[_0x2db6fd(0x104)]===_0x516994['rank'],()=>_0x2db6fd(0x3f9)+_0x516994[_0x2db6fd(0x36e)]+'.\x20'+(_0x2db6fd(0x32a)+_0x450be0[_0x2db6fd(0x104)]+'.'));const _0x117d9c=_0x251626===_0x2db6fd(0x1b0)?0x1:0x0;for(let _0x3703cf=0x0;_0x3703cf<_0x516994[_0x2db6fd(0x36e)];_0x3703cf++){assert(_0x450be0[_0x3703cf][_0x2db6fd(0x104)]===0x2,()=>_0x2db6fd(0x47c)),assert(_0x450be0[_0x3703cf][0x0]>=0x0&&_0x450be0[_0x3703cf][0x0]<=_0x516994['shape'][_0x3703cf]-_0x117d9c&&_0x450be0[_0x3703cf][0x1]>=0x0&&_0x450be0[_0x3703cf][0x1]<=_0x516994[_0x2db6fd(0x50f)][_0x3703cf]-_0x117d9c,()=>_0x2db6fd(0x325)+_0x3703cf+'\x20cannot\x20be\x20greater\x20than\x20or\x20equal\x20'+(_0x2db6fd(0x185)+(_0x516994[_0x2db6fd(0x50f)][_0x3703cf]-_0x117d9c)+_0x2db6fd(0x1f4))+('shape\x20'+_0x516994[_0x2db6fd(0x50f)]));}const _0x295d3e={'paddings':_0x450be0,'mode':_0x251626},_0x4f4fdc={'x':_0x516994};return ENGINE['runKernel'](MirrorPad,_0x4f4fdc,_0x295d3e);}const mirrorPad=op({'mirrorPad_':mirrorPad_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function mod_(_0x1e315b,_0x1505c6){const _0x5d8708=a0_0x20018c;let _0x3758fd=convertToTensor(_0x1e315b,'a',_0x5d8708(0x46e)),_0x2dca7f=convertToTensor(_0x1505c6,'b',_0x5d8708(0x46e));[_0x3758fd,_0x2dca7f]=makeTypesMatch(_0x3758fd,_0x2dca7f);const _0x4afe8f={'a':_0x3758fd,'b':_0x2dca7f};return ENGINE[_0x5d8708(0x397)](Mod,_0x4afe8f);}const mod=op({'mod_':mod_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function moments_(_0x3fae18,_0x154440=null,_0x129b63=![]){const _0x4020b7=a0_0x20018c;_0x3fae18=convertToTensor(_0x3fae18,'x',_0x4020b7(0x3a2));const _0x10dac3=parseAxisParam(_0x154440,_0x3fae18['shape']),_0x2fa3b1=mean(_0x3fae18,_0x10dac3,_0x129b63);let _0x534686=_0x2fa3b1[_0x4020b7(0x50f)];!_0x129b63&&(_0x534686=expandShapeToKeepDim(_0x2fa3b1[_0x4020b7(0x50f)],_0x10dac3));const _0x40fb72=square(sub(cast(_0x3fae18,_0x4020b7(0x28b)),reshape(_0x2fa3b1,_0x534686))),_0x57e7a3=mean(_0x40fb72,_0x10dac3,_0x129b63);return{'mean':_0x2fa3b1,'variance':_0x57e7a3};}const moments=op({'moments_':moments_});function multiRNNCell_(_0x1b77e0,_0x958222,_0x11c991,_0xebf417){const _0x43ca50=a0_0x20018c,_0x304db2=convertToTensor(_0x958222,_0x43ca50(0x186),_0x43ca50(0x42d)),_0x3ef739=convertToTensorArray(_0x11c991,'c',_0x43ca50(0x42d)),_0x5dd08c=convertToTensorArray(_0xebf417,'h',_0x43ca50(0x42d));let _0x3965f2=_0x304db2;const _0x485a28=[];for(let _0x5ea919=0x0;_0x5ea919<_0x1b77e0[_0x43ca50(0x104)];_0x5ea919++){const _0x32db2a=_0x1b77e0[_0x5ea919](_0x3965f2,_0x3ef739[_0x5ea919],_0x5dd08c[_0x5ea919]);_0x485a28[_0x43ca50(0x30f)](_0x32db2a[0x0]),_0x485a28['push'](_0x32db2a[0x1]),_0x3965f2=_0x32db2a[0x1];}const _0x4fce82=[],_0x17c66d=[];for(let _0x528f2f=0x0;_0x528f2f<_0x485a28[_0x43ca50(0x104)];_0x528f2f+=0x2){_0x4fce82['push'](_0x485a28[_0x528f2f]),_0x17c66d[_0x43ca50(0x30f)](_0x485a28[_0x528f2f+0x1]);}return[_0x4fce82,_0x17c66d];}const multiRNNCell=op({'multiRNNCell_':multiRNNCell_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function multinomial_(_0x2beaf2,_0x3f6df1,_0x524666,_0x18270c=![]){const _0x2d1389=a0_0x20018c,_0x47a67f=convertToTensor(_0x2beaf2,_0x2d1389(0x5b9),'multinomial'),_0x26aa8c=_0x47a67f[_0x2d1389(0x302)],_0x375742=_0x47a67f['rank'];if(_0x26aa8c<0x2)throw new Error(_0x2d1389(0x4cb)+(_0x26aa8c+'.'));if(_0x375742>0x2)throw new Error('Rank\x20of\x20probabilities\x20must\x20be\x201\x20or\x202,\x20but\x20is\x20'+_0x375742);_0x524666=_0x524666||Math[_0x2d1389(0x4ce)]();const _0x340ae8=_0x375742===0x1?reshape(_0x47a67f,[0x1,-0x1]):_0x47a67f,_0x263aca={'logits':_0x340ae8},_0x4dfc6c={'numSamples':_0x3f6df1,'seed':_0x524666,'normalized':_0x18270c},_0x5b9ae6=ENGINE['runKernel'](Multinomial,_0x263aca,_0x4dfc6c);return _0x375742===0x1?reshape(_0x5b9ae6,[_0x5b9ae6[_0x2d1389(0x302)]]):_0x5b9ae6;}const multinomial=op({'multinomial_':multinomial_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function notEqual_(_0x45e8d0,_0x245798){const _0x3613b6=a0_0x20018c;let _0x3a8e15=convertToTensor(_0x45e8d0,'a',_0x3613b6(0x103),'string_or_numeric'),_0x3ec2d6=convertToTensor(_0x245798,'b',_0x3613b6(0x103),_0x3613b6(0x5c4));[_0x3a8e15,_0x3ec2d6]=makeTypesMatch(_0x3a8e15,_0x3ec2d6),assertAndGetBroadcastShape(_0x3a8e15[_0x3613b6(0x50f)],_0x3ec2d6[_0x3613b6(0x50f)]);const _0x5cca28={'a':_0x3a8e15,'b':_0x3ec2d6};return ENGINE['runKernel'](NotEqual,_0x5cca28);}const notEqual=op({'notEqual_':notEqual_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function oneHot_(_0x45f49e,_0x4bb5e7,_0x4cf075=0x1,_0x2a3e4a=0x0){const _0x1207bc=a0_0x20018c;if(_0x4bb5e7<0x2)throw new Error(_0x1207bc(0x119)+_0x4bb5e7);const _0x59de00=convertToTensor(_0x45f49e,_0x1207bc(0x402),_0x1207bc(0x548),_0x1207bc(0x4d1)),_0x3c3132={'indices':_0x59de00},_0x23e4da={'depth':_0x4bb5e7,'onValue':_0x4cf075,'offValue':_0x2a3e4a};return ENGINE[_0x1207bc(0x397)](OneHot,_0x3c3132,_0x23e4da);}const oneHot=op({'oneHot_':oneHot_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function onesLike_(_0x359e0a){const _0x3e045b=a0_0x20018c,_0x5aaa85=convertToTensor(_0x359e0a,'x',_0x3e045b(0x4fd)),_0x55d1d0={'x':_0x5aaa85};return ENGINE[_0x3e045b(0x397)](OnesLike,_0x55d1d0);}const onesLike=op({'onesLike_':onesLike_});function outerProduct_(_0xa4102a,_0x40bb51){const _0x407acb=a0_0x20018c,_0x330db2=convertToTensor(_0xa4102a,'v1',_0x407acb(0x47b)),_0x3d8cbe=convertToTensor(_0x40bb51,'v2',_0x407acb(0x47b));assert(_0x330db2[_0x407acb(0x36e)]===0x1&&_0x3d8cbe['rank']===0x1,()=>_0x407acb(0x2f4)+(_0x330db2['rank']+_0x407acb(0x1de)+_0x3d8cbe[_0x407acb(0x36e)]+'.'));const _0xe89824=reshape(_0x330db2,[-0x1,0x1]),_0x4e00ad=reshape(_0x3d8cbe,[0x1,-0x1]);return matMul(_0xe89824,_0x4e00ad);}const outerProduct=op({'outerProduct_':outerProduct_});function pad1d_(_0x5731d8,_0x85527e,_0x448e95=0x0){const _0xc7799d=a0_0x20018c;return assert(_0x85527e[_0xc7799d(0x104)]===0x2,()=>'Invalid\x20number\x20of\x20paddings.\x20Must\x20be\x20length\x20of\x202.'),pad(_0x5731d8,[_0x85527e],_0x448e95);}const pad1d=op({'pad1d_':pad1d_});function pad2d_(_0x4b2391,_0xa4164c,_0xa0256a=0x0){const _0x377fb3=a0_0x20018c;return assert(_0xa4164c[_0x377fb3(0x104)]===0x2&&_0xa4164c[0x0]['length']===0x2&&_0xa4164c[0x1]['length']===0x2,()=>_0x377fb3(0x47c)),pad(_0x4b2391,_0xa4164c,_0xa0256a);}const pad2d=op({'pad2d_':pad2d_});function pad3d_(_0x7e7476,_0x563f67,_0x412257=0x0){const _0x5f1fa3=a0_0x20018c;return assert(_0x563f67[_0x5f1fa3(0x104)]===0x3&&_0x563f67[0x0][_0x5f1fa3(0x104)]===0x2&&_0x563f67[0x1]['length']===0x2&&_0x563f67[0x2][_0x5f1fa3(0x104)]===0x2,()=>_0x5f1fa3(0x47c)),pad(_0x7e7476,_0x563f67,_0x412257);}const pad3d=op({'pad3d_':pad3d_});function pad4d_(_0x5865b9,_0xee5396,_0x4c3e63=0x0){const _0x125964=a0_0x20018c;return assert(_0xee5396[_0x125964(0x104)]===0x4&&_0xee5396[0x0][_0x125964(0x104)]===0x2&&_0xee5396[0x1][_0x125964(0x104)]===0x2&&_0xee5396[0x2][_0x125964(0x104)]===0x2&&_0xee5396[0x3]['length']===0x2,()=>_0x125964(0x47c)),pad(_0x5865b9,_0xee5396,_0x4c3e63);}const pad4d=op({'pad4d_':pad4d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function pool_(_0x2322ca,_0x4cf578,_0x16f729,_0x6d4cc9,_0x27c045,_0x39321d){const _0x350a14=a0_0x20018c;_0x27c045==null&&(_0x27c045=[0x1,0x1]);_0x39321d==null&&(_0x39321d=0x1);_0x6d4cc9===0x0&&(_0x6d4cc9='valid');const _0x5f1b6a=convertToTensor(_0x2322ca,'x',_0x350a14(0x2fb));let _0x160dff=_0x5f1b6a,_0x15d648=![];_0x5f1b6a[_0x350a14(0x36e)]===0x3&&(_0x15d648=!![],_0x160dff=reshape(_0x5f1b6a,[0x1,_0x5f1b6a[_0x350a14(0x50f)][0x0],_0x5f1b6a[_0x350a14(0x50f)][0x1],_0x5f1b6a[_0x350a14(0x50f)][0x2]]));assert(eitherStridesOrDilationsAreOne(_0x39321d,_0x27c045),()=>_0x350a14(0x53c)+(_0x350a14(0x54f)+_0x39321d+_0x350a14(0x4b9)+_0x27c045+'\x27'));const _0x39065e=computePool2DInfo(_0x160dff[_0x350a14(0x50f)],_0x4cf578,_0x39321d,_0x27c045,_0x6d4cc9),_0x2618bd=[_0x39065e[_0x350a14(0x552)],_0x39065e[_0x350a14(0x57d)]];let _0xf75088;_0x6d4cc9===_0x350a14(0x525)?_0xf75088=withSpaceToBatchBasePaddings([_0x39065e[_0x350a14(0x3fe)],_0x39065e[_0x350a14(0x480)]],_0x2618bd):_0xf75088=[[0x0,0x0],[0x0,0x0]];const _0x77cdc7=_0x2618bd[0x0]===0x1&&_0x2618bd[0x1]===0x1,[_0x2ec569,_0x34fc56]=requiredSpaceToBatchPaddings([_0x39065e[_0x350a14(0x1c3)],_0x39065e[_0x350a14(0x560)]],_0x2618bd,_0xf75088),_0x2c0698=_0x77cdc7?_0x6d4cc9:_0x350a14(0x5ca),_0x186941=_0x77cdc7?_0x160dff:spaceToBatchND(_0x160dff,_0x2618bd,_0x2ec569),_0x420837=_0x16f729===_0x350a14(0x4a6)?()=>avgPool(_0x186941,_0x4cf578,_0x39321d,_0x2c0698):()=>maxPool(_0x186941,_0x4cf578,_0x39321d,_0x2c0698),_0xa5ce63=_0x420837(),_0x1e390f=_0x77cdc7?_0xa5ce63:batchToSpaceND(_0xa5ce63,_0x2618bd,_0x34fc56);if(_0x15d648)return reshape(_0x1e390f,[_0x1e390f[_0x350a14(0x50f)][0x1],_0x1e390f[_0x350a14(0x50f)][0x2],_0x1e390f[_0x350a14(0x50f)][0x3]]);return _0x1e390f;}function requiredSpaceToBatchPaddings(_0x59b38e,_0x3007ee,_0x239be1){const _0x14ad45=a0_0x20018c,_0x5e72de=_0x239be1[_0x14ad45(0x3ab)](_0x2e470b=>_0x2e470b[0x0]),_0x55f2fa=_0x239be1[_0x14ad45(0x3ab)](_0x8c09ad=>_0x8c09ad[0x1]),_0x5b1eba=_0x59b38e['concat'](_0x5e72de,_0x55f2fa),_0x13143d=_0x3007ee[_0x14ad45(0x3ab)]((_0x2e245d,_0x381b45)=>(_0x2e245d-_0x5b1eba[_0x381b45]%_0x2e245d)%_0x2e245d),_0x5e3f08=_0x55f2fa[_0x14ad45(0x3ab)]((_0x2e7c26,_0xaec15b)=>_0x2e7c26+_0x13143d[_0xaec15b]),_0x134fd5=_0x3007ee[_0x14ad45(0x3ab)]((_0x2fd7e2,_0x47900d)=>[_0x5e72de[_0x47900d],_0x5e3f08[_0x47900d]]),_0x16fcad=_0x3007ee[_0x14ad45(0x3ab)]((_0xc4d1bc,_0x4f724b)=>[0x0,_0x13143d[_0x4f724b]]);return[_0x134fd5,_0x16fcad];}function withSpaceToBatchBasePaddings(_0x50b8fc,_0x15abf7){const _0x5e04ba=a0_0x20018c,_0x1b65b5=_0x50b8fc[_0x5e04ba(0x3ab)]((_0x472422,_0x4d75a9)=>{return _0x472422+(_0x472422-0x1)*(_0x15abf7[_0x4d75a9]-0x1);}),_0x43646f=_0x1b65b5[_0x5e04ba(0x3ab)](_0x3a5a12=>_0x3a5a12-0x1),_0xa32a20=_0x43646f['map'](_0x129f8c=>Math['floor'](_0x129f8c/0x2)),_0x427140=_0x43646f[_0x5e04ba(0x3ab)]((_0x479390,_0x5aa238)=>_0x479390-_0xa32a20[_0x5aa238]);return _0x43646f[_0x5e04ba(0x3ab)]((_0x193bf5,_0x5657d9)=>{return[_0xa32a20[_0x5657d9],_0x427140[_0x5657d9]];});}const pool=op({'pool_':pool_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function prelu_(_0x4f9ef8,_0x29d2bf){const _0x1a0399=a0_0x20018c,_0x2d5f6a=convertToTensor(_0x4f9ef8,'x',_0x1a0399(0x337)),_0x4e3eb8=convertToTensor(_0x29d2bf,_0x1a0399(0x321),_0x1a0399(0x337)),_0x3765fc={'x':_0x2d5f6a,'alpha':_0x4e3eb8};return ENGINE[_0x1a0399(0x397)](Prelu,_0x3765fc);}const prelu=op({'prelu_':prelu_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function print(_0x1e5ebd,_0x361991=![]){console['log'](_0x1e5ebd['toString'](_0x361991));}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function prod_(_0x20e792,_0x236149=null,_0x415de2=![]){const _0x2f44bc=a0_0x20018c;let _0x15c255=convertToTensor(_0x20e792,'x',_0x2f44bc(0x2a6));_0x15c255['dtype']===_0x2f44bc(0x188)&&(_0x15c255=cast(_0x15c255,'int32'));const _0x5dc9fe={'x':_0x15c255},_0x3de008={'axis':_0x236149,'keepDims':_0x415de2};return ENGINE[_0x2f44bc(0x397)](Prod,_0x5dc9fe,_0x3de008);}const prod=op({'prod_':prod_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function rand_(_0x4d1c94,_0x78db7c,_0x221884){const _0x2d8499=a0_0x20018c,_0x42e6ac=sizeFromShape(_0x4d1c94);let _0x3d65c5=null;if(_0x221884==null||_0x221884==='float32')_0x3d65c5=new Float32Array(_0x42e6ac);else{if(_0x221884===_0x2d8499(0x4d1))_0x3d65c5=new Int32Array(_0x42e6ac);else{if(_0x221884===_0x2d8499(0x188))_0x3d65c5=new Uint8Array(_0x42e6ac);else throw new Error(_0x2d8499(0x404)+_0x221884);}}for(let _0x1e04ab=0x0;_0x1e04ab<_0x42e6ac;_0x1e04ab++){_0x3d65c5[_0x1e04ab]=_0x78db7c();}return ENGINE[_0x2d8499(0x210)](_0x3d65c5,_0x4d1c94,_0x221884);}const rand=op({'rand_':rand_});var commonjsGlobal=typeof globalThis!=='undefined'?globalThis:typeof window!=='undefined'?window:typeof global!==a0_0x20018c(0x312)?global:typeof self!==a0_0x20018c(0x312)?self:{};function unwrapExports(_0x345d44){const _0x27d0a5=a0_0x20018c;return _0x345d44&&_0x345d44[_0x27d0a5(0x4f2)]&&Object[_0x27d0a5(0x3cb)][_0x27d0a5(0xe1)][_0x27d0a5(0x5ae)](_0x345d44,'default')?_0x345d44['default']:_0x345d44;}function createCommonjsModule(_0x55d083,_0x34be64){const _0x325832=a0_0x20018c;return _0x34be64={'exports':{}},_0x55d083(_0x34be64,_0x34be64['exports']),_0x34be64[_0x325832(0x1a3)];}function getCjsExportFromNamespace(_0x2b2033){const _0x459de4=a0_0x20018c;return _0x2b2033&&_0x2b2033[_0x459de4(0x50e)]||_0x2b2033;}function commonjsRequire(){const _0x5da40e=a0_0x20018c;throw new Error(_0x5da40e(0x539));}var alea=createCommonjsModule(function(_0x43834d){const _0x37b4a0=a0_0x20018c;(function(_0x59780f,_0x59a256,_0x458745){const _0x3381ad=a0_0x367f;function _0x330aed(_0x35a900){var _0x22c8c5=this,_0x4cbfba=_0x15d582();_0x22c8c5['next']=function(){var _0x1bcfc8=0x1fea77*_0x22c8c5['s0']+_0x22c8c5['c']*2.3283064365386963e-10;return _0x22c8c5['s0']=_0x22c8c5['s1'],_0x22c8c5['s1']=_0x22c8c5['s2'],_0x22c8c5['s2']=_0x1bcfc8-(_0x22c8c5['c']=_0x1bcfc8|0x0);},_0x22c8c5['c']=0x1,_0x22c8c5['s0']=_0x4cbfba('\x20'),_0x22c8c5['s1']=_0x4cbfba('\x20'),_0x22c8c5['s2']=_0x4cbfba('\x20'),_0x22c8c5['s0']-=_0x4cbfba(_0x35a900),_0x22c8c5['s0']<0x0&&(_0x22c8c5['s0']+=0x1),_0x22c8c5['s1']-=_0x4cbfba(_0x35a900),_0x22c8c5['s1']<0x0&&(_0x22c8c5['s1']+=0x1),_0x22c8c5['s2']-=_0x4cbfba(_0x35a900),_0x22c8c5['s2']<0x0&&(_0x22c8c5['s2']+=0x1),_0x4cbfba=null;}function _0x1b65d5(_0x51dfcd,_0x36ec79){return _0x36ec79['c']=_0x51dfcd['c'],_0x36ec79['s0']=_0x51dfcd['s0'],_0x36ec79['s1']=_0x51dfcd['s1'],_0x36ec79['s2']=_0x51dfcd['s2'],_0x36ec79;}function _0x3c5286(_0x3854db,_0x9de606){const _0x30ce36=a0_0x367f;var _0x87bbf8=new _0x330aed(_0x3854db),_0x754c13=_0x9de606&&_0x9de606[_0x30ce36(0x23a)],_0x2d5385=_0x87bbf8[_0x30ce36(0x360)];_0x2d5385['int32']=function(){const _0x441f20=_0x30ce36;return _0x87bbf8[_0x441f20(0x360)]()*0x100000000|0x0;},_0x2d5385['double']=function(){return _0x2d5385()+(_0x2d5385()*0x200000|0x0)*1.1102230246251565e-16;},_0x2d5385['quick']=_0x2d5385;if(_0x754c13){if(typeof _0x754c13==_0x30ce36(0x130))_0x1b65d5(_0x754c13,_0x87bbf8);_0x2d5385['state']=function(){return _0x1b65d5(_0x87bbf8,{});};}return _0x2d5385;}function _0x15d582(){var _0x4e4b44=0xefc8249d,_0x50ad56=function(_0x173c28){const _0x21b6e0=a0_0x367f;_0x173c28=_0x173c28['toString']();for(var _0x113c03=0x0;_0x113c03<_0x173c28[_0x21b6e0(0x104)];_0x113c03++){_0x4e4b44+=_0x173c28[_0x21b6e0(0x59d)](_0x113c03);var _0x35cf49=0.02519603282416938*_0x4e4b44;_0x4e4b44=_0x35cf49>>>0x0,_0x35cf49-=_0x4e4b44,_0x35cf49*=_0x4e4b44,_0x4e4b44=_0x35cf49>>>0x0,_0x35cf49-=_0x4e4b44,_0x4e4b44+=_0x35cf49*0x100000000;}return(_0x4e4b44>>>0x0)*2.3283064365386963e-10;};return _0x50ad56;}if(_0x59a256&&_0x59a256[_0x3381ad(0x1a3)])_0x59a256[_0x3381ad(0x1a3)]=_0x3c5286;else _0x458745&&_0x458745['amd']?_0x458745(function(){return _0x3c5286;}):this['alea']=_0x3c5286;}(commonjsGlobal,_0x37b4a0(0x130)==_0x37b4a0(0x130)&&_0x43834d,typeof undefined==_0x37b4a0(0x557)&&undefined));}),xor128=createCommonjsModule(function(_0x349d5c){const _0x4bb863=a0_0x20018c;(function(_0x53c28c,_0x503ce7,_0x552b18){const _0x310888=a0_0x367f;function _0x125ea3(_0xfafe29){const _0xe2a791=a0_0x367f;var _0x10028a=this,_0x237af2='';_0x10028a['x']=0x0,_0x10028a['y']=0x0,_0x10028a['z']=0x0,_0x10028a['w']=0x0,_0x10028a[_0xe2a791(0x360)]=function(){var _0xfe2238=_0x10028a['x']^_0x10028a['x']<<0xb;return _0x10028a['x']=_0x10028a['y'],_0x10028a['y']=_0x10028a['z'],_0x10028a['z']=_0x10028a['w'],_0x10028a['w']^=_0x10028a['w']>>>0x13^_0xfe2238^_0xfe2238>>>0x8;};_0xfafe29===(_0xfafe29|0x0)?_0x10028a['x']=_0xfafe29:_0x237af2+=_0xfafe29;for(var _0x490008=0x0;_0x490008<_0x237af2[_0xe2a791(0x104)]+0x40;_0x490008++){_0x10028a['x']^=_0x237af2[_0xe2a791(0x59d)](_0x490008)|0x0,_0x10028a[_0xe2a791(0x360)]();}}function _0x19d701(_0xaa9213,_0x27f547){return _0x27f547['x']=_0xaa9213['x'],_0x27f547['y']=_0xaa9213['y'],_0x27f547['z']=_0xaa9213['z'],_0x27f547['w']=_0xaa9213['w'],_0x27f547;}function _0x24a1ea(_0x3275e3,_0x5d1b06){const _0x500ce9=a0_0x367f;var _0x1fad4b=new _0x125ea3(_0x3275e3),_0x5f33d3=_0x5d1b06&&_0x5d1b06[_0x500ce9(0x23a)],_0x1b7a4a=function(){return(_0x1fad4b['next']()>>>0x0)/0x100000000;};_0x1b7a4a[_0x500ce9(0x1d0)]=function(){const _0x13a389=_0x500ce9;do{var _0x283a8d=_0x1fad4b['next']()>>>0xb,_0x23f32a=(_0x1fad4b[_0x13a389(0x360)]()>>>0x0)/0x100000000,_0x5124af=(_0x283a8d+_0x23f32a)/(0x1<<0x15);}while(_0x5124af===0x0);return _0x5124af;},_0x1b7a4a[_0x500ce9(0x4d1)]=_0x1fad4b[_0x500ce9(0x360)],_0x1b7a4a[_0x500ce9(0x1bf)]=_0x1b7a4a;if(_0x5f33d3){if(typeof _0x5f33d3=='object')_0x19d701(_0x5f33d3,_0x1fad4b);_0x1b7a4a[_0x500ce9(0x23a)]=function(){return _0x19d701(_0x1fad4b,{});};}return _0x1b7a4a;}if(_0x503ce7&&_0x503ce7[_0x310888(0x1a3)])_0x503ce7[_0x310888(0x1a3)]=_0x24a1ea;else _0x552b18&&_0x552b18['amd']?_0x552b18(function(){return _0x24a1ea;}):this[_0x310888(0x584)]=_0x24a1ea;}(commonjsGlobal,_0x4bb863(0x130)==_0x4bb863(0x130)&&_0x349d5c,typeof undefined=='function'&&undefined));}),xorwow=createCommonjsModule(function(_0x32d7bb){const _0x862ba2=a0_0x20018c;(function(_0x2bfcdb,_0x388525,_0x3a9fe7){const _0x1376a7=a0_0x367f;function _0x35653f(_0x3b89f6){const _0x964074=a0_0x367f;var _0x4be5fc=this,_0xade4e4='';_0x4be5fc[_0x964074(0x360)]=function(){var _0x5b25fa=_0x4be5fc['x']^_0x4be5fc['x']>>>0x2;return _0x4be5fc['x']=_0x4be5fc['y'],_0x4be5fc['y']=_0x4be5fc['z'],_0x4be5fc['z']=_0x4be5fc['w'],_0x4be5fc['w']=_0x4be5fc['v'],(_0x4be5fc['d']=_0x4be5fc['d']+0x587c5|0x0)+(_0x4be5fc['v']=_0x4be5fc['v']^_0x4be5fc['v']<<0x4^(_0x5b25fa^_0x5b25fa<<0x1))|0x0;},_0x4be5fc['x']=0x0,_0x4be5fc['y']=0x0,_0x4be5fc['z']=0x0,_0x4be5fc['w']=0x0,_0x4be5fc['v']=0x0;_0x3b89f6===(_0x3b89f6|0x0)?_0x4be5fc['x']=_0x3b89f6:_0xade4e4+=_0x3b89f6;for(var _0x315773=0x0;_0x315773<_0xade4e4[_0x964074(0x104)]+0x40;_0x315773++){_0x4be5fc['x']^=_0xade4e4['charCodeAt'](_0x315773)|0x0,_0x315773==_0xade4e4[_0x964074(0x104)]&&(_0x4be5fc['d']=_0x4be5fc['x']<<0xa^_0x4be5fc['x']>>>0x4),_0x4be5fc[_0x964074(0x360)]();}}function _0x378f52(_0x48edf8,_0x1931fd){return _0x1931fd['x']=_0x48edf8['x'],_0x1931fd['y']=_0x48edf8['y'],_0x1931fd['z']=_0x48edf8['z'],_0x1931fd['w']=_0x48edf8['w'],_0x1931fd['v']=_0x48edf8['v'],_0x1931fd['d']=_0x48edf8['d'],_0x1931fd;}function _0x54c10c(_0x7bef48,_0x11e4f5){const _0x49798c=a0_0x367f;var _0x4b501a=new _0x35653f(_0x7bef48),_0x543dd9=_0x11e4f5&&_0x11e4f5[_0x49798c(0x23a)],_0x4d388c=function(){const _0x377996=_0x49798c;return(_0x4b501a[_0x377996(0x360)]()>>>0x0)/0x100000000;};_0x4d388c['double']=function(){const _0xd7db30=_0x49798c;do{var _0x358fa1=_0x4b501a['next']()>>>0xb,_0x5658ce=(_0x4b501a[_0xd7db30(0x360)]()>>>0x0)/0x100000000,_0x461e4c=(_0x358fa1+_0x5658ce)/(0x1<<0x15);}while(_0x461e4c===0x0);return _0x461e4c;},_0x4d388c[_0x49798c(0x4d1)]=_0x4b501a[_0x49798c(0x360)],_0x4d388c[_0x49798c(0x1bf)]=_0x4d388c;if(_0x543dd9){if(typeof _0x543dd9=='object')_0x378f52(_0x543dd9,_0x4b501a);_0x4d388c[_0x49798c(0x23a)]=function(){return _0x378f52(_0x4b501a,{});};}return _0x4d388c;}if(_0x388525&&_0x388525[_0x1376a7(0x1a3)])_0x388525[_0x1376a7(0x1a3)]=_0x54c10c;else _0x3a9fe7&&_0x3a9fe7[_0x1376a7(0x433)]?_0x3a9fe7(function(){return _0x54c10c;}):this[_0x1376a7(0x5af)]=_0x54c10c;}(commonjsGlobal,_0x862ba2(0x130)==_0x862ba2(0x130)&&_0x32d7bb,typeof undefined=='function'&&undefined));}),xorshift7=createCommonjsModule(function(_0x9ad236){const _0x3db8bc=a0_0x20018c;(function(_0x114147,_0x1d0242,_0x568456){const _0x10df52=a0_0x367f;function _0x3d6aca(_0x5d1964){var _0x529997=this;_0x529997['next']=function(){var _0x453526=_0x529997['x'],_0x3e7251=_0x529997['i'],_0x1db4ad,_0x26a0d0,_0x44415c;return _0x1db4ad=_0x453526[_0x3e7251],_0x1db4ad^=_0x1db4ad>>>0x7,_0x26a0d0=_0x1db4ad^_0x1db4ad<<0x18,_0x1db4ad=_0x453526[_0x3e7251+0x1&0x7],_0x26a0d0^=_0x1db4ad^_0x1db4ad>>>0xa,_0x1db4ad=_0x453526[_0x3e7251+0x3&0x7],_0x26a0d0^=_0x1db4ad^_0x1db4ad>>>0x3,_0x1db4ad=_0x453526[_0x3e7251+0x4&0x7],_0x26a0d0^=_0x1db4ad^_0x1db4ad<<0x7,_0x1db4ad=_0x453526[_0x3e7251+0x7&0x7],_0x1db4ad=_0x1db4ad^_0x1db4ad<<0xd,_0x26a0d0^=_0x1db4ad^_0x1db4ad<<0x9,_0x453526[_0x3e7251]=_0x26a0d0,_0x529997['i']=_0x3e7251+0x1&0x7,_0x26a0d0;};function _0x46974e(_0x378939,_0x4c900a){const _0x562993=a0_0x367f;var _0x2901f1,_0x1c3239,_0x20345c=[];if(_0x4c900a===(_0x4c900a|0x0))_0x1c3239=_0x20345c[0x0]=_0x4c900a;else{_0x4c900a=''+_0x4c900a;for(_0x2901f1=0x0;_0x2901f1<_0x4c900a['length'];++_0x2901f1){_0x20345c[_0x2901f1&0x7]=_0x20345c[_0x2901f1&0x7]<<0xf^_0x4c900a[_0x562993(0x59d)](_0x2901f1)+_0x20345c[_0x2901f1+0x1&0x7]<<0xd;}}while(_0x20345c[_0x562993(0x104)]<0x8)_0x20345c[_0x562993(0x30f)](0x0);for(_0x2901f1=0x0;_0x2901f1<0x8&&_0x20345c[_0x2901f1]===0x0;++_0x2901f1);if(_0x2901f1==0x8)_0x1c3239=_0x20345c[0x7]=-0x1;else _0x1c3239=_0x20345c[_0x2901f1];_0x378939['x']=_0x20345c,_0x378939['i']=0x0;for(_0x2901f1=0x100;_0x2901f1>0x0;--_0x2901f1){_0x378939[_0x562993(0x360)]();}}_0x46974e(_0x529997,_0x5d1964);}function _0x7d8e8a(_0x4d9c98,_0x297239){const _0x50288c=a0_0x367f;return _0x297239['x']=_0x4d9c98['x'][_0x50288c(0x2b0)](),_0x297239['i']=_0x4d9c98['i'],_0x297239;}function _0x5d9063(_0x4c3507,_0x7065c1){const _0x1d10f9=a0_0x367f;if(_0x4c3507==null)_0x4c3507=+new Date();var _0x2c8663=new _0x3d6aca(_0x4c3507),_0x5e533a=_0x7065c1&&_0x7065c1[_0x1d10f9(0x23a)],_0x2bc133=function(){return(_0x2c8663['next']()>>>0x0)/0x100000000;};_0x2bc133[_0x1d10f9(0x1d0)]=function(){const _0x1dcdea=_0x1d10f9;do{var _0x2400da=_0x2c8663['next']()>>>0xb,_0x52be3b=(_0x2c8663[_0x1dcdea(0x360)]()>>>0x0)/0x100000000,_0x19a80c=(_0x2400da+_0x52be3b)/(0x1<<0x15);}while(_0x19a80c===0x0);return _0x19a80c;},_0x2bc133[_0x1d10f9(0x4d1)]=_0x2c8663[_0x1d10f9(0x360)],_0x2bc133[_0x1d10f9(0x1bf)]=_0x2bc133;if(_0x5e533a){if(_0x5e533a['x'])_0x7d8e8a(_0x5e533a,_0x2c8663);_0x2bc133[_0x1d10f9(0x23a)]=function(){return _0x7d8e8a(_0x2c8663,{});};}return _0x2bc133;}if(_0x1d0242&&_0x1d0242[_0x10df52(0x1a3)])_0x1d0242[_0x10df52(0x1a3)]=_0x5d9063;else _0x568456&&_0x568456[_0x10df52(0x433)]?_0x568456(function(){return _0x5d9063;}):this[_0x10df52(0x35b)]=_0x5d9063;}(commonjsGlobal,_0x3db8bc(0x130)==_0x3db8bc(0x130)&&_0x9ad236,typeof undefined=='function'&&undefined));}),xor4096=createCommonjsModule(function(_0xc06c3){const _0x2e071d=a0_0x20018c;(function(_0x28f208,_0x481830,_0xfe82c9){const _0x3b908a=a0_0x367f;function _0x1abfaa(_0x11b7c1){const _0x36f005=a0_0x367f;var _0x5728a4=this;_0x5728a4[_0x36f005(0x360)]=function(){var _0x53ae4b=_0x5728a4['w'],_0x5c78e7=_0x5728a4['X'],_0x5ed68a=_0x5728a4['i'],_0x2f9d57,_0x4e2585;return _0x5728a4['w']=_0x53ae4b=_0x53ae4b+0x61c88647|0x0,_0x4e2585=_0x5c78e7[_0x5ed68a+0x22&0x7f],_0x2f9d57=_0x5c78e7[_0x5ed68a=_0x5ed68a+0x1&0x7f],_0x4e2585^=_0x4e2585<<0xd,_0x2f9d57^=_0x2f9d57<<0x11,_0x4e2585^=_0x4e2585>>>0xf,_0x2f9d57^=_0x2f9d57>>>0xc,_0x4e2585=_0x5c78e7[_0x5ed68a]=_0x4e2585^_0x2f9d57,_0x5728a4['i']=_0x5ed68a,_0x4e2585+(_0x53ae4b^_0x53ae4b>>>0x10)|0x0;};function _0x41671a(_0x49a4b6,_0x494f0e){const _0x504b00=_0x36f005;var _0x181a46,_0x2f3eb6,_0x213969,_0x5ae2a5,_0x126e29,_0x3332d3=[],_0x202d24=0x80;_0x494f0e===(_0x494f0e|0x0)?(_0x2f3eb6=_0x494f0e,_0x494f0e=null):(_0x494f0e=_0x494f0e+'\x00',_0x2f3eb6=0x0,_0x202d24=Math[_0x504b00(0x1e2)](_0x202d24,_0x494f0e['length']));for(_0x213969=0x0,_0x5ae2a5=-0x20;_0x5ae2a5<_0x202d24;++_0x5ae2a5){if(_0x494f0e)_0x2f3eb6^=_0x494f0e[_0x504b00(0x59d)]((_0x5ae2a5+0x20)%_0x494f0e[_0x504b00(0x104)]);if(_0x5ae2a5===0x0)_0x126e29=_0x2f3eb6;_0x2f3eb6^=_0x2f3eb6<<0xa,_0x2f3eb6^=_0x2f3eb6>>>0xf,_0x2f3eb6^=_0x2f3eb6<<0x4,_0x2f3eb6^=_0x2f3eb6>>>0xd,_0x5ae2a5>=0x0&&(_0x126e29=_0x126e29+0x61c88647|0x0,_0x181a46=_0x3332d3[_0x5ae2a5&0x7f]^=_0x2f3eb6+_0x126e29,_0x213969=0x0==_0x181a46?_0x213969+0x1:0x0);}_0x213969>=0x80&&(_0x3332d3[(_0x494f0e&&_0x494f0e['length']||0x0)&0x7f]=-0x1);_0x213969=0x7f;for(_0x5ae2a5=0x4*0x80;_0x5ae2a5>0x0;--_0x5ae2a5){_0x2f3eb6=_0x3332d3[_0x213969+0x22&0x7f],_0x181a46=_0x3332d3[_0x213969=_0x213969+0x1&0x7f],_0x2f3eb6^=_0x2f3eb6<<0xd,_0x181a46^=_0x181a46<<0x11,_0x2f3eb6^=_0x2f3eb6>>>0xf,_0x181a46^=_0x181a46>>>0xc,_0x3332d3[_0x213969]=_0x2f3eb6^_0x181a46;}_0x49a4b6['w']=_0x126e29,_0x49a4b6['X']=_0x3332d3,_0x49a4b6['i']=_0x213969;}_0x41671a(_0x5728a4,_0x11b7c1);}function _0x2b298f(_0x392871,_0x5b5ffa){const _0x530e59=a0_0x367f;return _0x5b5ffa['i']=_0x392871['i'],_0x5b5ffa['w']=_0x392871['w'],_0x5b5ffa['X']=_0x392871['X'][_0x530e59(0x2b0)](),_0x5b5ffa;};function _0x3bb02f(_0x1e683b,_0x58ecde){const _0x17ac94=a0_0x367f;if(_0x1e683b==null)_0x1e683b=+new Date();var _0x3ddaf1=new _0x1abfaa(_0x1e683b),_0x5b83f1=_0x58ecde&&_0x58ecde[_0x17ac94(0x23a)],_0x39f8a8=function(){const _0x3e12d1=_0x17ac94;return(_0x3ddaf1[_0x3e12d1(0x360)]()>>>0x0)/0x100000000;};_0x39f8a8[_0x17ac94(0x1d0)]=function(){const _0x4e3166=_0x17ac94;do{var _0x347098=_0x3ddaf1[_0x4e3166(0x360)]()>>>0xb,_0x57519d=(_0x3ddaf1[_0x4e3166(0x360)]()>>>0x0)/0x100000000,_0x4dc854=(_0x347098+_0x57519d)/(0x1<<0x15);}while(_0x4dc854===0x0);return _0x4dc854;},_0x39f8a8['int32']=_0x3ddaf1[_0x17ac94(0x360)],_0x39f8a8['quick']=_0x39f8a8;if(_0x5b83f1){if(_0x5b83f1['X'])_0x2b298f(_0x5b83f1,_0x3ddaf1);_0x39f8a8[_0x17ac94(0x23a)]=function(){return _0x2b298f(_0x3ddaf1,{});};}return _0x39f8a8;}if(_0x481830&&_0x481830[_0x3b908a(0x1a3)])_0x481830[_0x3b908a(0x1a3)]=_0x3bb02f;else _0xfe82c9&&_0xfe82c9['amd']?_0xfe82c9(function(){return _0x3bb02f;}):this['xor4096']=_0x3bb02f;}(commonjsGlobal,_0x2e071d(0x130)=='object'&&_0xc06c3,typeof undefined==_0x2e071d(0x557)&&undefined));}),tychei=createCommonjsModule(function(_0x156063){const _0x3de746=a0_0x20018c;(function(_0x2f7c37,_0x17a334,_0x5dc7c5){const _0x3e175b=a0_0x367f;function _0x99d3e4(_0x12b29c){const _0x2055b8=a0_0x367f;var _0x393d42=this,_0x40dc24='';_0x393d42[_0x2055b8(0x360)]=function(){var _0x3adb74=_0x393d42['b'],_0x4ded17=_0x393d42['c'],_0x1734bc=_0x393d42['d'],_0x41b75f=_0x393d42['a'];return _0x3adb74=_0x3adb74<<0x19^_0x3adb74>>>0x7^_0x4ded17,_0x4ded17=_0x4ded17-_0x1734bc|0x0,_0x1734bc=_0x1734bc<<0x18^_0x1734bc>>>0x8^_0x41b75f,_0x41b75f=_0x41b75f-_0x3adb74|0x0,_0x393d42['b']=_0x3adb74=_0x3adb74<<0x14^_0x3adb74>>>0xc^_0x4ded17,_0x393d42['c']=_0x4ded17=_0x4ded17-_0x1734bc|0x0,_0x393d42['d']=_0x1734bc<<0x10^_0x4ded17>>>0x10^_0x41b75f,_0x393d42['a']=_0x41b75f-_0x3adb74|0x0;},_0x393d42['a']=0x0,_0x393d42['b']=0x0,_0x393d42['c']=0x9e3779b9|0x0,_0x393d42['d']=0x517cc1b7;_0x12b29c===Math[_0x2055b8(0x476)](_0x12b29c)?(_0x393d42['a']=_0x12b29c/0x100000000|0x0,_0x393d42['b']=_0x12b29c|0x0):_0x40dc24+=_0x12b29c;for(var _0x3fd2f4=0x0;_0x3fd2f4<_0x40dc24[_0x2055b8(0x104)]+0x14;_0x3fd2f4++){_0x393d42['b']^=_0x40dc24['charCodeAt'](_0x3fd2f4)|0x0,_0x393d42[_0x2055b8(0x360)]();}}function _0x2080d6(_0x1068aa,_0x3844b2){return _0x3844b2['a']=_0x1068aa['a'],_0x3844b2['b']=_0x1068aa['b'],_0x3844b2['c']=_0x1068aa['c'],_0x3844b2['d']=_0x1068aa['d'],_0x3844b2;};function _0x29cae3(_0x34ac06,_0x15997c){const _0x4e13d9=a0_0x367f;var _0x41760d=new _0x99d3e4(_0x34ac06),_0x12e4a2=_0x15997c&&_0x15997c['state'],_0x30c037=function(){const _0x3a086e=a0_0x367f;return(_0x41760d[_0x3a086e(0x360)]()>>>0x0)/0x100000000;};_0x30c037['double']=function(){const _0xee8bfe=a0_0x367f;do{var _0x214a3b=_0x41760d[_0xee8bfe(0x360)]()>>>0xb,_0x476f5a=(_0x41760d[_0xee8bfe(0x360)]()>>>0x0)/0x100000000,_0x32c8e8=(_0x214a3b+_0x476f5a)/(0x1<<0x15);}while(_0x32c8e8===0x0);return _0x32c8e8;},_0x30c037['int32']=_0x41760d[_0x4e13d9(0x360)],_0x30c037[_0x4e13d9(0x1bf)]=_0x30c037;if(_0x12e4a2){if(typeof _0x12e4a2=='object')_0x2080d6(_0x12e4a2,_0x41760d);_0x30c037[_0x4e13d9(0x23a)]=function(){return _0x2080d6(_0x41760d,{});};}return _0x30c037;}if(_0x17a334&&_0x17a334[_0x3e175b(0x1a3)])_0x17a334[_0x3e175b(0x1a3)]=_0x29cae3;else _0x5dc7c5&&_0x5dc7c5[_0x3e175b(0x433)]?_0x5dc7c5(function(){return _0x29cae3;}):this['tychei']=_0x29cae3;}(commonjsGlobal,_0x3de746(0x130)==_0x3de746(0x130)&&_0x156063,typeof undefined=='function'&&undefined));}),seedrandom=createCommonjsModule(function(_0x1e1ed4){(function(_0x9ae7f5,_0x455133){const _0x4a7aac=a0_0x367f;var _0x321902=this,_0x359535=0x100,_0x2a810b=0x6,_0x1ac549=0x34,_0xac97c0=_0x4a7aac(0x4ce),_0x488361=_0x455133[_0x4a7aac(0xdb)](_0x359535,_0x2a810b),_0x3bbe1e=_0x455133[_0x4a7aac(0xdb)](0x2,_0x1ac549),_0x3571f4=_0x3bbe1e*0x2,_0x3edde3=_0x359535-0x1,_0x4cb94c;function _0x4b5d11(_0x2573d1,_0x1973de,_0x39f2bc){const _0x5a9c66=_0x4a7aac;var _0x1366de=[];_0x1973de=_0x1973de==!![]?{'entropy':!![]}:_0x1973de||{};var _0x29c103=_0x281492(_0x1d7df9(_0x1973de[_0x5a9c66(0x258)]?[_0x2573d1,_0x1bb71b(_0x9ae7f5)]:_0x2573d1==null?_0x4e0638():_0x2573d1,0x3),_0x1366de),_0x2eb277=new _0x136f2d(_0x1366de),_0x15ca57=function(){var _0x3edbde=_0x2eb277['g'](_0x2a810b),_0xba3da4=_0x488361,_0x46232a=0x0;while(_0x3edbde<_0x3bbe1e){_0x3edbde=(_0x3edbde+_0x46232a)*_0x359535,_0xba3da4*=_0x359535,_0x46232a=_0x2eb277['g'](0x1);}while(_0x3edbde>=_0x3571f4){_0x3edbde/=0x2,_0xba3da4/=0x2,_0x46232a>>>=0x1;}return(_0x3edbde+_0x46232a)/_0xba3da4;};return _0x15ca57[_0x5a9c66(0x4d1)]=function(){return _0x2eb277['g'](0x4)|0x0;},_0x15ca57['quick']=function(){return _0x2eb277['g'](0x4)/0x100000000;},_0x15ca57['double']=_0x15ca57,_0x281492(_0x1bb71b(_0x2eb277['S']),_0x9ae7f5),(_0x1973de[_0x5a9c66(0x512)]||_0x39f2bc||function(_0x38bdab,_0x125454,_0x26a34e,_0x451fca){const _0x196ebb=_0x5a9c66;_0x451fca&&(_0x451fca['S']&&_0x448019(_0x451fca,_0x2eb277),_0x38bdab[_0x196ebb(0x23a)]=function(){return _0x448019(_0x2eb277,{});});if(_0x26a34e)return _0x455133[_0xac97c0]=_0x38bdab,_0x125454;else return _0x38bdab;})(_0x15ca57,_0x29c103,_0x5a9c66(0x108)in _0x1973de?_0x1973de[_0x5a9c66(0x108)]:this==_0x455133,_0x1973de[_0x5a9c66(0x23a)]);}_0x455133[_0x4a7aac(0x33c)+_0xac97c0]=_0x4b5d11;function _0x136f2d(_0x5304d5){const _0x1163b9=_0x4a7aac;var _0x4f0aaa,_0x481651=_0x5304d5[_0x1163b9(0x104)],_0x148e45=this,_0x4d1460=0x0,_0x53902e=_0x148e45['i']=_0x148e45['j']=0x0,_0x9423c3=_0x148e45['S']=[];!_0x481651&&(_0x5304d5=[_0x481651++]);while(_0x4d1460<_0x359535){_0x9423c3[_0x4d1460]=_0x4d1460++;}for(_0x4d1460=0x0;_0x4d1460<_0x359535;_0x4d1460++){_0x9423c3[_0x4d1460]=_0x9423c3[_0x53902e=_0x3edde3&_0x53902e+_0x5304d5[_0x4d1460%_0x481651]+(_0x4f0aaa=_0x9423c3[_0x4d1460])],_0x9423c3[_0x53902e]=_0x4f0aaa;}(_0x148e45['g']=function(_0x14f6d2){var _0x313305,_0x3b38bf=0x0,_0x4226e9=_0x148e45['i'],_0x1855c5=_0x148e45['j'],_0x1e5587=_0x148e45['S'];while(_0x14f6d2--){_0x313305=_0x1e5587[_0x4226e9=_0x3edde3&_0x4226e9+0x1],_0x3b38bf=_0x3b38bf*_0x359535+_0x1e5587[_0x3edde3&(_0x1e5587[_0x4226e9]=_0x1e5587[_0x1855c5=_0x3edde3&_0x1855c5+_0x313305])+(_0x1e5587[_0x1855c5]=_0x313305)];}return _0x148e45['i']=_0x4226e9,_0x148e45['j']=_0x1855c5,_0x3b38bf;})(_0x359535);}function _0x448019(_0x47af5f,_0x21935d){const _0x3f7966=_0x4a7aac;return _0x21935d['i']=_0x47af5f['i'],_0x21935d['j']=_0x47af5f['j'],_0x21935d['S']=_0x47af5f['S'][_0x3f7966(0x2b0)](),_0x21935d;};function _0x1d7df9(_0x25176b,_0x349b2a){const _0x92960f=_0x4a7aac;var _0xa4400d=[],_0x3a85f3=typeof _0x25176b,_0x4340ef;if(_0x349b2a&&_0x3a85f3=='object')for(_0x4340ef in _0x25176b){try{_0xa4400d[_0x92960f(0x30f)](_0x1d7df9(_0x25176b[_0x4340ef],_0x349b2a-0x1));}catch(_0x3f38e3){}}return _0xa4400d[_0x92960f(0x104)]?_0xa4400d:_0x3a85f3=='string'?_0x25176b:_0x25176b+'\x00';}function _0x281492(_0x531f2c,_0x183ec3){const _0x121382=_0x4a7aac;var _0x372bf6=_0x531f2c+'',_0x28999e,_0x250e91=0x0;while(_0x250e91<_0x372bf6[_0x121382(0x104)]){_0x183ec3[_0x3edde3&_0x250e91]=_0x3edde3&(_0x28999e^=_0x183ec3[_0x3edde3&_0x250e91]*0x13)+_0x372bf6[_0x121382(0x59d)](_0x250e91++);}return _0x1bb71b(_0x183ec3);}function _0x4e0638(){const _0x16212b=_0x4a7aac;try{var _0x47446e;return _0x4cb94c&&(_0x47446e=_0x4cb94c[_0x16212b(0x17d)])?_0x47446e=_0x47446e(_0x359535):(_0x47446e=new Uint8Array(_0x359535),(_0x321902[_0x16212b(0x183)]||_0x321902[_0x16212b(0x2d3)])[_0x16212b(0x553)](_0x47446e)),_0x1bb71b(_0x47446e);}catch(_0x31e9c8){var _0x11cfa1=_0x321902[_0x16212b(0x3a9)],_0x4da472=_0x11cfa1&&_0x11cfa1[_0x16212b(0x2e3)];return[+new Date(),_0x321902,_0x4da472,_0x321902['screen'],_0x1bb71b(_0x9ae7f5)];}}function _0x1bb71b(_0x3daf31){const _0x104fa4=_0x4a7aac;return String[_0x104fa4(0x4ae)][_0x104fa4(0x3db)](0x0,_0x3daf31);}_0x281492(_0x455133['random'](),_0x9ae7f5);if(_0x4a7aac(0x130)=='object'&&_0x1e1ed4['exports']){_0x1e1ed4['exports']=_0x4b5d11;try{_0x4cb94c=require('crypto');}catch(_0xe9f549){}}else typeof undefined==_0x4a7aac(0x557)&&undefined[_0x4a7aac(0x433)]&&undefined(function(){return _0x4b5d11;});}([],Math));});seedrandom[a0_0x20018c(0x372)]=alea,seedrandom[a0_0x20018c(0x584)]=xor128,seedrandom[a0_0x20018c(0x5af)]=xorwow,seedrandom[a0_0x20018c(0x35b)]=xorshift7,seedrandom['xor4096']=xor4096,seedrandom[a0_0x20018c(0x274)]=tychei;var seedrandom$1=seedrandom,seedrandom_1=seedrandom$1[a0_0x20018c(0x372)];/**
 * @license
 * Copyright 2017 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const TEST_EPSILON_FLOAT32=0.001,TEST_EPSILON_FLOAT16=0.1;function expectArraysClose(_0xa82f4,_0x19cc87,_0x16913d){return _0x16913d==null&&(_0x16913d=testEpsilon()),expectArraysPredicate(_0xa82f4,_0x19cc87,(_0xbed0cb,_0xfcb5c8)=>areClose(_0xbed0cb,_0xfcb5c8,_0x16913d));}function testEpsilon(){const _0x103f41=a0_0x20018c;return ENGINE[_0x103f41(0x162)][_0x103f41(0x163)]()===0x20?TEST_EPSILON_FLOAT32:TEST_EPSILON_FLOAT16;}function expectArraysPredicate(_0x3edb4c,_0x262b0c,_0x5abccb){const _0x2315c9=a0_0x20018c;let _0x2699fe=!![];(isTypedArray(_0x3edb4c)||isTypedArray(_0x262b0c))&&(_0x2699fe=![]);isTypedArray(_0x3edb4c)&&isTypedArray(_0x262b0c)&&(_0x2699fe=!![]);if(_0x2699fe){const _0xdac2cd=_0x3edb4c[_0x2315c9(0x3ae)]['name'],_0x42aa17=_0x262b0c[_0x2315c9(0x3ae)][_0x2315c9(0x1aa)];if(_0xdac2cd!==_0x42aa17)throw new Error(_0x2315c9(0x436)+_0xdac2cd+'.\x20'+(_0x2315c9(0x516)+_0x42aa17));}if(Array[_0x2315c9(0x576)](_0x3edb4c)&&Array[_0x2315c9(0x576)](_0x262b0c)){const _0x2dfc6f=inferShape(_0x3edb4c),_0x21a12e=inferShape(_0x262b0c);if(!arraysEqual(_0x2dfc6f,_0x21a12e))throw new Error(_0x2315c9(0x450)+(_0x2315c9(0x1d3)+_0x2dfc6f+'].\x20Expected:\x20['+_0x21a12e+']'));}const _0x24bea8=isTypedArray(_0x3edb4c)?_0x3edb4c:flatten(_0x3edb4c),_0x4a92fa=isTypedArray(_0x262b0c)?_0x262b0c:flatten(_0x262b0c);if(_0x24bea8[_0x2315c9(0x104)]!==_0x4a92fa[_0x2315c9(0x104)])throw new Error(_0x2315c9(0x518)+_0x24bea8[_0x2315c9(0x104)]+'\x20vs\x20'+(_0x2315c9(0x42b)+_0x4a92fa[_0x2315c9(0x104)]+'.\x0a')+('Actual:\x20\x20\x20'+_0x24bea8+'.\x0a')+(_0x2315c9(0x516)+_0x4a92fa+'.'));for(let _0x58be8d=0x0;_0x58be8d<_0x4a92fa[_0x2315c9(0x104)];++_0x58be8d){const _0x2a1610=_0x24bea8[_0x58be8d],_0x5ade8a=_0x4a92fa[_0x58be8d];if(!_0x5abccb(_0x2a1610,_0x5ade8a))throw new Error(_0x2315c9(0x264)+_0x58be8d+']\x20=\x20'+_0x2a1610+_0x2315c9(0x4d8)+_0x58be8d+_0x2315c9(0x15e)+_0x5ade8a+'.\x0a'+(_0x2315c9(0xf4)+_0x24bea8+'.\x0a')+(_0x2315c9(0x516)+_0x4a92fa+'.'));}}function expectPromiseToFail(_0x26d450,_0x46b1e7){const _0x466836=a0_0x20018c;_0x26d450()[_0x466836(0x236)](()=>_0x46b1e7['fail'](),()=>_0x46b1e7());}function expectArraysEqual(_0x2df223,_0x57284d){const _0x3959b0=a0_0x20018c,_0x416e19=typeof _0x57284d==='string'||typeof _0x57284d===_0x3959b0(0x4ac)||typeof _0x57284d===_0x3959b0(0x4eb)?[_0x57284d]:_0x57284d;if(isString(_0x2df223)||isString(_0x2df223[0x0])||isString(_0x57284d)||isString(_0x57284d[0x0]))return expectArraysPredicate(_0x2df223,_0x416e19,(_0xaab116,_0x4786e0)=>_0xaab116==_0x4786e0);return expectArraysPredicate(_0x2df223,_0x57284d,(_0x4ebd9a,_0x19adc7)=>areClose(_0x4ebd9a,_0x19adc7,0x0));}function expectNumbersClose(_0x1c3ad4,_0x436fad,_0x4374b9){_0x4374b9==null&&(_0x4374b9=testEpsilon());if(!areClose(_0x1c3ad4,_0x436fad,_0x4374b9))throw new Error('Numbers\x20differ:\x20actual\x20===\x20'+_0x1c3ad4+',\x20expected\x20===\x20'+_0x436fad);}function areClose(_0x29a781,_0x2403e5,_0x34e04f){const _0x550fc4=a0_0x20018c;if(!isFinite(_0x29a781)&&!isFinite(_0x2403e5))return!![];if(isNaN(_0x29a781)||isNaN(_0x2403e5)||Math[_0x550fc4(0x596)](_0x29a781-_0x2403e5)>_0x34e04f)return![];return!![];}function expectValuesInRange(_0x5db10f,_0x4f0fe8,_0x121e09){const _0x3b1ad2=a0_0x20018c;for(let _0xbf760d=0x0;_0xbf760d<_0x5db10f[_0x3b1ad2(0x104)];_0xbf760d++){if(_0x5db10f[_0xbf760d]<_0x4f0fe8||_0x5db10f[_0xbf760d]>_0x121e09)throw new Error('Value\x20out\x20of\x20range:'+_0x5db10f[_0xbf760d]+'\x20low:\x20'+_0x4f0fe8+_0x3b1ad2(0x2cf)+_0x121e09);}}function expectArrayBuffersEqual(_0x466cab,_0x425b2a){const _0x234d4c=a0_0x20018c;expect(new Float32Array(_0x466cab))[_0x234d4c(0x329)](new Float32Array(_0x425b2a));}function encodeStrings(_0x34544d){const _0x569e7e=a0_0x20018c;for(let _0x4172b0=0x0;_0x4172b0<_0x34544d[_0x569e7e(0x104)];_0x4172b0++){const _0x42cc0e=_0x34544d[_0x4172b0];Array['isArray'](_0x42cc0e)?encodeStrings(_0x42cc0e):_0x34544d[_0x4172b0]=encodeString(_0x42cc0e);}return _0x34544d;}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
class MPRandGauss{constructor(_0x98d4a5,_0x61dfac,_0xd6d4a2,_0x1d37b3,_0x5426af){const _0x4e40f5=a0_0x20018c;this[_0x4e40f5(0x51e)]=_0x98d4a5,this[_0x4e40f5(0x4b5)]=_0x61dfac,this[_0x4e40f5(0x51c)]=_0xd6d4a2,this['nextVal']=NaN,this[_0x4e40f5(0x328)]=_0x1d37b3;this[_0x4e40f5(0x328)]&&(this[_0x4e40f5(0x2c2)]=this['mean']+this['stdDev']*0x2,this[_0x4e40f5(0x180)]=this[_0x4e40f5(0x51e)]-this[_0x4e40f5(0x4b5)]*0x2);const _0x16ffca=_0x5426af?_0x5426af:Math[_0x4e40f5(0x4ce)]();this[_0x4e40f5(0x4ce)]=seedrandom_1(_0x16ffca[_0x4e40f5(0x499)]());}[a0_0x20018c(0x30c)](){const _0x32daa5=a0_0x20018c;if(!isNaN(this[_0x32daa5(0x5c5)])){const _0x14dbff=this[_0x32daa5(0x5c5)];return this[_0x32daa5(0x5c5)]=NaN,_0x14dbff;}let _0x3c2fd4,_0x49db6e,_0x3d882c=![];while(!_0x3d882c){let _0x521792,_0x474d08,_0x2444f7;do{_0x521792=0x2*this[_0x32daa5(0x4ce)]()-0x1,_0x474d08=0x2*this[_0x32daa5(0x4ce)]()-0x1,_0x2444f7=_0x521792*_0x521792+_0x474d08*_0x474d08;}while(_0x2444f7>=0x1||_0x2444f7===0x0);const _0x2e7466=Math['sqrt'](-0x2*Math['log'](_0x2444f7)/_0x2444f7);_0x3c2fd4=this[_0x32daa5(0x51e)]+this[_0x32daa5(0x4b5)]*_0x521792*_0x2e7466,_0x49db6e=this['mean']+this[_0x32daa5(0x4b5)]*_0x474d08*_0x2e7466,(!this[_0x32daa5(0x328)]||this[_0x32daa5(0x36a)](_0x3c2fd4))&&(_0x3d882c=!![]);}return(!this[_0x32daa5(0x328)]||this['isValidTruncated'](_0x49db6e))&&(this[_0x32daa5(0x5c5)]=this[_0x32daa5(0x4d7)](_0x49db6e)),this[_0x32daa5(0x4d7)](_0x3c2fd4);}[a0_0x20018c(0x4d7)](_0x50ff13){const _0x59980b=a0_0x20018c;if(this['dtype']==null||this[_0x59980b(0x51c)]==='float32')return _0x50ff13;return Math['round'](_0x50ff13);}['isValidTruncated'](_0x583b32){const _0x5ab754=a0_0x20018c;return _0x583b32<=this[_0x5ab754(0x2c2)]&&_0x583b32>=this['lower'];}}class RandGamma{constructor(_0xcbc815,_0x42cd4e,_0x3d37c9,_0x464c04){const _0x907006=a0_0x20018c;this[_0x907006(0x321)]=_0xcbc815,this[_0x907006(0x568)]=0x1/_0x42cd4e,this[_0x907006(0x51c)]=_0x3d37c9;const _0x5847a0=_0x464c04?_0x464c04:Math[_0x907006(0x4ce)]();this['randu']=seedrandom_1(_0x5847a0[_0x907006(0x499)]()),this['randn']=new MPRandGauss(0x0,0x1,_0x3d37c9,![],this[_0x907006(0x3bf)]()),_0xcbc815<0x1?this['d']=_0xcbc815+0x2/0x3:this['d']=_0xcbc815-0x1/0x3,this['c']=0x1/Math[_0x907006(0x106)](0x9*this['d']);}[a0_0x20018c(0x30c)](){const _0x1529b9=a0_0x20018c;let _0x56400c,_0x186845,_0x17aeed,_0x4e03e6,_0x4ada1b,_0x47985f;while(!![]){do{_0x4e03e6=this[_0x1529b9(0x351)][_0x1529b9(0x30c)](),_0x47985f=0x1+this['c']*_0x4e03e6;}while(_0x47985f<=0x0);_0x47985f*=_0x47985f*_0x47985f,_0x56400c=_0x4e03e6*_0x4e03e6,_0x186845=0x1-0.331*_0x56400c*_0x56400c,_0x17aeed=0.5*_0x56400c+this['d']*(0x1-_0x47985f+Math[_0x1529b9(0x4d2)](_0x47985f)),_0x4ada1b=this['randu']();if(_0x4ada1b<_0x186845||Math[_0x1529b9(0x4d2)](_0x4ada1b)<_0x17aeed)break;}return _0x47985f=0x1/this['beta']*this['d']*_0x47985f,this[_0x1529b9(0x321)]<0x1&&(_0x47985f*=Math[_0x1529b9(0xdb)](this[_0x1529b9(0x3bf)](),0x1/this[_0x1529b9(0x321)])),this[_0x1529b9(0x4d7)](_0x47985f);}[a0_0x20018c(0x4d7)](_0x292782){const _0x287f4a=a0_0x20018c;if(this['dtype']===_0x287f4a(0x28b))return _0x292782;return Math[_0x287f4a(0x1f8)](_0x292782);}}class UniformRandom{constructor(_0x44c4f9=0x0,_0x51db08=0x1,_0x77dbfa,_0x411ebd){const _0x41420f=a0_0x20018c;this[_0x41420f(0x5c2)]=()=>this['dtype']==null||this['dtype']==='float32',this[_0x41420f(0x58b)]=_0x44c4f9,this['range']=_0x51db08-_0x44c4f9,this[_0x41420f(0x51c)]=_0x77dbfa;_0x411ebd==null&&(_0x411ebd=Math[_0x41420f(0x4ce)]());typeof _0x411ebd==='number'&&(_0x411ebd=_0x411ebd['toString']());if(!this[_0x41420f(0x5c2)]()&&this[_0x41420f(0x59a)]<=0x1)throw new Error(_0x41420f(0x579)+_0x44c4f9+'\x20-\x20'+_0x51db08+_0x41420f(0x5b6));this[_0x41420f(0x4ce)]=seedrandom_1(_0x411ebd);}[a0_0x20018c(0x4d7)](_0x4603ea){const _0xc7b131=a0_0x20018c;if(this['canReturnFloat']())return _0x4603ea;return Math[_0xc7b131(0x1f8)](_0x4603ea);}['nextValue'](){const _0xdf574f=a0_0x20018c;return this[_0xdf574f(0x4d7)](this[_0xdf574f(0x58b)]+this[_0xdf574f(0x59a)]*this[_0xdf574f(0x4ce)]());}}function jarqueBeraNormalityTest(_0x40bab1){const _0x3d5254=a0_0x20018c,_0x40c6bd=_0x40bab1[_0x3d5254(0x104)],_0x477055=skewness(_0x40bab1),_0x349b7a=kurtosis(_0x40bab1),_0xfeeec7=_0x40c6bd/0x6*(Math[_0x3d5254(0xdb)](_0x477055,0x2)+0.25*Math[_0x3d5254(0xdb)](_0x349b7a-0x3,0x2)),_0x59291c=5.991;if(_0xfeeec7>_0x59291c)throw new Error(_0x3d5254(0x1eb)+_0xfeeec7);}function expectArrayInMeanStdRange(_0x12807e,_0x29ad26,_0x4177d1,_0x5428a2){_0x5428a2==null&&(_0x5428a2=testEpsilon());const _0x5c6852=mean$1(_0x12807e);expectNumbersClose(_0x5c6852,_0x29ad26,_0x5428a2),expectNumbersClose(standardDeviation(_0x12807e,_0x5c6852),_0x4177d1,_0x5428a2);}function mean$1(_0x5e8340){const _0x346a2b=a0_0x20018c;let _0x1adb84=0x0;for(let _0x46f44a=0x0;_0x46f44a<_0x5e8340[_0x346a2b(0x104)];_0x46f44a++){_0x1adb84+=_0x5e8340[_0x46f44a];}return _0x1adb84/_0x5e8340[_0x346a2b(0x104)];}function standardDeviation(_0x224543,_0x339345){const _0x60d497=a0_0x20018c;let _0x153558=0x0;for(let _0x8c7246=0x0;_0x8c7246<_0x224543[_0x60d497(0x104)];_0x8c7246++){const _0x523e7c=_0x224543[_0x8c7246]-_0x339345;_0x153558+=_0x523e7c*_0x523e7c;}return Math['sqrt'](_0x153558/_0x224543[_0x60d497(0x104)]);}function kurtosis(_0x3827da){const _0x4fb161=a0_0x20018c,_0x5273b5=mean$1(_0x3827da),_0x52ea30=_0x3827da[_0x4fb161(0x104)];let _0x59312d=0x0,_0x41c9e2=0x0;for(let _0x233565=0x0;_0x233565<_0x52ea30;_0x233565++){const _0x5b4553=_0x3827da[_0x233565]-_0x5273b5;_0x59312d+=Math['pow'](_0x5b4553,0x2),_0x41c9e2+=Math[_0x4fb161(0xdb)](_0x5b4553,0x4);}return 0x1/_0x52ea30*_0x41c9e2/Math['pow'](0x1/_0x52ea30*_0x59312d,0x2);}function skewness(_0x4283b3){const _0x8053c0=a0_0x20018c,_0x308e3d=mean$1(_0x4283b3),_0x3301ef=_0x4283b3['length'];let _0xcf6bde=0x0,_0x3c909e=0x0;for(let _0x5dcf7c=0x0;_0x5dcf7c<_0x3301ef;_0x5dcf7c++){const _0x52fb93=_0x4283b3[_0x5dcf7c]-_0x308e3d;_0xcf6bde+=Math[_0x8053c0(0xdb)](_0x52fb93,0x2),_0x3c909e+=Math[_0x8053c0(0xdb)](_0x52fb93,0x3);}return 0x1/_0x3301ef*_0x3c909e/Math[_0x8053c0(0xdb)](0x1/(_0x3301ef-0x1)*_0xcf6bde,0x3/0x2);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function randomGamma_(_0x23bec4,_0x4326bf,_0x18cebf=0x1,_0x47027a=a0_0x20018c(0x28b),_0xce7bb9){const _0x349136=a0_0x20018c;_0x18cebf==null&&(_0x18cebf=0x1);_0x47027a==null&&(_0x47027a='float32');if(_0x47027a!==_0x349136(0x28b)&&_0x47027a!==_0x349136(0x4d1))throw new Error(_0x349136(0x371)+_0x47027a);const _0x3c3ff1=new RandGamma(_0x4326bf,_0x18cebf,_0x47027a,_0xce7bb9),_0x3a11b7=buffer(_0x23bec4,_0x47027a);for(let _0x130096=0x0;_0x130096<_0x3a11b7[_0x349136(0x313)]['length'];_0x130096++){_0x3a11b7[_0x349136(0x313)][_0x130096]=_0x3c3ff1[_0x349136(0x30c)]();}return _0x3a11b7[_0x349136(0x21a)]();}const randomGamma=op({'randomGamma_':randomGamma_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function randomNormal_(_0x1f0d39,_0x5ca7f2=0x0,_0x1a2fcc=0x1,_0x40ecd5,_0x3872db){const _0x19589b=a0_0x20018c;if(_0x40ecd5!=null&&_0x40ecd5===_0x19589b(0x188))throw new Error('Unsupported\x20data\x20type\x20'+_0x40ecd5);const _0x2886f7=new MPRandGauss(_0x5ca7f2,_0x1a2fcc,_0x40ecd5,![],_0x3872db),_0x54e16e=buffer(_0x1f0d39,_0x40ecd5);for(let _0x5aa052=0x0;_0x5aa052<_0x54e16e[_0x19589b(0x313)]['length'];_0x5aa052++){_0x54e16e[_0x19589b(0x313)][_0x5aa052]=_0x2886f7[_0x19589b(0x30c)]();}return _0x54e16e['toTensor']();}const randomNormal=op({'randomNormal_':randomNormal_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function randomUniform_(_0x5b226c,_0xbf80d5=0x0,_0xfb7689=0x1,_0x503a5e=a0_0x20018c(0x28b),_0x4667d1){const _0x28033a=a0_0x20018c,_0x5ddcd6=buffer(_0x5b226c,_0x503a5e),_0x1c346c=new UniformRandom(_0xbf80d5,_0xfb7689,null,_0x4667d1);for(let _0x1cad1b=0x0;_0x1cad1b<_0x5ddcd6[_0x28033a(0x313)]['length'];_0x1cad1b++){_0x5ddcd6[_0x28033a(0x313)][_0x1cad1b]=_0x1c346c[_0x28033a(0x30c)]();}return _0x5ddcd6[_0x28033a(0x21a)]();}const randomUniform=op({'randomUniform_':randomUniform_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function range(_0x51c8b3,_0x55c5cc,_0x41b3cf=0x1,_0x4b9e87=a0_0x20018c(0x28b)){const _0x25a5f9=a0_0x20018c;if(_0x41b3cf===0x0)throw new Error(_0x25a5f9(0x215));const _0x2dd6d3={'start':_0x51c8b3,'stop':_0x55c5cc,'step':_0x41b3cf,'dtype':_0x4b9e87};return ENGINE[_0x25a5f9(0x397)](Range,{},_0x2dd6d3);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function real_(_0x3e6919){const _0x4688d2=a0_0x20018c,_0x1379af=convertToTensor(_0x3e6919,_0x4688d2(0x333),_0x4688d2(0x420)),_0x1d31cd={'input':_0x1379af};return ENGINE[_0x4688d2(0x397)](Real,_0x1d31cd);}const real=op({'real_':real_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reciprocal_(_0x5b0ba4){const _0x49c756=convertToTensor(_0x5b0ba4,'x','reciprocal'),_0x4107ac={'x':_0x49c756};return ENGINE['runKernel'](Reciprocal,_0x4107ac);}const reciprocal=op({'reciprocal_':reciprocal_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function relu_(_0x1c6805){const _0x5e93d2=a0_0x20018c,_0x54e76e=convertToTensor(_0x1c6805,'x',_0x5e93d2(0x265)),_0x2786aa={'x':_0x54e76e};return ENGINE[_0x5e93d2(0x397)](Relu,_0x2786aa);}const relu=op({'relu_':relu_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function relu6_(_0x2a7bb4){const _0xa7df69=a0_0x20018c,_0x91f16c=convertToTensor(_0x2a7bb4,'x',_0xa7df69(0x5a0)),_0x160f92={'x':_0x91f16c};return ENGINE[_0xa7df69(0x397)](Relu6,_0x160f92);}const relu6=op({'relu6_':relu6_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reverse1d_(_0x23fda8){const _0xbeccb1=a0_0x20018c,_0x13ccc0=convertToTensor(_0x23fda8,'x',_0xbeccb1(0x48d));return assert(_0x13ccc0[_0xbeccb1(0x36e)]===0x1,()=>_0xbeccb1(0x2c3)+_0x13ccc0[_0xbeccb1(0x36e)]+'.'),reverse(_0x13ccc0,0x0);}const reverse1d=op({'reverse1d_':reverse1d_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reverse2d_(_0x4ddd6b,_0x186113){const _0x5712cc=a0_0x20018c,_0x47a533=convertToTensor(_0x4ddd6b,'x',_0x5712cc(0x48d));return assert(_0x47a533[_0x5712cc(0x36e)]===0x2,()=>'Error\x20in\x20reverse2D:\x20x\x20must\x20be\x20rank\x202\x20but\x20got\x20rank\x20'+_0x47a533[_0x5712cc(0x36e)]+'.'),reverse(_0x47a533,_0x186113);}const reverse2d=op({'reverse2d_':reverse2d_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reverse3d_(_0x5c973a,_0xc689da){const _0x774ef6=a0_0x20018c,_0x1873f2=convertToTensor(_0x5c973a,'x',_0x774ef6(0x48d));return assert(_0x1873f2[_0x774ef6(0x36e)]===0x3,()=>_0x774ef6(0x5cb)+_0x1873f2[_0x774ef6(0x36e)]+'.'),reverse(_0x1873f2,_0xc689da);}const reverse3d=op({'reverse3d_':reverse3d_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function reverse4d_(_0x1bbeba,_0x55ab72){const _0x40aa27=a0_0x20018c,_0x203ae4=convertToTensor(_0x1bbeba,'x',_0x40aa27(0x48d));return assert(_0x203ae4[_0x40aa27(0x36e)]===0x4,()=>_0x40aa27(0x3b5)+_0x203ae4[_0x40aa27(0x36e)]+'.'),reverse(_0x203ae4,_0x55ab72);}const reverse4d=op({'reverse4d_':reverse4d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function round_(_0x50f24b){const _0xcec188=a0_0x20018c,_0x354373=convertToTensor(_0x50f24b,'x',_0xcec188(0x1f8)),_0xfbd69a={'x':_0x354373};return ENGINE['runKernel'](Round,_0xfbd69a);}const round$1=op({'round_':round_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function selu_(_0x701aa3){const _0x324b61=a0_0x20018c,_0x1d5a11=convertToTensor(_0x701aa3,'x',_0x324b61(0xf9)),_0x469ca7={'x':_0x1d5a11};return ENGINE[_0x324b61(0x397)](Selu,_0x469ca7);}const selu=op({'selu_':selu_});function separableConv2d_(_0x1f2dfa,_0x5bec31,_0x979b8a,_0x2a2245,_0x1651a4,_0x1519c5=[0x1,0x1],_0x4aa430='NHWC'){const _0x320bbb=a0_0x20018c,_0x491aff=convertToTensor(_0x1f2dfa,'x','separableConv2d'),_0x3d2832=convertToTensor(_0x5bec31,_0x320bbb(0x529),_0x320bbb(0x3ff)),_0x5dadb5=convertToTensor(_0x979b8a,_0x320bbb(0xef),_0x320bbb(0x3ff));let _0x32509c=_0x491aff,_0x1d780c=![];_0x491aff[_0x320bbb(0x36e)]===0x3&&(_0x1d780c=!![],_0x32509c=reshape(_0x491aff,[0x1,_0x491aff[_0x320bbb(0x50f)][0x0],_0x491aff[_0x320bbb(0x50f)][0x1],_0x491aff[_0x320bbb(0x50f)][0x2]]));if(_0x4aa430===_0x320bbb(0x452))throw new Error('separableConv2d\x20currently\x20does\x20not\x20support\x20dataFormat\x20NCHW;\x20only\x20'+_0x320bbb(0x24f));assert(_0x32509c['rank']===0x4,()=>'Error\x20in\x20separableConv2d:\x20input\x20must\x20be\x20rank\x204,\x20but\x20got\x20'+('rank\x20'+_0x32509c[_0x320bbb(0x36e)]+'.')),assert(_0x3d2832['rank']===0x4,()=>'Error\x20in\x20separableConv2d:\x20depthwise\x20filter\x20must\x20be\x20rank\x204,\x20but\x20'+(_0x320bbb(0x4ff)+_0x3d2832[_0x320bbb(0x36e)]+'.')),assert(_0x5dadb5[_0x320bbb(0x36e)]===0x4,()=>_0x320bbb(0x1fd)+('got\x20rank\x20'+_0x3d2832[_0x320bbb(0x36e)]+'.')),assert(_0x5dadb5['shape'][0x0]===0x1,()=>_0x320bbb(0x12b)+(_0x320bbb(0x485)+_0x5dadb5[_0x320bbb(0x50f)][0x0]+'.')),assert(_0x5dadb5[_0x320bbb(0x50f)][0x1]===0x1,()=>_0x320bbb(0x203)+('filter\x20must\x20be\x201,\x20but\x20got\x20'+_0x5dadb5['shape'][0x1]+'.'));const _0x40ef24=_0x3d2832[_0x320bbb(0x50f)][0x2],_0x299743=_0x3d2832[_0x320bbb(0x50f)][0x3];assert(_0x5dadb5[_0x320bbb(0x50f)][0x2]===_0x40ef24*_0x299743,()=>_0x320bbb(0x22d)+(_0x320bbb(0x35d)+_0x40ef24*_0x299743+',\x20')+(_0x320bbb(0x5b2)+_0x5dadb5[_0x320bbb(0x50f)][0x2]+'.'));const _0x533a97=depthwiseConv2d(_0x32509c,_0x3d2832,_0x2a2245,_0x1651a4,_0x4aa430,_0x1519c5),_0x3361e6=0x1,_0x34a529=conv2d(_0x533a97,_0x5dadb5,_0x3361e6,_0x320bbb(0x5ca),_0x4aa430);if(_0x1d780c)return reshape(_0x34a529,[_0x34a529[_0x320bbb(0x50f)][0x1],_0x34a529[_0x320bbb(0x50f)][0x2],_0x34a529[_0x320bbb(0x50f)][0x3]]);return _0x34a529;}const separableConv2d=op({'separableConv2d_':separableConv2d_});/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function setdiff1dAsync_(_0x289298,_0x284e33){const _0x59ea86=a0_0x20018c,_0x25d6e1=convertToTensor(_0x289298,'x',_0x59ea86(0x2a0)),_0x1862a1=convertToTensor(_0x284e33,'y',_0x59ea86(0x2a0));assert(_0x25d6e1[_0x59ea86(0x51c)]===_0x1862a1[_0x59ea86(0x51c)],()=>_0x59ea86(0x48e)+_0x25d6e1['dtype']+')\x20and\x20y\x20('+_0x1862a1['dtype']+').'),assert(_0x25d6e1[_0x59ea86(0x36e)]===0x1,()=>_0x59ea86(0x4a8)+_0x25d6e1[_0x59ea86(0x50f)]+').'),assert(_0x1862a1[_0x59ea86(0x36e)]===0x1,()=>'y\x20should\x20be\x201D\x20tensor,\x20but\x20got\x20y\x20('+_0x1862a1[_0x59ea86(0x50f)]+').');const _0x75ea8d=await _0x25d6e1['data'](),_0x546f6a=await _0x1862a1['data'](),_0x1eacea=new Set(_0x546f6a);let _0x25c5d5=0x0;for(let _0x5ca1c1=0x0;_0x5ca1c1<_0x75ea8d['length'];_0x5ca1c1++){!_0x1eacea[_0x59ea86(0x18a)](_0x75ea8d[_0x5ca1c1])&&_0x25c5d5++;}const _0xd1433f=new TensorBuffer([_0x25c5d5],_0x25d6e1[_0x59ea86(0x51c)]),_0x2c285b=new TensorBuffer([_0x25c5d5],'int32');for(let _0x38d193=0x0,_0x5db4b1=0x0;_0x38d193<_0x75ea8d[_0x59ea86(0x104)];_0x38d193++){!_0x1eacea[_0x59ea86(0x18a)](_0x75ea8d[_0x38d193])&&(_0xd1433f[_0x59ea86(0x313)][_0x5db4b1]=_0x75ea8d[_0x38d193],_0x2c285b[_0x59ea86(0x313)][_0x5db4b1]=_0x38d193,_0x5db4b1++);}return[_0xd1433f[_0x59ea86(0x21a)](),_0x2c285b[_0x59ea86(0x21a)]()];}const setdiff1dAsync=setdiff1dAsync_;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sign_(_0x4e092f){const _0x31c4b7=a0_0x20018c,_0xd9b0b5=convertToTensor(_0x4e092f,'x',_0x31c4b7(0x232)),_0x433b16={'x':_0xd9b0b5};return ENGINE['runKernel'](Sign,_0x433b16);}const sign=op({'sign_':sign_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function slice1d_(_0x35915f,_0x12f285,_0x23e47a){const _0x40679c=a0_0x20018c,_0x42cf51=convertToTensor(_0x35915f,'x',_0x40679c(0x176));return assert(_0x42cf51[_0x40679c(0x36e)]===0x1,()=>_0x40679c(0x4ee)+_0x42cf51[_0x40679c(0x36e)]+'\x20tensor'),slice(_0x42cf51,[_0x12f285],[_0x23e47a]);}const slice1d=op({'slice1d_':slice1d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function slice2d_(_0x11fdad,_0x51af33,_0x12a662){const _0x2d4d2e=a0_0x20018c,_0x55e0e1=convertToTensor(_0x11fdad,'x',_0x2d4d2e(0x4b0));return assert(_0x55e0e1[_0x2d4d2e(0x36e)]===0x2,()=>_0x2d4d2e(0x4c6)+_0x55e0e1[_0x2d4d2e(0x36e)]+_0x2d4d2e(0x353)),slice(_0x55e0e1,_0x51af33,_0x12a662);}const slice2d=op({'slice2d_':slice2d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function slice3d_(_0x3fab8,_0x521833,_0x2174e9){const _0x190f26=a0_0x20018c,_0x5e2f0f=convertToTensor(_0x3fab8,'x',_0x190f26(0x34e));return assert(_0x5e2f0f['rank']===0x3,()=>_0x190f26(0x3e7)+_0x5e2f0f[_0x190f26(0x36e)]+_0x190f26(0x353)),slice(_0x5e2f0f,_0x521833,_0x2174e9);}const slice3d=op({'slice3d_':slice3d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function slice4d_(_0x4e9c26,_0x358c92,_0x5e904d){const _0x3386a0=a0_0x20018c,_0x215c81=convertToTensor(_0x4e9c26,'x','slice4d');return assert(_0x215c81[_0x3386a0(0x36e)]===0x4,()=>_0x3386a0(0x327)+_0x215c81[_0x3386a0(0x36e)]+_0x3386a0(0x353)),slice(_0x215c81,_0x358c92,_0x5e904d);}const slice4d=op({'slice4d_':slice4d_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function softmax_(_0xe5d8a8,_0x38d02f=-0x1){const _0xaf9960=a0_0x20018c,_0x16f681=convertToTensor(_0xe5d8a8,_0xaf9960(0x5b9),_0xaf9960(0xdc),_0xaf9960(0x28b));_0x38d02f===-0x1&&(_0x38d02f=_0x16f681[_0xaf9960(0x36e)]-0x1);if(_0x38d02f!==_0x16f681[_0xaf9960(0x36e)]-0x1)throw Error(_0xaf9960(0x378)+('Logits\x20was\x20rank\x20'+_0x16f681[_0xaf9960(0x36e)]+_0xaf9960(0x528)+_0x38d02f));const _0x19bc71={'logits':_0x16f681},_0x474ef2={'dim':_0x38d02f};return ENGINE[_0xaf9960(0x397)](Softmax,_0x19bc71,_0x474ef2);}const softmax=op({'softmax_':softmax_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function fft_(_0x1a2d04){const _0x38cb00=a0_0x20018c;assert(_0x1a2d04[_0x38cb00(0x51c)]===_0x38cb00(0xe8),()=>_0x38cb00(0xf7)+('but\x20got\x20'+_0x1a2d04[_0x38cb00(0x51c)]+'.'));const _0x5860d8={'input':_0x1a2d04};return ENGINE[_0x38cb00(0x397)](FFT,_0x5860d8);}const fft=op({'fft_':fft_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function ifft_(_0x286b32){const _0x2d231a=a0_0x20018c;assert(_0x286b32[_0x2d231a(0x51c)]===_0x2d231a(0xe8),()=>_0x2d231a(0x245)+(_0x2d231a(0x5b2)+_0x286b32[_0x2d231a(0x51c)]+'.'));const _0x1c7892={'input':_0x286b32};return ENGINE[_0x2d231a(0x397)](IFFT,_0x1c7892);}const ifft=op({'ifft_':ifft_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function irfft_(_0x301ab2){const _0x12ce0d=a0_0x20018c,_0x54a131=_0x301ab2[_0x12ce0d(0x50f)][_0x301ab2[_0x12ce0d(0x50f)][_0x12ce0d(0x104)]-0x1],_0x1601a0=_0x301ab2['size']/_0x54a131;let _0x2bdb09;if(_0x54a131<=0x2){const _0x5fb1e0=reshape(_0x301ab2,[_0x1601a0,_0x54a131]);_0x2bdb09=ifft(_0x5fb1e0);}else{const _0x5f31dc=[_0x1601a0,0x2*(_0x54a131-0x1)],_0x5cf370=reshape(real(_0x301ab2),[_0x1601a0,_0x54a131]),_0x25f9d2=reshape(imag(_0x301ab2),[_0x1601a0,_0x54a131]),_0x16fc72=reverse(slice(_0x5cf370,[0x0,0x1],[_0x1601a0,_0x54a131-0x2]),0x1),_0x791952=mul(reverse(slice(_0x25f9d2,[0x0,0x1],[_0x1601a0,_0x54a131-0x2]),0x1),scalar(-0x1)),_0x167d74=concat([_0x5cf370,_0x16fc72],0x1),_0x49e3b3=concat([_0x25f9d2,_0x791952],0x1),_0x5b2cb7=reshape(complex(_0x167d74,_0x49e3b3),[_0x5f31dc[0x0],_0x5f31dc[0x1]]);_0x2bdb09=ifft(_0x5b2cb7);}_0x2bdb09=real(_0x2bdb09);if(_0x301ab2[_0x12ce0d(0x36e)]===0x3&&_0x301ab2['shape'][0x0]!==0x0){const _0x119662=_0x2bdb09,_0x522b55=_0x301ab2[_0x12ce0d(0x50f)][0x0];_0x2bdb09=reshape(_0x2bdb09,[_0x522b55,_0x2bdb09[_0x12ce0d(0x50f)][0x0]/_0x522b55,_0x2bdb09[_0x12ce0d(0x50f)][0x1]]),_0x119662[_0x12ce0d(0x47d)]();}return _0x2bdb09;}const irfft=op({'irfft_':irfft_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function rfft_(_0x999763,_0x24d017){const _0xc35bd3=a0_0x20018c;assert(_0x999763['dtype']===_0xc35bd3(0x28b),()=>_0xc35bd3(0x228)+_0x999763[_0xc35bd3(0x51c)]);let _0x5f050c=_0x999763[_0xc35bd3(0x50f)][_0x999763[_0xc35bd3(0x50f)][_0xc35bd3(0x104)]-0x1];const _0xb46f19=_0x999763[_0xc35bd3(0x302)]/_0x5f050c;let _0x5c50fa;if(_0x24d017!=null&&_0x24d017<_0x5f050c){const _0x4df4ea=_0x999763[_0xc35bd3(0x50f)][_0xc35bd3(0x3ab)](_0x4a8c5d=>0x0),_0x5baef6=_0x999763[_0xc35bd3(0x50f)][_0xc35bd3(0x3ab)](_0x2e7cb5=>_0x2e7cb5);_0x5baef6[_0x999763['shape'][_0xc35bd3(0x104)]-0x1]=_0x24d017,_0x5c50fa=slice(_0x999763,_0x4df4ea,_0x5baef6),_0x5f050c=_0x24d017;}else{if(_0x24d017!=null&&_0x24d017>_0x5f050c){const _0xfb84f=_0x999763['shape'][_0xc35bd3(0x3ab)](_0x442a7d=>_0x442a7d);_0xfb84f[_0x999763[_0xc35bd3(0x50f)][_0xc35bd3(0x104)]-0x1]=_0x24d017-_0x5f050c,_0x5c50fa=concat([_0x999763,zeros(_0xfb84f)],_0x999763[_0xc35bd3(0x50f)][_0xc35bd3(0x104)]-0x1),_0x5f050c=_0x24d017;}else _0x5c50fa=_0x999763;}const _0x131a66=zerosLike(_0x5c50fa),_0x27054e=reshape(complex(_0x5c50fa,_0x131a66),[_0xb46f19,_0x5f050c]),_0x3dd578=fft(_0x27054e),_0x1c9b6e=Math['floor'](_0x5f050c/0x2)+0x1,_0x439726=real(_0x3dd578),_0x2ffe11=imag(_0x3dd578),_0x568b5a=split(_0x439726,[_0x1c9b6e,_0x5f050c-_0x1c9b6e],_0x439726['shape'][_0xc35bd3(0x104)]-0x1),_0x337bd1=split(_0x2ffe11,[_0x1c9b6e,_0x5f050c-_0x1c9b6e],_0x2ffe11[_0xc35bd3(0x50f)][_0xc35bd3(0x104)]-0x1),_0x3e09eb=_0x5c50fa[_0xc35bd3(0x50f)][_0xc35bd3(0x2b0)]();return _0x3e09eb[_0x5c50fa[_0xc35bd3(0x50f)][_0xc35bd3(0x104)]-0x1]=_0x1c9b6e,reshape(complex(_0x568b5a[0x0],_0x337bd1[0x0]),_0x3e09eb);}const rfft=op({'rfft_':rfft_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function squaredDifference_(_0x586a65,_0x62116b){const _0x2ba7c1=a0_0x20018c;let _0x11802a=convertToTensor(_0x586a65,'a',_0x2ba7c1(0x330)),_0x35c92b=convertToTensor(_0x62116b,'b',_0x2ba7c1(0x330));[_0x11802a,_0x35c92b]=makeTypesMatch(_0x11802a,_0x35c92b),assertAndGetBroadcastShape(_0x11802a[_0x2ba7c1(0x50f)],_0x35c92b['shape']);const _0x4dfe1a={'a':_0x11802a,'b':_0x35c92b},_0x215c2d={};return ENGINE[_0x2ba7c1(0x397)](SquaredDifference,_0x4dfe1a,_0x215c2d);}const squaredDifference=op({'squaredDifference_':squaredDifference_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function squeeze_(_0xfc9d0a,_0x7cb9c){const _0x42d3f3=a0_0x20018c,_0x1c430a=convertToTensor(_0xfc9d0a,'x',_0x42d3f3(0xf1));return reshape(_0x1c430a,squeezeShape(_0x1c430a[_0x42d3f3(0x50f)],_0x7cb9c)[_0x42d3f3(0x4bf)]);}const squeeze=op({'squeeze_':squeeze_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function stridedSlice_(_0x45954d,_0x58eb29,_0x242e50,_0x3f5dc5,_0x38ba4a=0x0,_0x1f669c=0x0,_0x384898=0x0,_0x595457=0x0,_0x1ff7db=0x0){const _0x445ab6=a0_0x20018c,_0x3ce7b5=convertToTensor(_0x45954d,'x','stridedSlice',_0x445ab6(0x5c4)),_0x5d4b0a={'x':_0x3ce7b5},_0x410af8={'begin':_0x58eb29,'end':_0x242e50,'strides':_0x3f5dc5,'beginMask':_0x38ba4a,'endMask':_0x1f669c,'ellipsisMask':_0x384898,'newAxisMask':_0x595457,'shrinkAxisMask':_0x1ff7db};return ENGINE['runKernel'](StridedSlice,_0x5d4b0a,_0x410af8);}const stridedSlice=op({'stridedSlice_':stridedSlice_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tan_(_0x99143d){const _0x5bb852=a0_0x20018c,_0x490791=convertToTensor(_0x99143d,'x',_0x5bb852(0x376)),_0x30f5ae={'x':_0x490791};return ENGINE[_0x5bb852(0x397)](Tan,_0x30f5ae);}const tan=op({'tan_':tan_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor(_0x15559f,_0x58a863,_0x4a5549){const _0x2ebb4d=inferShape(_0x15559f,_0x4a5549);return makeTensor(_0x15559f,_0x58a863,_0x2ebb4d,_0x4a5549);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor1d(_0x1525d1,_0x172451){const _0x4fea40=a0_0x20018c;assertNonNull(_0x1525d1);const _0x1cf2b8=inferShape(_0x1525d1,_0x172451);if(_0x1cf2b8[_0x4fea40(0x104)]!==0x1)throw new Error(_0x4fea40(0x445));const _0x178b0d=null;return makeTensor(_0x1525d1,_0x178b0d,_0x1cf2b8,_0x172451);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor2d(_0x30528c,_0x11a6a9,_0x3bc2bf){const _0x8fbc1c=a0_0x20018c;assertNonNull(_0x30528c);if(_0x11a6a9!=null&&_0x11a6a9[_0x8fbc1c(0x104)]!==0x2)throw new Error('tensor2d()\x20requires\x20shape\x20to\x20have\x20two\x20numbers');const _0x4d305b=inferShape(_0x30528c,_0x3bc2bf);if(_0x4d305b[_0x8fbc1c(0x104)]!==0x2&&_0x4d305b[_0x8fbc1c(0x104)]!==0x1)throw new Error('tensor2d()\x20requires\x20values\x20to\x20be\x20number[][]\x20or\x20flat/TypedArray');if(_0x4d305b[_0x8fbc1c(0x104)]===0x1&&_0x11a6a9==null)throw new Error('tensor2d()\x20requires\x20shape\x20to\x20be\x20provided\x20when\x20`values`\x20'+_0x8fbc1c(0x244));return makeTensor(_0x30528c,_0x11a6a9,_0x4d305b,_0x3bc2bf);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor3d(_0x11f488,_0x33d23e,_0x366ded){const _0x32a12d=a0_0x20018c;assertNonNull(_0x11f488);if(_0x33d23e!=null&&_0x33d23e[_0x32a12d(0x104)]!==0x3)throw new Error(_0x32a12d(0x44e));const _0x2fbf35=inferShape(_0x11f488,_0x366ded);if(_0x2fbf35[_0x32a12d(0x104)]!==0x3&&_0x2fbf35[_0x32a12d(0x104)]!==0x1)throw new Error(_0x32a12d(0xfc));if(_0x2fbf35['length']===0x1&&_0x33d23e==null)throw new Error('tensor3d()\x20requires\x20shape\x20to\x20be\x20provided\x20when\x20`values`\x20'+_0x32a12d(0x465));return makeTensor(_0x11f488,_0x33d23e,_0x2fbf35,_0x366ded);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor4d(_0x252544,_0x4e9597,_0x400fe7){const _0x3a0830=a0_0x20018c;assertNonNull(_0x252544);if(_0x4e9597!=null&&_0x4e9597[_0x3a0830(0x104)]!==0x4)throw new Error(_0x3a0830(0x196));const _0x43db57=inferShape(_0x252544,_0x400fe7);if(_0x43db57[_0x3a0830(0x104)]!==0x4&&_0x43db57[_0x3a0830(0x104)]!==0x1)throw new Error(_0x3a0830(0x4e4));if(_0x43db57[_0x3a0830(0x104)]===0x1&&_0x4e9597==null)throw new Error(_0x3a0830(0x53a)+_0x3a0830(0x465));return makeTensor(_0x252544,_0x4e9597,_0x43db57,_0x400fe7);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor5d(_0x16bcf9,_0x1f79d3,_0x4ee088){const _0x5e22b7=a0_0x20018c;assertNonNull(_0x16bcf9);if(_0x1f79d3!=null&&_0x1f79d3[_0x5e22b7(0x104)]!==0x5)throw new Error(_0x5e22b7(0x415));const _0x173f08=inferShape(_0x16bcf9,_0x4ee088);if(_0x173f08[_0x5e22b7(0x104)]!==0x5&&_0x173f08[_0x5e22b7(0x104)]!==0x1)throw new Error(_0x5e22b7(0x52d)+_0x5e22b7(0x1bb));if(_0x173f08['length']===0x1&&_0x1f79d3==null)throw new Error(_0x5e22b7(0x22a)+_0x5e22b7(0x465));return makeTensor(_0x16bcf9,_0x1f79d3,_0x173f08,_0x4ee088);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function tensor6d(_0x3d9635,_0x24a2d4,_0x49809d){const _0x285fad=a0_0x20018c;assertNonNull(_0x3d9635);if(_0x24a2d4!=null&&_0x24a2d4[_0x285fad(0x104)]!==0x6)throw new Error(_0x285fad(0x19b));const _0x1183b0=inferShape(_0x3d9635,_0x49809d);if(_0x1183b0['length']!==0x6&&_0x1183b0[_0x285fad(0x104)]!==0x1)throw new Error(_0x285fad(0x33a)+'flat/TypedArray');if(_0x1183b0[_0x285fad(0x104)]===0x1&&_0x24a2d4==null)throw new Error(_0x285fad(0x5d1)+_0x285fad(0x465));return _0x24a2d4=_0x24a2d4||_0x1183b0,makeTensor(_0x3d9635,_0x24a2d4,_0x1183b0,_0x49809d);}function a0_0x367f(_0x27b696,_0x570e90){const _0x8a454=a0_0x8a45();return a0_0x367f=function(_0x367f5e,_0x3f0a02){_0x367f5e=_0x367f5e-0xdb;let _0x53ced4=_0x8a454[_0x367f5e];return _0x53ced4;},a0_0x367f(_0x27b696,_0x570e90);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function topk_(_0x1ace32,_0x29fddd=0x1,_0x34933e=!![]){const _0x2ee4d5=a0_0x20018c,_0x2a7973=convertToTensor(_0x1ace32,'x',_0x2ee4d5(0x53f));if(_0x2a7973['rank']===0x0)throw new Error(_0x2ee4d5(0x483));const _0x2382d9=_0x2a7973[_0x2ee4d5(0x50f)][_0x2a7973['shape'][_0x2ee4d5(0x104)]-0x1];if(_0x29fddd<0x0)throw new Error(_0x2ee4d5(0x5a1)+_0x29fddd);if(_0x29fddd>_0x2382d9)throw new Error('\x27k\x27\x20passed\x20to\x20topk()\x20must\x20be\x20<=\x20the\x20last\x20dimension\x20('+_0x2382d9+')\x20'+(_0x2ee4d5(0x5b2)+_0x29fddd));const _0x12f20e={'x':_0x2a7973},_0x3a4eb7={'k':_0x29fddd,'sorted':_0x34933e},[_0x3d11b0,_0x5a09be]=ENGINE['runKernel'](TopK,_0x12f20e,_0x3a4eb7);return{'values':_0x3d11b0,'indices':_0x5a09be};}const topk=op({'topk_':topk_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function truncatedNormal_(_0xdd17c4,_0x287407=0x0,_0x34396f=0x1,_0x3769a5,_0x45a97f){const _0x7af2b7=a0_0x20018c;if(_0x3769a5!=null&&_0x3769a5===_0x7af2b7(0x188))throw new Error(_0x7af2b7(0x33e));const _0x591fba=new MPRandGauss(_0x287407,_0x34396f,_0x3769a5,!![],_0x45a97f),_0x1b7f6c=buffer(_0xdd17c4,_0x3769a5);for(let _0x48d6f0=0x0;_0x48d6f0<_0x1b7f6c[_0x7af2b7(0x313)][_0x7af2b7(0x104)];_0x48d6f0++){_0x1b7f6c['values'][_0x48d6f0]=_0x591fba['nextValue']();}return _0x1b7f6c['toTensor']();}const truncatedNormal=op({'truncatedNormal_':truncatedNormal_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function unique_(_0x1a7763,_0x20be17=0x0){const _0x269cfe=a0_0x20018c,_0x7f0ed2=convertToTensor(_0x1a7763,'x',_0x269cfe(0x4df),_0x269cfe(0x5c4));assert(_0x7f0ed2[_0x269cfe(0x36e)]>0x0,()=>_0x269cfe(0x408));const _0x1da2a1={'x':_0x7f0ed2},_0x56fd7e={'axis':_0x20be17},[_0x3d278f,_0x431d4a]=ENGINE[_0x269cfe(0x397)](Unique,_0x1da2a1,_0x56fd7e);return{'values':_0x3d278f,'indices':_0x431d4a};}const unique=op({'unique_':unique_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function variable(_0x1d07c4,_0x50525d=!![],_0x56a91d,_0x4d9fb3){const _0x425fd2=a0_0x20018c;return ENGINE[_0x425fd2(0x398)](_0x1d07c4,_0x50525d,_0x56a91d,_0x4d9fb3);}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function whereImpl(_0x5c4cc7,_0xeba5ea){const _0x3b3861=a0_0x20018c,_0x41c1ac=[];for(let _0x6ab05e=0x0;_0x6ab05e<_0xeba5ea[_0x3b3861(0x104)];_0x6ab05e++){_0xeba5ea[_0x6ab05e]&&_0x41c1ac['push'](_0x6ab05e);}const _0x4daa6b=buffer(_0x5c4cc7,_0x3b3861(0x4d1)),_0x1bf124=buffer([_0x41c1ac[_0x3b3861(0x104)],_0x5c4cc7[_0x3b3861(0x104)]],_0x3b3861(0x4d1));for(let _0x2a7332=0x0;_0x2a7332<_0x41c1ac[_0x3b3861(0x104)];_0x2a7332++){const _0x17a147=_0x4daa6b[_0x3b3861(0xe4)](_0x41c1ac[_0x2a7332]),_0x109f1b=_0x2a7332*_0x5c4cc7[_0x3b3861(0x104)];_0x1bf124[_0x3b3861(0x313)][_0x3b3861(0x5a6)](_0x17a147,_0x109f1b);}return _0x1bf124[_0x3b3861(0x21a)]();}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function whereAsync_(_0x5614eb){const _0x5e4fa9=a0_0x20018c,_0x175f35=convertToTensor(_0x5614eb,_0x5e4fa9(0x1a2),_0x5e4fa9(0x4e2),_0x5e4fa9(0x188)),_0x3f6a72=await _0x175f35[_0x5e4fa9(0x186)](),_0x10977=whereImpl(_0x175f35[_0x5e4fa9(0x50f)],_0x3f6a72);return _0x5614eb!==_0x175f35&&_0x175f35[_0x5e4fa9(0x47d)](),_0x10977;}const whereAsync=whereAsync_;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function booleanMaskAsync_(_0x3ae409,_0x460d27,_0x58ff1c){const _0x3eebd1=a0_0x20018c,_0xf854bf=convertToTensor(_0x3ae409,_0x3eebd1(0x324),_0x3eebd1(0x3de)),_0x29f58b=convertToTensor(_0x460d27,'mask',_0x3eebd1(0x3de),_0x3eebd1(0x188)),_0x207513=_0x58ff1c==null?0x0:_0x58ff1c,_0x5c7ae6=_0x29f58b['rank'],_0x9a399f=_0xf854bf['shape'];assert(_0x5c7ae6>0x0,()=>_0x3eebd1(0x10b)),assertShapesMatch(_0x9a399f['slice'](_0x207513,_0x207513+_0x5c7ae6),_0x29f58b[_0x3eebd1(0x50f)],_0x3eebd1(0x223));let _0x4afcc2=0x1;for(let _0x580ac5=_0x207513;_0x580ac5<_0x207513+_0x5c7ae6;_0x580ac5++){_0x4afcc2*=_0x9a399f[_0x580ac5];}const _0xa494b9=_0x9a399f[_0x3eebd1(0x2b0)](0x0,_0x207513)[_0x3eebd1(0x300)]([_0x4afcc2],_0x9a399f[_0x3eebd1(0x2b0)](_0x207513+_0x5c7ae6)),_0x2212e1=reshape(_0xf854bf,_0xa494b9),_0x554c64=reshape(_0x29f58b,[-0x1]),_0x4e47a1=await whereAsync(_0x554c64),_0x342346=squeeze(_0x4e47a1,[0x1]),_0x102a5e=gather(_0x2212e1,_0x342346,_0x207513);return _0x3ae409!==_0xf854bf&&_0xf854bf[_0x3eebd1(0x47d)](),_0x460d27!==_0x29f58b&&_0x29f58b[_0x3eebd1(0x47d)](),_0x342346[_0x3eebd1(0x47d)](),_0x2212e1[_0x3eebd1(0x47d)](),_0x554c64[_0x3eebd1(0x47d)](),_0x4e47a1[_0x3eebd1(0x47d)](),_0x102a5e;}const booleanMaskAsync=booleanMaskAsync_;/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function norm_(_0x2e8d82,_0x5917e4=a0_0x20018c(0x4be),_0x2e1c47=null,_0x52f267=![]){const _0x710a=a0_0x20018c;_0x2e8d82=convertToTensor(_0x2e8d82,'x',_0x710a(0x20d));const _0x1bda81=normImpl(_0x2e8d82,_0x5917e4,_0x2e1c47);let _0x358aa1=_0x1bda81[_0x710a(0x50f)];if(_0x52f267){const _0x560452=parseAxisParam(_0x2e1c47,_0x2e8d82[_0x710a(0x50f)]);_0x358aa1=expandShapeToKeepDim(_0x1bda81[_0x710a(0x50f)],_0x560452);}return reshape(_0x1bda81,_0x358aa1);}function normImpl(_0xab9fbb,_0x4e9072,_0x22588c=null){const _0x32ecd8=a0_0x20018c;if(_0xab9fbb[_0x32ecd8(0x36e)]===0x0)return abs(_0xab9fbb);if(_0xab9fbb[_0x32ecd8(0x36e)]!==0x1&&_0x22588c===null)return normImpl(reshape(_0xab9fbb,[-0x1]),_0x4e9072,_0x22588c);if(_0xab9fbb['rank']===0x1||typeof _0x22588c===_0x32ecd8(0x4ac)||Array[_0x32ecd8(0x576)](_0x22588c)&&_0x22588c[_0x32ecd8(0x104)]===0x1){if(_0x4e9072===0x1)return sum$1(abs(_0xab9fbb),_0x22588c);if(_0x4e9072===Infinity)return max(abs(_0xab9fbb),_0x22588c);if(_0x4e9072===-Infinity)return min(abs(_0xab9fbb),_0x22588c);if(_0x4e9072===_0x32ecd8(0x4be)||_0x4e9072===0x2)return sqrt(sum$1(pow(abs(_0xab9fbb),scalar(0x2,_0x32ecd8(0x4d1))),_0x22588c));throw new Error(_0x32ecd8(0x58e)+_0x4e9072);}if(Array[_0x32ecd8(0x576)](_0x22588c)&&_0x22588c[_0x32ecd8(0x104)]===0x2){if(_0x4e9072===0x1)return max(sum$1(abs(_0xab9fbb),_0x22588c[0x0]),_0x22588c[0x1]-0x1);if(_0x4e9072===Infinity)return max(sum$1(abs(_0xab9fbb),_0x22588c[0x1]),_0x22588c[0x0]);if(_0x4e9072===-Infinity)return min(sum$1(abs(_0xab9fbb),_0x22588c[0x1]),_0x22588c[0x0]);if(_0x4e9072===_0x32ecd8(0x2a3)||_0x4e9072===_0x32ecd8(0x4be))return sqrt(sum$1(square(_0xab9fbb),_0x22588c));throw new Error('Error\x20in\x20norm:\x20invalid\x20ord\x20value:\x20'+_0x4e9072);}throw new Error(_0x32ecd8(0x159)+_0x22588c);}const norm=op({'norm_':norm_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function movingAverage_(_0x43e1e2,_0x20609a,_0x2e92ce,_0x130b10,_0x5769ee=!![]){const _0x155e7c=a0_0x20018c,_0x3208b9=convertToTensor(_0x43e1e2,'v','movingAverage'),_0x54521a=convertToTensor(_0x20609a,'x',_0x155e7c(0x1dd)),_0x5d12b8=convertToTensor(_0x2e92ce,_0x155e7c(0x343),_0x155e7c(0x1dd));assertTypesMatch(_0x3208b9,_0x54521a),assert(arraysEqual(_0x3208b9['shape'],_0x54521a[_0x155e7c(0x50f)]),()=>_0x155e7c(0x598));const _0x3a8789=scalar(0x1),_0x53622b=sub(_0x3a8789,_0x5d12b8);let _0x34bbe2=mul(sub(_0x54521a,_0x3208b9),_0x53622b);if(_0x5769ee){assert(_0x130b10!=null,()=>'When\x20using\x20zeroDebias:\x20true,\x20step\x20is\x20required.');const _0x9a49de=convertToTensor(_0x130b10,_0x155e7c(0x3f8),_0x155e7c(0x1dd));_0x34bbe2=div(_0x34bbe2,sub(_0x3a8789,pow(_0x5d12b8,_0x9a49de)));}return add$1(_0x3208b9,_0x34bbe2);}const movingAverage=op({'movingAverage_':movingAverage_});function validateUpdateShape(_0x3ad839,_0x237095,_0x2ca3f3){const _0x40259b=a0_0x20018c,_0x108d0d=_0x237095[_0x40259b(0x36e)]>0x1?_0x237095[_0x40259b(0x50f)][_0x237095[_0x40259b(0x36e)]-0x1]:0x1,_0x27c429=_0x237095[_0x40259b(0x36e)]>0x1?_0x237095[_0x40259b(0x36e)]-0x1:0x1,_0x571caa=_0x40259b(0x508)+(_0x40259b(0x17b)+_0x2ca3f3[_0x40259b(0x50f)])+(_0x40259b(0x538)+_0x237095[_0x40259b(0x50f)]+_0x40259b(0x21e)+_0x3ad839)+(_0x40259b(0x53d)+_0x108d0d+',\x20and\x20batchDim:\x20'+_0x27c429+'.');if(_0x2ca3f3['rank']<_0x27c429)throw new Error(_0x571caa+('\x20update.rank\x20<\x20'+_0x27c429+'.\x20'));if(_0x3ad839[_0x40259b(0x104)]<_0x108d0d+(_0x2ca3f3[_0x40259b(0x36e)]-_0x27c429))throw new Error(_0x571caa+('\x20Output\x20shape\x20length\x20<\x20'+(_0x108d0d+(_0x2ca3f3['rank']-_0x27c429))));if(_0x2ca3f3[_0x40259b(0x36e)]!==_0x27c429+_0x3ad839[_0x40259b(0x104)]-_0x108d0d)throw new Error(_0x571caa+(_0x40259b(0x2dc)+(_0x27c429+_0x3ad839[_0x40259b(0x104)]-_0x108d0d)));for(let _0x26b583=0x0;_0x26b583<_0x27c429;++_0x26b583){if(_0x2ca3f3[_0x40259b(0x50f)][_0x26b583]!==_0x237095[_0x40259b(0x50f)][_0x26b583])throw new Error(_0x571caa+('\x20updates.shape['+_0x26b583+_0x40259b(0x16a)+_0x2ca3f3[_0x40259b(0x50f)][_0x26b583]+_0x40259b(0x19f)+_0x26b583+_0x40259b(0x16a)+_0x237095[_0x40259b(0x50f)][_0x26b583]+').'));}for(let _0x597c3d=0x0;_0x597c3d<_0x2ca3f3[_0x40259b(0x36e)]-_0x27c429;++_0x597c3d){if(_0x2ca3f3[_0x40259b(0x50f)][_0x597c3d+_0x27c429]!==_0x3ad839[_0x597c3d+_0x108d0d])throw new Error(_0x571caa+(_0x40259b(0x2aa)+(_0x597c3d+_0x27c429)+']\x20('+_0x2ca3f3['shape'][_0x597c3d+_0x27c429]+_0x40259b(0x290)+(_0x597c3d+_0x27c429)+']\x20('+_0x3ad839[_0x597c3d+_0x27c429]+')'));}}function validateInput(_0x84dff8,_0x22799c,_0x32b103){const _0x474fc5=a0_0x20018c;if(_0x22799c[_0x474fc5(0x36e)]<0x1)throw new Error(_0x474fc5(0x1e8)+(_0x474fc5(0x42f)+_0x22799c['rank']+'.'));if(_0x84dff8[_0x474fc5(0x36e)]<0x1)throw new Error(_0x474fc5(0x474)+(_0x474fc5(0x42f)+_0x84dff8[_0x474fc5(0x36e)]+'.'));if(_0x22799c[_0x474fc5(0x51c)]!=='int32')throw new Error(_0x474fc5(0x299)+_0x22799c[_0x474fc5(0x51c)]);if(_0x32b103['length']<0x1)throw new Error('Output\x20rank\x20must\x20be\x20greater\x20or\x20equal\x20to\x201,\x20but\x20got\x20shape:\x20'+_0x32b103);if(_0x32b103[_0x474fc5(0x104)]===0x0){if(_0x22799c[_0x474fc5(0x302)]===0x0)throw new Error(_0x474fc5(0x287)+_0x22799c[_0x474fc5(0x50f)]);if(_0x84dff8[_0x474fc5(0x302)]===0x0)throw new Error(_0x474fc5(0x3af)+_0x84dff8['shape']);}validateUpdateShape(_0x32b103,_0x22799c,_0x84dff8);}function calculateShapes(_0x18a91b,_0x238292,_0x3b9761){const _0x4d6981=a0_0x20018c,_0x274808=_0x238292[_0x4d6981(0x50f)][_0x4d6981(0x104)],_0x14f738=_0x274808>0x1?_0x238292[_0x4d6981(0x50f)][_0x274808-0x1]:0x1,_0x2869bc=_0x3b9761[_0x4d6981(0x104)];let _0x277f07=0x1;for(let _0x376517=_0x14f738;_0x376517<_0x2869bc;++_0x376517){_0x277f07*=_0x3b9761[_0x376517];}const _0x3678e3=_0x14f738<0x1?0x1:_0x14f738,_0x1ef689=sizeFromShape(_0x238292[_0x4d6981(0x50f)])/_0x3678e3,_0x3b1285=[...computeStrides(_0x3b9761[_0x4d6981(0x2b0)](0x0,_0x14f738)),0x1],_0x175ab9=sizeFromShape(_0x3b9761);return{'sliceRank':_0x14f738,'numUpdates':_0x1ef689,'sliceSize':_0x277f07,'strides':_0x3b1285,'outputSize':_0x175ab9};}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function scatterND_(_0x124dcc,_0x1ee836,_0x415eee){const _0x5404d2=a0_0x20018c,_0x2725f3=convertToTensor(_0x124dcc,'indices',_0x5404d2(0x2ac),_0x5404d2(0x4d1)),_0x197d81=convertToTensor(_0x1ee836,_0x5404d2(0x394),_0x5404d2(0x2ac));validateInput(_0x197d81,_0x2725f3,_0x415eee);const _0x3f8062={'indices':_0x2725f3,'updates':_0x197d81},_0x430c82={'shape':_0x415eee};return ENGINE['runKernel'](ScatterNd,_0x3f8062,_0x430c82);}const scatterND=op({'scatterND_':scatterND_});function validateInput$1(_0x52da5a,_0xe2c2b9,_0x29f597,_0x1ce215){const _0x4a3ee1=a0_0x20018c;if(_0x52da5a['dtype']!==_0x4a3ee1(0x4d1))throw new Error('tf.sparseToDense()\x20expects\x20the\x20indices\x20to\x20be\x20int32\x20type,'+(_0x4a3ee1(0x19a)+_0x52da5a[_0x4a3ee1(0x51c)]+'.'));if(_0x52da5a['rank']>0x2)throw new Error(_0x4a3ee1(0x2c1)+(_0x4a3ee1(0x523)+_0x52da5a['shape']+'.'));const _0x4388fc=_0x52da5a[_0x4a3ee1(0x36e)]>0x0?_0x52da5a['shape'][0x0]:0x1,_0xa71b0d=_0x52da5a['rank']>0x1?_0x52da5a[_0x4a3ee1(0x50f)][0x1]:0x1;if(_0x29f597[_0x4a3ee1(0x104)]!==_0xa71b0d)throw new Error('outputShape\x20has\x20incorrect\x20number\x20of\x20elements:,'+('\x20'+_0x29f597[_0x4a3ee1(0x104)]+_0x4a3ee1(0x220)+_0xa71b0d+'.'));const _0x9b7187=_0xe2c2b9[_0x4a3ee1(0x302)];if(!(_0xe2c2b9[_0x4a3ee1(0x36e)]===0x0||_0xe2c2b9['rank']===0x1&&_0x9b7187===_0x4388fc))throw new Error(_0x4a3ee1(0x2e0)+(_0xe2c2b9[_0x4a3ee1(0x50f)]+_0x4a3ee1(0x473)+_0x4388fc+']'));if(_0xe2c2b9[_0x4a3ee1(0x51c)]!==_0x1ce215[_0x4a3ee1(0x51c)])throw new Error(_0x4a3ee1(0x1f7));}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sparseToDense_(_0x8db7b0,_0x336646,_0x436952,_0x127a89=0x0){const _0x6d09bf=a0_0x20018c,_0x32c1b4=convertToTensor(_0x8db7b0,_0x6d09bf(0x278),_0x6d09bf(0x32f),'int32'),_0x564339=convertToTensor(_0x336646,_0x6d09bf(0x461),_0x6d09bf(0x32f)),_0x49877f=convertToTensor(_0x127a89,_0x6d09bf(0x29d),'sparseToDense',_0x564339[_0x6d09bf(0x51c)]);validateInput$1(_0x32c1b4,_0x564339,_0x436952,_0x49877f);const _0x25d40e={'sparseIndices':_0x32c1b4,'sparseValues':_0x564339,'defaultValue':_0x49877f},_0x27f8ec={'outputShape':_0x436952};return ENGINE['runKernel'](SparseToDense,_0x25d40e,_0x27f8ec);}const sparseToDense=op({'sparseToDense_':sparseToDense_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function gatherND_(_0x577c6f,_0x381111){const _0xe017a2=a0_0x20018c,_0x155539=convertToTensor(_0x381111,_0xe017a2(0x402),'gatherND',_0xe017a2(0x4d1)),_0x449d45=convertToTensor(_0x577c6f,'x','gatherND',_0xe017a2(0x5c4)),_0x36e829={'params':_0x449d45,'indices':_0x155539};return ENGINE[_0xe017a2(0x397)](GatherNd,_0x36e829);}const gatherND=op({'gatherND_':gatherND_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function getNoiseShape(_0x1bb20a,_0x4d0131){const _0x359e66=a0_0x20018c;if(_0x4d0131==null)return _0x1bb20a[_0x359e66(0x50f)][_0x359e66(0x2b0)]();if(arraysEqual(_0x1bb20a[_0x359e66(0x50f)],_0x4d0131))return _0x4d0131;if(_0x1bb20a[_0x359e66(0x50f)][_0x359e66(0x104)]===_0x4d0131[_0x359e66(0x104)]){const _0x2998c3=[];for(let _0x1f8269=0x0;_0x1f8269<_0x1bb20a[_0x359e66(0x50f)][_0x359e66(0x104)];_0x1f8269++){_0x4d0131[_0x1f8269]==null&&_0x1bb20a['shape'][_0x1f8269]!=null?_0x2998c3[_0x359e66(0x30f)](_0x1bb20a[_0x359e66(0x50f)][_0x1f8269]):_0x2998c3[_0x359e66(0x30f)](_0x4d0131[_0x1f8269]);}return _0x2998c3;}return _0x4d0131;}/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function dropout_(_0x4fb585,_0x10942b,_0x5aa6d8,_0x269c3b){const _0x4290b8=a0_0x20018c,_0x2bfbe=convertToTensor(_0x4fb585,'x','dropout');assert(_0x2bfbe['dtype']===_0x4290b8(0x28b),()=>'x\x20has\x20to\x20be\x20a\x20floating\x20point\x20tensor\x20since\x20it\x27s\x20going\x20to\x20be\x20'+('scaled,\x20but\x20got\x20a\x20'+_0x2bfbe[_0x4290b8(0x51c)]+_0x4290b8(0x3cd))),assert(_0x10942b>=0x0&&_0x10942b<0x1,()=>_0x4290b8(0x1e3)+_0x10942b+'.');if(_0x10942b===0x0)return _0x4fb585 instanceof Tensor?_0x2bfbe[_0x4290b8(0x49d)]():_0x2bfbe;const _0x4513da=getNoiseShape(_0x2bfbe,_0x5aa6d8),_0x52ac7c=0x1-_0x10942b,_0x1739ee=div(floor(add$1(randomUniform(_0x4513da,0x0,0x1,_0x4290b8(0x28b),_0x269c3b),_0x52ac7c)),_0x52ac7c);return mul(_0x2bfbe,_0x1739ee);}const dropout=op({'dropout_':dropout_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function enclosingPowerOfTwo(_0x58fdef){const _0x152d1a=a0_0x20018c;return Math['floor'](Math['pow'](0x2,Math[_0x152d1a(0x4a7)](Math[_0x152d1a(0x4d2)](_0x58fdef)/Math['log'](0x2))));}function cosineWindow(_0x2e872d,_0x17c499,_0x60da65){const _0x2007d0=0x1-_0x2e872d%0x2,_0x59bae1=new Float32Array(_0x2e872d);for(let _0x37dc7f=0x0;_0x37dc7f<_0x2e872d;++_0x37dc7f){const _0x27beae=0x2*Math['PI']*_0x37dc7f/(_0x2e872d+_0x2007d0-0x1);_0x59bae1[_0x37dc7f]=_0x17c499-_0x60da65*Math['cos'](_0x27beae);}return tensor1d(_0x59bae1,'float32');}/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function inTopKAsync_(_0xefb8ca,_0x511db4,_0x8d212=0x1){const _0x4bc770=a0_0x20018c,_0x57fa3e=convertToTensor(_0xefb8ca,'predictions',_0x4bc770(0x21b)),_0x5b39f4=convertToTensor(_0x511db4,'targets',_0x4bc770(0x21b));assert(_0x57fa3e[_0x4bc770(0x36e)]>0x1,()=>_0x4bc770(0x487)+(_0x4bc770(0x5b2)+_0x57fa3e[_0x4bc770(0x36e)])),assert(_0x57fa3e[_0x4bc770(0x36e)]-0x1===_0x5b39f4[_0x4bc770(0x36e)],()=>'predictions\x20rank\x20should\x20be\x201\x20larger\x20than\x20'+_0x4bc770(0x169)+(_0x57fa3e[_0x4bc770(0x36e)]+_0x4bc770(0x44b)+_0x5b39f4[_0x4bc770(0x36e)])),assertShapesMatch(_0x57fa3e['shape'][_0x4bc770(0x2b0)](0x0,_0x57fa3e[_0x4bc770(0x50f)][_0x4bc770(0x104)]-0x1),_0x5b39f4[_0x4bc770(0x50f)],'predictions\x27s\x20shape\x20should\x20be\x20align\x20with\x20the\x20targets\x27\x20shape,\x20'+_0x4bc770(0x323));const _0x3c314d=_0x57fa3e['shape'][_0x57fa3e[_0x4bc770(0x50f)]['length']-0x1];assert(_0x8d212>0x0&&_0x8d212<=_0x3c314d,()=>'\x27k\x27\x20passed\x20to\x20inTopK()\x20must\x20be\x20>\x200\x20&&\x20<=\x20the\x20predictions\x20last\x20'+(_0x4bc770(0x496)+_0x3c314d+_0x4bc770(0x181)+_0x8d212));const _0x2cc974=await _0x57fa3e[_0x4bc770(0x186)](),_0x17d307=await _0x5b39f4[_0x4bc770(0x186)](),[_0x4ff27b,_0x52bb55]=[_0x2cc974[_0x4bc770(0x104)]/_0x3c314d,_0x3c314d],_0x5869b0=getTypedArrayFromDType(_0x4bc770(0x188),_0x4ff27b);for(let _0x71218=0x0;_0x71218<_0x4ff27b;_0x71218++){const _0x1cf262=_0x71218*_0x52bb55,_0x416f8c=_0x2cc974[_0x4bc770(0x1be)](_0x1cf262,_0x1cf262+_0x52bb55),_0x9bb1f2=[];for(let _0x3c39b4=0x0;_0x3c39b4<_0x416f8c[_0x4bc770(0x104)];_0x3c39b4++){_0x9bb1f2[_0x4bc770(0x30f)]({'value':_0x416f8c[_0x3c39b4],'index':_0x3c39b4});}_0x9bb1f2[_0x4bc770(0x2f6)]((_0x7e8cf0,_0x2d0ab3)=>_0x2d0ab3[_0x4bc770(0x238)]-_0x7e8cf0[_0x4bc770(0x238)]),_0x5869b0[_0x71218]=0x0;for(let _0x568b4a=0x0;_0x568b4a<_0x8d212;_0x568b4a++){if(_0x9bb1f2[_0x568b4a][_0x4bc770(0x385)]===_0x17d307[_0x71218]){_0x5869b0[_0x71218]=0x1;break;}}}return _0xefb8ca!==_0x57fa3e&&_0x57fa3e[_0x4bc770(0x47d)](),_0x511db4!==_0x5b39f4&&_0x5b39f4[_0x4bc770(0x47d)](),tensor(_0x5869b0,_0x5b39f4[_0x4bc770(0x50f)],_0x4bc770(0x188));}const inTopKAsync=inTopKAsync_;/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function getFusedDyActivation(_0x54b60a,_0x23eb82,_0x47196f){const _0x9b7594=a0_0x20018c;if(_0x47196f==null||_0x47196f==='linear')return _0x54b60a;if(_0x47196f===_0x9b7594(0x265))return mul(_0x54b60a,step(_0x23eb82));throw new Error(_0x9b7594(0x2b3)+_0x47196f+'.');}function getFusedBiasGradient(_0x53e3a0,_0xc9cf7b){const _0x3cc6ad=a0_0x20018c;let _0x216a63=_0xc9cf7b;const _0x162b4a=getReductionAxes(_0x53e3a0[_0x3cc6ad(0x50f)],_0xc9cf7b[_0x3cc6ad(0x50f)]);return _0x162b4a[_0x3cc6ad(0x104)]>0x0&&(_0x216a63=sum$1(_0x216a63,_0x162b4a)),reshape(_0x216a63,_0x53e3a0[_0x3cc6ad(0x50f)]);}function applyActivation(_0x56ad75,_0x2c95ee,_0x1bd25d,_0x3c4b9e){const _0x4a79aa=a0_0x20018c;if(_0x2c95ee===_0x4a79aa(0x26d))return _0x56ad75;else{if(_0x2c95ee===_0x4a79aa(0x265))return relu(_0x56ad75);else{if(_0x2c95ee==='elu')return elu(_0x56ad75);else{if(_0x2c95ee==='relu6')return relu6(_0x56ad75);else{if(_0x2c95ee===_0x4a79aa(0x337))return prelu(_0x56ad75,_0x1bd25d);else{if(_0x2c95ee===_0x4a79aa(0x3dc))return leakyRelu(_0x56ad75,_0x3c4b9e);else{if(_0x2c95ee===_0x4a79aa(0x41f))return sigmoid(_0x56ad75);}}}}}}throw new Error(_0x4a79aa(0x43e)+_0x2c95ee+'.');}const shouldFuse=(_0x41c86a,_0x550da8)=>{const _0x301805=_0x41c86a>0x0;return!_0x301805||_0x550da8==='linear';};/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function fusedConv2d_({x:_0x4c95e8,filter:_0x51a160,strides:_0x5eab1f,pad:_0x4d925b,dataFormat:dataFormat=a0_0x20018c(0x4c9),dilations:dilations=[0x1,0x1],dimRoundingMode:_0xed5f5c,bias:_0xc39b38,activation:activation=a0_0x20018c(0x26d),preluActivationWeights:_0x4933db,leakyreluAlpha:_0x25c0fe}){const _0x1fe9cf=a0_0x20018c;activation=activation||_0x1fe9cf(0x26d);if(shouldFuse(ENGINE[_0x1fe9cf(0x23a)][_0x1fe9cf(0x1c8)],activation)===![]){let _0xcc1eff=conv2d(_0x4c95e8,_0x51a160,_0x5eab1f,_0x4d925b,dataFormat,dilations,_0xed5f5c);return _0xc39b38!=null&&(_0xcc1eff=add$1(_0xcc1eff,_0xc39b38)),applyActivation(_0xcc1eff,activation,_0x4933db,_0x25c0fe);}const _0x561f22=convertToTensor(_0x4c95e8,'x',_0x1fe9cf(0x1a1)),_0x52187b=convertToTensor(_0x51a160,'filter',_0x1fe9cf(0x1a1));let _0x5c443a=_0x561f22,_0x2fe351=![];_0x561f22[_0x1fe9cf(0x36e)]===0x3&&(_0x2fe351=!![],_0x5c443a=reshape(_0x561f22,[0x1,_0x561f22['shape'][0x0],_0x561f22[_0x1fe9cf(0x50f)][0x1],_0x561f22['shape'][0x2]]));assert(_0x5c443a[_0x1fe9cf(0x36e)]===0x4,()=>_0x1fe9cf(0x467)+(_0x5c443a['rank']+'.')),assert(_0x52187b[_0x1fe9cf(0x36e)]===0x4,()=>_0x1fe9cf(0x427)+(_0x52187b[_0x1fe9cf(0x36e)]+'.'));_0xed5f5c!=null&&assert(isInt(_0x4d925b),()=>'Error\x20in\x20fused\x20conv2d:\x20pad\x20must\x20be\x20an\x20integer\x20when\x20using,\x20'+('dimRoundingMode\x20'+_0xed5f5c+_0x1fe9cf(0x27d)+_0x4d925b+'.'));assert(_0x5c443a[_0x1fe9cf(0x50f)][0x3]===_0x52187b[_0x1fe9cf(0x50f)][0x2],()=>'Error\x20in\x20conv2d:\x20depth\x20of\x20input\x20('+_0x5c443a[_0x1fe9cf(0x50f)][0x3]+_0x1fe9cf(0x4e3)+(_0x1fe9cf(0x2f5)+_0x52187b[_0x1fe9cf(0x50f)][0x2]+'.')),assert(eitherStridesOrDilationsAreOne(_0x5eab1f,dilations),()=>_0x1fe9cf(0x3a7)+(_0x1fe9cf(0x54f)+_0x5eab1f+_0x1fe9cf(0x4b9)+dilations+'\x27')),assert(dataFormat===_0x1fe9cf(0x4c9),()=>_0x1fe9cf(0x49a)+dataFormat+_0x1fe9cf(0x124));const _0x1bbe41=computeConv2DInfo(_0x5c443a[_0x1fe9cf(0x50f)],_0x52187b['shape'],_0x5eab1f,dilations,_0x4d925b,_0xed5f5c);let _0x5a5be0;_0xc39b38!=null&&(_0x5a5be0=convertToTensor(_0xc39b38,_0x1fe9cf(0x2c0),'fused\x20conv2d'),[_0x5a5be0]=makeTypesMatch(_0x5a5be0,_0x561f22),assertAndGetBroadcastShape(_0x1bbe41['outShape'],_0x5a5be0['shape']));let _0x80d253;_0x4933db!=null&&(_0x80d253=convertToTensor(_0x4933db,_0x1fe9cf(0x5bc),_0x1fe9cf(0x484)));const _0x2b58ec=(_0x134e45,_0x11b9a2)=>{const _0x419417=_0x1fe9cf,[_0x1c4eb1,_0x5b9e09,_0x1a1e45,_0x4328d3]=_0x11b9a2,_0x31c580=getFusedDyActivation(_0x134e45,_0x1a1e45,activation);assert(tupleValuesAreOne(dilations),()=>_0x419417(0x18b)+_0x419417(0x54d)+('are\x20not\x20yet\x20supported\x20in\x20gradients.\x20Got\x20dilations\x20\x27'+dilations+'\x27'));const _0x34df38=conv2DBackpropInput(_0x5b9e09[_0x419417(0x50f)],_0x31c580,_0x1c4eb1,_0x5eab1f,_0x4d925b),_0x3521bf=conv2DBackpropFilter(_0x5b9e09,_0x31c580,_0x1c4eb1[_0x419417(0x50f)],_0x5eab1f,_0x4d925b),_0x4500dd=[_0x34df38,_0x3521bf];if(_0x4328d3!=null){const _0x1653ad=getFusedBiasGradient(_0x4328d3,_0x31c580);_0x4500dd[_0x419417(0x30f)](_0x1653ad);}return _0x4500dd;},_0x1e0075={'x':_0x5c443a,'filter':_0x52187b,'bias':_0x5a5be0,'preluActivationWeights':_0x80d253},_0x460909={'strides':_0x5eab1f,'pad':_0x4d925b,'dataFormat':dataFormat,'dilations':dilations,'dimRoundingMode':_0xed5f5c,'activation':activation,'leakyreluAlpha':_0x25c0fe};if(_0xc39b38==null){const _0x3c6f10=customGrad((_0x2d999a,_0x222ba0,_0x3f7566)=>{const _0x5e450e=_0x1fe9cf;let _0x4bb320=ENGINE['runKernel'](FusedConv2D,_0x1e0075,_0x460909);return _0x3f7566([_0x222ba0,_0x2d999a,_0x4bb320]),_0x2fe351&&(_0x4bb320=reshape(_0x4bb320,[_0x4bb320[_0x5e450e(0x50f)][0x1],_0x4bb320[_0x5e450e(0x50f)][0x2],_0x4bb320[_0x5e450e(0x50f)][0x3]])),{'value':_0x4bb320,'gradFunc':_0x2b58ec};});return _0x3c6f10(_0x5c443a,_0x52187b);}else{const _0x254c3d=customGrad((_0x4b00b9,_0x3f1dda,_0x12c041,_0x1fe1fd)=>{const _0xfe3bca=_0x1fe9cf;let _0x36a20f=ENGINE['runKernel'](FusedConv2D,_0x1e0075,_0x460909);return _0x1fe1fd([_0x3f1dda,_0x4b00b9,_0x36a20f,_0x12c041]),_0x2fe351&&(_0x36a20f=reshape(_0x36a20f,[_0x36a20f['shape'][0x1],_0x36a20f['shape'][0x2],_0x36a20f[_0xfe3bca(0x50f)][0x3]])),{'value':_0x36a20f,'gradFunc':_0x2b58ec};});return _0x254c3d(_0x5c443a,_0x52187b,_0x5a5be0);}}const conv2d$1=op({'fusedConv2d_':fusedConv2d_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function fusedDepthwiseConv2d_({x:_0x101406,filter:_0x463568,strides:_0x4498f7,pad:_0x21d7e8,dataFormat:dataFormat=a0_0x20018c(0x4c9),dilations:dilations=[0x1,0x1],dimRoundingMode:_0xf7de38,bias:_0x17dcd2,activation:activation='linear',preluActivationWeights:_0x55b8a2,leakyreluAlpha:_0x3815cc}){const _0x355bb8=a0_0x20018c;if(shouldFuse(ENGINE[_0x355bb8(0x23a)][_0x355bb8(0x1c8)],activation)===![]){let _0x337fd3=depthwiseConv2d(_0x101406,_0x463568,_0x4498f7,_0x21d7e8,dataFormat,dilations,_0xf7de38);return _0x17dcd2!=null&&(_0x337fd3=add$1(_0x337fd3,_0x17dcd2)),applyActivation(_0x337fd3,activation,_0x55b8a2,_0x3815cc);}const _0x897af9=convertToTensor(_0x101406,'x','depthwiseConv2d'),_0x1b7332=convertToTensor(_0x463568,'filter','depthwiseConv2d');let _0x3f4f27=_0x897af9,_0x1dea91=![];_0x897af9[_0x355bb8(0x36e)]===0x3&&(_0x1dea91=!![],_0x3f4f27=reshape(_0x897af9,[0x1,_0x897af9[_0x355bb8(0x50f)][0x0],_0x897af9[_0x355bb8(0x50f)][0x1],_0x897af9['shape'][0x2]]));assert(_0x3f4f27[_0x355bb8(0x36e)]===0x4,()=>_0x355bb8(0x1ad)+(_0x355bb8(0x5b5)+_0x3f4f27[_0x355bb8(0x36e)]+'.')),assert(_0x1b7332[_0x355bb8(0x36e)]===0x4,()=>'Error\x20in\x20fused\x20depthwiseConv2d:\x20filter\x20must\x20be\x20rank\x204,\x20'+(_0x355bb8(0x283)+_0x1b7332['rank']+'.')),assert(_0x3f4f27['shape'][0x3]===_0x1b7332[_0x355bb8(0x50f)][0x2],()=>_0x355bb8(0x412)+('('+_0x3f4f27[_0x355bb8(0x50f)][0x3]+_0x355bb8(0x407))+(_0x355bb8(0x52f)+_0x1b7332[_0x355bb8(0x50f)][0x2]+'.'));dilations==null&&(dilations=[0x1,0x1]);assert(eitherStridesOrDilationsAreOne(_0x4498f7,dilations),()=>_0x355bb8(0x50a)+(_0x355bb8(0x373)+_0x4498f7+'\x20and\x20dilations\x20\x27'+dilations+'\x27'));_0xf7de38!=null&&assert(isInt(_0x21d7e8),()=>_0x355bb8(0x11a)+('using\x20dimRoundingMode\x20'+_0xf7de38+_0x355bb8(0x27d)+_0x21d7e8+'.'));const _0x49322b=computeConv2DInfo(_0x3f4f27[_0x355bb8(0x50f)],_0x1b7332[_0x355bb8(0x50f)],_0x4498f7,dilations,_0x21d7e8,_0xf7de38,!![]);let _0x1a0bd8;_0x17dcd2!=null&&(_0x1a0bd8=convertToTensor(_0x17dcd2,'bias','fused\x20conv2d'),[_0x1a0bd8]=makeTypesMatch(_0x1a0bd8,_0x897af9),assertAndGetBroadcastShape(_0x49322b['outShape'],_0x1a0bd8[_0x355bb8(0x50f)]));let _0x14c8df;_0x55b8a2!=null&&(_0x14c8df=convertToTensor(_0x55b8a2,_0x355bb8(0x5bc),_0x355bb8(0x2af)));const _0x6b30db=(_0x4b3f28,_0x32cdbc)=>{const _0xfa27b2=_0x355bb8;assert(tupleValuesAreOne(dilations),()=>_0xfa27b2(0xfb)+_0xfa27b2(0x138)+('\x27'+dilations+'\x27'));const [_0x4ad7d8,_0x4ed1be,_0x28c061,_0x3ca0ff]=_0x32cdbc,_0x12b611=getFusedDyActivation(_0x4b3f28,_0x28c061,activation),_0x2f549f=depthwiseConv2dNativeBackpropInput(_0x4ed1be[_0xfa27b2(0x50f)],_0x12b611,_0x4ad7d8,_0x4498f7,_0x21d7e8,dilations,_0xf7de38),_0x58e96f=depthwiseConv2dNativeBackpropFilter(_0x4ed1be,_0x12b611,_0x4ad7d8['shape'],_0x4498f7,_0x21d7e8,dilations,_0xf7de38);if(_0x3ca0ff!=null){const _0x16d51c=getFusedBiasGradient(_0x1a0bd8,_0x12b611);return[_0x2f549f,_0x58e96f,_0x16d51c];}return[_0x2f549f,_0x58e96f];},_0x4762c7={'x':_0x3f4f27,'filter':_0x1b7332,'bias':_0x1a0bd8,'preluActivationWeights':_0x14c8df},_0x26bb60={'strides':_0x4498f7,'pad':_0x21d7e8,'dataFormat':dataFormat,'dilations':dilations,'dimRoundingMode':_0xf7de38,'activation':activation,'leakyreluAlpha':_0x3815cc};if(_0x17dcd2==null){const _0x53c15e=customGrad((_0x314d5b,_0x49ee86,_0xb318d0)=>{const _0x529f42=_0x355bb8;let _0x68e479=ENGINE['runKernel'](FusedDepthwiseConv2D,_0x4762c7,_0x26bb60);return _0xb318d0([_0x49ee86,_0x314d5b,_0x68e479]),_0x1dea91&&(_0x68e479=reshape(_0x68e479,[_0x68e479[_0x529f42(0x50f)][0x1],_0x68e479['shape'][0x2],_0x68e479[_0x529f42(0x50f)][0x3]])),{'value':_0x68e479,'gradFunc':_0x6b30db};});return _0x53c15e(_0x3f4f27,_0x1b7332);}else{const _0x5d7189=customGrad((_0x35cb5d,_0x4cf78a,_0x58d3b6,_0x42c552)=>{const _0x5d273d=_0x355bb8;let _0x3bd0db=ENGINE[_0x5d273d(0x397)](FusedDepthwiseConv2D,_0x4762c7,_0x26bb60);return _0x42c552([_0x4cf78a,_0x35cb5d,_0x3bd0db,_0x58d3b6]),_0x1dea91&&(_0x3bd0db=reshape(_0x3bd0db,[_0x3bd0db[_0x5d273d(0x50f)][0x1],_0x3bd0db[_0x5d273d(0x50f)][0x2],_0x3bd0db[_0x5d273d(0x50f)][0x3]])),{'value':_0x3bd0db,'gradFunc':_0x6b30db};});return _0x5d7189(_0x3f4f27,_0x1b7332,_0x1a0bd8);}}const depthwiseConv2d$1=op({'fusedDepthwiseConv2d_':fusedDepthwiseConv2d_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function fusedMatMul_({a:_0xd43cbc,b:_0x3d24b5,transposeA:transposeA=![],transposeB:transposeB=![],bias:_0x118877,activation:activation=a0_0x20018c(0x26d),preluActivationWeights:_0x563542,leakyreluAlpha:_0x1f7ea0}){const _0x11a602=a0_0x20018c;if(shouldFuse(ENGINE[_0x11a602(0x23a)][_0x11a602(0x1c8)],activation)===![]){let _0x38c3ee=matMul(_0xd43cbc,_0x3d24b5,transposeA,transposeB);return _0x118877!=null&&(_0x38c3ee=add$1(_0x38c3ee,_0x118877)),applyActivation(_0x38c3ee,activation,_0x563542,_0x1f7ea0);}let _0x3a0e39=convertToTensor(_0xd43cbc,'a',_0x11a602(0x591)),_0x4b63b0=convertToTensor(_0x3d24b5,'b',_0x11a602(0x591));[_0x3a0e39,_0x4b63b0]=makeTypesMatch(_0x3a0e39,_0x4b63b0);const _0x344d78=transposeA?_0x3a0e39[_0x11a602(0x50f)][_0x3a0e39[_0x11a602(0x36e)]-0x2]:_0x3a0e39['shape'][_0x3a0e39[_0x11a602(0x36e)]-0x1],_0x5717d1=transposeB?_0x4b63b0[_0x11a602(0x50f)][_0x4b63b0[_0x11a602(0x36e)]-0x1]:_0x4b63b0['shape'][_0x4b63b0[_0x11a602(0x36e)]-0x2],_0x22cd05=transposeA?_0x3a0e39[_0x11a602(0x50f)][_0x3a0e39[_0x11a602(0x36e)]-0x1]:_0x3a0e39[_0x11a602(0x50f)][_0x3a0e39[_0x11a602(0x36e)]-0x2],_0x542972=transposeB?_0x4b63b0[_0x11a602(0x50f)][_0x4b63b0[_0x11a602(0x36e)]-0x2]:_0x4b63b0[_0x11a602(0x50f)][_0x4b63b0[_0x11a602(0x36e)]-0x1],_0xf11dfd=_0x3a0e39[_0x11a602(0x50f)][_0x11a602(0x2b0)](0x0,-0x2),_0x12f5c0=_0x4b63b0[_0x11a602(0x50f)][_0x11a602(0x2b0)](0x0,-0x2),_0xa454f8=sizeFromShape(_0xf11dfd),_0x506cb1=sizeFromShape(_0x12f5c0);assert(_0x3a0e39[_0x11a602(0x36e)]>=0x2&&_0x4b63b0[_0x11a602(0x36e)]>=0x2&&_0x3a0e39[_0x11a602(0x36e)]===_0x4b63b0[_0x11a602(0x36e)],()=>_0x11a602(0x55d)+(_0x11a602(0x587)+_0x3a0e39['rank']+'\x20and\x20'+_0x4b63b0[_0x11a602(0x36e)]+'.')),assert(arraysEqual(_0xf11dfd,_0x12f5c0),()=>_0x11a602(0x225)+_0xf11dfd+_0x11a602(0x472)+(_0x12f5c0+')\x20of\x20Tensors\x20with\x20shapes\x20'+_0x3a0e39[_0x11a602(0x50f)]+_0x11a602(0x1de))+(_0x4b63b0['shape']+_0x11a602(0x40e))),assert(_0x344d78===_0x5717d1,()=>_0x11a602(0x55e)+_0x344d78+_0x11a602(0x472)+(_0x5717d1+_0x11a602(0x428)+_0x3a0e39[_0x11a602(0x50f)]+_0x11a602(0x1de))+(_0x4b63b0[_0x11a602(0x50f)]+_0x11a602(0x489)+transposeA)+(_0x11a602(0x2a4)+transposeB+_0x11a602(0x40e)));const _0x3ee5ab=_0x3a0e39[_0x11a602(0x50f)]['slice'](0x0,-0x2)[_0x11a602(0x300)]([_0x22cd05,_0x542972]),_0x5e2682=transposeA?reshape(_0x3a0e39,[_0xa454f8,_0x344d78,_0x22cd05]):reshape(_0x3a0e39,[_0xa454f8,_0x22cd05,_0x344d78]),_0x2ce5d7=transposeB?reshape(_0x4b63b0,[_0x506cb1,_0x542972,_0x5717d1]):reshape(_0x4b63b0,[_0x506cb1,_0x5717d1,_0x542972]);let _0x5de1ec;_0x118877!=null&&(_0x5de1ec=convertToTensor(_0x118877,_0x11a602(0x2c0),_0x11a602(0x591)),[_0x5de1ec]=makeTypesMatch(_0x5de1ec,_0x3a0e39),assertAndGetBroadcastShape(_0x3ee5ab,_0x5de1ec['shape']));let _0x56a4a0;_0x563542!=null&&(_0x56a4a0=convertToTensor(_0x563542,_0x11a602(0x5bc),_0x11a602(0x591)));const _0x46fe73=(_0x19cfb5,_0x5dfed5)=>{const _0x2ade0d=_0x11a602,[_0x52a08c,_0x1a7beb,_0x10340b,_0x3c9ba3]=_0x5dfed5,_0x4aaf6f=getFusedDyActivation(reshape(_0x19cfb5,_0x10340b[_0x2ade0d(0x50f)]),_0x10340b,activation);let _0x2e0d1f,_0x1d3c85;if(!transposeA&&!transposeB)_0x2e0d1f=matMul(_0x4aaf6f,_0x1a7beb,![],!![]),_0x1d3c85=matMul(_0x52a08c,_0x4aaf6f,!![],![]);else{if(!transposeA&&transposeB)_0x2e0d1f=matMul(_0x4aaf6f,_0x1a7beb,![],![]),_0x1d3c85=matMul(_0x4aaf6f,_0x52a08c,!![],![]);else transposeA&&!transposeB?(_0x2e0d1f=matMul(_0x1a7beb,_0x4aaf6f,![],!![]),_0x1d3c85=matMul(_0x52a08c,_0x4aaf6f,![],![])):(_0x2e0d1f=matMul(_0x1a7beb,_0x4aaf6f,!![],!![]),_0x1d3c85=matMul(_0x4aaf6f,_0x52a08c,!![],!![]));}if(_0x118877!=null){const _0x101a5b=getFusedBiasGradient(_0x3c9ba3,_0x4aaf6f);return[_0x2e0d1f,_0x1d3c85,_0x101a5b];}else return[_0x2e0d1f,_0x1d3c85];},_0x21942b={'a':_0x5e2682,'b':_0x2ce5d7,'bias':_0x5de1ec,'preluActivationWeights':_0x56a4a0},_0x152308={'transposeA':transposeA,'transposeB':transposeB,'activation':activation,'leakyreluAlpha':_0x1f7ea0};if(_0x118877==null){const _0x5bbd97=customGrad((_0x98f759,_0x4743ea,_0x44ba2f)=>{const _0x5b84f1=ENGINE['runKernel'](_FusedMatMul,_0x21942b,_0x152308);return _0x44ba2f([_0x98f759,_0x4743ea,_0x5b84f1]),{'value':reshape(_0x5b84f1,_0x3ee5ab),'gradFunc':_0x46fe73};});return _0x5bbd97(_0x5e2682,_0x2ce5d7);}else{const _0x3020e1=customGrad((_0xfcf10e,_0x20c9e8,_0x5cf19b,_0x8920c3)=>{const _0x3eb6fa=_0x11a602,_0x506422=ENGINE[_0x3eb6fa(0x397)](_FusedMatMul,_0x21942b,_0x152308);return _0x8920c3([_0xfcf10e,_0x20c9e8,_0x506422,_0x5cf19b]),{'value':reshape(_0x506422,_0x3ee5ab),'gradFunc':_0x46fe73};});return _0x3020e1(_0x5e2682,_0x2ce5d7,_0x5de1ec);}}const matMul$1=op({'fusedMatMul_':fusedMatMul_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function hammingWindow_(_0x258de8){return cosineWindow(_0x258de8,0.54,0.46);}const hammingWindow=op({'hammingWindow_':hammingWindow_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function hannWindow_(_0x4279c1){return cosineWindow(_0x4279c1,0.5,0.5);}const hannWindow=op({'hannWindow_':hannWindow_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function frame_(_0x58dc5c,_0x218636,_0x17360c,_0x5e77d7=![],_0x8a701a=0x0){const _0x1b9848=a0_0x20018c;let _0x41f1da=0x0;const _0x1dc9fb=[];while(_0x41f1da+_0x218636<=_0x58dc5c[_0x1b9848(0x302)]){_0x1dc9fb[_0x1b9848(0x30f)](slice(_0x58dc5c,_0x41f1da,_0x218636)),_0x41f1da+=_0x17360c;}if(_0x5e77d7)while(_0x41f1da<_0x58dc5c[_0x1b9848(0x302)]){const _0x561172=_0x41f1da+_0x218636-_0x58dc5c[_0x1b9848(0x302)],_0x247f3e=concat([slice(_0x58dc5c,_0x41f1da,_0x218636-_0x561172),fill([_0x561172],_0x8a701a)]);_0x1dc9fb[_0x1b9848(0x30f)](_0x247f3e),_0x41f1da+=_0x17360c;}if(_0x1dc9fb[_0x1b9848(0x104)]===0x0)return tensor2d([],[0x0,_0x218636]);return reshape(concat(_0x1dc9fb),[_0x1dc9fb[_0x1b9848(0x104)],_0x218636]);}const frame=op({'frame_':frame_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function stft_(_0x29a814,_0xa5f9ee,_0x45157d,_0xb8a51,_0x1b0eac=hannWindow){_0xb8a51==null&&(_0xb8a51=enclosingPowerOfTwo(_0xa5f9ee));const _0x38d85b=frame(_0x29a814,_0xa5f9ee,_0x45157d),_0x4f68d6=mul(_0x38d85b,_0x1b0eac(_0xa5f9ee));return rfft(_0x4f68d6,_0xb8a51);}const stft=op({'stft_':stft_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function cropAndResize_(_0x2f7399,_0x3c5837,_0x19725b,_0x2a3cd6,_0x34c9dc=a0_0x20018c(0x28d),_0x328040=0x0){const _0xc2ac2b=a0_0x20018c,_0x2dd205=convertToTensor(_0x2f7399,_0xc2ac2b(0x21c),_0xc2ac2b(0x195)),_0x25c545=convertToTensor(_0x3c5837,'boxes',_0xc2ac2b(0x195),'float32'),_0x90d015=convertToTensor(_0x19725b,'boxInd','cropAndResize',_0xc2ac2b(0x4d1)),_0x236d84=_0x25c545[_0xc2ac2b(0x50f)][0x0];assert(_0x2dd205['rank']===0x4,()=>'Error\x20in\x20cropAndResize:\x20image\x20must\x20be\x20rank\x204,'+(_0xc2ac2b(0x283)+_0x2dd205[_0xc2ac2b(0x36e)]+'.')),assert(_0x25c545[_0xc2ac2b(0x36e)]===0x2&&_0x25c545[_0xc2ac2b(0x50f)][0x1]===0x4,()=>_0xc2ac2b(0x13a)+_0x236d84+_0xc2ac2b(0x34f)+(_0xc2ac2b(0x1ae)+_0x25c545[_0xc2ac2b(0x50f)]+'.')),assert(_0x90d015['rank']===0x1&&_0x90d015[_0xc2ac2b(0x50f)][0x0]===_0x236d84,()=>_0xc2ac2b(0x1ab)+_0x236d84+']\x20'+(_0xc2ac2b(0x1ae)+_0x25c545[_0xc2ac2b(0x50f)]+'.')),assert(_0x2a3cd6[_0xc2ac2b(0x104)]===0x2,()=>_0xc2ac2b(0x534)+(_0xc2ac2b(0x289)+_0x2a3cd6[_0xc2ac2b(0x104)]+'.')),assert(_0x2a3cd6[0x0]>=0x1&&_0x2a3cd6[0x1]>=0x1,()=>_0xc2ac2b(0x341)+_0x2a3cd6),assert(_0x34c9dc===_0xc2ac2b(0x28d)||_0x34c9dc===_0xc2ac2b(0x466),()=>_0xc2ac2b(0x4d0)+_0x34c9dc);const _0x3c4ce1={'image':_0x2dd205,'boxes':_0x25c545,'boxInd':_0x90d015},_0x790903={'method':_0x34c9dc,'extrapolationValue':_0x328040,'cropSize':_0x2a3cd6},_0x45192f=ENGINE[_0xc2ac2b(0x397)](CropAndResize,_0x3c4ce1,_0x790903);return _0x45192f;}const cropAndResize=op({'cropAndResize_':cropAndResize_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function flipLeftRight_(_0x1083af){const _0x17edfb=a0_0x20018c,_0x1040a4=convertToTensor(_0x1083af,_0x17edfb(0x21c),_0x17edfb(0x3f2),_0x17edfb(0x28b));assert(_0x1040a4[_0x17edfb(0x36e)]===0x4,()=>_0x17edfb(0x1c4)+(_0x17edfb(0x283)+_0x1040a4['rank']+'.'));const _0x33f168={'image':_0x1040a4},_0xc6c2fd=ENGINE[_0x17edfb(0x397)](FlipLeftRight,_0x33f168,{});return _0xc6c2fd;}const flipLeftRight=op({'flipLeftRight_':flipLeftRight_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function grayscaleToRGB_(_0x1883c6){const _0xa16459=a0_0x20018c,_0x12aa7d=convertToTensor(_0x1883c6,_0xa16459(0x21c),'grayscaleToRGB'),_0x472f34=_0x12aa7d[_0xa16459(0x36e)]-0x1,_0x4858ea=_0x12aa7d['shape'][_0x472f34];assert(_0x12aa7d['rank']>=0x2,()=>_0xa16459(0x1fb)+(_0xa16459(0x283)+_0x12aa7d[_0xa16459(0x36e)]+'.')),assert(_0x4858ea===0x1,()=>_0xa16459(0x117)+(_0xa16459(0x409)+_0x4858ea+'.'));const _0x5a5445=new Array(_0x12aa7d['rank']);return _0x5a5445[_0xa16459(0x233)](0x1,0x0,_0x472f34),_0x5a5445[_0x472f34]=0x3,tile(_0x12aa7d,_0x5a5445);}const grayscaleToRGB=op({'grayscaleToRGB_':grayscaleToRGB_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function rotateWithOffset_(_0x2f7621,_0x3fa710,_0x276fa7=0x0,_0x4b9a73=0.5){const _0x4d75fd=a0_0x20018c,_0x492740=convertToTensor(_0x2f7621,_0x4d75fd(0x21c),_0x4d75fd(0x135),_0x4d75fd(0x28b));assert(_0x492740['rank']===0x4,()=>'Error\x20in\x20rotateWithOffset:\x20image\x20must\x20be\x20rank\x204,'+(_0x4d75fd(0x283)+_0x492740[_0x4d75fd(0x36e)]+'.'));const _0x2c7a13={'image':_0x492740},_0x26623e={'radians':_0x3fa710,'fillValue':_0x276fa7,'center':_0x4b9a73},_0x28d00c=ENGINE['runKernel'](RotateWithOffset,_0x2c7a13,_0x26623e);return _0x28d00c;}const rotateWithOffset=op({'rotateWithOffset_':rotateWithOffset_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function nonMaxSuppSanityCheck(_0x56d279,_0x2b3a29,_0x15fddc,_0x3619e4,_0x52637e,_0xb667e7){const _0x3a5126=a0_0x20018c;_0x3619e4==null&&(_0x3619e4=0.5);_0x52637e==null&&(_0x52637e=Number['NEGATIVE_INFINITY']);_0xb667e7==null&&(_0xb667e7=0x0);const _0x50b1bd=_0x56d279['shape'][0x0];return _0x15fddc=Math[_0x3a5126(0x58b)](_0x15fddc,_0x50b1bd),assert(0x0<=_0x3619e4&&_0x3619e4<=0x1,()=>_0x3a5126(0x3b8)+_0x3619e4+'\x27'),assert(_0x56d279[_0x3a5126(0x36e)]===0x2,()=>_0x3a5126(0x211)+_0x56d279['rank']+'\x27'),assert(_0x56d279['shape'][0x1]===0x4,()=>'boxes\x20must\x20have\x204\x20columns,\x20but\x202nd\x20dimension\x20was\x20'+_0x56d279[_0x3a5126(0x50f)][0x1]),assert(_0x2b3a29[_0x3a5126(0x36e)]===0x1,()=>_0x3a5126(0x254)),assert(_0x2b3a29[_0x3a5126(0x50f)][0x0]===_0x50b1bd,()=>_0x3a5126(0x4b1)+_0x50b1bd+',\x20'+(_0x3a5126(0x1fe)+_0x2b3a29[_0x3a5126(0x50f)][0x0])),assert(0x0<=_0xb667e7&&_0xb667e7<=0x1,()=>_0x3a5126(0x574)+_0xb667e7+'\x27'),{'maxOutputSize':_0x15fddc,'iouThreshold':_0x3619e4,'scoreThreshold':_0x52637e,'softNmsSigma':_0xb667e7};}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function nonMaxSuppression_(_0x2d7635,_0x3a76e8,_0x436a23,_0xee51b6=0.5,_0x1aef86=Number[a0_0x20018c(0x2cc)]){const _0x22bde0=a0_0x20018c,_0x59c48c=convertToTensor(_0x2d7635,_0x22bde0(0x1f2),_0x22bde0(0x1f6)),_0x4a4852=convertToTensor(_0x3a76e8,_0x22bde0(0x4ec),_0x22bde0(0x1f6)),_0x38bd95=nonMaxSuppSanityCheck(_0x59c48c,_0x4a4852,_0x436a23,_0xee51b6,_0x1aef86);_0x436a23=_0x38bd95[_0x22bde0(0x469)],_0xee51b6=_0x38bd95['iouThreshold'],_0x1aef86=_0x38bd95['scoreThreshold'];const _0xf1d78d={'maxOutputSize':_0x436a23,'iouThreshold':_0xee51b6,'scoreThreshold':_0x1aef86};return ENGINE[_0x22bde0(0x397)](NonMaxSuppressionV3,{'boxes':_0x59c48c,'scores':_0x4a4852},_0xf1d78d);}const nonMaxSuppression=op({'nonMaxSuppression_':nonMaxSuppression_});/**
 * @license
 * Copyright 2019 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function binaryInsert(_0x3466bc,_0x4ad24f,_0x13edb0){const _0x36c89c=binarySearch(_0x3466bc,_0x4ad24f,_0x13edb0),_0xa26702=_0x36c89c<0x0?-(_0x36c89c+0x1):_0x36c89c;_0x3466bc['splice'](_0xa26702,0x0,_0x4ad24f);}function binarySearch(_0x1e45a6,_0x3c9c7d,_0x2caf2d){return binarySearch_(_0x1e45a6,_0x3c9c7d,_0x2caf2d||defaultComparator);}function defaultComparator(_0x3e756c,_0x527aa4){return _0x3e756c>_0x527aa4?0x1:_0x3e756c<_0x527aa4?-0x1:0x0;}function binarySearch_(_0x258283,_0x455e41,_0x198ed9){const _0x2babf4=a0_0x20018c;let _0x27364a=0x0,_0x4551e7=_0x258283[_0x2babf4(0x104)],_0x32d976=0x0,_0x3d1042=![];while(_0x27364a<_0x4551e7){_0x32d976=_0x27364a+(_0x4551e7-_0x27364a>>>0x1);const _0x1c5b37=_0x198ed9(_0x455e41,_0x258283[_0x32d976]);_0x1c5b37>0x0?_0x27364a=_0x32d976+0x1:(_0x4551e7=_0x32d976,_0x3d1042=!_0x1c5b37);}return _0x3d1042?_0x27364a:-_0x27364a-0x1;}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function nonMaxSuppressionV3Impl(_0x10080f,_0xb79670,_0x30cce6,_0x267f4c,_0x2cd42f){return nonMaxSuppressionImpl_(_0x10080f,_0xb79670,_0x30cce6,_0x267f4c,_0x2cd42f,0x0);}function nonMaxSuppressionV4Impl(_0x5a4b7c,_0x95e619,_0x9fca9d,_0x38ca32,_0x5c92dc,_0x42131f){return nonMaxSuppressionImpl_(_0x5a4b7c,_0x95e619,_0x9fca9d,_0x38ca32,_0x5c92dc,0x0,![],_0x42131f,!![]);}function nonMaxSuppressionV5Impl(_0x12ef16,_0x336718,_0x360b6f,_0x34019d,_0x1a17c8,_0x14090e){return nonMaxSuppressionImpl_(_0x12ef16,_0x336718,_0x360b6f,_0x34019d,_0x1a17c8,_0x14090e,!![]);}function nonMaxSuppressionImpl_(_0x4514c4,_0x345a49,_0x44b7f9,_0x4bc2a2,_0xf50b54,_0x349cb0,_0xb85c76=![],_0x2b50f0=![],_0x3836f1=![]){const _0x18160e=a0_0x20018c,_0x32aa3f=[];for(let _0x447f11=0x0;_0x447f11<_0x345a49['length'];_0x447f11++){_0x345a49[_0x447f11]>_0xf50b54&&_0x32aa3f[_0x18160e(0x30f)]({'score':_0x345a49[_0x447f11],'boxIndex':_0x447f11,'suppressBeginIndex':0x0});}_0x32aa3f[_0x18160e(0x2f6)](ascendingComparator);const _0x13b204=_0x349cb0>0x0?-0.5/_0x349cb0:0x0,_0x4376dd=[],_0x5debc=[];while(_0x4376dd[_0x18160e(0x104)]<_0x44b7f9&&_0x32aa3f[_0x18160e(0x104)]>0x0){const _0x542b14=_0x32aa3f['pop'](),{score:_0x3fc5bb,boxIndex:_0x319f7d,suppressBeginIndex:_0x17b82d}=_0x542b14;if(_0x3fc5bb<_0xf50b54)break;let _0x16f096=![];for(let _0x34d661=_0x4376dd['length']-0x1;_0x34d661>=_0x17b82d;--_0x34d661){const _0x61f1b=intersectionOverUnion(_0x4514c4,_0x319f7d,_0x4376dd[_0x34d661]);if(_0x61f1b>=_0x4bc2a2){_0x16f096=!![];break;}_0x542b14[_0x18160e(0x4bb)]=_0x542b14[_0x18160e(0x4bb)]*suppressWeight(_0x4bc2a2,_0x13b204,_0x61f1b);if(_0x542b14[_0x18160e(0x4bb)]<=_0xf50b54)break;}_0x542b14[_0x18160e(0x241)]=_0x4376dd[_0x18160e(0x104)];if(!_0x16f096){if(_0x542b14[_0x18160e(0x4bb)]===_0x3fc5bb)_0x4376dd['push'](_0x319f7d),_0x5debc[_0x18160e(0x30f)](_0x542b14[_0x18160e(0x4bb)]);else _0x542b14['score']>_0xf50b54&&binaryInsert(_0x32aa3f,_0x542b14,ascendingComparator);}}const _0x5b58a6=_0x4376dd[_0x18160e(0x104)],_0x2ff5fc=_0x44b7f9-_0x5b58a6;_0x2b50f0&&_0x2ff5fc>0x0&&(_0x4376dd[_0x18160e(0x30f)](...new Array(_0x2ff5fc)[_0x18160e(0x233)](0x0)),_0x5debc[_0x18160e(0x30f)](...new Array(_0x2ff5fc)[_0x18160e(0x233)](0x0)));const _0x5138ff={'selectedIndices':_0x4376dd};return _0xb85c76&&(_0x5138ff[_0x18160e(0x3c5)]=_0x5debc),_0x3836f1&&(_0x5138ff['validOutputs']=_0x5b58a6),_0x5138ff;}function intersectionOverUnion(_0x5b34ea,_0x1f7fcb,_0x4e4a6e){const _0x56bc78=a0_0x20018c,_0x487b38=_0x5b34ea[_0x56bc78(0x1be)](_0x1f7fcb*0x4,_0x1f7fcb*0x4+0x4),_0xa07934=_0x5b34ea[_0x56bc78(0x1be)](_0x4e4a6e*0x4,_0x4e4a6e*0x4+0x4),_0x3e5f19=Math[_0x56bc78(0x58b)](_0x487b38[0x0],_0x487b38[0x2]),_0xbbee2=Math[_0x56bc78(0x58b)](_0x487b38[0x1],_0x487b38[0x3]),_0x388008=Math['max'](_0x487b38[0x0],_0x487b38[0x2]),_0x335c3e=Math['max'](_0x487b38[0x1],_0x487b38[0x3]),_0x1b4bbd=Math[_0x56bc78(0x58b)](_0xa07934[0x0],_0xa07934[0x2]),_0x6afb3d=Math[_0x56bc78(0x58b)](_0xa07934[0x1],_0xa07934[0x3]),_0x2e0513=Math[_0x56bc78(0x1e2)](_0xa07934[0x0],_0xa07934[0x2]),_0x590740=Math['max'](_0xa07934[0x1],_0xa07934[0x3]),_0x42f4e7=(_0x388008-_0x3e5f19)*(_0x335c3e-_0xbbee2),_0xfbb56b=(_0x2e0513-_0x1b4bbd)*(_0x590740-_0x6afb3d);if(_0x42f4e7<=0x0||_0xfbb56b<=0x0)return 0x0;const _0x2a9437=Math[_0x56bc78(0x1e2)](_0x3e5f19,_0x1b4bbd),_0x4fd45d=Math['max'](_0xbbee2,_0x6afb3d),_0x2da30f=Math[_0x56bc78(0x58b)](_0x388008,_0x2e0513),_0x1a05e8=Math[_0x56bc78(0x58b)](_0x335c3e,_0x590740),_0x2e134c=Math[_0x56bc78(0x1e2)](_0x2da30f-_0x2a9437,0x0)*Math['max'](_0x1a05e8-_0x4fd45d,0x0);return _0x2e134c/(_0x42f4e7+_0xfbb56b-_0x2e134c);}function suppressWeight(_0x278bc7,_0x58a0b9,_0x1d3b63){const _0x239efc=a0_0x20018c,_0x366375=Math[_0x239efc(0x57c)](_0x58a0b9*_0x1d3b63*_0x1d3b63);return _0x1d3b63<=_0x278bc7?_0x366375:0x0;}function ascendingComparator(_0x52e462,_0x1867c4){const _0x29b8a3=a0_0x20018c;return _0x52e462[_0x29b8a3(0x4bb)]-_0x1867c4[_0x29b8a3(0x4bb)]||_0x52e462['score']===_0x1867c4[_0x29b8a3(0x4bb)]&&_0x1867c4[_0x29b8a3(0x592)]-_0x52e462[_0x29b8a3(0x592)];}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function nonMaxSuppressionAsync_(_0x279cd6,_0x1bd657,_0x3424bd,_0x49659e=0.5,_0x4d0dc5=Number[a0_0x20018c(0x2cc)]){const _0x443875=a0_0x20018c,_0x5a77dd=convertToTensor(_0x279cd6,_0x443875(0x1f2),_0x443875(0x567)),_0x3f5d87=convertToTensor(_0x1bd657,'scores','nonMaxSuppressionAsync'),_0x24dee3=nonMaxSuppSanityCheck(_0x5a77dd,_0x3f5d87,_0x3424bd,_0x49659e,_0x4d0dc5);_0x3424bd=_0x24dee3[_0x443875(0x469)],_0x49659e=_0x24dee3[_0x443875(0x3f6)],_0x4d0dc5=_0x24dee3['scoreThreshold'];const _0x1213a6=await Promise[_0x443875(0x21f)]([_0x5a77dd[_0x443875(0x186)](),_0x3f5d87['data']()]),_0x1f70d0=_0x1213a6[0x0],_0x194cff=_0x1213a6[0x1],{selectedIndices:_0x3ff870}=nonMaxSuppressionV3Impl(_0x1f70d0,_0x194cff,_0x3424bd,_0x49659e,_0x4d0dc5);return _0x5a77dd!==_0x279cd6&&_0x5a77dd[_0x443875(0x47d)](),_0x3f5d87!==_0x1bd657&&_0x3f5d87[_0x443875(0x47d)](),tensor1d(_0x3ff870,_0x443875(0x4d1));}const nonMaxSuppressionAsync=nonMaxSuppressionAsync_;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function nonMaxSuppressionWithScore_(_0x2a3cea,_0x424638,_0x122ffe,_0x3148fa=0.5,_0x545580=Number[a0_0x20018c(0x2cc)],_0x31b8aa=0x0){const _0x46ea96=a0_0x20018c,_0x2a5005=convertToTensor(_0x2a3cea,_0x46ea96(0x1f2),_0x46ea96(0x1f6)),_0xfd7d09=convertToTensor(_0x424638,_0x46ea96(0x4ec),'nonMaxSuppression'),_0x30adee=nonMaxSuppSanityCheck(_0x2a5005,_0xfd7d09,_0x122ffe,_0x3148fa,_0x545580,_0x31b8aa);_0x122ffe=_0x30adee[_0x46ea96(0x469)],_0x3148fa=_0x30adee[_0x46ea96(0x3f6)],_0x545580=_0x30adee[_0x46ea96(0x562)],_0x31b8aa=_0x30adee[_0x46ea96(0x22f)];const _0x50113b={'boxes':_0x2a5005,'scores':_0xfd7d09},_0x13fe6d={'maxOutputSize':_0x122ffe,'iouThreshold':_0x3148fa,'scoreThreshold':_0x545580,'softNmsSigma':_0x31b8aa},_0x45e8af=ENGINE[_0x46ea96(0x397)](NonMaxSuppressionV5,_0x50113b,_0x13fe6d);return{'selectedIndices':_0x45e8af[0x0],'selectedScores':_0x45e8af[0x1]};}const nonMaxSuppressionWithScore=op({'nonMaxSuppressionWithScore_':nonMaxSuppressionWithScore_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function nonMaxSuppressionWithScoreAsync_(_0x2d0fdd,_0x3a5f12,_0x5c5444,_0x162a8a=0.5,_0x50b1ec=Number[a0_0x20018c(0x2cc)],_0x37f5af=0x0){const _0x4de440=a0_0x20018c,_0x4b4714=convertToTensor(_0x2d0fdd,_0x4de440(0x1f2),_0x4de440(0x567)),_0x1b18f=convertToTensor(_0x3a5f12,'scores',_0x4de440(0x567)),_0x3a11cf=nonMaxSuppSanityCheck(_0x4b4714,_0x1b18f,_0x5c5444,_0x162a8a,_0x50b1ec,_0x37f5af);_0x5c5444=_0x3a11cf[_0x4de440(0x469)],_0x162a8a=_0x3a11cf[_0x4de440(0x3f6)],_0x50b1ec=_0x3a11cf[_0x4de440(0x562)],_0x37f5af=_0x3a11cf[_0x4de440(0x22f)];const _0x405db5=await Promise[_0x4de440(0x21f)]([_0x4b4714[_0x4de440(0x186)](),_0x1b18f[_0x4de440(0x186)]()]),_0x20154b=_0x405db5[0x0],_0xcdc8c6=_0x405db5[0x1],{selectedIndices:_0x3458bc,selectedScores:_0x32939}=nonMaxSuppressionV5Impl(_0x20154b,_0xcdc8c6,_0x5c5444,_0x162a8a,_0x50b1ec,_0x37f5af);return _0x4b4714!==_0x2d0fdd&&_0x4b4714[_0x4de440(0x47d)](),_0x1b18f!==_0x3a5f12&&_0x1b18f['dispose'](),{'selectedIndices':tensor1d(_0x3458bc,_0x4de440(0x4d1)),'selectedScores':tensor1d(_0x32939)};}const nonMaxSuppressionWithScoreAsync=nonMaxSuppressionWithScoreAsync_;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function nonMaxSuppressionPadded_(_0x695079,_0x3263c7,_0x25e8aa,_0xd04845=0.5,_0x226111=Number[a0_0x20018c(0x2cc)],_0x393ef0=![]){const _0x3ceea6=a0_0x20018c,_0x527b4d=convertToTensor(_0x695079,'boxes',_0x3ceea6(0x1f6)),_0x3f77d2=convertToTensor(_0x3263c7,_0x3ceea6(0x4ec),_0x3ceea6(0x1f6)),_0x2da6e8=nonMaxSuppSanityCheck(_0x527b4d,_0x3f77d2,_0x25e8aa,_0xd04845,_0x226111,null),_0x30d996=_0x2da6e8[_0x3ceea6(0x469)],_0x3af2ed=_0x2da6e8[_0x3ceea6(0x3f6)],_0x472f23=_0x2da6e8[_0x3ceea6(0x562)],_0x226409={'boxes':_0x527b4d,'scores':_0x3f77d2},_0x4b7dee={'maxOutputSize':_0x30d996,'iouThreshold':_0x3af2ed,'scoreThreshold':_0x472f23,'padToMaxOutputSize':_0x393ef0},_0x42b656=ENGINE[_0x3ceea6(0x397)](NonMaxSuppressionV4,_0x226409,_0x4b7dee);return{'selectedIndices':_0x42b656[0x0],'validOutputs':_0x42b656[0x1]};}const nonMaxSuppressionPadded=op({'nonMaxSuppressionPadded_':nonMaxSuppressionPadded_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
async function nonMaxSuppressionPaddedAsync_(_0x593e99,_0x2b48da,_0x25ab7d,_0x2e62e6=0.5,_0x5971ad=Number[a0_0x20018c(0x2cc)],_0x339306=![]){const _0x46ba4c=a0_0x20018c,_0x42cb31=convertToTensor(_0x593e99,'boxes',_0x46ba4c(0x567)),_0x5154fb=convertToTensor(_0x2b48da,_0x46ba4c(0x4ec),_0x46ba4c(0x567)),_0x548a0d=nonMaxSuppSanityCheck(_0x42cb31,_0x5154fb,_0x25ab7d,_0x2e62e6,_0x5971ad,null),_0x4f270d=_0x548a0d[_0x46ba4c(0x469)],_0x260333=_0x548a0d[_0x46ba4c(0x3f6)],_0x369cbe=_0x548a0d[_0x46ba4c(0x562)],[_0x1155f4,_0x263247]=await Promise[_0x46ba4c(0x21f)]([_0x42cb31[_0x46ba4c(0x186)](),_0x5154fb['data']()]),{selectedIndices:_0xa2eb6d,validOutputs:_0x10bd62}=nonMaxSuppressionV4Impl(_0x1155f4,_0x263247,_0x4f270d,_0x260333,_0x369cbe,_0x339306);return _0x42cb31!==_0x593e99&&_0x42cb31[_0x46ba4c(0x47d)](),_0x5154fb!==_0x2b48da&&_0x5154fb['dispose'](),{'selectedIndices':tensor1d(_0xa2eb6d,_0x46ba4c(0x4d1)),'validOutputs':scalar(_0x10bd62,_0x46ba4c(0x4d1))};}const nonMaxSuppressionPaddedAsync=nonMaxSuppressionPaddedAsync_;/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function resizeBilinear_(_0x144e80,_0x3ee000,_0x11c444=![],_0x552239=![]){const _0xa0901a=a0_0x20018c,_0x17a77a=convertToTensor(_0x144e80,_0xa0901a(0x171),_0xa0901a(0x310));assert(_0x17a77a[_0xa0901a(0x36e)]===0x3||_0x17a77a[_0xa0901a(0x36e)]===0x4,()=>_0xa0901a(0x37b)+(_0xa0901a(0x5b5)+_0x17a77a[_0xa0901a(0x36e)]+'.')),assert(_0x3ee000[_0xa0901a(0x104)]===0x2,()=>_0xa0901a(0x25b)+(_0x3ee000+'.')),assert(_0x552239===![]||_0x11c444===![],()=>_0xa0901a(0x204)+_0xa0901a(0x143));let _0xb60b86=_0x17a77a,_0x48ac4f=![];_0x17a77a[_0xa0901a(0x36e)]===0x3&&(_0x48ac4f=!![],_0xb60b86=reshape(_0x17a77a,[0x1,_0x17a77a['shape'][0x0],_0x17a77a[_0xa0901a(0x50f)][0x1],_0x17a77a[_0xa0901a(0x50f)][0x2]]));const []=_0x3ee000,_0x37d319={'images':_0xb60b86},_0x10571a={'alignCorners':_0x11c444,'halfPixelCenters':_0x552239,'size':_0x3ee000},_0x322e9a=ENGINE['runKernel'](ResizeBilinear,_0x37d319,_0x10571a);if(_0x48ac4f)return reshape(_0x322e9a,[_0x322e9a[_0xa0901a(0x50f)][0x1],_0x322e9a['shape'][0x2],_0x322e9a[_0xa0901a(0x50f)][0x3]]);return _0x322e9a;}const resizeBilinear=op({'resizeBilinear_':resizeBilinear_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function resizeNearestNeighbor_(_0x1aa610,_0x3b3396,_0x1f9ac2=![],_0x22334a=![]){const _0x1cfa20=a0_0x20018c,_0x1fedeb=convertToTensor(_0x1aa610,_0x1cfa20(0x171),_0x1cfa20(0x1b3));assert(_0x1fedeb[_0x1cfa20(0x36e)]===0x3||_0x1fedeb[_0x1cfa20(0x36e)]===0x4,()=>_0x1cfa20(0x1d8)+('rank\x20'+_0x1fedeb['rank']+'.')),assert(_0x3b3396['length']===0x2,()=>_0x1cfa20(0x298)+(_0x3b3396+'.')),assert(_0x1fedeb['dtype']===_0x1cfa20(0x28b)||_0x1fedeb[_0x1cfa20(0x51c)]===_0x1cfa20(0x4d1),()=>_0x1cfa20(0x173)),assert(_0x22334a===![]||_0x1f9ac2===![],()=>_0x1cfa20(0x269)+_0x1cfa20(0x143));let _0x3b96f3=_0x1fedeb,_0x3e1611=![];_0x1fedeb[_0x1cfa20(0x36e)]===0x3&&(_0x3e1611=!![],_0x3b96f3=reshape(_0x1fedeb,[0x1,_0x1fedeb[_0x1cfa20(0x50f)][0x0],_0x1fedeb[_0x1cfa20(0x50f)][0x1],_0x1fedeb[_0x1cfa20(0x50f)][0x2]]));const []=_0x3b3396,_0x35162c={'images':_0x3b96f3},_0x2b6284={'alignCorners':_0x1f9ac2,'halfPixelCenters':_0x22334a,'size':_0x3b3396},_0xae85ee=ENGINE['runKernel'](ResizeNearestNeighbor,_0x35162c,_0x2b6284);if(_0x3e1611)return reshape(_0xae85ee,[_0xae85ee['shape'][0x1],_0xae85ee[_0x1cfa20(0x50f)][0x2],_0xae85ee[_0x1cfa20(0x50f)][0x3]]);return _0xae85ee;}const resizeNearestNeighbor=op({'resizeNearestNeighbor_':resizeNearestNeighbor_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function threshold_(_0xca9d29,_0x42ac50='binary',_0x5309b0=![],_0x4def31=0.5){const _0x2157a7=a0_0x20018c,_0x3aaaa2=convertToTensor(_0xca9d29,'image','threshold'),_0x469660=0.2989,_0x556418=0.587,_0x11a6de=0.114,_0xda720=_0x3aaaa2[_0x2157a7(0x50f)][0x0]*_0x3aaaa2[_0x2157a7(0x50f)][0x1];let _0x5a7442=mul(tensor1d([_0x4def31]),0xff),_0x4ce005,_0x263c03,_0x58dac4,_0x3c0a9f;assert(_0x3aaaa2[_0x2157a7(0x36e)]===0x3,()=>_0x2157a7(0x1c1)+(_0x2157a7(0x283)+_0x3aaaa2[_0x2157a7(0x36e)]+'.')),assert(_0x3aaaa2[_0x2157a7(0x50f)][0x2]===0x3||_0x3aaaa2[_0x2157a7(0x50f)][0x2]===0x1,()=>_0x2157a7(0x36c)+_0x2157a7(0x53b)+(_0x2157a7(0x5b2)+_0x3aaaa2[_0x2157a7(0x50f)][0x2]+'.')),assert(_0x3aaaa2[_0x2157a7(0x51c)]===_0x2157a7(0x4d1)||_0x3aaaa2[_0x2157a7(0x51c)]===_0x2157a7(0x28b),()=>'Error\x20in\x20dtype:\x20image\x20dtype\x20must\x20be\x20int32\x20or\x20float32,'+(_0x2157a7(0x389)+_0x3aaaa2[_0x2157a7(0x51c)]+'.')),assert(_0x42ac50===_0x2157a7(0x537)||_0x42ac50===_0x2157a7(0x1d5),()=>_0x2157a7(0x114)+_0x42ac50);if(_0x3aaaa2['shape'][0x2]===0x3){[_0x4ce005,_0x263c03,_0x58dac4]=split(_0x3aaaa2,[0x1,0x1,0x1],-0x1);const _0x3f0fbf=mul(_0x4ce005,_0x469660),_0x4e442d=mul(_0x263c03,_0x556418),_0x45838b=mul(_0x58dac4,_0x11a6de);_0x3c0a9f=add$1(add$1(_0x3f0fbf,_0x4e442d),_0x45838b);}else _0x3c0a9f=_0xca9d29;if(_0x42ac50===_0x2157a7(0x537)){const _0xf1ee0=bincount(cast(round$1(_0x3c0a9f),'int32'),tensor([]),0x100);_0x5a7442=otsu(_0xf1ee0,_0xda720);}const _0xc7f54b=_0x5309b0?lessEqual(_0x3c0a9f,_0x5a7442):greater(_0x3c0a9f,_0x5a7442),_0x5631d1=cast(mul(_0xc7f54b,0xff),_0x2157a7(0x4d1));return _0x5631d1;}function otsu(_0x1a3f0a,_0x429b87){const _0xd419f0=a0_0x20018c;let _0xf7fdc8=tensor1d([-0x1]),_0xbb49cf=tensor1d([0x0]),_0x520e7a=tensor1d([0x0]),_0x4d5ef2,_0xb91ec8,_0x2db419,_0x1332a3,_0xac3ea1,_0x13769f;for(let _0xc6a6df=0x0;_0xc6a6df<_0x1a3f0a[_0xd419f0(0x302)]-0x1;_0xc6a6df++){_0x4d5ef2=slice(_0x1a3f0a,0x0,_0xc6a6df+0x1),_0xb91ec8=slice(_0x1a3f0a,_0xc6a6df+0x1),_0xac3ea1=div(sum$1(_0x4d5ef2),_0x429b87),_0x13769f=div(sum$1(_0xb91ec8),_0x429b87);const _0x2c4b7c=sum$1(mul(_0x4d5ef2,range(0x0,_0x4d5ef2[_0xd419f0(0x302)])));_0x2db419=div(_0x2c4b7c,sum$1(_0x4d5ef2));const _0x3bf153=fill(_0xb91ec8['shape'],_0x4d5ef2[_0xd419f0(0x302)]),_0x3fad65=add$1(range(0x0,_0xb91ec8[_0xd419f0(0x302)]),_0x3bf153),_0x49e331=mul(_0xb91ec8,_0x3fad65);_0x1332a3=div(sum$1(_0x49e331),sum$1(_0xb91ec8));const _0x145305=sub(_0x2db419,_0x1332a3),_0x216c6a=sub(_0x2db419,_0x1332a3),_0x3a81e3=mul(_0xac3ea1,_0x13769f);_0x520e7a=mul(mul(_0x3a81e3,_0x145305),_0x216c6a);const _0x288b70=greater(_0x520e7a,_0xbb49cf);_0xbb49cf=where(_0x288b70,_0x520e7a,_0xbb49cf),_0xf7fdc8=where(_0x288b70,tensor1d([_0xc6a6df]),_0xf7fdc8);}return _0xf7fdc8;}const threshold=op({'threshold_':threshold_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function transform_(_0x33d92a,_0x2bea8d,_0x2ad6c5=a0_0x20018c(0x466),_0x5c1276=a0_0x20018c(0x569),_0x2d6534=0x0,_0x4c5061){const _0x20f58f=a0_0x20018c,_0x222877=convertToTensor(_0x33d92a,_0x20f58f(0x21c),_0x20f58f(0x25e),_0x20f58f(0x28b)),_0x177b99=convertToTensor(_0x2bea8d,_0x20f58f(0x3a4),_0x20f58f(0x25e),_0x20f58f(0x28b));assert(_0x222877[_0x20f58f(0x36e)]===0x4,()=>'Error\x20in\x20transform:\x20image\x20must\x20be\x20rank\x204,'+(_0x20f58f(0x283)+_0x222877['rank']+'.')),assert(_0x177b99[_0x20f58f(0x36e)]===0x2&&(_0x177b99[_0x20f58f(0x50f)][0x0]===_0x222877['shape'][0x0]||_0x177b99[_0x20f58f(0x50f)][0x0]===0x1)&&_0x177b99[_0x20f58f(0x50f)][0x1]===0x8,()=>'Error\x20in\x20transform:\x20Input\x20transform\x20should\x20be\x20batch\x20x\x208\x20or\x201\x20x\x208'),assert(_0x4c5061==null||_0x4c5061['length']===0x2,()=>_0x20f58f(0x3fa)+(_0x20f58f(0x5b2)+_0x4c5061+'.'));const _0x109db3={'image':_0x222877,'transforms':_0x177b99},_0x3d301e={'interpolation':_0x2ad6c5,'fillMode':_0x5c1276,'fillValue':_0x2d6534,'outputShape':_0x4c5061};return ENGINE[_0x20f58f(0x397)](Transform,_0x109db3,_0x3d301e);}const transform=op({'transform_':transform_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function bandPart_(_0x39e206,_0x5d4679,_0x1c0a18){const _0x37bc6b=a0_0x20018c;assert(_0x5d4679%0x1===0x0,()=>'bandPart():\x20numLower\x20must\x20be\x20an\x20integer,\x20got\x20'+_0x5d4679+'.'),assert(_0x1c0a18%0x1===0x0,()=>'bandPart():\x20numUpper\x20must\x20be\x20an\x20integer,\x20got\x20'+_0x1c0a18+'.');const _0x324cb4=convertToTensor(_0x39e206,'a',_0x37bc6b(0x3ee));assert(_0x324cb4[_0x37bc6b(0x36e)]>=0x2,()=>_0x37bc6b(0xdf)+_0x324cb4[_0x37bc6b(0x36e)]+'.');const _0x29ae7d=_0x324cb4[_0x37bc6b(0x50f)],[_0x32b77b,_0x582c43]=_0x324cb4[_0x37bc6b(0x50f)][_0x37bc6b(0x2b0)](-0x2);if(!(_0x5d4679<=_0x32b77b))throw new Error('bandPart():\x20numLower\x20('+_0x5d4679+')'+(_0x37bc6b(0x585)+_0x32b77b+').'));if(!(_0x1c0a18<=_0x582c43))throw new Error(_0x37bc6b(0x317)+_0x1c0a18+')'+(_0x37bc6b(0x551)+_0x582c43+').'));_0x5d4679<0x0&&(_0x5d4679=_0x32b77b);_0x1c0a18<0x0&&(_0x1c0a18=_0x582c43);const _0x3159ac=reshape(range(0x0,_0x32b77b,0x1,_0x37bc6b(0x4d1)),[-0x1,0x1]),_0x48123b=range(0x0,_0x582c43,0x1,_0x37bc6b(0x4d1)),_0x3eeaaf=sub(_0x3159ac,_0x48123b),_0x1c7a40=logicalAnd(lessEqual(_0x3eeaaf,scalar(+_0x5d4679,_0x37bc6b(0x4d1))),greaterEqual(_0x3eeaaf,scalar(-_0x1c0a18,_0x37bc6b(0x4d1)))),_0x4cbf8a=zeros([_0x32b77b,_0x582c43],_0x324cb4['dtype']);return reshape(stack(unstack(reshape(_0x324cb4,[-0x1,_0x32b77b,_0x582c43]))[_0x37bc6b(0x3ab)](_0x21f5e4=>where(_0x1c7a40,_0x21f5e4,_0x4cbf8a))),_0x29ae7d);}const bandPart=op({'bandPart_':bandPart_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function gramSchmidt_(_0x481e48){const _0xc3ea86=a0_0x20018c;let _0x3c6b3c;if(Array[_0xc3ea86(0x576)](_0x481e48)){_0x3c6b3c=![],assert(_0x481e48!=null&&_0x481e48[_0xc3ea86(0x104)]>0x0,()=>'Gram-Schmidt\x20process:\x20input\x20must\x20not\x20be\x20null,\x20undefined,\x20or\x20'+_0xc3ea86(0x384));const _0x154ce8=_0x481e48[0x0]['shape'][0x0];for(let _0x207c67=0x1;_0x207c67<_0x481e48[_0xc3ea86(0x104)];++_0x207c67){assert(_0x481e48[_0x207c67][_0xc3ea86(0x50f)][0x0]===_0x154ce8,()=>_0xc3ea86(0x256)+('('+_0x481e48[_0x207c67][_0xc3ea86(0x50f)][0x0]+'\x20vs.\x20'+_0x154ce8+')'));}}else _0x3c6b3c=!![],_0x481e48=split(_0x481e48,_0x481e48['shape'][0x0],0x0)[_0xc3ea86(0x3ab)](_0x5c7986=>squeeze(_0x5c7986,[0x0]));assert(_0x481e48[_0xc3ea86(0x104)]<=_0x481e48[0x0][_0xc3ea86(0x50f)][0x0],()=>_0xc3ea86(0x17a)+_0x481e48['length']+_0xc3ea86(0x18c)+(_0xc3ea86(0x520)+_0x481e48[0x0][_0xc3ea86(0x50f)][0x0]+').'));const _0x2d558a=[],_0x35b738=_0x481e48;for(let _0x1e5d1d=0x0;_0x1e5d1d<_0x481e48[_0xc3ea86(0x104)];++_0x1e5d1d){_0x2d558a[_0xc3ea86(0x30f)](ENGINE[_0xc3ea86(0x50d)](()=>{const _0x51bf56=_0xc3ea86;let _0x19223b=_0x35b738[_0x1e5d1d];if(_0x1e5d1d>0x0)for(let _0x5d604e=0x0;_0x5d604e<_0x1e5d1d;++_0x5d604e){const _0x1949a0=mul(sum$1(mul(_0x2d558a[_0x5d604e],_0x19223b)),_0x2d558a[_0x5d604e]);_0x19223b=sub(_0x19223b,_0x1949a0);}return div(_0x19223b,norm(_0x19223b,_0x51bf56(0x4be)));}));}return _0x3c6b3c?stack(_0x2d558a,0x0):_0x2d558a;}const gramSchmidt=op({'gramSchmidt_':gramSchmidt_});/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function enableProdMode(){const _0xd1d6a9=a0_0x20018c;env()[_0xd1d6a9(0x5a6)](_0xd1d6a9(0x252),!![]);}function enableDebugMode(){const _0x285e13=a0_0x20018c;env()[_0x285e13(0x5a6)](_0x285e13(0x153),!![]);}function disableDeprecationWarnings(){const _0x1ef93c=a0_0x20018c;env()['set'](_0x1ef93c(0x366),![]),console['warn'](_0x1ef93c(0x535));}function deprecationWarn(_0x228a26){const _0x2c3b0d=a0_0x20018c;env()[_0x2c3b0d(0x501)]('DEPRECATION_WARNINGS_ENABLED')&&console[_0x2c3b0d(0x297)](_0x228a26+_0x2c3b0d(0x1e5)+_0x2c3b0d(0x43f));}setDeprecationWarningFn(deprecationWarn);function disposeVariables(){const _0x14dbbf=a0_0x20018c;ENGINE[_0x14dbbf(0x370)]();}function engine(){return ENGINE;}function memory(){const _0x28cc52=a0_0x20018c;return ENGINE[_0x28cc52(0x27f)]();}function profile(_0x2f9788){return ENGINE['profile'](_0x2f9788);}function tidy(_0x1f15e7,_0x3c2477){return ENGINE['tidy'](_0x1f15e7,_0x3c2477);}function dispose(_0x1722b7){const _0x5d1a36=a0_0x20018c,_0x5d0b89=getTensorsInContainer(_0x1722b7);_0x5d0b89[_0x5d1a36(0x1e4)](_0x4f952b=>_0x4f952b[_0x5d1a36(0x47d)]());}function keep(_0x44391e){const _0x2c00f3=a0_0x20018c;return ENGINE[_0x2c00f3(0x47f)](_0x44391e);}function time(_0x5e233c){const _0x9eb8f2=a0_0x20018c;return ENGINE[_0x9eb8f2(0x5d5)](_0x5e233c);}function setBackend(_0x200d93){const _0x487306=a0_0x20018c;return ENGINE[_0x487306(0x544)](_0x200d93);}function ready(){const _0x838784=a0_0x20018c;return ENGINE[_0x838784(0x307)]();}function getBackend(){const _0xb47eb8=a0_0x20018c;return ENGINE[_0xb47eb8(0x453)];}function removeBackend(_0x366202){ENGINE['removeBackend'](_0x366202);}function findBackend(_0x1ebd81){const _0x1d1862=a0_0x20018c;return ENGINE[_0x1d1862(0x261)](_0x1ebd81);}function findBackendFactory(_0x353401){const _0x354c3c=a0_0x20018c;return ENGINE[_0x354c3c(0x2e1)](_0x353401);}function registerBackend(_0x4aca4f,_0x18aba7,_0xb6db6f=0x1){return ENGINE['registerBackend'](_0x4aca4f,_0x18aba7,_0xb6db6f);}function backend(){const _0x1ba879=a0_0x20018c;return ENGINE[_0x1ba879(0x162)];}function setPlatform(_0x1158d3,_0x4280fb){env()['setPlatform'](_0x1158d3,_0x4280fb);}/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function qr_(_0xca741d,_0xba1fde=![]){const _0x384734=a0_0x20018c;assert(_0xca741d[_0x384734(0x36e)]>=0x2,()=>_0x384734(0x417)+_0xca741d[_0x384734(0x36e)]);if(_0xca741d[_0x384734(0x36e)]===0x2)return qr2d(_0xca741d,_0xba1fde);else{const _0x24d133=_0xca741d[_0x384734(0x50f)][_0x384734(0x2b0)](0x0,_0xca741d[_0x384734(0x50f)]['length']-0x2)[_0x384734(0x48a)]((_0x29ad99,_0x51f8b6)=>_0x29ad99*_0x51f8b6),_0x2506e3=unstack(reshape(_0xca741d,[_0x24d133,_0xca741d[_0x384734(0x50f)][_0xca741d['shape'][_0x384734(0x104)]-0x2],_0xca741d[_0x384734(0x50f)][_0xca741d['shape'][_0x384734(0x104)]-0x1]]),0x0),_0x9394b1=[],_0x2e71a2=[];_0x2506e3[_0x384734(0x1e4)](_0x511dd8=>{const _0x5c498c=_0x384734,[_0x4791bf,_0x41c9aa]=qr2d(_0x511dd8,_0xba1fde);_0x9394b1[_0x5c498c(0x30f)](_0x4791bf),_0x2e71a2[_0x5c498c(0x30f)](_0x41c9aa);});const _0x3cc97b=reshape(stack(_0x9394b1,0x0),_0xca741d['shape']),_0x400db9=reshape(stack(_0x2e71a2,0x0),_0xca741d[_0x384734(0x50f)]);return[_0x3cc97b,_0x400db9];}}function qr2d(_0x5b3861,_0x29dc80=![]){const _0xad8115=a0_0x20018c;return ENGINE[_0xad8115(0x50d)](()=>{const _0x3613c3=_0xad8115;assert(_0x5b3861[_0x3613c3(0x50f)][_0x3613c3(0x104)]===0x2,()=>_0x3613c3(0x2bc)+_0x5b3861[_0x3613c3(0x50f)][_0x3613c3(0x104)]+_0x3613c3(0x54b));const _0x22a30c=_0x5b3861[_0x3613c3(0x50f)][0x0],_0x181d84=_0x5b3861[_0x3613c3(0x50f)][0x1];let _0x56f395=eye(_0x22a30c),_0x73b23c=clone(_0x5b3861);const _0x4a11be=tensor2d([[0x1]],[0x1,0x1]);let _0x3d2d41=clone(_0x4a11be);const _0x107dc5=_0x22a30c>=_0x181d84?_0x181d84:_0x22a30c;for(let _0x1c3b58=0x0;_0x1c3b58<_0x107dc5;++_0x1c3b58){const _0x2cf9c0=_0x73b23c,_0x3d592e=_0x3d2d41,_0x3ea1a3=_0x56f395;[_0x3d2d41,_0x73b23c,_0x56f395]=ENGINE[_0x3613c3(0x50d)](()=>{const _0x21309c=_0x3613c3,_0x1c967f=slice(_0x73b23c,[_0x1c3b58,_0x1c3b58],[_0x22a30c-_0x1c3b58,0x1]),_0x5e002b=norm(_0x1c967f),_0x560cb5=slice(_0x73b23c,[_0x1c3b58,_0x1c3b58],[0x1,0x1]),_0x5d6552=where(greater(_0x560cb5,0x0),tensor2d([[-0x1]]),tensor2d([[0x1]])),_0x3dd597=sub(_0x560cb5,mul(_0x5d6552,_0x5e002b)),_0x2f9ec2=div(_0x1c967f,_0x3dd597);_0x2f9ec2[_0x21309c(0x50f)][0x0]===0x1?_0x3d2d41=clone(_0x4a11be):_0x3d2d41=concat([_0x4a11be,slice(_0x2f9ec2,[0x1,0x0],[_0x2f9ec2[_0x21309c(0x50f)][0x0]-0x1,_0x2f9ec2[_0x21309c(0x50f)][0x1]])],0x0);const _0x189bf9=neg(div(matMul(_0x5d6552,_0x3dd597),_0x5e002b)),_0x5d2b8a=slice(_0x73b23c,[_0x1c3b58,0x0],[_0x22a30c-_0x1c3b58,_0x181d84]),_0x2cf937=mul(_0x189bf9,_0x3d2d41),_0x4ebbcc=transpose(_0x3d2d41);if(_0x1c3b58===0x0)_0x73b23c=sub(_0x5d2b8a,matMul(_0x2cf937,matMul(_0x4ebbcc,_0x5d2b8a)));else{const _0xa7204b=sub(_0x5d2b8a,matMul(_0x2cf937,matMul(_0x4ebbcc,_0x5d2b8a)));_0x73b23c=concat([slice(_0x73b23c,[0x0,0x0],[_0x1c3b58,_0x181d84]),_0xa7204b],0x0);}const _0x2d4f31=transpose(_0x2cf937),_0x335f3f=slice(_0x56f395,[0x0,_0x1c3b58],[_0x22a30c,_0x56f395['shape'][0x1]-_0x1c3b58]);if(_0x1c3b58===0x0)_0x56f395=sub(_0x335f3f,matMul(matMul(_0x335f3f,_0x3d2d41),_0x2d4f31));else{const _0x2691b5=sub(_0x335f3f,matMul(matMul(_0x335f3f,_0x3d2d41),_0x2d4f31));_0x56f395=concat([slice(_0x56f395,[0x0,0x0],[_0x22a30c,_0x1c3b58]),_0x2691b5],0x1);}return[_0x3d2d41,_0x73b23c,_0x56f395];}),dispose([_0x2cf9c0,_0x3d592e,_0x3ea1a3]);}return!_0x29dc80&&_0x22a30c>_0x181d84&&(_0x56f395=slice(_0x56f395,[0x0,0x0],[_0x22a30c,_0x181d84]),_0x73b23c=slice(_0x73b23c,[0x0,0x0],[_0x181d84,_0x181d84])),[_0x56f395,_0x73b23c];});}const qr=op({'qr_':qr_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
var Reduction;(function(_0x4698d8){const _0x13880c=a0_0x20018c;_0x4698d8[_0x4698d8['NONE']=0x0]='NONE',_0x4698d8[_0x4698d8[_0x13880c(0x464)]=0x1]='MEAN',_0x4698d8[_0x4698d8[_0x13880c(0x403)]=0x2]=_0x13880c(0x403),_0x4698d8[_0x4698d8[_0x13880c(0x2ef)]=0x3]=_0x13880c(0x2ef);}(Reduction||(Reduction={})));function computeWeightedLoss_(_0x1ada41,_0x529b3f,_0x388bd5=Reduction['SUM_BY_NONZERO_WEIGHTS']){const _0x3e6291=a0_0x20018c,_0xf019ee=convertToTensor(_0x1ada41,_0x3e6291(0x240),'computeWeightedLoss');let _0x27bc8a=null;_0x529b3f!=null&&(_0x27bc8a=convertToTensor(_0x529b3f,_0x3e6291(0x5d6),_0x3e6291(0x55f)));const _0x215bd0=_0x27bc8a==null?_0xf019ee:mul(_0xf019ee,_0x27bc8a);if(_0x388bd5===Reduction['NONE'])return _0x215bd0;if(_0x388bd5===Reduction[_0x3e6291(0x403)])return sum$1(_0x215bd0);if(_0x388bd5===Reduction[_0x3e6291(0x464)]){if(_0x27bc8a==null)return mean(_0x215bd0);else{const _0x3fa805=_0xf019ee[_0x3e6291(0x302)]/_0x27bc8a['size'],_0x39a1cd=div(sum$1(_0x215bd0),sum$1(_0x27bc8a));return _0x3fa805>0x1?div(_0x39a1cd,scalar(_0x3fa805)):_0x39a1cd;}}if(_0x388bd5===Reduction['SUM_BY_NONZERO_WEIGHTS']){if(_0x27bc8a==null)return div(sum$1(_0x215bd0),scalar(_0xf019ee[_0x3e6291(0x302)]));else{const _0x411ecd=mul(_0x27bc8a,ones$1(_0xf019ee['shape'])),_0x31d3f5=cast(sum$1(notEqual(_0x411ecd,scalar(0x0))),_0x3e6291(0x28b));return div(sum$1(_0x215bd0),_0x31d3f5);}}throw Error('Unknown\x20reduction:\x20'+_0x388bd5);}const computeWeightedLoss=op({'computeWeightedLoss_':computeWeightedLoss_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function absoluteDifference_(_0x338730,_0x4026f3,_0x579f6b,_0x41987e=Reduction[a0_0x20018c(0x2ef)]){const _0x2ae020=a0_0x20018c,_0x133362=convertToTensor(_0x338730,_0x2ae020(0x5b3),'absoluteDifference'),_0x2e1ea1=convertToTensor(_0x4026f3,_0x2ae020(0x184),_0x2ae020(0x363));let _0x41459d=null;_0x579f6b!=null&&(_0x41459d=convertToTensor(_0x579f6b,'weights','absoluteDifference'));assertShapesMatch(_0x133362[_0x2ae020(0x50f)],_0x2e1ea1[_0x2ae020(0x50f)],'Error\x20in\x20absoluteDifference:\x20');const _0x1fdc94=abs(sub(_0x133362,_0x2e1ea1));return computeWeightedLoss(_0x1fdc94,_0x41459d,_0x41987e);}const absoluteDifference=op({'absoluteDifference_':absoluteDifference_});function cosineDistance_(_0x2fde74,_0x531947,_0x14814d,_0x4162e0,_0x1c6382=Reduction[a0_0x20018c(0x2ef)]){const _0x350b31=a0_0x20018c,_0xb3b71a=convertToTensor(_0x2fde74,_0x350b31(0x5b3),_0x350b31(0x3d1)),_0x2b5461=convertToTensor(_0x531947,_0x350b31(0x184),_0x350b31(0x3d1));let _0xe52d6b=null;_0x4162e0!=null&&(_0xe52d6b=convertToTensor(_0x4162e0,'weights',_0x350b31(0x3d1)));assertShapesMatch(_0xb3b71a[_0x350b31(0x50f)],_0x2b5461[_0x350b31(0x50f)],_0x350b31(0x1cd));const _0x42b7d2=scalar(0x1),_0x346f0b=sub(_0x42b7d2,sum$1(mul(_0xb3b71a,_0x2b5461),_0x14814d,!![]));return computeWeightedLoss(_0x346f0b,_0xe52d6b,_0x1c6382);}const cosineDistance=op({'cosineDistance_':cosineDistance_});function hingeLoss_(_0x3822e6,_0x371e24,_0x528d51,_0x3dada5=Reduction[a0_0x20018c(0x2ef)]){const _0x1094b9=a0_0x20018c;let _0x2ab14a=convertToTensor(_0x3822e6,_0x1094b9(0x5b3),_0x1094b9(0x3d7));const _0xa20a99=convertToTensor(_0x371e24,_0x1094b9(0x184),_0x1094b9(0x3d7));let _0x350280=null;_0x528d51!=null&&(_0x350280=convertToTensor(_0x528d51,_0x1094b9(0x5d6),_0x1094b9(0x3d7)));assertShapesMatch(_0x2ab14a['shape'],_0xa20a99['shape'],_0x1094b9(0x166));const _0x5ee477=scalar(0x1);_0x2ab14a=sub(mul(scalar(0x2),_0x2ab14a),_0x5ee477);const _0x2ccf5e=relu(sub(_0x5ee477,mul(_0x2ab14a,_0xa20a99)));return computeWeightedLoss(_0x2ccf5e,_0x350280,_0x3dada5);}const hingeLoss=op({'hingeLoss_':hingeLoss_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function huberLoss_(_0x19c489,_0x42bbbc,_0x112601,_0xcb4a64=0x1,_0xe9488=Reduction[a0_0x20018c(0x2ef)]){const _0x2eb258=a0_0x20018c,_0x119727=convertToTensor(_0x19c489,_0x2eb258(0x5b3),_0x2eb258(0x5b1)),_0x2c87be=convertToTensor(_0x42bbbc,_0x2eb258(0x184),_0x2eb258(0x5b1));let _0xc45417=null;_0x112601!=null&&(_0xc45417=convertToTensor(_0x112601,_0x2eb258(0x5d6),'huberLoss'));assertShapesMatch(_0x119727['shape'],_0x2c87be['shape'],_0x2eb258(0x26c));const _0x4080bd=scalar(_0xcb4a64),_0x65671a=abs(sub(_0x2c87be,_0x119727)),_0x4bafb1=minimum(_0x65671a,_0x4080bd),_0x503f6b=sub(_0x65671a,_0x4bafb1),_0xf12dcf=add$1(mul(scalar(0.5),square(_0x4bafb1)),mul(_0x4080bd,_0x503f6b));return computeWeightedLoss(_0xf12dcf,_0xc45417,_0xe9488);}const huberLoss=op({'huberLoss_':huberLoss_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function logLoss_(_0x35f689,_0x3bd523,_0x3bef70,_0x1dbccb=1e-7,_0x43062c=Reduction['SUM_BY_NONZERO_WEIGHTS']){const _0x29626f=a0_0x20018c,_0x51a579=convertToTensor(_0x35f689,_0x29626f(0x5b3),_0x29626f(0x2ff)),_0x42d5b8=convertToTensor(_0x3bd523,_0x29626f(0x184),_0x29626f(0x2ff));let _0x46645c=null;_0x3bef70!=null&&(_0x46645c=convertToTensor(_0x3bef70,_0x29626f(0x5d6),_0x29626f(0x2ff)));assertShapesMatch(_0x51a579[_0x29626f(0x50f)],_0x42d5b8[_0x29626f(0x50f)],_0x29626f(0x393));const _0x16b459=scalar(0x1),_0x40213c=scalar(_0x1dbccb),_0x307b36=neg(mul(_0x51a579,log$1(add$1(_0x42d5b8,_0x40213c)))),_0x2b1251=mul(sub(_0x16b459,_0x51a579),log$1(add$1(sub(_0x16b459,_0x42d5b8),_0x40213c))),_0x17b8c5=sub(_0x307b36,_0x2b1251);return computeWeightedLoss(_0x17b8c5,_0x46645c,_0x43062c);}const logLoss=op({'logLoss_':logLoss_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function meanSquaredError_(_0x326d30,_0x1fb46e,_0x4f6cc0,_0x6ecc4a=Reduction[a0_0x20018c(0x2ef)]){const _0x584e33=a0_0x20018c,_0x4adbcd=convertToTensor(_0x326d30,'labels',_0x584e33(0x4e6)),_0x47210f=convertToTensor(_0x1fb46e,_0x584e33(0x184),_0x584e33(0x4e6));let _0x2e1776=null;_0x4f6cc0!=null&&(_0x2e1776=convertToTensor(_0x4f6cc0,_0x584e33(0x5d6),_0x584e33(0x4e6)));assertShapesMatch(_0x4adbcd[_0x584e33(0x50f)],_0x47210f[_0x584e33(0x50f)],'Error\x20in\x20meanSquaredError:\x20');const _0x121c3a=squaredDifference(_0x4adbcd,_0x47210f);return computeWeightedLoss(_0x121c3a,_0x2e1776,_0x6ecc4a);}const meanSquaredError=op({'meanSquaredError_':meanSquaredError_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sigmoidCrossEntropyWithLogits_(_0x4365e9,_0x4a9fa9){const _0x2227bb=a0_0x20018c,_0x5142b8=convertToTensor(_0x4365e9,'labels',_0x2227bb(0x422)),_0x3cc5dc=convertToTensor(_0x4a9fa9,_0x2227bb(0x5b9),'sigmoidCrossEntropyWithLogits');assertShapesMatch(_0x5142b8[_0x2227bb(0x50f)],_0x3cc5dc['shape'],_0x2227bb(0x1ba));const _0x3b844b=relu(_0x3cc5dc),_0x3a1bdc=mul(_0x3cc5dc,_0x5142b8),_0x6dd601=log1p(exp(neg(abs(_0x3cc5dc))));return add$1(sub(_0x3b844b,_0x3a1bdc),_0x6dd601);}function sigmoidCrossEntropy_(_0x3457f2,_0x1b060c,_0x566621,_0x4fe758=0x0,_0x48a6dc=Reduction['SUM_BY_NONZERO_WEIGHTS']){const _0x10025b=a0_0x20018c;let _0x24eba2=convertToTensor(_0x3457f2,_0x10025b(0x216),'sigmoidCrossEntropy');const _0x4ee584=convertToTensor(_0x1b060c,_0x10025b(0x5b9),_0x10025b(0x3b3));let _0x40488e=null;_0x566621!=null&&(_0x40488e=convertToTensor(_0x566621,'weights',_0x10025b(0x3b3)));assertShapesMatch(_0x24eba2[_0x10025b(0x50f)],_0x4ee584[_0x10025b(0x50f)],_0x10025b(0x4a3));if(_0x4fe758>0x0){const _0x15438f=scalar(_0x4fe758),_0x8aa0c4=scalar(0x1),_0x55940=scalar(0.5);_0x24eba2=add$1(mul(_0x24eba2,sub(_0x8aa0c4,_0x15438f)),mul(_0x55940,_0x15438f));}const _0x105542=sigmoidCrossEntropyWithLogits_(_0x24eba2,_0x4ee584);return computeWeightedLoss(_0x105542,_0x40488e,_0x48a6dc);}const sigmoidCrossEntropy=op({'sigmoidCrossEntropy_':sigmoidCrossEntropy_});/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function softmaxCrossEntropyWithLogits_(_0x9c7dd3,_0xd7116d,_0x115592=-0x1){const _0x891824=a0_0x20018c;_0x115592===-0x1&&(_0x115592=_0xd7116d['rank']-0x1);if(_0x115592!==_0xd7116d[_0x891824(0x36e)]-0x1)throw Error(_0x891824(0x14a)+(_0x891824(0x504)+_0xd7116d['rank']+'\x20')+('and\x20dim\x20was\x20'+_0x115592));const _0x30320d=customGrad((_0x358941,_0xd9c19e,_0x4010ef)=>{const _0x22443e=_0x891824,_0x1f95cb=!![],_0x60d4d8=logSumExp(_0xd9c19e,[_0x115592],_0x1f95cb),_0x22c6e1=sub(cast(_0xd9c19e,_0x22443e(0x28b)),_0x60d4d8);_0x4010ef([_0x358941,_0x22c6e1]);const _0x1e8459=neg(mul(_0x22c6e1,_0x358941)),_0x28386=sum$1(_0x1e8459,[_0x115592]),_0x321c37=(_0x3f42e4,_0x75b4db)=>{const _0x1b6f5c=_0x22443e,[_0xc8e3b,_0xe573e2]=_0x75b4db,_0x117433=expandShapeToKeepDim(_0x3f42e4[_0x1b6f5c(0x50f)],[_0x115592]);return[mul(reshape(_0x3f42e4,_0x117433),sub(cast(_0xc8e3b,'float32'),exp(_0xe573e2))),mul(reshape(_0x3f42e4,_0x117433),sub(exp(_0xe573e2),cast(_0xc8e3b,_0x1b6f5c(0x28b))))];};return{'value':_0x28386,'gradFunc':_0x321c37};});return _0x30320d(_0x9c7dd3,_0xd7116d);}function softmaxCrossEntropy_(_0x3e0dd7,_0x2b22de,_0x119478,_0x27e05f=0x0,_0x337905=Reduction[a0_0x20018c(0x2ef)]){const _0x36169f=a0_0x20018c;let _0x2c5f69=convertToTensor(_0x3e0dd7,'onehotLabels',_0x36169f(0x37c));const _0xc1c98a=convertToTensor(_0x2b22de,_0x36169f(0x5b9),'softmaxCrossEntropy');let _0x5e2e7e=null;_0x119478!=null&&(_0x5e2e7e=convertToTensor(_0x119478,_0x36169f(0x5d6),_0x36169f(0x37c)));assertShapesMatch(_0x2c5f69[_0x36169f(0x50f)],_0xc1c98a[_0x36169f(0x50f)],_0x36169f(0x4c3));if(_0x27e05f>0x0){const _0x229341=scalar(_0x27e05f),_0x31a83a=scalar(0x1),_0x1e69ee=scalar(_0x2c5f69['shape'][0x1]);_0x2c5f69=add$1(mul(_0x2c5f69,sub(_0x31a83a,_0x229341)),div(_0x229341,_0x1e69ee));}const _0x296542=softmaxCrossEntropyWithLogits_(_0x2c5f69,_0xc1c98a);return computeWeightedLoss(_0x296542,_0x5e2e7e,_0x337905);}const softmaxCrossEntropy=op({'softmaxCrossEntropy_':softmaxCrossEntropy_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sparseFillEmptyRows_(_0x4e8143,_0x19bdaa,_0x4f1caa,_0x497e00){const _0x353772=a0_0x20018c,_0x4cf6cb=convertToTensor(_0x4e8143,_0x353772(0x402),_0x353772(0x340)),_0xb0e5da=convertToTensor(_0x19bdaa,_0x353772(0x313),_0x353772(0x340)),_0x39583a=convertToTensor(_0x4f1caa,_0x353772(0x2e7),_0x353772(0x340)),_0x457205=convertToTensor(_0x497e00,'defaultValue',_0x353772(0x340),_0xb0e5da['dtype']);if(_0x4cf6cb[_0x353772(0x36e)]!==0x2)throw new Error(_0x353772(0x4fe)+_0x4cf6cb['shape']);if(_0xb0e5da[_0x353772(0x36e)]!==0x1)throw new Error(_0x353772(0x167)+_0xb0e5da[_0x353772(0x50f)]);if(_0x39583a[_0x353772(0x36e)]!==0x1)throw new Error(_0x353772(0x13c)+_0x39583a[_0x353772(0x50f)]);if(_0x457205['rank']!==0x0)throw new Error(_0x353772(0x4ef)+_0x457205['shape']);const _0x1e22d4={'indices':_0x4cf6cb,'values':_0xb0e5da,'denseShape':_0x39583a,'defaultValue':_0x457205},_0x895402=ENGINE[_0x353772(0x397)](SparseFillEmptyRows,_0x1e22d4);return{'outputIndices':_0x895402[0x0],'outputValues':_0x895402[0x1],'emptyRowIndicator':_0x895402[0x2],'reverseIndexMap':_0x895402[0x3]};}const sparseFillEmptyRows=op({'sparseFillEmptyRows_':sparseFillEmptyRows_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sparseReshape_(_0x46cf9f,_0x1ec681,_0x4925a4){const _0x3583a7=a0_0x20018c,_0x429e94=convertToTensor(_0x46cf9f,'inputIndices','sparseReshape'),_0x201770=convertToTensor(_0x1ec681,_0x3583a7(0x270),_0x3583a7(0x4e1)),_0x20e832=convertToTensor(_0x4925a4,_0x3583a7(0x4bf),_0x3583a7(0x4e1));if(_0x429e94[_0x3583a7(0x36e)]!==0x2)throw new Error('Input\x20indices\x20should\x20be\x20Tensor2D\x20but\x20received\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20'+_0x429e94['shape']);if(_0x201770[_0x3583a7(0x36e)]!==0x1)throw new Error(_0x3583a7(0x3ed)+_0x201770[_0x3583a7(0x50f)]);if(_0x20e832['rank']!==0x1)throw new Error('New\x20shape\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x20'+_0x20e832[_0x3583a7(0x50f)]);const _0x2b9726={'inputIndices':_0x429e94,'inputShape':_0x201770,'newShape':_0x20e832},_0x439d25=ENGINE[_0x3583a7(0x397)](SparseReshape,_0x2b9726);return{'outputIndices':_0x439d25[0x0],'outputShape':_0x439d25[0x1]};}const sparseReshape=op({'sparseReshape_':sparseReshape_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sparseSegmentMean_(_0x1fffa3,_0xf534bd,_0x35a8e9){const _0x3c4398=a0_0x20018c,_0x5ac24a=convertToTensor(_0x1fffa3,_0x3c4398(0x186),_0x3c4398(0x558)),_0x2dad7c=convertToTensor(_0xf534bd,'indices',_0x3c4398(0x558)),_0x330dce=convertToTensor(_0x35a8e9,_0x3c4398(0x157),_0x3c4398(0x558));if(_0x5ac24a[_0x3c4398(0x36e)]<0x1)throw new Error(_0x3c4398(0x5a4));if(_0x2dad7c['rank']!==0x1)throw new Error(_0x3c4398(0x2c6)+_0x2dad7c[_0x3c4398(0x50f)]);if(_0x330dce['rank']!==0x1)throw new Error('Segment\x20ids\x20should\x20be\x20Tensor1D\x20but\x20received\x20shape\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20'+_0x330dce['shape']);const _0x19a39f={'data':_0x5ac24a,'indices':_0x2dad7c,'segmentIds':_0x330dce};return ENGINE['runKernel'](SparseSegmentMean,_0x19a39f);}const sparseSegmentMean=op({'sparseSegmentMean_':sparseSegmentMean_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function sparseSegmentSum_(_0x4c82f8,_0xa8ce8e,_0x51b239){const _0x28c8e2=a0_0x20018c,_0x541dd0=convertToTensor(_0x4c82f8,_0x28c8e2(0x186),_0x28c8e2(0x2eb)),_0x13660b=convertToTensor(_0xa8ce8e,_0x28c8e2(0x402),'sparseSegmentSum'),_0x21f70d=convertToTensor(_0x51b239,'segmentIds',_0x28c8e2(0x2eb));if(_0x541dd0['rank']<0x1)throw new Error('Data\x20should\x20be\x20at\x20least\x201\x20dimensional\x20but\x20received\x20scalar');if(_0x13660b[_0x28c8e2(0x36e)]!==0x1)throw new Error(_0x28c8e2(0x4e9)+_0x13660b[_0x28c8e2(0x50f)]);if(_0x21f70d[_0x28c8e2(0x36e)]!==0x1)throw new Error(_0x28c8e2(0x379)+_0x21f70d[_0x28c8e2(0x50f)]);const _0x163352={'data':_0x541dd0,'indices':_0x13660b,'segmentIds':_0x21f70d};return ENGINE['runKernel'](SparseSegmentSum,_0x163352);}const sparseSegmentSum=op({'sparseSegmentSum_':sparseSegmentSum_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function stringNGrams_(_0x5c19e8,_0x99f937,_0x20b176,_0x1a55be,_0x42b10f,_0x2b2d9e,_0x80052b,_0x275467){const _0x394c98=a0_0x20018c,_0x128b65=convertToTensor(_0x5c19e8,_0x394c98(0x186),'stringNGrams',_0x394c98(0x5cf));if(_0x128b65[_0x394c98(0x51c)]!=='string')throw new Error('Data\x20must\x20be\x20of\x20datatype\x20string');if(_0x128b65[_0x394c98(0x50f)][_0x394c98(0x104)]!==0x1)throw new Error(_0x394c98(0x190)+_0x128b65[_0x394c98(0x50f)]);const _0x56e925=convertToTensor(_0x99f937,_0x394c98(0x40d),_0x394c98(0x1ed));if(_0x56e925[_0x394c98(0x51c)]!=='int32')throw new Error(_0x394c98(0x154));const _0x210eba={'separator':_0x20b176,'nGramWidths':_0x1a55be,'leftPad':_0x42b10f,'rightPad':_0x2b2d9e,'padWidth':_0x80052b,'preserveShortSequences':_0x275467},_0x10f7d2={'data':_0x128b65,'dataSplits':_0x56e925},_0x22b6ed=ENGINE[_0x394c98(0x397)](StringNGrams,_0x10f7d2,_0x210eba);return{'nGrams':_0x22b6ed[0x0],'nGramsSplits':_0x22b6ed[0x1]};}const stringNGrams=op({'stringNGrams_':stringNGrams_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function stringSplit_(_0x5e3c00,_0xdccbd9,_0x53a238=!![]){const _0x58bb88=a0_0x20018c,_0x36e381=convertToTensor(_0x5e3c00,_0x58bb88(0x333),_0x58bb88(0x146),_0x58bb88(0x5cf)),_0x3c6eca=convertToTensor(_0xdccbd9,'delimiter','stringSplit','string');if(_0x36e381[_0x58bb88(0x36e)]!==0x1)throw new Error(_0x58bb88(0x399)+_0x36e381[_0x58bb88(0x50f)]);if(_0x3c6eca[_0x58bb88(0x36e)]!==0x0)throw new Error(_0x58bb88(0x507)+_0x3c6eca[_0x58bb88(0x50f)]);const _0x37e0b2={'skipEmpty':_0x53a238},_0x1289f6={'input':_0x36e381,'delimiter':_0x3c6eca},_0x1446fe=ENGINE[_0x58bb88(0x397)](StringSplit,_0x1289f6,_0x37e0b2);return{'indices':_0x1446fe[0x0],'values':_0x1446fe[0x1],'shape':_0x1446fe[0x2]};}const stringSplit=op({'stringSplit_':stringSplit_});/**
 * @license
 * Copyright 2021 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
function stringToHashBucketFast_(_0x4d3474,_0x301348){const _0x4b835c=a0_0x20018c,_0x375bb6=convertToTensor(_0x4d3474,_0x4b835c(0x333),_0x4b835c(0x3e8),_0x4b835c(0x5cf)),_0x1ef389={'numBuckets':_0x301348};if(_0x301348<=0x0)throw new Error(_0x4b835c(0x2ae));const _0x2e4f76={'input':_0x375bb6};return ENGINE[_0x4b835c(0x397)](StringToHashBucketFast,_0x2e4f76,_0x1ef389);}const stringToHashBucketFast=op({'stringToHashBucketFast_':stringToHashBucketFast_}),spectral={'fft':fft,'ifft':ifft,'rfft':rfft,'irfft':irfft},signal={'hammingWindow':hammingWindow,'hannWindow':hannWindow,'frame':frame,'stft':stft},image={'flipLeftRight':flipLeftRight,'grayscaleToRGB':grayscaleToRGB,'resizeNearestNeighbor':resizeNearestNeighbor,'resizeBilinear':resizeBilinear,'rotateWithOffset':rotateWithOffset,'cropAndResize':cropAndResize,'nonMaxSuppression':nonMaxSuppression,'nonMaxSuppressionAsync':nonMaxSuppressionAsync,'nonMaxSuppressionWithScore':nonMaxSuppressionWithScore,'nonMaxSuppressionWithScoreAsync':nonMaxSuppressionWithScoreAsync,'nonMaxSuppressionPadded':nonMaxSuppressionPadded,'nonMaxSuppressionPaddedAsync':nonMaxSuppressionPaddedAsync,'threshold':threshold,'transform':transform},linalg={'bandPart':bandPart,'gramSchmidt':gramSchmidt,'qr':qr},losses={'absoluteDifference':absoluteDifference,'computeWeightedLoss':computeWeightedLoss,'cosineDistance':cosineDistance,'hingeLoss':hingeLoss,'huberLoss':huberLoss,'logLoss':logLoss,'meanSquaredError':meanSquaredError,'sigmoidCrossEntropy':sigmoidCrossEntropy,'softmaxCrossEntropy':softmaxCrossEntropy},sparse={'sparseFillEmptyRows':sparseFillEmptyRows,'sparseReshape':sparseReshape,'sparseSegmentMean':sparseSegmentMean,'sparseSegmentSum':sparseSegmentSum},string={'stringNGrams':stringNGrams,'stringSplit':stringSplit,'stringToHashBucketFast':stringToHashBucketFast};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x596)]=function(){return this['throwIfDisposed'](),abs(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x48c)]=function(){const _0x4a17e1=a0_0x20018c;return this[_0x4a17e1(0x39e)](),acos(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['acosh']=function(){const _0x10760e=a0_0x20018c;return this[_0x10760e(0x39e)](),acosh(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4ed)]=function(_0x38fc34){return this['throwIfDisposed'](),add$1(this,_0x38fc34);},getGlobalTensorClass()['prototype']['all']=function(_0x1fbc0f,_0x16c4ca){const _0x37a258=a0_0x20018c;return this[_0x37a258(0x39e)](),all(this,_0x1fbc0f,_0x16c4ca);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x322)]=function(_0x5e60d7,_0x53c431){const _0x4c0e00=a0_0x20018c;return this[_0x4c0e00(0x39e)](),any(this,_0x5e60d7,_0x53c431);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x354)]=function(_0x4fd464){const _0x3af8c4=a0_0x20018c;return this[_0x3af8c4(0x39e)](),argMax(this,_0x4fd464);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1ef)]=function(_0x508e36){return this['throwIfDisposed'](),argMin(this,_0x508e36);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4b7)]=function(){const _0x1ae532=a0_0x20018c;return this['throwIfDisposed'](),assert(this['size']===0x1,()=>_0x1ae532(0x339)),reshape(this,[]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x242)]=function(_0x325867){const _0xa5c8da=a0_0x20018c;return this[_0xa5c8da(0x39e)](),cast(this,_0x325867);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x3b1)]=function(){const _0x415d76=a0_0x20018c;return this[_0x415d76(0x39e)](),reshape(this,[this[_0x415d76(0x302)]]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['as2D']=function(_0x5d8e2f,_0x17b156){const _0x4aa57c=a0_0x20018c;return this[_0x4aa57c(0x39e)](),reshape(this,[_0x5d8e2f,_0x17b156]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x43b)]=function(_0x53e77b,_0xc3b4f4,_0x1832e4){return this['throwIfDisposed'](),reshape(this,[_0x53e77b,_0xc3b4f4,_0x1832e4]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x161)]=function(_0x460cbe,_0x467994,_0x416833,_0x110434){return this['throwIfDisposed'](),reshape(this,[_0x460cbe,_0x467994,_0x416833,_0x110434]);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x59f)]=function(_0x1af0ad,_0x1c2f8f,_0x27c41f,_0x11db9f,_0x5c3be6){const _0x2e4ca6=a0_0x20018c;return this[_0x2e4ca6(0x39e)](),reshape(this,[_0x1af0ad,_0x1c2f8f,_0x27c41f,_0x11db9f,_0x5c3be6]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1a9)]=function(){const _0x219a40=a0_0x20018c;return this[_0x219a40(0x39e)](),asin(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4f0)]=function(){const _0x1670e4=a0_0x20018c;return this[_0x1670e4(0x39e)](),asinh(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x3ba)]=function(){const _0x323b88=a0_0x20018c;return this[_0x323b88(0x39e)](),atan(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x4fa)]=function(_0x551b5c){const _0x1704a7=a0_0x20018c;return this[_0x1704a7(0x39e)](),atan2(this,_0x551b5c);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x49c)]=function(){const _0x3edc14=a0_0x20018c;return this[_0x3edc14(0x39e)](),atanh(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['avgPool']=function(_0x174186,_0x3b470b,_0x552d42,_0x113b77){return this['throwIfDisposed'](),avgPool(this,_0x174186,_0x3b470b,_0x552d42,_0x113b77);},getGlobalTensorClass()['prototype']['batchToSpaceND']=function(_0x20bb97,_0x271fbc){const _0x1ef67c=a0_0x20018c;return this[_0x1ef67c(0x39e)](),batchToSpaceND(this,_0x20bb97,_0x271fbc);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x316)]=function(_0x39deb0,_0x30bd91,_0x13c395,_0x14135a,_0xa81b41){return this['throwIfDisposed'](),batchNorm(this,_0x39deb0,_0x30bd91,_0x13c395,_0x14135a,_0xa81b41);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x284)]=function(_0xcd2301){const _0xdebb54=a0_0x20018c;return this[_0xdebb54(0x39e)](),broadcastTo(this,_0xcd2301);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x335)]=function(_0x35e7d5){const _0x31e4b3=a0_0x20018c;return this[_0x31e4b3(0x39e)](),cast(this,_0x35e7d5);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4a7)]=function(){const _0x4e96f2=a0_0x20018c;return this[_0x4e96f2(0x39e)](),ceil(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x11d)]=function(_0x4ea433,_0x47e75f){const _0x346db9=a0_0x20018c;return this[_0x346db9(0x39e)](),clipByValue(this,_0x4ea433,_0x47e75f);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x300)]=function(_0x4adda7,_0x21e15b){const _0x154219=a0_0x20018c;return this[_0x154219(0x39e)](),_0x4adda7 instanceof Tensor&&(_0x4adda7=[_0x4adda7]),concat([this,..._0x4adda7],_0x21e15b);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x202)]=function(_0x1f8a92,_0x200c8b,_0x350836,_0x46ec49,_0x592a48,_0x3a27fa){const _0x522b72=a0_0x20018c;return this[_0x522b72(0x39e)](),conv1d(this,_0x1f8a92,_0x200c8b,_0x350836,_0x46ec49,_0x592a48,_0x3a27fa);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['conv2dTranspose']=function(_0x4f1bc7,_0x3183b8,_0x2591be,_0x5bfa61,_0x213d00){const _0x1c8918=a0_0x20018c;return this[_0x1c8918(0x39e)](),conv2dTranspose(this,_0x4f1bc7,_0x3183b8,_0x2591be,_0x5bfa61,_0x213d00);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x1a1)]=function(_0x4f3690,_0x3daec6,_0x3df77b,_0x2d1616,_0x1fdc88,_0x5158e2){const _0x1b84e1=a0_0x20018c;return this[_0x1b84e1(0x39e)](),conv2d(this,_0x4f3690,_0x3daec6,_0x3df77b,_0x2d1616,_0x1fdc88,_0x5158e2);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x33f)]=function(){const _0x4d8e59=a0_0x20018c;return this[_0x4d8e59(0x39e)](),cos(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x239)]=function(){const _0x10c867=a0_0x20018c;return this[_0x10c867(0x39e)](),cosh(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['cumsum']=function(_0x54e795,_0x450178,_0x4d88f6){const _0x32f1a7=a0_0x20018c;return this[_0x32f1a7(0x39e)](),cumsum(this,_0x54e795,_0x450178,_0x4d88f6);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x5b0)]=function(_0x24efda,_0x234a4a){return this['throwIfDisposed'](),depthToSpace(this,_0x24efda,_0x234a4a);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x125)]=function(_0x5dbc0f,_0x57fa08,_0x3f5822,_0x28eb3a,_0x5f0ed6,_0x547d5d){return this['throwIfDisposed'](),depthwiseConv2d(this,_0x5dbc0f,_0x57fa08,_0x3f5822,_0x28eb3a,_0x5f0ed6,_0x547d5d);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x251)]=function(_0x4d226b,_0x4eb271,_0x3b790a,_0x2769ae,_0x38d276){const _0x4cc424=a0_0x20018c;return this[_0x4cc424(0x39e)](),dilation2d(this,_0x4d226b,_0x4eb271,_0x3b790a,_0x2769ae,_0x38d276);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x273)]=function(_0x54389e){return this['throwIfDisposed'](),divNoNan(this,_0x54389e);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0xfd)]=function(_0x4ebcc0){return this['throwIfDisposed'](),div(this,_0x4ebcc0);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x49e)]=function(_0x44b080){const _0x4b15f0=a0_0x20018c;return this[_0x4b15f0(0x39e)](),dot(this,_0x44b080);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['elu']=function(){return this['throwIfDisposed'](),elu(this);},getGlobalTensorClass()['prototype']['equal']=function(_0x2678e8){return this['throwIfDisposed'](),equal(this,_0x2678e8);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x3dd)]=function(){const _0x161391=a0_0x20018c;return this[_0x161391(0x39e)](),erf(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x57c)]=function(){const _0xd0f1b=a0_0x20018c;return this[_0xd0f1b(0x39e)](),exp(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x54c)]=function(_0x12feb4){const _0x2b14b6=a0_0x20018c;return this[_0x2b14b6(0x39e)](),expandDims(this,_0x12feb4);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x20e)]=function(){const _0x2496bc=a0_0x20018c;return this[_0x2496bc(0x39e)](),expm1(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x432)]=function(){return this['throwIfDisposed'](),fft(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x52e)]=function(){const _0x21a065=a0_0x20018c;return this[_0x21a065(0x39e)](),reshape(this,[this[_0x21a065(0x302)]]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['floor']=function(){const _0x21eca7=a0_0x20018c;return this[_0x21eca7(0x39e)](),floor(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x50c)]=function(_0x2e933f){const _0x1146a4=a0_0x20018c;return this[_0x1146a4(0x39e)](),floorDiv(this,_0x2e933f);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x400)]=function(_0x121e88,_0x35bfeb){const _0x280284=a0_0x20018c;return this[_0x280284(0x39e)](),gather(this,_0x121e88,_0x35bfeb);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1dc)]=function(_0x98f34c){const _0x1a1e17=a0_0x20018c;return this[_0x1a1e17(0x39e)](),greaterEqual(this,_0x98f34c);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x2dd)]=function(_0x1367b4){const _0x481ed6=a0_0x20018c;return this[_0x481ed6(0x39e)](),greater(this,_0x1367b4);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x213)]=function(){const _0x3e2673=a0_0x20018c;return this[_0x3e2673(0x39e)](),ifft(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x288)]=function(){const _0x2da413=a0_0x20018c;return this[_0x2da413(0x39e)](),irfft(this);},getGlobalTensorClass()['prototype']['isFinite']=function(){const _0x170e1f=a0_0x20018c;return this[_0x170e1f(0x39e)](),isFinite$1(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x33b)]=function(){const _0x26aa0b=a0_0x20018c;return this[_0x26aa0b(0x39e)](),isInf(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x2bd)]=function(){return this['throwIfDisposed'](),isNaN$1(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x593)]=function(_0x480186){const _0x4e8690=a0_0x20018c;return this[_0x4e8690(0x39e)](),leakyRelu(this,_0x480186);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['lessEqual']=function(_0xabc34d){const _0x2da1e6=a0_0x20018c;return this[_0x2da1e6(0x39e)](),lessEqual(this,_0xabc34d);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x18d)]=function(_0x38bea0){const _0x1715b7=a0_0x20018c;return this[_0x1715b7(0x39e)](),less(this,_0x38bea0);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4ad)]=function(_0x15a4df,_0x12e373,_0x16da02,_0x168d1a){return this['throwIfDisposed'](),localResponseNormalization(this,_0x15a4df,_0x12e373,_0x16da02,_0x168d1a);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['logSigmoid']=function(){const _0x31c8a6=a0_0x20018c;return this[_0x31c8a6(0x39e)](),logSigmoid(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['logSoftmax']=function(_0x12a923){const _0x218064=a0_0x20018c;return this[_0x218064(0x39e)](),logSoftmax(this,_0x12a923);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x421)]=function(_0x2c901b,_0x47e228){const _0x3e09d8=a0_0x20018c;return this[_0x3e09d8(0x39e)](),logSumExp(this,_0x2c901b,_0x47e228);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4d2)]=function(){const _0x446f3e=a0_0x20018c;return this[_0x446f3e(0x39e)](),log$1(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x2df)]=function(){const _0x8dce8e=a0_0x20018c;return this[_0x8dce8e(0x39e)](),log1p(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x2db)]=function(_0x4f7857){const _0x3dc31a=a0_0x20018c;return this[_0x3dc31a(0x39e)](),logicalAnd(this,_0x4f7857);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4d4)]=function(){return this['throwIfDisposed'](),logicalNot(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1b6)]=function(_0x246172){const _0x5e702a=a0_0x20018c;return this[_0x5e702a(0x39e)](),logicalOr(this,_0x246172);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x41a)]=function(_0x3f7dd5){const _0x1b68d0=a0_0x20018c;return this[_0x1b68d0(0x39e)](),logicalXor(this,_0x3f7dd5);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x356)]=function(_0x152d85,_0x4d439a,_0x253c44){const _0x3cf564=a0_0x20018c;return this[_0x3cf564(0x39e)](),matMul(this,_0x152d85,_0x4d439a,_0x253c44);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x2fb)]=function(_0x571eee,_0x58c960,_0x300de8,_0x480b4a){return this['throwIfDisposed'](),maxPool(this,_0x571eee,_0x58c960,_0x300de8,_0x480b4a);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1e2)]=function(_0x19b708,_0x492928){const _0x558d2d=a0_0x20018c;return this[_0x558d2d(0x39e)](),max(this,_0x19b708,_0x492928);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x38c)]=function(_0x19acf8){return this['throwIfDisposed'](),maximum(this,_0x19acf8);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x51e)]=function(_0xc2cc2d,_0x200059){return this['throwIfDisposed'](),mean(this,_0xc2cc2d,_0x200059);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x58b)]=function(_0x3ea1cc,_0x3e0ccd){const _0x5b683e=a0_0x20018c;return this[_0x5b683e(0x39e)](),min(this,_0x3ea1cc,_0x3e0ccd);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['minimum']=function(_0x305e54){return this['throwIfDisposed'](),minimum(this,_0x305e54);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x2d8)]=function(_0xff006,_0x3bccfc){const _0x479aa3=a0_0x20018c;return this[_0x479aa3(0x39e)](),mirrorPad(this,_0xff006,_0x3bccfc);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['mod']=function(_0x7159b3){const _0x52540c=a0_0x20018c;return this[_0x52540c(0x39e)](),mod(this,_0x7159b3);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['mul']=function(_0x411c33){return this['throwIfDisposed'](),mul(this,_0x411c33);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x40c)]=function(){const _0x4bbbbf=a0_0x20018c;return this[_0x4bbbbf(0x39e)](),neg(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x20d)]=function(_0x31e24f,_0x4cd204,_0x4587a2){const _0x3b2230=a0_0x20018c;return this[_0x3b2230(0x39e)](),norm(this,_0x31e24f,_0x4cd204,_0x4587a2);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['notEqual']=function(_0x2a612a){const _0x112537=a0_0x20018c;return this[_0x112537(0x39e)](),notEqual(this,_0x2a612a);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x548)]=function(_0x3d9b76,_0x30e398=0x1,_0x5ab076=0x0){const _0x41b8bf=a0_0x20018c;return this[_0x41b8bf(0x39e)](),oneHot(this,_0x3d9b76,_0x30e398,_0x5ab076);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x4fd)]=function(){return this['throwIfDisposed'](),onesLike(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x15c)]=function(_0xbd5888,_0x1751e0){return this['throwIfDisposed'](),pad(this,_0xbd5888,_0x1751e0);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x177)]=function(_0x9ecf7b,_0x37a4dc,_0x54df15,_0x24a476,_0x3b3e59){const _0x34430c=a0_0x20018c;return this[_0x34430c(0x39e)](),pool(this,_0x9ecf7b,_0x37a4dc,_0x54df15,_0x24a476,_0x3b3e59);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['pow']=function(_0x27625b){const _0x2dcb54=a0_0x20018c;return this[_0x2dcb54(0x39e)](),pow(this,_0x27625b);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x337)]=function(_0xdaa05c){const _0x1a3161=a0_0x20018c;return this[_0x1a3161(0x39e)](),prelu(this,_0xdaa05c);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['prod']=function(_0x214532,_0x5c7c6d){const _0x1ad620=a0_0x20018c;return this[_0x1ad620(0x39e)](),prod(this,_0x214532,_0x5c7c6d);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['reciprocal']=function(){const _0x81b17a=a0_0x20018c;return this[_0x81b17a(0x39e)](),reciprocal(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x265)]=function(){const _0x1f413d=a0_0x20018c;return this[_0x1f413d(0x39e)](),relu(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['relu6']=function(){const _0x2f6677=a0_0x20018c;return this[_0x2f6677(0x39e)](),relu6(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['reshapeAs']=function(_0x22c0fa){const _0x168cd5=a0_0x20018c;return this[_0x168cd5(0x39e)](),reshape(this,_0x22c0fa[_0x168cd5(0x50f)]);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1cf)]=function(_0x4db006){return this['throwIfDisposed'](),reshape(this,_0x4db006);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['resizeBilinear']=function(_0x13e9e0,_0x319ed0,_0xe8d032){const _0x4ead3f=a0_0x20018c;return this[_0x4ead3f(0x39e)](),resizeBilinear(this,_0x13e9e0,_0x319ed0,_0xe8d032);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1b3)]=function(_0xe26f1f,_0x5b9569,_0x59df93){const _0x1579be=a0_0x20018c;return this[_0x1579be(0x39e)](),resizeNearestNeighbor(this,_0xe26f1f,_0x5b9569,_0x59df93);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['reverse']=function(_0x567769){return this['throwIfDisposed'](),reverse(this,_0x567769);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x331)]=function(){return this['throwIfDisposed'](),rfft(this);},getGlobalTensorClass()['prototype']['round']=function(){const _0x4de526=a0_0x20018c;return this[_0x4de526(0x39e)](),round$1(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x31d)]=function(){const _0x236495=a0_0x20018c;return this[_0x236495(0x39e)](),rsqrt(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0xf9)]=function(){const _0x1096a6=a0_0x20018c;return this[_0x1096a6(0x39e)](),selu(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x3ff)]=function(_0x5a769c,_0x3c33f7,_0x50b48d,_0x92194d,_0x149c7a,_0x214a5b){const _0x2b414e=a0_0x20018c;return this[_0x2b414e(0x39e)](),separableConv2d(this,_0x5a769c,_0x3c33f7,_0x50b48d,_0x92194d,_0x149c7a,_0x214a5b);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x41f)]=function(){const _0x419766=a0_0x20018c;return this[_0x419766(0x39e)](),sigmoid(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x232)]=function(){const _0x346983=a0_0x20018c;return this[_0x346983(0x39e)](),sign(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['sin']=function(){const _0x58fb0e=a0_0x20018c;return this[_0x58fb0e(0x39e)](),sin(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['sinh']=function(){const _0x4a60eb=a0_0x20018c;return this[_0x4a60eb(0x39e)](),sinh(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x2b0)]=function(_0x3ed14b,_0x596c8a){const _0x8f081=a0_0x20018c;return this[_0x8f081(0x39e)](),slice(this,_0x3ed14b,_0x596c8a);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['softmax']=function(_0x55c497){return this['throwIfDisposed'](),softmax(this,_0x55c497);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x429)]=function(){return this['throwIfDisposed'](),softplus(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4ba)]=function(_0x3a132a,_0x505350){const _0x301740=a0_0x20018c;return this[_0x301740(0x39e)](),spaceToBatchND(this,_0x3a132a,_0x505350);},getGlobalTensorClass()['prototype']['split']=function(_0x4fe728,_0x4947f5){return this['throwIfDisposed'](),split(this,_0x4fe728,_0x4947f5);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['sqrt']=function(){const _0x2747f2=a0_0x20018c;return this[_0x2747f2(0x39e)](),sqrt(this);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x3b0)]=function(){const _0x1726e7=a0_0x20018c;return this[_0x1726e7(0x39e)](),square(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x330)]=function(_0x28810d){return this['throwIfDisposed'](),squaredDifference(this,_0x28810d);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['squeeze']=function(_0x8962ee){const _0x360e13=a0_0x20018c;return this[_0x360e13(0x39e)](),squeeze(this,_0x8962ee);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x30e)]=function(_0x37652c,_0x2236af){const _0xc76d35=a0_0x20018c;this[_0xc76d35(0x39e)]();const _0x203f3c=_0x37652c instanceof Tensor?[this,_0x37652c]:[this,..._0x37652c];return stack(_0x203f3c,_0x2236af);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['step']=function(_0x2d349b){const _0xab99a4=a0_0x20018c;return this[_0xab99a4(0x39e)](),step(this,_0x2d349b);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4a9)]=function(_0x403124,_0x461b79,_0x9d2063,_0x1ff08e,_0x9ed560,_0x259e6b,_0x388140,_0x1e45d7){const _0x165b5b=a0_0x20018c;return this[_0x165b5b(0x39e)](),stridedSlice(this,_0x403124,_0x461b79,_0x9d2063,_0x1ff08e,_0x9ed560,_0x259e6b,_0x388140,_0x1e45d7);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x301)]=function(_0x5e3756){return this['throwIfDisposed'](),sub(this,_0x5e3756);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x19e)]=function(_0x4ddb94,_0x1c4fdf){return this['throwIfDisposed'](),sum$1(this,_0x4ddb94,_0x1c4fdf);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x376)]=function(){const _0x5eb580=a0_0x20018c;return this[_0x5eb580(0x39e)](),tan(this);},getGlobalTensorClass()['prototype']['tanh']=function(){return this['throwIfDisposed'](),tanh$1(this);},getGlobalTensorClass()[a0_0x20018c(0x3cb)]['tile']=function(_0x359344){return this['throwIfDisposed'](),tile(this,_0x359344);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x3e5)]=function(){const _0x1c4e7a=a0_0x20018c;return this[_0x1c4e7a(0x39e)](),cast(this,_0x1c4e7a(0x188));},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x2d9)]=function(){const _0x1c93cf=a0_0x20018c;return this[_0x1c93cf(0x39e)](),cast(this,_0x1c93cf(0x28b));},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x160)]=function(){const _0x2e2063=a0_0x20018c;return this[_0x2e2063(0x39e)](),cast(this,_0x2e2063(0x4d1));},getGlobalTensorClass()['prototype']['topk']=function(_0x2661d1,_0x44522e){const _0x3ad9e7=a0_0x20018c;return this[_0x3ad9e7(0x39e)](),topk(this,_0x2661d1,_0x44522e);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x4e0)]=function(_0x4df4ee){return this['throwIfDisposed'](),transpose(this,_0x4df4ee);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4df)]=function(_0x476ff5){const _0x4a388e=a0_0x20018c;return this[_0x4a388e(0x39e)](),unique(this,_0x476ff5);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x4f7)]=function(_0x1708d4,_0x2cb508){const _0x3a1145=a0_0x20018c;return this[_0x3a1145(0x39e)](),unsortedSegmentSum(this,_0x1708d4,_0x2cb508);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x250)]=function(_0x463698){return this['throwIfDisposed'](),unstack(this,_0x463698);},getGlobalTensorClass()['prototype'][a0_0x20018c(0x543)]=function(_0x187ab6,_0x52ee20){const _0x58443e=a0_0x20018c;return this[_0x58443e(0x39e)](),where(_0x187ab6,this,_0x52ee20);},getGlobalTensorClass()[a0_0x20018c(0x3cb)][a0_0x20018c(0x1a8)]=function(){const _0x238cfc=a0_0x20018c;return this[_0x238cfc(0x39e)](),zerosLike(this);};/**
 * @license
 * Copyright 2020 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
/** @license See the LICENSE file. */
var version='3.9.0',version$1={'tfjs-core':tfjsCore[a0_0x20018c(0x413)],'tfjs-backend-cpu':tfjsBackendCpu[a0_0x20018c(0x5bb)],'tfjs-backend-webgl':tfjsBackendWebgl[a0_0x20018c(0x3aa)],'tfjs-data':tfjsData[a0_0x20018c(0x170)],'tfjs-layers':tfjsLayers[a0_0x20018c(0x34b)],'tfjs-converter':tfjsConverter[a0_0x20018c(0x406)],'tfjs':version};Object['keys'](tfjsCore)[a0_0x20018c(0x1e4)](function(_0x3386e5){const _0x465273=a0_0x20018c;if(_0x3386e5!==_0x465273(0x50e))Object[_0x465273(0x41d)](exports,_0x3386e5,{'enumerable':!![],'get':function(){return tfjsCore[_0x3386e5];}});}),Object[a0_0x20018c(0x586)](tfjsLayers)[a0_0x20018c(0x1e4)](function(_0x21f883){const _0x576d76=a0_0x20018c;if(_0x21f883!==_0x576d76(0x50e))Object[_0x576d76(0x41d)](exports,_0x21f883,{'enumerable':!![],'get':function(){return tfjsLayers[_0x21f883];}});}),Object[a0_0x20018c(0x586)](tfjsConverter)[a0_0x20018c(0x1e4)](function(_0x1d8b1c){const _0x35bd10=a0_0x20018c;if(_0x1d8b1c!==_0x35bd10(0x50e))Object['defineProperty'](exports,_0x1d8b1c,{'enumerable':!![],'get':function(){return tfjsConverter[_0x1d8b1c];}});}),exports['data']=tfjsData,exports[a0_0x20018c(0x3a0)]=version$1;