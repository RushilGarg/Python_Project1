/**
 * @license
 * Copyright 2016 E2EMail authors. All rights reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x2b42(){var _0x5a192a=['101466JTtmpB','e2email.models.mail.Thread','1064575wadezQ','2251184UEjThB','e2email.models.mail.Attachment','mail','167342AqfQtt','Mail','840210LEBzzc','e2email.models.mail.Mail','6EJHWvN','440137uDnVpm','1046744BxOKEC','e2email.models.mail.Mailbox','provide','models','Thread'];a0_0x2b42=function(){return _0x5a192a;};return a0_0x2b42();}function a0_0xc36a(_0x4723e1,_0xe4cbd8){var _0x2b4241=a0_0x2b42();return a0_0xc36a=function(_0xc36a4,_0x3624c6){_0xc36a4=_0xc36a4-0x182;var _0x5df9c0=_0x2b4241[_0xc36a4];return _0x5df9c0;},a0_0xc36a(_0x4723e1,_0xe4cbd8);}var a0_0x3f89a5=a0_0xc36a;(function(_0x507b8a,_0xf8b23e){var _0x25b913=a0_0xc36a,_0x26dca0=_0x507b8a();while(!![]){try{var _0x567167=-parseInt(_0x25b913(0x189))/0x1+parseInt(_0x25b913(0x18f))/0x2+parseInt(_0x25b913(0x186))/0x3+parseInt(_0x25b913(0x192))/0x4+-parseInt(_0x25b913(0x191))/0x5+-parseInt(_0x25b913(0x188))/0x6*(-parseInt(_0x25b913(0x184))/0x7)+parseInt(_0x25b913(0x18a))/0x8;if(_0x567167===_0xf8b23e)break;else _0x26dca0['push'](_0x26dca0['shift']());}catch(_0x5167d6){_0x26dca0['push'](_0x26dca0['shift']());}}}(a0_0x2b42,0x60820),goog[a0_0x3f89a5(0x18c)](a0_0x3f89a5(0x182)),goog[a0_0x3f89a5(0x18c)](a0_0x3f89a5(0x187)),goog[a0_0x3f89a5(0x18c)](a0_0x3f89a5(0x18b)),goog[a0_0x3f89a5(0x18c)](a0_0x3f89a5(0x190)),e2email['models']['mail']['Attachment'],e2email['models'][a0_0x3f89a5(0x183)][a0_0x3f89a5(0x185)],e2email[a0_0x3f89a5(0x18d)][a0_0x3f89a5(0x183)]['Mailbox'],e2email[a0_0x3f89a5(0x18d)][a0_0x3f89a5(0x183)][a0_0x3f89a5(0x18e)]);