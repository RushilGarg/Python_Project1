'use strict';const a0_0x5d5156=a0_0x3721;function a0_0x3721(_0xb3e583,_0x1c14ef){const _0x371804=a0_0x3718();return a0_0x3721=function(_0x3721e0,_0x5e29f7){_0x3721e0=_0x3721e0-0xb5;let _0x231a56=_0x371804[_0x3721e0];return _0x231a56;},a0_0x3721(_0xb3e583,_0x1c14ef);}(function(_0x34517a,_0x36b4dc){const _0x2bd305=a0_0x3721,_0x5816a4=_0x34517a();while(!![]){try{const _0xee814c=-parseInt(_0x2bd305(0xc5))/0x1*(parseInt(_0x2bd305(0xfe))/0x2)+parseInt(_0x2bd305(0xe0))/0x3+parseInt(_0x2bd305(0xc1))/0x4*(-parseInt(_0x2bd305(0xf8))/0x5)+parseInt(_0x2bd305(0xe8))/0x6+-parseInt(_0x2bd305(0xc9))/0x7+-parseInt(_0x2bd305(0xb8))/0x8+-parseInt(_0x2bd305(0xc7))/0x9*(-parseInt(_0x2bd305(0xf1))/0xa);if(_0xee814c===_0x36b4dc)break;else _0x5816a4['push'](_0x5816a4['shift']());}catch(_0x5bdcd5){_0x5816a4['push'](_0x5816a4['shift']());}}}(a0_0x3718,0x5511f));const rule=require(a0_0x5d5156(0xe9)),RuleTester=require(a0_0x5d5156(0xed)),fs=require('fs'),path=require(a0_0x5d5156(0xb5)),fixture=fs[a0_0x5d5156(0xc6)](path[a0_0x5d5156(0xbc)](__dirname,'../../fixtures/rules/indent/indent-invalid-fixture-1.js'),a0_0x5d5156(0xe3)),fixedFixture=fs[a0_0x5d5156(0xc6)](path[a0_0x5d5156(0xbc)](__dirname,'../../fixtures/rules/indent/indent-valid-fixture-1.js'),a0_0x5d5156(0xe3)),parser=require('../../fixtures/fixture-parser');function a0_0x3718(){const _0x1bae0c=['3541uIjXmZ','readFileSync','11925963XxyWgm','3\x20tabs','2399621wmZiqt','14\x20spaces','Punctuator','<a\x20href=\x22foo\x22>bar</a>;','unknown-nodes/variable-declarator-type-indent-two-spaces','Line','off','Numeric','length','var\x20x\x20=\x200\x20&&\x20{\x20a:\x201,\x20b:\x202\x20};','unknown-nodes/namespace-invalid','tab','map','unknown-nodes/variable-declarator-type-no-indent','<App></App>','apply','4\x20spaces','module','0\x20spaces','unknown-nodes/namespace-with-functions-with-abstract-class-invalid','indent','<Foo\x20a=\x22b\x22\x20c=\x22d\x22/>;','first','391332xrnjQT','\x20but\x20found\x20','filter','utf8','//\x20comment','Identifier','while\x20(1\x20<\x202)\x20console.log(\x27hi\x27)','\x20\x20//\x20comment','2657844HcFdCU','../../../lib/rules/indent','unknown-nodes/namespace-valid','min','Buffer.length','../../../lib/testers/rule-tester','string','Keyword','var\x20geometry,\x20box,\x20face1,\x20face2,\x20colorT,\x20colorB,\x20sprite,\x20padding,\x20maxWidth;','10FYqkse','[sparse,\x20,\x20array];','import\x20\x27foo\x27','1\x20tab','switch(value){\x20default:\x20a();\x20break;\x20}','unknown-nodes/functions-with-abstract-class-valid','space','804235XuxuMo','new\x20Foo','unknown-nodes/interface','String','new\x20(Foo)','x\x20=>\x20{}','206rxfJUJ','path','Template','replace','5453640AtmKvJ','JSXIdentifier','unknown-nodes/functions-with-abstract-class-invalid','Block','join','2\x20tabs','while\x20(1\x20<\x202)\x20console.log(\x27hi\x27);','Expected\x20indentation\x20of\x20','1\x20space','4qZtoRG','[\x0a]','slice','{\x0a}'];a0_0x3718=function(){return _0x1bae0c;};return a0_0x3718();}function expectedErrors(_0x39d294,_0x68374b){const _0x177acf=a0_0x5d5156;return Array['isArray'](_0x39d294)&&(_0x68374b=_0x39d294,_0x39d294=_0x177acf(0xf7)),!_0x68374b[0x0][_0x177acf(0xd1)]&&(_0x68374b=[_0x68374b]),_0x68374b[_0x177acf(0xd5)](_0x3c330a=>{const _0x16268d=_0x177acf;let _0x2c3986;if(typeof _0x3c330a[0x1]===_0x16268d(0xee)&&typeof _0x3c330a[0x2]===_0x16268d(0xee))_0x2c3986=_0x16268d(0xbf)+_0x3c330a[0x1]+_0x16268d(0xe1)+_0x3c330a[0x2]+'.';else{const _0x2fd653=_0x39d294+(_0x3c330a[0x1]===0x1?'':'s');_0x2c3986=_0x16268d(0xbf)+_0x3c330a[0x1]+'\x20'+_0x2fd653+_0x16268d(0xe1)+_0x3c330a[0x2]+'.';}return{'message':_0x2c3986,'type':_0x3c330a[0x3],'line':_0x3c330a[0x0],'endLine':_0x3c330a[0x0],'column':0x1,'endColumn':parseInt(_0x3c330a[0x2],0xa)+0x1};});}function unIndent(_0xece1d6){const _0x166a6b=a0_0x5d5156,_0x1aacba=_0xece1d6[0x0],_0xa2ee79=_0x1aacba[_0x166a6b(0xb7)](/^\n/,'')[_0x166a6b(0xb7)](/\n\s*$/,'')['split']('\x0a'),_0x34e4fa=_0xa2ee79[_0x166a6b(0xe2)](_0xe69065=>_0xe69065['trim']())['map'](_0xc6be55=>_0xc6be55['match'](/ */)[0x0][_0x166a6b(0xd1)]),_0x3fd327=Math[_0x166a6b(0xeb)][_0x166a6b(0xd8)](null,_0x34e4fa);return _0xa2ee79['map'](_0x291f82=>_0x291f82[_0x166a6b(0xc3)](_0x3fd327))['join']('\x0a');}const ruleTester=new RuleTester({'parserOptions':{'ecmaVersion':0x6,'ecmaFeatures':{'jsx':!![]}}});ruleTester['run'](a0_0x5d5156(0xdd),rule,{'valid':[{'code':unIndent`
                bridge.callHandler(
                  'getAppVersion', 'test23', function(responseData) {
                    window.ah.mobileAppVersion = responseData;
                  }
                );
            `,'options':[0x2]},{'code':unIndent`
                bridge.callHandler(
                  'getAppVersion', 'test23', function(responseData) {
                    window.ah.mobileAppVersion = responseData;
                  });
            `,'options':[0x2]},{'code':unIndent`
                bridge.callHandler(
                  'getAppVersion',
                  null,
                  function responseCallback(responseData) {
                    window.ah.mobileAppVersion = responseData;
                  }
                );
            `,'options':[0x2]},{'code':unIndent`
                bridge.callHandler(
                  'getAppVersion',
                  null,
                  function responseCallback(responseData) {
                    window.ah.mobileAppVersion = responseData;
                  });
            `,'options':[0x2]},{'code':unIndent`
                function doStuff(keys) {
                    _.forEach(
                        keys,
                        key => {
                            doSomething(key);
                        }
                    );
                }
            `,'options':[0x4]},{'code':unIndent`
                example(
                    function () {
                        console.log('example');
                    }
                );
            `,'options':[0x4]},{'code':unIndent`
                let foo = somethingList
                    .filter(x => {
                        return x;
                    })
                    .map(x => {
                        return 100 * x;
                    });
            `,'options':[0x4]},{'code':unIndent`
                var x = 0 &&
                    {
                        a: 1,
                        b: 2
                    };
            `,'options':[0x4]},{'code':unIndent`
                var x = 0 &&
                \t{
                \t\ta: 1,
                \t\tb: 2
                \t};
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                var x = 0 &&
                    {
                        a: 1,
                        b: 2
                    }||
                    {
                        c: 3,
                        d: 4
                    };
            `,'options':[0x4]},{'code':unIndent`
                var x = [
                    'a',
                    'b',
                    'c'
                ];
            `,'options':[0x4]},{'code':unIndent`
                var x = ['a',
                    'b',
                    'c',
                ];
            `,'options':[0x4]},{'code':'var\x20x\x20=\x200\x20&&\x201;','options':[0x4]},{'code':a0_0x5d5156(0xd2),'options':[0x4]},{'code':unIndent`
                var x = 0 &&
                    (
                        1
                    );
            `,'options':[0x4]},{'code':'var\x20x\x20=\x200\x20&&\x20{\x20a:\x201,\x20b:\x202\x20};','options':[0x4]},{'code':unIndent`
                require('http').request({hostname: 'localhost',
                  port: 80}, function(res) {
                  res.end();
                });
            `,'options':[0x2]},{'code':unIndent`
                function test() {
                  return client.signUp(email, PASSWORD, { preVerified: true })
                    .then(function (result) {
                      // hi
                    })
                    .then(function () {
                      return FunctionalHelpers.clearBrowserState(self, {
                        contentServer: true,
                        contentServer1: true
                      });
                    });
                }
            `,'options':[0x2]},{'code':unIndent`
                it('should... some lengthy test description that is forced to be' +
                  'wrapped into two lines since the line length limit is set', () => {
                  expect(true).toBe(true);
                });
            `,'options':[0x2]},{'code':unIndent`
                function test() {
                    return client.signUp(email, PASSWORD, { preVerified: true })
                        .then(function (result) {
                            var x = 1;
                            var y = 1;
                        }, function(err){
                            var o = 1 - 2;
                            var y = 1 - 2;
                            return true;
                        })
                }
            `,'options':[0x4]},{'code':unIndent`
                function test() {
                    return client.signUp(email, PASSWORD, { preVerified: true })
                    .then(function (result) {
                        var x = 1;
                        var y = 1;
                    }, function(err){
                        var o = 1 - 2;
                        var y = 1 - 2;
                        return true;
                    });
                }
            `,'options':[0x4,{'MemberExpression':0x0}]},{'code':'//\x20hi','options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var Command = function() {
                  var fileList = [],
                      files = []

                  files.concat(fileList)
                };
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2,'let':0x2,'const':0x3}}]},{'code':'\x20\x20','options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                if(data) {
                  console.log('hi');
                  b = true;};
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                foo = () => {
                  console.log('hi');
                  return true;};
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                function test(data) {
                  console.log('hi');
                  return true;};
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var test = function(data) {
                  console.log('hi');
                };
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                arr.forEach(function(data) {
                  otherdata.forEach(function(zero) {
                    console.log('hi');
                  }) });
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                a = [
                    ,3
                ]
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                [
                  ['gzip', 'gunzip'],
                  ['gzip', 'unzip'],
                  ['deflate', 'inflate'],
                  ['deflateRaw', 'inflateRaw'],
                ].forEach(function(method) {
                  console.log(method);
                });
            `,'options':[0x2,{'SwitchCase':0x1,'VariableDeclarator':0x2}]},{'code':unIndent`
                test(123, {
                    bye: {
                        hi: [1,
                            {
                                b: 2
                            }
                        ]
                    }
                });
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var xyz = 2,
                    lmn = [
                        {
                            a: 1
                        }
                    ];
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                lmnn = [{
                    a: 1
                },
                {
                    b: 2
                }, {
                    x: 2
                }];
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                [{
                    foo: 1
                }, {
                    foo: 2
                }, {
                    foo: 3
                }]
            `},{'code':unIndent`
                foo([
                    bar
                ], [
                    baz
                ], [
                    qux
                ]);
            `},{'code':unIndent`
                abc({
                    test: [
                        [
                            c,
                            xyz,
                            2
                        ].join(',')
                    ]
                });
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                abc = {
                  test: [
                    [
                      c,
                      xyz,
                      2
                    ]
                  ]
                };
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                abc(
                  {
                    a: 1,
                    b: 2
                  }
                );
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                abc({
                    a: 1,
                    b: 2
                });
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var abc =
                  [
                    c,
                    xyz,
                    {
                      a: 1,
                      b: 2
                    }
                  ];
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var abc = [
                  c,
                  xyz,
                  {
                    a: 1,
                    b: 2
                  }
                ];
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var abc = 5,
                    c = 2,
                    xyz =
                    {
                      a: 1,
                      b: 2
                    };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var foo = 1,
                  bar =
                    2
            `,'options':[0x2,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var foo = 1,
                  bar
                    = 2
            `,'options':[0x2,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var foo
                  = 1,
                  bar
                    = 2
            `,'options':[0x2,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var foo
                  =
                  1,
                  bar
                    =
                    2
            `,'options':[0x2,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var foo
                  = (1),
                  bar
                    = (2)
            `,'options':[0x2,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var foo = 1,
                    bar = 2,
                    baz = 3
                ;
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2}}]},{'code':unIndent`
                var foo = 1,
                    bar = 2,
                    baz = 3
                    ;
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2}}]},{'code':unIndent`
                var abc =
                    {
                      a: 1,
                      b: 2
                    };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var a = new abc({
                        a: 1,
                        b: 2
                    }),
                    b = 2;
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var a = 2,
                  c = {
                    a: 1,
                    b: 2
                  },
                  b = 2;
            `,'options':[0x2,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var x = 2,
                    y = {
                      a: 1,
                      b: 2
                    },
                    b = 2;
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var e = {
                      a: 1,
                      b: 2
                    },
                    b = 2;
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var a = {
                  a: 1,
                  b: 2
                };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                function test() {
                  if (true ||
                            false){
                    console.log(val);
                  }
                }
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var foo = bar ||
                    !(
                        baz
                    );
            `},{'code':unIndent`
                for (var foo = 1;
                    foo < 10;
                    foo++) {}
            `},{'code':unIndent`
                for (
                    var foo = 1;
                    foo < 10;
                    foo++
                ) {}
            `},{'code':unIndent`
                for (var val in obj)
                  if (true)
                    console.log(val);
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                if(true)
                  if (true)
                    if (true)
                      console.log(val);
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                function hi(){     var a = 1;
                  y++;                   x++;
                }
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                for(;length > index; index++)if(NO_HOLES || index in self){
                  x++;
                }
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                function test(){
                  switch(length){
                    case 1: return function(a){
                      return fn.call(that, a);
                    };
                  }
                }
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var geometry = 2,
                rotate = 2;
            `,'options':[0x2,{'VariableDeclarator':0x0}]},{'code':unIndent`
                var geometry,
                    rotate;
            `,'options':[0x4,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var geometry,
                \trotate;
            `,'options':[a0_0x5d5156(0xd4),{'VariableDeclarator':0x1}]},{'code':unIndent`
                var geometry,
                  rotate;
            `,'options':[0x2,{'VariableDeclarator':0x1}]},{'code':unIndent`
                var geometry,
                    rotate;
            `,'options':[0x2,{'VariableDeclarator':0x2}]},{'code':unIndent`
                let geometry,
                    rotate;
            `,'options':[0x2,{'VariableDeclarator':0x2}]},{'code':unIndent`
                const geometry = 2,
                    rotate = 3;
            `,'options':[0x2,{'VariableDeclarator':0x2}]},{'code':unIndent`
                var geometry, box, face1, face2, colorT, colorB, sprite, padding, maxWidth,
                  height, rotate;
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':a0_0x5d5156(0xf0),'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                if (1 < 2){
                //hi sd
                }
            `,'options':[0x2]},{'code':unIndent`
                while (1 < 2){
                  //hi sd
                }
            `,'options':[0x2]},{'code':a0_0x5d5156(0xbe),'options':[0x2]},{'code':unIndent`
                [a, boop,
                    c].forEach((index) => {
                    index;
                });
            `,'options':[0x4]},{'code':unIndent`
                [a, b,
                    c].forEach(function(index){
                    return index;
                });
            `,'options':[0x4]},{'code':unIndent`
                [a, b, c].forEach((index) => {
                    index;
                });
            `,'options':[0x4]},{'code':unIndent`
                [a, b, c].forEach(function(index){
                    return index;
                });
            `,'options':[0x4]},{'code':unIndent`
                (foo)
                    .bar([
                        baz
                    ]);
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                switch (x) {
                    case "foo":
                        a();
                        break;
                    case "bar":
                        switch (y) {
                            case "1":
                                break;
                            case "2":
                                a = 6;
                                break;
                        }
                    case "test":
                        break;
                }
            `,'options':[0x4,{'SwitchCase':0x1}]},{'code':unIndent`
                switch (x) {
                        case "foo":
                            a();
                            break;
                        case "bar":
                            switch (y) {
                                    case "1":
                                        break;
                                    case "2":
                                        a = 6;
                                        break;
                            }
                        case "test":
                            break;
                }
            `,'options':[0x4,{'SwitchCase':0x2}]},{'code':unIndent`
                switch (a) {
                case "foo":
                    a();
                    break;
                case "bar":
                    switch(x){
                    case '1':
                        break;
                    case '2':
                        a = 6;
                        break;
                    }
                }
            `},{'code':unIndent`
                switch (a) {
                case "foo":
                    a();
                    break;
                case "bar":
                    if(x){
                        a = 2;
                    }
                    else{
                        a = 6;
                    }
                }
            `},{'code':unIndent`
                switch (a) {
                case "foo":
                    a();
                    break;
                case "bar":
                    if(x){
                        a = 2;
                    }
                    else
                        a = 6;
                }
            `},{'code':unIndent`
                switch (a) {
                case "foo":
                    a();
                    break;
                case "bar":
                    a(); break;
                case "baz":
                    a(); break;
                }
            `},{'code':unIndent`
                switch (0) {
                }
            `},{'code':unIndent`
                function foo() {
                    var a = "a";
                    switch(a) {
                    case "a":
                        return "A";
                    case "b":
                        return "B";
                    }
                }
                foo();
            `},{'code':unIndent`
                switch(value){
                    case "1":
                    case "2":
                        a();
                        break;
                    default:
                        a();
                        break;
                }
                switch(value){
                    case "1":
                        a();
                        break;
                    case "2":
                        break;
                    default:
                        break;
                }
            `,'options':[0x4,{'SwitchCase':0x1}]},{'code':unIndent`
                var obj = {foo: 1, bar: 2};
                with (obj) {
                    console.log(foo + bar);
                }
            `},{'code':unIndent`
                if (a) {
                    (1 + 2 + 3); // no error on this line
                }
            `},{'code':a0_0x5d5156(0xf5)},{'code':unIndent`
                import {addons} from 'react/addons'
                import React from 'react'
            `,'options':[0x2],'parserOptions':{'sourceType':a0_0x5d5156(0xda)}},{'code':unIndent`
                import {
                    foo,
                    bar,
                    baz
                } from 'qux';
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)}},{'code':unIndent`
                export {
                    foo,
                    bar,
                    baz
                } from 'qux';
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)}},{'code':unIndent`
                var a = 1,
                    b = 2,
                    c = 3;
            `,'options':[0x4]},{'code':unIndent`
                var a = 1
                    ,b = 2
                    ,c = 3;
            `,'options':[0x4]},{'code':a0_0x5d5156(0xe6),'options':[0x2]},{'code':unIndent`
                function salutation () {
                  switch (1) {
                    case 0: return console.log('hi')
                    case 1: return console.log('hey')
                  }
                }
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                var items = [
                  {
                    foo: 'bar'
                  }
                ];
            `,'options':[0x2,{'VariableDeclarator':0x2}]},{'code':unIndent`
                const a = 1,
                      b = 2;
                const items1 = [
                  {
                    foo: 'bar'
                  }
                ];
                const items2 = Items(
                  {
                    foo: 'bar'
                  }
                );
            `,'options':[0x2,{'VariableDeclarator':0x3}]},{'code':unIndent`
                const geometry = 2,
                      rotate = 3;
                var a = 1,
                  b = 2;
                let light = true,
                    shadow = false;
            `,'options':[0x2,{'VariableDeclarator':{'const':0x3,'let':0x2}}]},{'code':unIndent`
                const abc = 5,
                      c = 2,
                      xyz =
                      {
                        a: 1,
                        b: 2
                      };
                let abc2 = 5,
                  c2 = 2,
                  xyz2 =
                  {
                    a: 1,
                    b: 2
                  };
                var abc3 = 5,
                    c3 = 2,
                    xyz3 =
                    {
                      a: 1,
                      b: 2
                    };
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2,'const':0x3},'SwitchCase':0x1}]},{'code':unIndent`
                module.exports = {
                  'Unit tests':
                  {
                    rootPath: './',
                    environment: 'node',
                    tests:
                    [
                      'test/test-*.js'
                    ],
                    sources:
                    [
                      '*.js',
                      'test/**.js'
                    ]
                  }
                };
            `,'options':[0x2]},{'code':unIndent`
                foo =
                  bar;
            `,'options':[0x2]},{'code':unIndent`
                foo = (
                  bar
                );
            `,'options':[0x2]},{'code':unIndent`
                var path     = require('path')
                  , crypto    = require('crypto')
                  ;
            `,'options':[0x2]},{'code':unIndent`
                var a = 1
                    ,b = 2
                    ;
            `},{'code':unIndent`
                export function create (some,
                                        argument) {
                  return Object.create({
                    a: some,
                    b: argument
                  });
                };
            `,'parserOptions':{'sourceType':'module'},'options':[0x2,{'FunctionDeclaration':{'parameters':a0_0x5d5156(0xdf)}}]},{'code':unIndent`
                export function create (id, xfilter, rawType,
                                        width=defaultWidth, height=defaultHeight,
                                        footerHeight=defaultFooterHeight,
                                        padding=defaultPadding) {
                  // ... function body, indented two spaces
                }
            `,'parserOptions':{'sourceType':'module'},'options':[0x2,{'FunctionDeclaration':{'parameters':a0_0x5d5156(0xdf)}}]},{'code':unIndent`
                var obj = {
                  foo: function () {
                    return new p()
                      .then(function (ok) {
                        return ok;
                      }, function () {
                        // ignore things
                      });
                  }
                };
            `,'options':[0x2]},{'code':unIndent`
                a.b()
                  .c(function(){
                    var a;
                  }).d.e;
            `,'options':[0x2]},{'code':unIndent`
                const YO = 'bah',
                      TE = 'mah'

                var res,
                    a = 5,
                    b = 4
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2,'let':0x2,'const':0x3}}]},{'code':unIndent`
                const YO = 'bah',
                      TE = 'mah'

                var res,
                    a = 5,
                    b = 4

                if (YO) console.log(TE)
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2,'let':0x2,'const':0x3}}]},{'code':unIndent`
                var foo = 'foo',
                  bar = 'bar',
                  baz = function() {

                  }

                function hello () {

                }
            `,'options':[0x2]},{'code':unIndent`
                var obj = {
                  send: function () {
                    return P.resolve({
                      type: 'POST'
                    })
                      .then(function () {
                        return true;
                      }, function () {
                        return false;
                      });
                  }
                };
            `,'options':[0x2]},{'code':unIndent`
                var obj = {
                  send: function () {
                    return P.resolve({
                      type: 'POST'
                    })
                    .then(function () {
                      return true;
                    }, function () {
                      return false;
                    });
                  }
                };
            `,'options':[0x2,{'MemberExpression':0x0}]},{'code':unIndent`
                const someOtherFunction = argument => {
                        console.log(argument);
                    },
                    someOtherValue = 'someOtherValue';
            `},{'code':unIndent`
                [
                  'a',
                  'b'
                ].sort().should.deepEqual([
                  'x',
                  'y'
                ]);
            `,'options':[0x2]},{'code':unIndent`
                var a = 1,
                    B = class {
                      constructor(){}
                      a(){}
                      get b(){}
                    };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                var a = 1,
                    B =
                    class {
                      constructor(){}
                      a(){}
                      get b(){}
                    },
                    c = 3;
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}]},{'code':unIndent`
                class A{
                    constructor(){}
                    a(){}
                    get b(){}
                }
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var A = class {
                    constructor(){}
                    a(){}
                    get b(){}
                }
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}]},{'code':unIndent`
                var a = {
                  some: 1
                  , name: 2
                };
            `,'options':[0x2]},{'code':unIndent`
                a.c = {
                    aa: function() {
                        'test1';
                        return 'aa';
                    }
                    , bb: function() {
                        return this.bb();
                    }
                };
            `,'options':[0x4]},{'code':unIndent`
                var a =
                {
                    actions:
                    [
                        {
                            name: 'compile'
                        }
                    ]
                };
            `,'options':[0x4,{'VariableDeclarator':0x0,'SwitchCase':0x1}]},{'code':unIndent`
                var a =
                [
                    {
                        name: 'compile'
                    }
                ];
            `,'options':[0x4,{'VariableDeclarator':0x0,'SwitchCase':0x1}]},{'code':unIndent`
                const func = function (opts) {
                    return Promise.resolve()
                    .then(() => {
                        [
                            'ONE', 'TWO'
                        ].forEach(command => { doSomething(); });
                    });
                };
            `,'options':[0x4,{'MemberExpression':0x0}]},{'code':unIndent`
                const func = function (opts) {
                    return Promise.resolve()
                        .then(() => {
                            [
                                'ONE', 'TWO'
                            ].forEach(command => { doSomething(); });
                        });
                };
            `,'options':[0x4]},{'code':unIndent`
                var haveFun = function () {
                    SillyFunction(
                        {
                            value: true,
                        },
                        {
                            _id: true,
                        }
                    );
                };
            `,'options':[0x4]},{'code':unIndent`
                var haveFun = function () {
                    new SillyFunction(
                        {
                            value: true,
                        },
                        {
                            _id: true,
                        }
                    );
                };
            `,'options':[0x4]},{'code':unIndent`
                let object1 = {
                  doThing() {
                    return _.chain([])
                      .map(v => (
                        {
                          value: true,
                        }
                      ))
                      .value();
                  }
                };
            `,'options':[0x2]},{'code':unIndent`
                var foo = {
                    bar: 1,
                    baz: {
                      qux: 2
                    }
                  },
                  bar = 1;
            `,'options':[0x2]},{'code':unIndent`
                class Foo
                  extends Bar {
                  baz() {}
                }
            `,'options':[0x2]},{'code':unIndent`
                class Foo extends
                  Bar {
                  baz() {}
                }
            `,'options':[0x2]},{'code':unIndent`
                class Foo extends
                  (
                    Bar
                  ) {
                  baz() {}
                }
            `,'options':[0x2]},{'code':unIndent`
                fs.readdirSync(path.join(__dirname, '../rules')).forEach(name => {
                  files[name] = foo;
                });
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                (function(){
                function foo(x) {
                  return x + 1;
                }
                })();
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                (function(){
                        function foo(x) {
                            return x + 1;
                        }
                })();
            `,'options':[0x4,{'outerIIFEBody':0x2}]},{'code':unIndent`
                (function(x, y){
                function foo(x) {
                  return x + 1;
                }
                })(1, 2);
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                (function(){
                function foo(x) {
                  return x + 1;
                }
                }());
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                !function(){
                function foo(x) {
                  return x + 1;
                }
                }();
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                !function(){
                \t\t\tfunction foo(x) {
                \t\t\t\treturn x + 1;
                \t\t\t}
                }();
            `,'options':[a0_0x5d5156(0xd4),{'outerIIFEBody':0x3}]},{'code':unIndent`
                var out = function(){
                  function fooVar(x) {
                    return x + 1;
                  }
                };
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                var ns = function(){
                function fooVar(x) {
                  return x + 1;
                }
                }();
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                ns = function(){
                function fooVar(x) {
                  return x + 1;
                }
                }();
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                var ns = (function(){
                function fooVar(x) {
                  return x + 1;
                }
                }(x));
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                var ns = (function(){
                        function fooVar(x) {
                            return x + 1;
                        }
                }(x));
            `,'options':[0x4,{'outerIIFEBody':0x2}]},{'code':unIndent`
                var obj = {
                  foo: function() {
                    return true;
                  }
                };
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                while (
                  function() {
                    return true;
                  }()) {

                  x = x + 1;
                };
            `,'options':[0x2,{'outerIIFEBody':0x14}]},{'code':unIndent`
                (() => {
                function foo(x) {
                  return x + 1;
                }
                })();
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                function foo() {
                }
            `,'options':[a0_0x5d5156(0xd4),{'outerIIFEBody':0x0}]},{'code':unIndent`
                ;(() => {
                function foo(x) {
                  return x + 1;
                }
                })();
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':unIndent`
                if(data) {
                  console.log('hi');
                }
            `,'options':[0x2,{'outerIIFEBody':0x0}]},{'code':a0_0x5d5156(0xec),'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                Buffer
                    .indexOf('a')
                    .toString()
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                Buffer.
                    length
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                Buffer
                    .foo
                    .bar
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                Buffer
                \t.foo
                \t.bar
            `,'options':[a0_0x5d5156(0xd4),{'MemberExpression':0x1}]},{'code':unIndent`
                Buffer
                    .foo
                    .bar
            `,'options':[0x2,{'MemberExpression':0x2}]},{'code':unIndent`
                MemberExpression
                .can
                  .be
                    .turned
                 .off();
            `,'options':[0x4,{'MemberExpression':a0_0x5d5156(0xcf)}]},{'code':unIndent`
                foo = bar.baz()
                    .bip();
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                if (foo) {
                  bar();
                } else if (baz) {
                  foobar();
                } else if (qux) {
                  qux();
                }
            `,'options':[0x2]},{'code':unIndent`
                function foo(aaa,
                  bbb, ccc, ddd) {
                    bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':0x1,'body':0x2}}]},{'code':unIndent`
                function foo(aaa, bbb,
                      ccc, ddd) {
                  bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':0x3,'body':0x1}}]},{'code':unIndent`
                function foo(aaa,
                    bbb,
                    ccc) {
                            bar();
                }
            `,'options':[0x4,{'FunctionDeclaration':{'parameters':0x1,'body':0x3}}]},{'code':unIndent`
                function foo(aaa,
                             bbb, ccc,
                             ddd, eee, fff) {
                  bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':'first','body':0x1}}]},{'code':unIndent`
                function foo(aaa, bbb)
                {
                      bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'body':0x3}}]},{'code':unIndent`
                function foo(
                  aaa,
                  bbb) {
                    bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':'first','body':0x2}}]},{'code':unIndent`
                var foo = function(aaa,
                    bbb,
                    ccc,
                    ddd) {
                bar();
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':0x2,'body':0x0}}]},{'code':unIndent`
                var foo = function(aaa,
                  bbb,
                  ccc) {
                                    bar();
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':0x1,'body':0xa}}]},{'code':unIndent`
                var foo = function(aaa,
                                   bbb, ccc, ddd,
                                   eee, fff) {
                    bar();
                }
            `,'options':[0x4,{'FunctionExpression':{'parameters':a0_0x5d5156(0xdf),'body':0x1}}]},{'code':unIndent`
                var foo = function(
                  aaa, bbb, ccc,
                  ddd, eee) {
                      bar();
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':a0_0x5d5156(0xdf),'body':0x3}}]},{'code':unIndent`
                foo.bar(
                      baz, qux, function() {
                            qux;
                      }
                );
            `,'options':[0x2,{'FunctionExpression':{'body':0x3},'CallExpression':{'arguments':0x3}}]},{'code':unIndent`
                function foo() {
                  bar();
                  \tbaz();
                \t   \t\t\t  \t\t\t  \t   \tqux();
                }
            `,'options':[0x2]},{'code':unIndent`
                function foo() {
                  function bar() {
                    baz();
                  }
                }
            `,'options':[0x2,{'FunctionDeclaration':{'body':0x1}}]},{'code':unIndent`
                function foo() {
                  bar();
                   \t\t}
            `,'options':[0x2]},{'code':unIndent`
                function foo() {
                  function bar(baz,
                      qux) {
                    foobar();
                  }
                }
            `,'options':[0x2,{'FunctionDeclaration':{'body':0x1,'parameters':0x2}}]},{'code':unIndent`
                ((
                    foo
                ))
            `,'options':[0x4]},{'code':unIndent`
                foo
                  ? bar
                  : baz
            `,'options':[0x2]},{'code':unIndent`
                foo = (bar ?
                  baz :
                  qux
                );
            `,'options':[0x2]},{'code':unIndent`
                [
                    foo ?
                        bar :
                        baz,
                    qux
                ];
            `},{'code':unIndent`
                foo();
                // Line
                /* multiline
                  Line */
                bar();
                // trailing comment
            `,'options':[0x2]},{'code':unIndent`
                switch (foo) {
                  case bar:
                    baz();
                    // call the baz function
                }
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                switch (foo) {
                  case bar:
                    baz();
                  // no default
                }
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                [
                    // no elements
                ]
            `},{'code':unIndent`
                var {
                  foo,
                  bar,
                  baz: qux,
                  foobar: baz = foobar
                } = qux;
            `,'options':[0x2]},{'code':unIndent`
                var [
                  foo,
                  bar,
                  baz,
                  foobar = baz
                ] = qux;
            `,'options':[0x2]},{'code':unIndent`
                var folder = filePath
                    .foo()
                    .bar;
            `,'options':[0x2,{'MemberExpression':0x2}]},{'code':unIndent`
                for (const foo of bar)
                  baz();
            `,'options':[0x2]},{'code':unIndent`
                var x = () =>
                  5;
            `,'options':[0x2]},{'code':unIndent`
                ({code:
                  "foo.bar();"})
            `,'options':[0x2]},{'code':unIndent`
                ({code:
                "foo.bar();"})
            `,'options':[0x2]},{'code':unIndent`
                switch (foo) {
                  // comment
                  case study:
                    // comment
                    bar();
                  case closed:
                    /* multiline comment
                    */
                }
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                switch (foo) {
                  // comment
                  case study:
                  // the comment can also be here
                  case closed:
                }
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                foo && (
                    bar
                )
            `,'options':[0x4]},{'code':unIndent`
                foo && ((
                    bar
                ))
            `,'options':[0x4]},{'code':unIndent`
                foo &&
                    (
                        bar
                    )
            `,'options':[0x4]},{'code':unIndent`
                foo =
                    bar;
            `,'options':[0x4]},{'code':unIndent`
                function foo() {
                  var bar = function(baz,
                        qux) {
                    foobar();
                  };
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':0x3}}]},{'code':unIndent`
                function foo() {
                    return (bar === 1 || bar === 2 &&
                        (/Function/.test(grandparent.type))) &&
                        directives(parent).indexOf(node) >= 0;
                }
            `},{'code':unIndent`
                function foo() {
                    return (foo === bar || (
                        baz === qux && (
                            foo === foo ||
                            bar === bar ||
                            baz === baz
                        )
                    ))
                }
            `,'options':[0x4]},{'code':unIndent`
                if (
                    foo === 1 ||
                    bar === 1 ||
                    // comment
                    (baz === 1 && qux === 1)
                ) {}
            `},{'code':unIndent`
                foo =
                  (bar + baz);
            `,'options':[0x2]},{'code':unIndent`
                function foo() {
                  return (bar === 1 || bar === 2) &&
                    (z === 3 || z === 4);
                }
            `,'options':[0x2]},{'code':unIndent`
                /* comment */ if (foo) {
                  bar();
                }
            `,'options':[0x2]},{'code':unIndent`
                if (foo) {
                  bar();
                // Otherwise, if foo is false, do baz.
                // baz is very important.
                } else {
                  baz();
                }
            `,'options':[0x2]},{'code':unIndent`
                function foo() {
                  return ((bar === 1 || bar === 2) &&
                    (z === 3 || z === 4));
                }
            `,'options':[0x2]},{'code':unIndent`
                foo(
                  bar,
                  baz,
                  qux
                );
            `,'options':[0x2,{'CallExpression':{'arguments':0x1}}]},{'code':unIndent`
                foo(
                \tbar,
                \tbaz,
                \tqux
                );
            `,'options':[a0_0x5d5156(0xd4),{'CallExpression':{'arguments':0x1}}]},{'code':unIndent`
                foo(bar,
                        baz,
                        qux);
            `,'options':[0x4,{'CallExpression':{'arguments':0x2}}]},{'code':unIndent`
                foo(
                bar,
                baz,
                qux
                );
            `,'options':[0x2,{'CallExpression':{'arguments':0x0}}]},{'code':unIndent`
                foo(bar,
                    baz,
                    qux
                );
            `,'options':[0x2,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}]},{'code':unIndent`
                foo(bar, baz,
                    qux, barbaz,
                    barqux, bazqux);
            `,'options':[0x2,{'CallExpression':{'arguments':'first'}}]},{'code':unIndent`
                foo(bar,
                        1 + 2,
                        !baz,
                        new Car('!')
                );
            `,'options':[0x2,{'CallExpression':{'arguments':0x4}}]},{'code':unIndent`
                foo(
                    (bar)
                );
            `},{'code':unIndent`
                foo(
                    (bar)
                );
            `,'options':[0x4,{'CallExpression':{'arguments':0x1}}]},{'code':unIndent`
                var foo = function() {
                  return bar(
                    [{
                    }].concat(baz)
                  );
                };
            `,'options':[0x2]},{'code':unIndent`
                return (
                    foo
                );
            `,'parserOptions':{'ecmaFeatures':{'globalReturn':!![]}}},{'code':unIndent`
                return (
                    foo
                )
            `,'parserOptions':{'ecmaFeatures':{'globalReturn':!![]}}},{'code':unIndent`
                var foo = [
                    bar,
                    baz
                ]
            `},{'code':unIndent`
                var foo = [bar,
                    baz,
                    qux
                ]
            `},{'code':unIndent`
                var foo = [bar,
                baz,
                qux
                ]
            `,'options':[0x2,{'ArrayExpression':0x0}]},{'code':unIndent`
                var foo = [bar,
                                baz,
                                qux
                ]
            `,'options':[0x2,{'ArrayExpression':0x8}]},{'code':unIndent`
                var foo = [bar,
                           baz,
                           qux
                ]
            `,'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                var foo = [bar,
                           baz, qux
                ]
            `,'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                var foo = [
                        { bar: 1,
                          baz: 2 },
                        { bar: 3,
                          baz: 4 }
                ]
            `,'options':[0x4,{'ArrayExpression':0x2,'ObjectExpression':'first'}]},{'code':unIndent`
                var foo = {
                bar: 1,
                baz: 2
                };
            `,'options':[0x2,{'ObjectExpression':0x0}]},{'code':unIndent`
                var foo = { foo: 1, bar: 2,
                            baz: 3 }
            `,'options':[0x2,{'ObjectExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                var foo = [
                        {
                            foo: 1
                        }
                ]
            `,'options':[0x4,{'ArrayExpression':0x2}]},{'code':unIndent`
                function foo() {
                  [
                          foo
                  ]
                }
            `,'options':[0x2,{'ArrayExpression':0x4}]},{'code':a0_0x5d5156(0xc2),'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':'[\x0a]','options':[0x2,{'ArrayExpression':0x1}]},{'code':a0_0x5d5156(0xc4),'options':[0x2,{'ObjectExpression':a0_0x5d5156(0xdf)}]},{'code':'{\x0a}','options':[0x2,{'ObjectExpression':0x1}]},{'code':unIndent`
                var foo = [
                  [
                    1
                  ]
                ]
            `,'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                var foo = [ 1,
                            [
                              2
                            ]
                ];
            `,'options':[0x2,{'ArrayExpression':'first'}]},{'code':unIndent`
                var foo = bar(1,
                              [ 2,
                                3
                              ]
                );
            `,'options':[0x4,{'ArrayExpression':'first','CallExpression':{'arguments':a0_0x5d5156(0xdf)}}]},{'code':unIndent`
                var foo =
                    [
                    ]()
            `,'options':[0x4,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)},'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                const lambda = foo => {
                  Object.assign({},
                    filterName,
                    {
                      display
                    }
                  );
                }
            `,'options':[0x2,{'ObjectExpression':0x1}]},{'code':unIndent`
                const lambda = foo => {
                  Object.assign({},
                    filterName,
                    {
                      display
                    }
                  );
                }
            `,'options':[0x2,{'ObjectExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                var foo = function() {
                \twindow.foo('foo',
                \t\t{
                \t\t\tfoo: 'bar',
                \t\t\tbar: {
                \t\t\t\tfoo: 'bar'
                \t\t\t}
                \t\t}
                \t);
                }
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                echo = spawn('cmd.exe',
                             ['foo', 'bar',
                              'baz']);
            `,'options':[0x2,{'ArrayExpression':'first','CallExpression':{'arguments':a0_0x5d5156(0xdf)}}]},{'code':unIndent`
                if (foo)
                  bar();
                // Otherwise, if foo is false, do baz.
                // baz is very important.
                else {
                  baz();
                }
            `,'options':[0x2]},{'code':unIndent`
                if (
                    foo && bar ||
                    baz && qux // This line is ignored because BinaryExpressions are not checked.
                ) {
                    qux();
                }
            `,'options':[0x4]},{'code':unIndent`
                [
                ] || [
                ]
            `},{'code':unIndent`
                (
                    [
                    ] || [
                    ]
                )
            `},{'code':unIndent`
                1
                + (
                    1
                )
            `},{'code':unIndent`
                (
                    foo && (
                        bar ||
                        baz
                    )
                )
            `},{'code':unIndent`
                var foo =
                        1;
            `,'options':[0x4,{'VariableDeclarator':0x2}]},{'code':unIndent`
                var foo = 1,
                    bar =
                    2;
            `,'options':[0x4]},{'code':unIndent`
                switch (foo) {
                  case bar:
                  {
                    baz();
                  }
                }
            `,'options':[0x2,{'SwitchCase':0x1}]},{'code':unIndent`
                \`foo\${
                  bar}\`
            `,'options':[0x2]},{'code':unIndent`
                \`foo\${
                  \`bar\${
                    baz}\`}\`
            `,'options':[0x2]},{'code':unIndent`
                \`foo\${
                  \`bar\${
                    baz
                  }\`
                }\`
            `,'options':[0x2]},{'code':unIndent`
                \`foo\${
                  (
                    bar
                  )
                }\`
            `,'options':[0x2]},{'code':unIndent`
                function foo() {
                    \`foo\${bar}baz\${
                        qux}foo\${
                        bar}baz\`
                }
            `},{'code':unIndent`
                JSON
                    .stringify(
                        {
                            ok: true
                        }
                    );
            `},{'code':unIndent`
                foo =
                    bar =
                    baz;
            `},{'code':unIndent`
                foo =
                bar =
                    baz;
            `},{'code':unIndent`
                function foo() {
                    const template = \`this indentation is not checked
                because it's part of a template literal.\`;
                }
            `},{'code':unIndent`
                function foo() {
                    const template = \`the indentation of a \${
                        node.type
                    } node is checked.\`;
                }
            `},{'code':unIndent`
                JSON
                    .stringify(
                        {
                            test: 'test'
                        }
                    );
            `,'options':[0x4,{'CallExpression':{'arguments':0x1}}]},{'code':unIndent`
                [
                    foo,
                    // comment
                    // another comment
                    bar
                ]
            `},{'code':unIndent`
                if (foo) {
                    /* comment */ bar();
                }
            `},{'code':unIndent`
                function foo() {
                    return (
                        1
                    );
                }
            `},{'code':unIndent`
                function foo() {
                    return (
                        1
                    )
                }
            `},{'code':unIndent`
                if (
                    foo &&
                    !(
                        bar
                    )
                ) {}
            `},{'code':unIndent`
                var abc = [
                  (
                    ''
                  ),
                  def,
                ]
            `,'options':[0x2]},{'code':unIndent`
                var abc = [
                  (
                    ''
                  ),
                  (
                    'bar'
                  )
                ]
            `,'options':[0x2]},{'code':unIndent`
                function f() {
                    return asyncCall()
                        .then(
                            'some string',
                            [
                                1,
                                2,
                                3
                            ]
                        );
                }
            `},{'code':unIndent`
                function f() {
                    return asyncCall()
                        .then(
                            'some string',
                            [
                                1,
                                2,
                                3
                            ]
                        );
                }
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                var x = [
                    [1],
                    [2]
                ]
            `},{'code':unIndent`
                var y = [
                    {a: 1},
                    {b: 2}
                ]
            `},{'code':unIndent`
                foo(
                )
            `},{'code':unIndent`
                foo(
                    bar,
                    {
                        baz: 1
                    }
                )
            `,'options':[0x4,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}]},{'code':a0_0x5d5156(0xf9)},{'code':a0_0x5d5156(0xfc)},{'code':unIndent`
                if (Foo) {
                    new Foo
                }
            `},{'code':unIndent`
                export {
                    foo,
                    bar,
                    baz
                }
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)}},{'code':unIndent`
                foo
                    ? bar
                    : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo ?
                    bar :
                    baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo ?
                    bar
                    : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo
                    ? bar :
                    baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo
                    ? bar
                    : baz
                        ? qux
                        : foobar
                            ? boop
                            : beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo ?
                    bar :
                    baz ?
                        qux :
                        foobar ?
                            boop :
                            beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                var a =
                    foo ? bar :
                    baz ? qux :
                    foobar ? boop :
                    /*else*/ beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                var a = foo
                    ? bar
                    : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                var a =
                    foo
                        ? bar
                        : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                a =
                    foo ? bar :
                    baz ? qux :
                    foobar ? boop :
                    /*else*/ beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                a = foo
                    ? bar
                    : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                a =
                    foo
                        ? bar
                        : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo(
                    foo ? bar :
                    baz ? qux :
                    foobar ? boop :
                    /*else*/ beep
                )
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                function wrap() {
                    return (
                        foo ? bar :
                        baz ? qux :
                        foobar ? boop :
                        /*else*/ beep
                    )
                }
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                function wrap() {
                    return foo
                        ? bar
                        : baz
                }
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                function wrap() {
                    return (
                        foo
                            ? bar
                            : baz
                    )
                }
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo(
                    foo
                        ? bar
                        : baz
                )
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo(foo
                    ? bar
                    : baz
                )
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                foo
                    ? bar
                    : baz
                        ? qux
                        : foobar
                            ? boop
                            : beep
            `,'options':[0x4,{'flatTernaryExpressions':![]}]},{'code':unIndent`
                foo ?
                    bar :
                    baz ?
                        qux :
                        foobar ?
                            boop :
                            beep
            `,'options':[0x4,{'flatTernaryExpressions':![]}]},{'code':'[,]','options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                [
                    ,
                    foo
                ]
            `,'options':[0x4,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':a0_0x5d5156(0xf2),'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                foo.bar('baz', function(err) {
                  qux;
                });
            `,'options':[0x2,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}]},{'code':unIndent`
                foo.bar(function() {
                  cookies;
                }).baz(function() {
                  cookies;
                });
            `,'options':[0x2,{'MemberExpression':0x1}]},{'code':unIndent`
                foo.bar().baz(function() {
                  cookies;
                }).qux(function() {
                  cookies;
                });
            `,'options':[0x2,{'MemberExpression':0x1}]},{'code':unIndent`
                (
                  {
                    foo: 1,
                    baz: 2
                  }
                );
            `,'options':[0x2,{'ObjectExpression':a0_0x5d5156(0xdf)}]},{'code':unIndent`
                foo(() => {
                    bar;
                }, () => {
                    baz;
                })
            `,'options':[0x4,{'CallExpression':{'arguments':'first'}}]},{'code':unIndent`
                [ foo,
                  bar ].forEach(function() {
                  baz;
                })
            `,'options':[0x2,{'ArrayExpression':'first','MemberExpression':0x1}]},{'code':unIndent`
                foo = bar[
                    baz
                ];
            `},{'code':unIndent`
                foo[
                    bar
                ];
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                foo[
                    (
                        bar
                    )
                ];
            `,'options':[0x4,{'MemberExpression':0x1}]},{'code':unIndent`
                if (foo)
                    bar;
                else if (baz)
                    qux;
            `},{'code':unIndent`
                if (foo) bar()

                ; [1, 2, 3].map(baz)
            `},{'code':a0_0x5d5156(0xfd)},{'code':unIndent`
                import {foo}
                    from 'bar';
            `,'parserOptions':{'sourceType':'module'}},{'code':a0_0x5d5156(0xf3),'parserOptions':{'sourceType':a0_0x5d5156(0xda)}},{'code':unIndent`
                (
                    a
                ) => b => {
                    c
                }
            `},{'code':unIndent`
                (
                    a
                ) => b => c => d => {
                    e
                }
            `},{'code':unIndent`
                (
                    a
                ) =>
                    (
                        b
                    ) => {
                        c
                    }
            `},{'code':unIndent`
                if (
                    foo
                ) bar(
                    baz
                );
            `},{'code':unIndent`
                if (foo)
                {
                    bar();
                }
            `},{'code':unIndent`
                function foo(bar)
                {
                    baz();
                }
            `},{'code':unIndent`
                () =>
                    ({})
            `},{'code':unIndent`
                () =>
                    (({}))
            `},{'code':unIndent`
                (
                    () =>
                        ({})
                )
            `},{'code':unIndent`
                var x = function foop(bar)
                {
                    baz();
                }
            `},{'code':unIndent`
                var x = (bar) =>
                {
                    baz();
                }
            `},{'code':unIndent`
                class Foo
                {
                    constructor()
                    {
                        foo();
                    }

                    bar()
                    {
                        baz();
                    }
                }
            `},{'code':unIndent`
                class Foo
                    extends Bar
                {
                    constructor()
                    {
                        foo();
                    }

                    bar()
                    {
                        baz();
                    }
                }
            `},{'code':unIndent`
                (
                    class Foo
                    {
                        constructor()
                        {
                            foo();
                        }

                        bar()
                        {
                            baz();
                        }
                    }
                )
            `},{'code':unIndent`
                switch (foo)
                {
                    case 1:
                        bar();
                }
            `,'options':[0x4,{'SwitchCase':0x1}]},{'code':unIndent`
                foo
                    .bar(function() {
                        baz
                    })
            `},{'code':unIndent`
                foo
                        .bar(function() {
                            baz
                        })
            `,'options':[0x4,{'MemberExpression':0x2}]},{'code':unIndent`
                foo
                    [bar](function() {
                        baz
                    })
            `},{'code':unIndent`
                foo.
                    bar.
                    baz
            `},{'code':unIndent`
                foo
                    .bar(function() {
                        baz
                    })
            `,'options':[0x4,{'MemberExpression':'off'}]},{'code':unIndent`
                foo
                                .bar(function() {
                                    baz
                                })
            `,'options':[0x4,{'MemberExpression':a0_0x5d5156(0xcf)}]},{'code':unIndent`
                foo
                                [bar](function() {
                                    baz
                                })
            `,'options':[0x4,{'MemberExpression':a0_0x5d5156(0xcf)}]},{'code':unIndent`
                  foo.
                          bar.
                                      baz
            `,'options':[0x4,{'MemberExpression':a0_0x5d5156(0xcf)}]},{'code':unIndent`
                  foo = bar(
                  ).baz(
                  )
            `,'options':[0x4,{'MemberExpression':a0_0x5d5156(0xcf)}]},{'code':unIndent`
                foo[
                    bar ? baz :
                    qux
                ]
            `,'options':[0x4,{'flatTernaryExpressions':!![]}]},{'code':unIndent`
                  foo
                      [
                          bar
                      ]
                      .baz(function() {
                          quz();
                      })
            `},{'code':unIndent`
                  [
                      foo
                  ][
                      "map"](function() {
                      qux();
                  })
            `},{'code':unIndent`
                (
                    a.b(function() {
                        c;
                    })
                )
            `},{'code':unIndent`
                (
                    foo
                ).bar(function() {
                    baz();
                })
            `},{'code':unIndent`
                new Foo(
                    bar
                        .baz
                        .qux
                )
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                        (baz(
                            'bar',
                            'bar'
                        ));
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                    (baz(
                        'bar',
                        'bar'
                    ));
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                        baz(
                            'bar',
                            'bar'
                        );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                    baz(
                        'bar',
                        'bar'
                    );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName
                        = baz(
                            'bar',
                            'bar'
                        );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName
                    = baz(
                        'bar',
                        'bar'
                    );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                        ('fff');
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                    ('fff');
            `},{'code':unIndent`
                const foo = a.b(),
                    longName
                        = ('fff');

            `},{'code':unIndent`
                const foo = a.b(),
                    longName
                    = ('fff');

            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                        (
                            'fff'
                        );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName =
                    (
                        'fff'
                    );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName
                        =(
                            'fff'
                        );
            `},{'code':unIndent`
                const foo = a.b(),
                    longName
                    =(
                        'fff'
                    );
            `},{'code':unIndent`
                interface Foo {
                    bar: string;
                    baz: number;
                }
            `,'parser':parser(a0_0x5d5156(0xfa))},{'code':unIndent`
                namespace Foo {
                    const bar = 3,
                        baz = 2;

                    if (true) {
                        const bax = 3;
                    }
                }
            `,'parser':parser(a0_0x5d5156(0xea))},{'code':unIndent`
                abstract class Foo {
                    public bar() {
                        let aaa = 4,
                            boo;

                        if (true) {
                            boo = 3;
                        }

                        boo = 3 + 2;
                    }
                }
            `,'parser':parser('unknown-nodes/abstract-class-valid')},{'code':unIndent`
                function foo() {
                    function bar() {
                        abstract class X {
                            public baz() {
                                if (true) {
                                    qux();
                                }
                            }
                        }
                    }
                }
            `,'parser':parser(a0_0x5d5156(0xf6))},{'code':unIndent`
                namespace Unknown {
                    function foo() {
                        function bar() {
                            abstract class X {
                                public baz() {
                                    if (true) {
                                        qux();
                                    }
                                }
                            }
                        }
                    }
                }
            `,'parser':parser('unknown-nodes/namespace-with-functions-with-abstract-class-valid')},{'code':unIndent`
                type httpMethod = 'GET'
                  | 'POST'
                  | 'PUT';
            `,'options':[0x2,{'VariableDeclarator':0x0}],'parser':parser(a0_0x5d5156(0xcd))},{'code':unIndent`
                type httpMethod = 'GET'
                | 'POST'
                | 'PUT';
            `,'options':[0x2,{'VariableDeclarator':0x1}],'parser':parser(a0_0x5d5156(0xd6))},{'code':unIndent`
                foo(\`foo
                        \`, {
                        ok: true
                    },
                    {
                        ok: false
                    }
                )
            `},{'code':unIndent`
                foo(tag\`foo
                        \`, {
                        ok: true
                    },
                    {
                        ok: false
                    }
                )
            `},{'code':a0_0x5d5156(0xde)},{'code':unIndent`
                <Foo
                    a="b"
                    c="d"
                />;
            `},{'code':'var\x20foo\x20=\x20<Bar\x20a=\x22b\x22\x20c=\x22d\x22/>;'},{'code':unIndent`
                var foo = <Bar
                    a="b"
                    c="d"
                />;
            `},{'code':unIndent`
                var foo = (<Bar
                    a="b"
                    c="d"
                />);
            `},{'code':unIndent`
                var foo = (
                    <Bar
                        a="b"
                        c="d"
                    />
                );
            `},{'code':unIndent`
                <
                    Foo
                    a="b"
                    c="d"
                />;
            `},{'code':unIndent`
                <Foo
                    a="b"
                    c="d"/>;
            `},{'code':unIndent`
                <
                    Foo
                    a="b"
                    c="d"/>;
            `},{'code':a0_0x5d5156(0xcc)},{'code':unIndent`
                <a href="foo">
                    bar
                </a>;
            `},{'code':unIndent`
                <a
                    href="foo"
                >
                    bar
                </a>;
            `},{'code':unIndent`
                <a
                    href="foo">
                    bar
                </a>;
            `},{'code':unIndent`
                <
                    a
                    href="foo">
                    bar
                </a>;
            `},{'code':unIndent`
                <a
                    href="foo">
                    bar
                </
                    a>;
            `},{'code':unIndent`
                <a
                    href="foo">
                    bar
                </a
                >;
            `},{'code':unIndent`
                var foo = <a href="bar">
                    baz
                </a>;
            `},{'code':unIndent`
                var foo = <a
                    href="bar"
                >
                    baz
                </a>;
            `},{'code':unIndent`
                var foo = <a
                    href="bar">
                    baz
                </a>;
            `},{'code':unIndent`
                var foo = <
                    a
                    href="bar">
                    baz
                </a>;
            `},{'code':unIndent`
                var foo = <a
                    href="bar">
                    baz
                </
                    a>;
            `},{'code':unIndent`
                var foo = <a
                    href="bar">
                    baz
                </a
                >
            `},{'code':unIndent`
                var foo = (<a
                    href="bar">
                    baz
                </a>);
            `},{'code':unIndent`
                var foo = (
                    <a href="bar">baz</a>
                );
            `},{'code':unIndent`
                var foo = (
                    <a href="bar">
                        baz
                    </a>
                );
            `},{'code':unIndent`
                var foo = (
                    <a
                        href="bar">
                        baz
                    </a>
                );
            `},{'code':'var\x20foo\x20=\x20<a\x20href=\x22bar\x22>baz</a>;'},{'code':unIndent`
                <a>
                    {
                    }
                </a>
            `},{'code':unIndent`
                <a>
                    {
                        foo
                    }
                </a>
            `},{'code':unIndent`
                function foo() {
                    return (
                        <a>
                            {
                                b.forEach(() => {
                                    // comment
                                    a = c
                                        .d()
                                        .e();
                                })
                            }
                        </a>
                    );
                }
            `},{'code':a0_0x5d5156(0xd7)},{'code':unIndent`
                <App>
                </App>
            `},{'code':unIndent`
                <App>
                  <Foo />
                </App>
            `,'options':[0x2]},{'code':unIndent`
                <App>
                <Foo />
                </App>
            `,'options':[0x0]},{'code':unIndent`
                <App>
                \t<Foo />
                </App>
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                function App() {
                  return <App>
                    <Foo />
                  </App>;
                }
            `,'options':[0x2]},{'code':unIndent`
                function App() {
                  return (<App>
                    <Foo />
                  </App>);
                }
            `,'options':[0x2]},{'code':unIndent`
                function App() {
                  return (
                    <App>
                      <Foo />
                    </App>
                  );
                }
            `,'options':[0x2]},{'code':unIndent`
                it(
                  (
                    <div>
                      <span />
                    </div>
                  )
                )
            `,'options':[0x2]},{'code':unIndent`
                it(
                  (<div>
                    <span />
                    <span />
                    <span />
                  </div>)
                )
            `,'options':[0x2]},{'code':unIndent`
                (
                  <div>
                    <span />
                  </div>
                )
            `,'options':[0x2]},{'code':unIndent`
                {
                  head.title &&
                  <h1>
                    {head.title}
                  </h1>
                }
            `,'options':[0x2]},{'code':unIndent`
                {
                  head.title &&
                    <h1>
                      {head.title}
                    </h1>
                }
            `,'options':[0x2]},{'code':unIndent`
                {
                  head.title && (
                    <h1>
                      {head.title}
                    </h1>)
                }
            `,'options':[0x2]},{'code':unIndent`
                {
                  head.title && (
                    <h1>
                      {head.title}
                    </h1>
                  )
                }
            `,'options':[0x2]},{'code':unIndent`
                [
                  <div />,
                  <div />
                ]
            `,'options':[0x2]},{'code':unIndent`
                <div>
                    {
                        [
                            <Foo />,
                            <Bar />
                        ]
                    }
                </div>
            `},{'code':unIndent`
                <div>
                    {foo &&
                        [
                            <Foo />,
                            <Bar />
                        ]
                    }
                </div>
            `},{'code':unIndent`
                <div>
                bar <div>
                   bar
                   bar {foo}
                bar </div>
                </div>
            `},{'code':unIndent`
                foo ?
                    <Foo /> :
                    <Bar />
            `},{'code':unIndent`
                foo ?
                    <Foo />
                    : <Bar />
            `},{'code':unIndent`
                foo ?
                    <Foo />
                    :
                    <Bar />
            `},{'code':unIndent`
                {!foo ?
                    <Foo
                        onClick={this.onClick}
                    />
                    :
                    <Bar
                        onClick={this.onClick}
                    />
                }
            `},{'code':unIndent`
                <span>
                  {condition ?
                    <Thing
                      foo={\`bar\`}
                    /> :
                    <Thing/>
                  }
                </span>
            `,'options':[0x2]},{'code':unIndent`
                <span>
                  {condition ?
                    <Thing
                      foo={"bar"}
                    /> :
                    <Thing/>
                  }
                </span>
            `,'options':[0x2]},{'code':unIndent`
                function foo() {
                  <span>
                    {condition ?
                      <Thing
                        foo={super}
                      /> :
                      <Thing/>
                    }
                  </span>
                }
            `,'options':[0x2]},{'code':unIndent`
              <App foo
              />
            `},{'code':unIndent`
              <App
                foo
              />
            `,'options':[0x2]},{'code':unIndent`
              <App
              foo
              />
            `,'options':[0x0]},{'code':unIndent`
              <App
              \tfoo
              />
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                <App
                    foo
                />
            `},{'code':unIndent`
                <App
                    foo
                ></App>
            `},{'code':unIndent`
                <App
                  foo={function() {
                    console.log('bar');
                  }}
                />
            `,'options':[0x2]},{'code':unIndent`
                <App foo={function() {
                  console.log('bar');
                }}
                />
            `,'options':[0x2]},{'code':unIndent`
                var x = function() {
                  return <App
                    foo={function() {
                      console.log('bar');
                    }}
                  />
                }
            `,'options':[0x2]},{'code':unIndent`
                var x = <App
                  foo={function() {
                    console.log('bar');
                  }}
                />
            `,'options':[0x2]},{'code':unIndent`
                <Provider
                  store
                >
                  <App
                    foo={function() {
                      console.log('bar');
                    }}
                  />
                </Provider>
            `,'options':[0x2]},{'code':unIndent`
                <Provider
                  store
                >
                  {baz && <App
                    foo={function() {
                      console.log('bar');
                    }}
                  />}
                </Provider>
            `,'options':[0x2]},{'code':unIndent`
                <App
                \tfoo
                />
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                <App
                \tfoo
                ></App>
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                <App foo={function() {
                \tconsole.log('bar');
                }}
                />
            `,'options':['tab']},{'code':unIndent`
                var x = <App
                \tfoo={function() {
                \t\tconsole.log('bar');
                \t}}
                />
            `,'options':[a0_0x5d5156(0xd4)]},{'code':unIndent`
                <App
                    foo />
            `},{'code':unIndent`
                <div>
                   unrelated{
                        foo
                    }
                </div>
            `},{'code':unIndent`
                <div>unrelated{
                    foo
                }
                </div>
            `},{'code':unIndent`
                <
                    foo
                        .bar
                        .baz
                >
                    foo
                </
                    foo.
                        bar.
                        baz
                >
            `},{'code':unIndent`
                <
                    input
                    type=
                        "number"
                />
            `},{'code':unIndent`
                <
                    input
                    type=
                        {'number'}
                />
            `},{'code':unIndent`
                <
                    input
                    type
                        ="number"
                />
            `},{'code':unIndent`
                foo ? (
                    bar
                ) : (
                    baz
                )
            `},{'code':unIndent`
                foo ? (
                    <div>
                    </div>
                ) : (
                    <span>
                    </span>
                )
            `}],'invalid':[{'code':unIndent`
                var a = b;
                if (a) {
                b();
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,0x2,0x0,'Identifier']]),'output':unIndent`
                var a = b;
                if (a) {
                  b();
                }
            `},{'code':unIndent`
                require('http').request({hostname: 'localhost',
                                  port: 80}, function(res) {
                    res.end();
                  });
            `,'output':unIndent`
                require('http').request({hostname: 'localhost',
                  port: 80}, function(res) {
                  res.end();
                });
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x12,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,'Identifier'],[0x4,0x0,0x2,'Punctuator']])},{'code':unIndent`
                if (array.some(function(){
                  return true;
                })) {
                a++; // ->
                  b++;
                    c++; // <-
                }
            `,'output':unIndent`
                if (array.some(function(){
                  return true;
                })) {
                  a++; // ->
                  b++;
                  c++; // <-
                }
            `,'options':[0x2],'errors':expectedErrors([[0x4,0x2,0x0,a0_0x5d5156(0xe5)],[0x6,0x2,0x4,'Identifier']])},{'code':unIndent`
                if (a){
                \tb=c;
                \t\tc=d;
                e=f;
                }
            `,'output':unIndent`
                if (a){
                \tb=c;
                \tc=d;
                \te=f;
                }
            `,'options':[a0_0x5d5156(0xd4)],'errors':expectedErrors(a0_0x5d5156(0xd4),[[0x3,0x1,0x2,a0_0x5d5156(0xe5)],[0x4,0x1,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                if (a){
                    b=c;
                      c=d;
                 e=f;
                }
            `,'output':unIndent`
                if (a){
                    b=c;
                    c=d;
                    e=f;
                }
            `,'options':[0x4],'errors':expectedErrors([[0x3,0x4,0x6,a0_0x5d5156(0xe5)],[0x4,0x4,0x1,'Identifier']])},{'code':fixture,'output':fixedFixture,'options':[0x2,{'SwitchCase':0x1,'MemberExpression':0x1,'CallExpression':{'arguments':a0_0x5d5156(0xcf)}}],'errors':expectedErrors([[0x5,0x2,0x4,a0_0x5d5156(0xef)],[0x6,0x2,0x0,a0_0x5d5156(0xce)],[0xa,0x4,0x6,a0_0x5d5156(0xcb)],[0xb,0x2,0x4,a0_0x5d5156(0xcb)],[0xf,0x4,0x2,a0_0x5d5156(0xe5)],[0x10,0x2,0x4,'Punctuator'],[0x17,0x2,0x4,a0_0x5d5156(0xcb)],[0x1d,0x2,0x4,'Keyword'],[0x1e,0x4,0x6,a0_0x5d5156(0xe5)],[0x24,0x4,0x6,a0_0x5d5156(0xe5)],[0x26,0x2,0x4,a0_0x5d5156(0xcb)],[0x27,0x4,0x2,a0_0x5d5156(0xe5)],[0x28,0x2,0x0,'Punctuator'],[0x36,0x2,0x4,'Punctuator'],[0x72,0x4,0x2,a0_0x5d5156(0xef)],[0x78,0x4,0x6,'Keyword'],[0x7c,0x4,0x2,a0_0x5d5156(0xef)],[0x86,0x4,0x6,a0_0x5d5156(0xef)],[0x8a,0x2,0x3,'Punctuator'],[0x8b,0x2,0x3,a0_0x5d5156(0xcb)],[0x8f,0x4,0x0,a0_0x5d5156(0xe5)],[0x90,0x6,0x2,a0_0x5d5156(0xcb)],[0x91,0x6,0x2,a0_0x5d5156(0xcb)],[0x97,0x4,0x6,'Identifier'],[0x98,0x6,0x8,'Punctuator'],[0x99,0x6,0x8,'Punctuator'],[0x9f,0x4,0x2,a0_0x5d5156(0xe5)],[0xa1,0x4,0x6,'Identifier'],[0xaf,0x2,0x0,a0_0x5d5156(0xe5)],[0xb1,0x2,0x4,a0_0x5d5156(0xe5)],[0xbd,0x2,0x0,'Keyword'],[0xc0,0x6,0x12,a0_0x5d5156(0xe5)],[0xc1,0x6,0x4,'Identifier'],[0xc3,0x6,0x8,'Identifier'],[0xe4,0x5,0x4,a0_0x5d5156(0xe5)],[0xe7,0x3,0x2,a0_0x5d5156(0xcb)],[0xf5,0x0,0x2,a0_0x5d5156(0xcb)],[0xf8,0x0,0x2,'Punctuator'],[0x130,0x4,0x6,a0_0x5d5156(0xe5)],[0x132,0x4,0x8,a0_0x5d5156(0xe5)],[0x133,0x2,0x4,a0_0x5d5156(0xcb)],[0x134,0x2,0x4,a0_0x5d5156(0xe5)],[0x137,0x4,0x6,a0_0x5d5156(0xe5)],[0x138,0x4,0x6,a0_0x5d5156(0xe5)],[0x139,0x4,0x6,'Identifier'],[0x13a,0x2,0x4,a0_0x5d5156(0xcb)],[0x13b,0x2,0x4,a0_0x5d5156(0xe5)],[0x13e,0x4,0x6,a0_0x5d5156(0xe5)],[0x13f,0x4,0x6,'Identifier'],[0x140,0x4,0x6,a0_0x5d5156(0xe5)],[0x141,0x2,0x4,a0_0x5d5156(0xcb)],[0x142,0x2,0x4,a0_0x5d5156(0xe5)],[0x146,0x2,0x1,a0_0x5d5156(0xd0)],[0x147,0x2,0x1,a0_0x5d5156(0xd0)],[0x148,0x2,0x1,a0_0x5d5156(0xd0)],[0x149,0x2,0x1,'Numeric'],[0x14a,0x2,0x1,'Numeric'],[0x14b,0x2,0x1,a0_0x5d5156(0xd0)],[0x14c,0x2,0x1,'Numeric'],[0x14d,0x2,0x1,'Numeric'],[0x14e,0x2,0x1,'Numeric'],[0x14f,0x2,0x1,a0_0x5d5156(0xd0)],[0x154,0x2,0x4,a0_0x5d5156(0xe5)],[0x155,0x2,0x0,a0_0x5d5156(0xe5)],[0x158,0x2,0x4,a0_0x5d5156(0xe5)],[0x159,0x2,0x0,a0_0x5d5156(0xe5)],[0x15c,0x2,0x4,a0_0x5d5156(0xe5)],[0x15d,0x2,0x0,a0_0x5d5156(0xe5)],[0x163,0x2,0x0,a0_0x5d5156(0xe5)],[0x165,0x2,0x4,a0_0x5d5156(0xe5)],[0x169,0x4,0x6,a0_0x5d5156(0xe5)],[0x16a,0x2,0x4,a0_0x5d5156(0xcb)],[0x16b,0x2,0x4,a0_0x5d5156(0xe5)],[0x170,0x2,0x0,a0_0x5d5156(0xef)],[0x172,0x2,0x4,'Keyword'],[0x176,0x4,0x6,a0_0x5d5156(0xef)],[0x178,0x4,0x2,a0_0x5d5156(0xef)],[0x17f,0x2,0x0,a0_0x5d5156(0xe5)],[0x181,0x2,0x4,a0_0x5d5156(0xe5)],[0x186,0x2,0x0,a0_0x5d5156(0xe5)],[0x188,0x2,0x4,a0_0x5d5156(0xe5)],[0x199,0x2,0x0,a0_0x5d5156(0xe5)],[0x19a,0x2,0x4,a0_0x5d5156(0xe5)],[0x1a0,0x2,0x0,a0_0x5d5156(0xe5)],[0x1a1,0x2,0x4,a0_0x5d5156(0xe5)],[0x1a2,0x0,0x4,a0_0x5d5156(0xcb)],[0x1a6,0x2,0x4,a0_0x5d5156(0xe5)],[0x1a7,0x2,0x0,'Identifier'],[0x1ab,0x2,0x6,a0_0x5d5156(0xe5)],[0x1ac,0x2,0x8,'Identifier'],[0x1ad,0x2,0x4,a0_0x5d5156(0xe5)],[0x1ae,0x0,0x4,a0_0x5d5156(0xcb)],[0x1b1,0x2,0x4,a0_0x5d5156(0xe5)],[0x1b2,0x0,0x4,'Punctuator'],[0x1b5,0x2,0x0,'Identifier'],[0x1b6,0x0,0x4,a0_0x5d5156(0xcb)],[0x1ba,0x2,0x4,a0_0x5d5156(0xe5)],[0x1bb,0x2,0x4,a0_0x5d5156(0xe5)],[0x1bc,0x0,0x2,a0_0x5d5156(0xcb)],[0x1c3,0x2,0x0,a0_0x5d5156(0xe5)],[0x1c5,0x2,0x4,a0_0x5d5156(0xe5)],[0x1f3,0x6,0x8,a0_0x5d5156(0xcb)],[0x1f4,0x8,0x6,a0_0x5d5156(0xe5)],[0x1f8,0x4,0x6,'Punctuator'],[0x1f9,0x6,0x8,a0_0x5d5156(0xe5)],[0x1fa,0x4,0x8,'Punctuator']])},{'code':unIndent`
                switch(value){
                    case "1":
                        a();
                    break;
                    case "2":
                        a();
                    break;
                    default:
                        a();
                        break;
                }
            `,'output':unIndent`
                switch(value){
                    case "1":
                        a();
                        break;
                    case "2":
                        a();
                        break;
                    default:
                        a();
                        break;
                }
            `,'options':[0x4,{'SwitchCase':0x1}],'errors':expectedErrors([[0x4,0x8,0x4,a0_0x5d5156(0xef)],[0x7,0x8,0x4,'Keyword']])},{'code':unIndent`
                var x = 0 &&
                    {
                       a: 1,
                          b: 2
                    };
            `,'output':unIndent`
                var x = 0 &&
                    {
                        a: 1,
                        b: 2
                    };
            `,'options':[0x4],'errors':expectedErrors([[0x3,0x8,0x7,a0_0x5d5156(0xe5)],[0x4,0x8,0xa,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                switch(value){
                    case "1":
                        a();
                        break;
                    case "2":
                        a();
                        break;
                    default:
                    break;
                }
            `,'output':unIndent`
                switch(value){
                    case "1":
                        a();
                        break;
                    case "2":
                        a();
                        break;
                    default:
                        break;
                }
            `,'options':[0x4,{'SwitchCase':0x1}],'errors':expectedErrors([0x9,0x8,0x4,a0_0x5d5156(0xef)])},{'code':unIndent`
                switch(value){
                    case "1":
                    case "2":
                        a();
                        break;
                    default:
                        break;
                }
                switch(value){
                    case "1":
                    break;
                    case "2":
                        a();
                    break;
                    default:
                        a();
                    break;
                }
            `,'output':unIndent`
                switch(value){
                    case "1":
                    case "2":
                        a();
                        break;
                    default:
                        break;
                }
                switch(value){
                    case "1":
                        break;
                    case "2":
                        a();
                        break;
                    default:
                        a();
                        break;
                }
            `,'options':[0x4,{'SwitchCase':0x1}],'errors':expectedErrors([[0xb,0x8,0x4,a0_0x5d5156(0xef)],[0xe,0x8,0x4,a0_0x5d5156(0xef)],[0x11,0x8,0x4,a0_0x5d5156(0xef)]])},{'code':unIndent`
                switch(value){
                case "1":
                        a();
                        break;
                    case "2":
                        break;
                    default:
                        break;
                }
            `,'output':unIndent`
                switch(value){
                case "1":
                    a();
                    break;
                case "2":
                    break;
                default:
                    break;
                }
            `,'options':[0x4],'errors':expectedErrors([[0x3,0x4,0x8,a0_0x5d5156(0xe5)],[0x4,0x4,0x8,a0_0x5d5156(0xef)],[0x5,0x0,0x4,a0_0x5d5156(0xef)],[0x6,0x4,0x8,a0_0x5d5156(0xef)],[0x7,0x0,0x4,a0_0x5d5156(0xef)],[0x8,0x4,0x8,'Keyword']])},{'code':unIndent`
                var obj = {foo: 1, bar: 2};
                with (obj) {
                console.log(foo + bar);
                }
            `,'output':unIndent`
                var obj = {foo: 1, bar: 2};
                with (obj) {
                    console.log(foo + bar);
                }
            `,'errors':expectedErrors([0x3,0x4,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                switch (a) {
                case '1':
                b();
                break;
                default:
                c();
                break;
                }
            `,'output':unIndent`
                switch (a) {
                    case '1':
                        b();
                        break;
                    default:
                        c();
                        break;
                }
            `,'options':[0x4,{'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xef)],[0x3,0x8,0x0,'Identifier'],[0x4,0x8,0x0,'Keyword'],[0x5,0x4,0x0,a0_0x5d5156(0xef)],[0x6,0x8,0x0,a0_0x5d5156(0xe5)],[0x7,0x8,0x0,'Keyword']])},{'code':unIndent`
                var foo = function(){
                    foo
                          .bar
                }
            `,'output':unIndent`
                var foo = function(){
                    foo
                        .bar
                }
            `,'options':[0x4,{'MemberExpression':0x1}],'errors':expectedErrors([0x3,0x8,0xa,a0_0x5d5156(0xcb)])},{'code':unIndent`
                var foo = function(){
                    foo
                             .bar
                }
            `,'output':unIndent`
                var foo = function(){
                    foo
                            .bar
                }
            `,'options':[0x4,{'MemberExpression':0x2}],'errors':expectedErrors([0x3,0xc,0xd,a0_0x5d5156(0xcb)])},{'code':unIndent`
                var foo = () => {
                    foo
                             .bar
                }
            `,'output':unIndent`
                var foo = () => {
                    foo
                            .bar
                }
            `,'options':[0x4,{'MemberExpression':0x2}],'errors':expectedErrors([0x3,0xc,0xd,a0_0x5d5156(0xcb)])},{'code':unIndent`
                TestClass.prototype.method = function () {
                  return Promise.resolve(3)
                      .then(function (x) {
                      return x;
                    });
                };
            `,'output':unIndent`
                TestClass.prototype.method = function () {
                  return Promise.resolve(3)
                    .then(function (x) {
                      return x;
                    });
                };
            `,'options':[0x2,{'MemberExpression':0x1}],'errors':expectedErrors([0x3,0x4,0x6,'Punctuator'])},{'code':unIndent`
                while (a)
                b();
            `,'output':unIndent`
                while (a)
                    b();
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,'Identifier']])},{'code':unIndent`
                lmn = [{
                        a: 1
                    },
                    {
                        b: 2
                    },
                    {
                        x: 2
                }];
            `,'output':unIndent`
                lmn = [{
                    a: 1
                },
                {
                    b: 2
                },
                {
                    x: 2
                }];
            `,'errors':expectedErrors([[0x2,0x4,0x8,a0_0x5d5156(0xe5)],[0x3,0x0,0x4,a0_0x5d5156(0xcb)],[0x4,0x0,0x4,a0_0x5d5156(0xcb)],[0x5,0x4,0x8,a0_0x5d5156(0xe5)],[0x6,0x0,0x4,a0_0x5d5156(0xcb)],[0x7,0x0,0x4,a0_0x5d5156(0xcb)],[0x8,0x4,0x8,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                for (var foo = 1;
                foo < 10;
                foo++) {}
            `,'output':unIndent`
                for (var foo = 1;
                    foo < 10;
                    foo++) {}
            `,'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x0,'Identifier']])},{'code':unIndent`
                for (
                var foo = 1;
                foo < 10;
                foo++
                    ) {}
            `,'output':unIndent`
                for (
                    var foo = 1;
                    foo < 10;
                    foo++
                ) {}
            `,'errors':expectedErrors([[0x2,0x4,0x0,'Keyword'],[0x3,0x4,0x0,'Identifier'],[0x4,0x4,0x0,'Identifier'],[0x5,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                for (;;)
                b();
            `,'output':unIndent`
                for (;;)
                    b();
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,'Identifier']])},{'code':unIndent`
                for (a in x)
                b();
            `,'output':unIndent`
                for (a in x)
                    b();
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,'Identifier']])},{'code':unIndent`
                do
                b();
                while(true)
            `,'output':unIndent`
                do
                    b();
                while(true)
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                if(true)
                b();
            `,'output':unIndent`
                if(true)
                    b();
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var test = {
                      a: 1,
                    b: 2
                    };
            `,'output':unIndent`
                var test = {
                  a: 1,
                  b: 2
                };
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x6,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,'Identifier'],[0x4,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var a = function() {
                      a++;
                    b++;
                          c++;
                    },
                    b;
            `,'output':unIndent`
                var a = function() {
                        a++;
                        b++;
                        c++;
                    },
                    b;
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x8,0x6,'Identifier'],[0x3,0x8,0x4,a0_0x5d5156(0xe5)],[0x4,0x8,0xa,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a = 1,
                b = 2,
                c = 3;
            `,'output':unIndent`
                var a = 1,
                    b = 2,
                    c = 3;
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                [a, b,
                    c].forEach((index) => {
                        index;
                    });
            `,'output':unIndent`
                [a, b,
                    c].forEach((index) => {
                    index;
                });
            `,'options':[0x4],'errors':expectedErrors([[0x3,0x4,0x8,a0_0x5d5156(0xe5)],[0x4,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                [a, b,
                c].forEach(function(index){
                  return index;
                });
            `,'output':unIndent`
                [a, b,
                    c].forEach(function(index){
                    return index;
                });
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                [a, b, c].forEach(function(index){
                  return index;
                });
            `,'output':unIndent`
                [a, b, c].forEach(function(index){
                    return index;
                });
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                (foo)
                    .bar([
                    baz
                ]);
            `,'output':unIndent`
                (foo)
                    .bar([
                        baz
                    ]);
            `,'options':[0x4,{'MemberExpression':0x1}],'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xe5)],[0x4,0x4,0x0,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var x = ['a',
                         'b',
                         'c'
                ];
            `,'output':unIndent`
                var x = ['a',
                    'b',
                    'c'
                ];
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x9,a0_0x5d5156(0xfb)],[0x3,0x4,0x9,a0_0x5d5156(0xfb)]])},{'code':unIndent`
                var x = [
                         'a',
                         'b',
                         'c'
                ];
            `,'output':unIndent`
                var x = [
                    'a',
                    'b',
                    'c'
                ];
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x9,'String'],[0x3,0x4,0x9,a0_0x5d5156(0xfb)],[0x4,0x4,0x9,a0_0x5d5156(0xfb)]])},{'code':unIndent`
                var x = [
                         'a',
                         'b',
                         'c',
                'd'];
            `,'output':unIndent`
                var x = [
                    'a',
                    'b',
                    'c',
                    'd'];
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x9,a0_0x5d5156(0xfb)],[0x3,0x4,0x9,a0_0x5d5156(0xfb)],[0x4,0x4,0x9,a0_0x5d5156(0xfb)],[0x5,0x4,0x0,a0_0x5d5156(0xfb)]])},{'code':unIndent`
                var x = [
                         'a',
                         'b',
                         'c'
                  ];
            `,'output':unIndent`
                var x = [
                    'a',
                    'b',
                    'c'
                ];
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x4,0x9,a0_0x5d5156(0xfb)],[0x3,0x4,0x9,a0_0x5d5156(0xfb)],[0x4,0x4,0x9,'String'],[0x5,0x0,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                while (1 < 2)
                console.log('foo')
                  console.log('bar')
            `,'output':unIndent`
                while (1 < 2)
                  console.log('foo')
                console.log('bar')
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x0,'Identifier'],[0x3,0x0,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function salutation () {
                  switch (1) {
                  case 0: return console.log('hi')
                    case 1: return console.log('hey')
                  }
                }
            `,'output':unIndent`
                function salutation () {
                  switch (1) {
                    case 0: return console.log('hi')
                    case 1: return console.log('hey')
                  }
                }
            `,'options':[0x2,{'SwitchCase':0x1}],'errors':expectedErrors([[0x3,0x4,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                var geometry, box, face1, face2, colorT, colorB, sprite, padding, maxWidth,
                height, rotate;
            `,'output':unIndent`
                var geometry, box, face1, face2, colorT, colorB, sprite, padding, maxWidth,
                  height, rotate;
            `,'options':[0x2,{'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                switch (a) {
                case '1':
                b();
                break;
                default:
                c();
                break;
                }
            `,'output':unIndent`
                switch (a) {
                        case '1':
                            b();
                            break;
                        default:
                            c();
                            break;
                }
            `,'options':[0x4,{'SwitchCase':0x2}],'errors':expectedErrors([[0x2,0x8,0x0,a0_0x5d5156(0xef)],[0x3,0xc,0x0,a0_0x5d5156(0xe5)],[0x4,0xc,0x0,a0_0x5d5156(0xef)],[0x5,0x8,0x0,a0_0x5d5156(0xef)],[0x6,0xc,0x0,a0_0x5d5156(0xe5)],[0x7,0xc,0x0,a0_0x5d5156(0xef)]])},{'code':unIndent`
                var geometry,
                rotate;
            `,'output':unIndent`
                var geometry,
                  rotate;
            `,'options':[0x2,{'VariableDeclarator':0x1}],'errors':expectedErrors([[0x2,0x2,0x0,'Identifier']])},{'code':unIndent`
                var geometry,
                  rotate;
            `,'output':unIndent`
                var geometry,
                    rotate;
            `,'options':[0x2,{'VariableDeclarator':0x2}],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var geometry,
                \trotate;
            `,'output':unIndent`
                var geometry,
                \t\trotate;
            `,'options':[a0_0x5d5156(0xd4),{'VariableDeclarator':0x2}],'errors':expectedErrors('tab',[[0x2,0x2,0x1,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                let geometry,
                  rotate;
            `,'output':unIndent`
                let geometry,
                    rotate;
            `,'options':[0x2,{'VariableDeclarator':0x2}],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                if(true)
                  if (true)
                    if (true)
                    console.log(val);
            `,'output':unIndent`
                if(true)
                  if (true)
                    if (true)
                      console.log(val);
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([[0x4,0x6,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a = {
                    a: 1,
                    b: 2
                }
            `,'output':unIndent`
                var a = {
                  a: 1,
                  b: 2
                }
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a = [
                    a,
                    b
                ]
            `,'output':unIndent`
                var a = [
                  a,
                  b
                ]
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                let a = [
                    a,
                    b
                ]
            `,'output':unIndent`
                let a = [
                  a,
                  b
                ]
            `,'options':[0x2,{'VariableDeclarator':{'let':0x2},'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a = new Test({
                      a: 1
                  }),
                    b = 4;
            `,'output':unIndent`
                var a = new Test({
                        a: 1
                    }),
                    b = 4;
            `,'options':[0x4],'errors':expectedErrors([[0x2,0x8,0x6,'Identifier'],[0x3,0x4,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var a = new Test({
                      a: 1
                    }),
                    b = 4;
                const c = new Test({
                      a: 1
                    }),
                    d = 4;
            `,'output':unIndent`
                var a = new Test({
                      a: 1
                    }),
                    b = 4;
                const c = new Test({
                    a: 1
                  }),
                  d = 4;
            `,'options':[0x2,{'VariableDeclarator':{'var':0x2}}],'errors':expectedErrors([[0x6,0x4,0x6,a0_0x5d5156(0xe5)],[0x7,0x2,0x4,a0_0x5d5156(0xcb)],[0x8,0x2,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var abc = 5,
                    c = 2,
                    xyz =
                    {
                      a: 1,
                       b: 2
                    };
            `,'output':unIndent`
                var abc = 5,
                    c = 2,
                    xyz =
                    {
                      a: 1,
                      b: 2
                    };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([0x6,0x6,0x7,a0_0x5d5156(0xe5)])},{'code':unIndent`
                var abc =
                     {
                       a: 1,
                        b: 2
                     };
            `,'output':unIndent`
                var abc =
                     {
                       a: 1,
                       b: 2
                     };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([0x4,0x7,0x8,'Identifier'])},{'code':unIndent`
                var foo = {
                    bar: 1,
                    baz: {
                        qux: 2
                      }
                  },
                  bar = 1;
            `,'output':unIndent`
                var foo = {
                    bar: 1,
                    baz: {
                      qux: 2
                    }
                  },
                  bar = 1;
            `,'options':[0x2],'errors':expectedErrors([[0x4,0x6,0x8,a0_0x5d5156(0xe5)],[0x5,0x4,0x6,'Punctuator']])},{'code':unIndent`
                var path     = require('path')
                 , crypto    = require('crypto')
                ;
            `,'output':unIndent`
                var path     = require('path')
                  , crypto    = require('crypto')
                ;
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x1,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var a = 1
                   ,b = 2
                ;
            `,'output':unIndent`
                var a = 1
                    ,b = 2
                ;
            `,'errors':expectedErrors([[0x2,0x4,0x3,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                class A{
                  constructor(){}
                    a(){}
                    get b(){}
                }
            `,'output':unIndent`
                class A{
                    constructor(){}
                    a(){}
                    get b(){}
                }
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var A = class {
                  constructor(){}
                    a(){}
                  get b(){}
                };
            `,'output':unIndent`
                var A = class {
                    constructor(){}
                    a(){}
                    get b(){}
                };
            `,'options':[0x4,{'VariableDeclarator':0x1,'SwitchCase':0x1}],'errors':expectedErrors([[0x2,0x4,0x2,'Identifier'],[0x4,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a = 1,
                    B = class {
                    constructor(){}
                      a(){}
                      get b(){}
                    };
            `,'output':unIndent`
                var a = 1,
                    B = class {
                      constructor(){}
                      a(){}
                      get b(){}
                    };
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([[0x3,0x6,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                {
                    if(a){
                        foo();
                    }
                  else{
                        bar();
                    }
                }
            `,'output':unIndent`
                {
                    if(a){
                        foo();
                    }
                    else{
                        bar();
                    }
                }
            `,'options':[0x4],'errors':expectedErrors([[0x5,0x4,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                {
                    if(a){
                        foo();
                    }
                  else
                        bar();

                }
            `,'output':unIndent`
                {
                    if(a){
                        foo();
                    }
                    else
                        bar();

                }
            `,'options':[0x4],'errors':expectedErrors([[0x5,0x4,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                {
                    if(a)
                        foo();
                  else
                        bar();
                }
            `,'output':unIndent`
                {
                    if(a)
                        foo();
                    else
                        bar();
                }
            `,'options':[0x4],'errors':expectedErrors([[0x4,0x4,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                (function(){
                  function foo(x) {
                    return x + 1;
                  }
                })();
            `,'output':unIndent`
                (function(){
                function foo(x) {
                  return x + 1;
                }
                })();
            `,'options':[0x2,{'outerIIFEBody':0x0}],'errors':expectedErrors([[0x2,0x0,0x2,a0_0x5d5156(0xef)],[0x3,0x2,0x4,a0_0x5d5156(0xef)],[0x4,0x0,0x2,'Punctuator']])},{'code':unIndent`
                (function(){
                    function foo(x) {
                        return x + 1;
                    }
                })();
            `,'output':unIndent`
                (function(){
                        function foo(x) {
                            return x + 1;
                        }
                })();
            `,'options':[0x4,{'outerIIFEBody':0x2}],'errors':expectedErrors([[0x2,0x8,0x4,'Keyword'],[0x3,0xc,0x8,'Keyword'],[0x4,0x8,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                if(data) {
                console.log('hi');
                }
            `,'output':unIndent`
                if(data) {
                  console.log('hi');
                }
            `,'options':[0x2,{'outerIIFEBody':0x0}],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var ns = function(){
                    function fooVar(x) {
                        return x + 1;
                    }
                }(x);
            `,'output':unIndent`
                var ns = function(){
                        function fooVar(x) {
                            return x + 1;
                        }
                }(x);
            `,'options':[0x4,{'outerIIFEBody':0x2}],'errors':expectedErrors([[0x2,0x8,0x4,a0_0x5d5156(0xef)],[0x3,0xc,0x8,a0_0x5d5156(0xef)],[0x4,0x8,0x4,'Punctuator']])},{'code':unIndent`
                var obj = {
                  foo: function() {
                  return true;
                  }()
                };
            `,'output':unIndent`
                var obj = {
                  foo: function() {
                    return true;
                  }()
                };
            `,'options':[0x2,{'outerIIFEBody':0x0}],'errors':expectedErrors([[0x3,0x4,0x2,'Keyword']])},{'code':unIndent`
                typeof function() {
                    function fooVar(x) {
                      return x + 1;
                    }
                }();
            `,'output':unIndent`
                typeof function() {
                  function fooVar(x) {
                    return x + 1;
                  }
                }();
            `,'options':[0x2,{'outerIIFEBody':0x2}],'errors':expectedErrors([[0x2,0x2,0x4,'Keyword'],[0x3,0x4,0x6,a0_0x5d5156(0xef)],[0x4,0x2,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                {
                \t!function(x) {
                \t\t\t\treturn x + 1;
                \t}()
                };
            `,'output':unIndent`
                {
                \t!function(x) {
                \t\treturn x + 1;
                \t}()
                };
            `,'options':['tab',{'outerIIFEBody':0x3}],'errors':expectedErrors(a0_0x5d5156(0xd4),[[0x3,0x2,0x4,'Keyword']])},{'code':unIndent`
                Buffer
                .toString()
            `,'output':unIndent`
                Buffer
                    .toString()
            `,'options':[0x4,{'MemberExpression':0x1}],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                Buffer
                    .indexOf('a')
                .toString()
            `,'output':unIndent`
                Buffer
                    .indexOf('a')
                    .toString()
            `,'options':[0x4,{'MemberExpression':0x1}],'errors':expectedErrors([[0x3,0x4,0x0,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                Buffer.
                length
            `,'output':unIndent`
                Buffer.
                    length
            `,'options':[0x4,{'MemberExpression':0x1}],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                Buffer.
                \t\tlength
            `,'output':unIndent`
                Buffer.
                \tlength
            `,'options':[a0_0x5d5156(0xd4),{'MemberExpression':0x1}],'errors':expectedErrors('tab',[[0x2,0x1,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                Buffer
                  .foo
                  .bar
            `,'output':unIndent`
                Buffer
                    .foo
                    .bar
            `,'options':[0x2,{'MemberExpression':0x2}],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xcb)],[0x3,0x4,0x2,'Punctuator']])},{'code':unIndent`
                if (foo) bar();
                else if (baz) foobar();
                  else if (qux) qux();
            `,'output':unIndent`
                if (foo) bar();
                else if (baz) foobar();
                else if (qux) qux();
            `,'options':[0x2],'errors':expectedErrors([0x3,0x0,0x2,a0_0x5d5156(0xef)])},{'code':unIndent`
                if (foo) bar();
                else if (baz) foobar();
                  else qux();
            `,'output':unIndent`
                if (foo) bar();
                else if (baz) foobar();
                else qux();
            `,'options':[0x2],'errors':expectedErrors([0x3,0x0,0x2,a0_0x5d5156(0xef)])},{'code':unIndent`
                foo();
                  if (baz) foobar();
                  else qux();
            `,'output':unIndent`
                foo();
                if (baz) foobar();
                else qux();
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x0,0x2,a0_0x5d5156(0xef)],[0x3,0x0,0x2,a0_0x5d5156(0xef)]])},{'code':unIndent`
                if (foo) bar();
                else if (baz) foobar();
                     else if (bip) {
                       qux();
                     }
            `,'output':unIndent`
                if (foo) bar();
                else if (baz) foobar();
                else if (bip) {
                  qux();
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,0x0,0x5,a0_0x5d5156(0xef)],[0x4,0x2,0x7,a0_0x5d5156(0xe5)],[0x5,0x0,0x5,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                if (foo) bar();
                else if (baz) {
                    foobar();
                     } else if (boop) {
                       qux();
                     }
            `,'output':unIndent`
                if (foo) bar();
                else if (baz) {
                  foobar();
                } else if (boop) {
                  qux();
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,0x2,0x4,a0_0x5d5156(0xe5)],[0x4,0x0,0x5,a0_0x5d5156(0xcb)],[0x5,0x2,0x7,a0_0x5d5156(0xe5)],[0x6,0x0,0x5,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function foo(aaa,
                    bbb, ccc, ddd) {
                      bar();
                }
            `,'output':unIndent`
                function foo(aaa,
                  bbb, ccc, ddd) {
                    bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':0x1,'body':0x2}}],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xe5)],[0x3,0x4,0x6,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo(aaa, bbb,
                  ccc, ddd) {
                bar();
                }
            `,'output':unIndent`
                function foo(aaa, bbb,
                      ccc, ddd) {
                  bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':0x3,'body':0x1}}],'errors':expectedErrors([[0x2,0x6,0x2,a0_0x5d5156(0xe5)],[0x3,0x2,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo(aaa,
                        bbb,
                  ccc) {
                      bar();
                }
            `,'output':unIndent`
                function foo(aaa,
                    bbb,
                    ccc) {
                            bar();
                }
            `,'options':[0x4,{'FunctionDeclaration':{'parameters':0x1,'body':0x3}}],'errors':expectedErrors([[0x2,0x4,0x8,'Identifier'],[0x3,0x4,0x2,a0_0x5d5156(0xe5)],[0x4,0xc,0x6,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo(aaa,
                  bbb, ccc,
                                   ddd, eee, fff) {
                   bar();
                }
            `,'output':unIndent`
                function foo(aaa,
                             bbb, ccc,
                             ddd, eee, fff) {
                  bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':'first','body':0x1}}],'errors':expectedErrors([[0x2,0xd,0x2,'Identifier'],[0x3,0xd,0x13,a0_0x5d5156(0xe5)],[0x4,0x2,0x3,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo(aaa, bbb)
                {
                bar();
                }
            `,'output':unIndent`
                function foo(aaa, bbb)
                {
                      bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'body':0x3}}],'errors':expectedErrors([0x3,0x6,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                function foo(
                aaa,
                    bbb) {
                bar();
                }
            `,'output':unIndent`
                function foo(
                  aaa,
                  bbb) {
                    bar();
                }
            `,'options':[0x2,{'FunctionDeclaration':{'parameters':a0_0x5d5156(0xdf),'body':0x2}}],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,a0_0x5d5156(0xe5)],[0x4,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = function(aaa,
                  bbb,
                    ccc,
                      ddd) {
                  bar();
                }
            `,'output':unIndent`
                var foo = function(aaa,
                    bbb,
                    ccc,
                    ddd) {
                bar();
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':0x2,'body':0x0}}],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xe5)],[0x4,0x4,0x6,'Identifier'],[0x5,0x0,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = function(aaa,
                   bbb,
                 ccc) {
                  bar();
                }
            `,'output':unIndent`
                var foo = function(aaa,
                  bbb,
                  ccc) {
                                    bar();
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':0x1,'body':0xa}}],'errors':expectedErrors([[0x2,0x2,0x3,a0_0x5d5156(0xe5)],[0x3,0x2,0x1,a0_0x5d5156(0xe5)],[0x4,0x14,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = function(aaa,
                  bbb, ccc, ddd,
                                        eee, fff) {
                        bar();
                }
            `,'output':unIndent`
                var foo = function(aaa,
                                   bbb, ccc, ddd,
                                   eee, fff) {
                    bar();
                }
            `,'options':[0x4,{'FunctionExpression':{'parameters':a0_0x5d5156(0xdf),'body':0x1}}],'errors':expectedErrors([[0x2,0x13,0x2,a0_0x5d5156(0xe5)],[0x3,0x13,0x18,a0_0x5d5156(0xe5)],[0x4,0x4,0x8,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = function(
                aaa, bbb, ccc,
                    ddd, eee) {
                  bar();
                }
            `,'output':unIndent`
                var foo = function(
                  aaa, bbb, ccc,
                  ddd, eee) {
                      bar();
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':a0_0x5d5156(0xdf),'body':0x3}}],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,a0_0x5d5156(0xe5)],[0x4,0x6,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = bar;
                \t\t\tvar baz = qux;
            `,'output':unIndent`
                var foo = bar;
                var baz = qux;
            `,'options':[0x2],'errors':expectedErrors([0x2,a0_0x5d5156(0xdb),a0_0x5d5156(0xc8),'Keyword'])},{'code':unIndent`
                function foo() {
                \tbar();
                  baz();
                              qux();
                }
            `,'output':unIndent`
                function foo() {
                \tbar();
                \tbaz();
                \tqux();
                }
            `,'options':[a0_0x5d5156(0xd4)],'errors':expectedErrors(a0_0x5d5156(0xd4),[[0x3,'1\x20tab','2\x20spaces','Identifier'],[0x4,a0_0x5d5156(0xf4),a0_0x5d5156(0xca),a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo() {
                  bar();
                \t\t}
            `,'output':unIndent`
                function foo() {
                  bar();
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,'0\x20spaces',a0_0x5d5156(0xbd),a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function foo() {
                  function bar() {
                        baz();
                  }
                }
            `,'output':unIndent`
                function foo() {
                  function bar() {
                    baz();
                  }
                }
            `,'options':[0x2,{'FunctionDeclaration':{'body':0x1}}],'errors':expectedErrors([0x3,0x4,0x8,a0_0x5d5156(0xe5)])},{'code':unIndent`
                function foo() {
                  function bar(baz,
                    qux) {
                    foobar();
                  }
                }
            `,'output':unIndent`
                function foo() {
                  function bar(baz,
                      qux) {
                    foobar();
                  }
                }
            `,'options':[0x2,{'FunctionDeclaration':{'body':0x1,'parameters':0x2}}],'errors':expectedErrors([0x3,0x6,0x4,a0_0x5d5156(0xe5)])},{'code':unIndent`
                function foo() {
                  var bar = function(baz,
                          qux) {
                    foobar();
                  };
                }
            `,'output':unIndent`
                function foo() {
                  var bar = function(baz,
                        qux) {
                    foobar();
                  };
                }
            `,'options':[0x2,{'FunctionExpression':{'parameters':0x3}}],'errors':expectedErrors([0x3,0x8,0xa,a0_0x5d5156(0xe5)])},{'code':unIndent`
                foo.bar(
                      baz, qux, function() {
                        qux;
                      }
                );
            `,'output':unIndent`
                foo.bar(
                      baz, qux, function() {
                            qux;
                      }
                );
            `,'options':[0x2,{'FunctionExpression':{'body':0x3},'CallExpression':{'arguments':0x3}}],'errors':expectedErrors([0x3,0xc,0x8,a0_0x5d5156(0xe5)])},{'code':unIndent`
                {
                    try {
                    }
                catch (err) {
                    }
                finally {
                    }
                }
            `,'output':unIndent`
                {
                    try {
                    }
                    catch (err) {
                    }
                    finally {
                    }
                }
            `,'errors':expectedErrors([[0x4,0x4,0x0,a0_0x5d5156(0xef)],[0x6,0x4,0x0,a0_0x5d5156(0xef)]])},{'code':unIndent`
                {
                    do {
                    }
                while (true)
                }
            `,'output':unIndent`
                {
                    do {
                    }
                    while (true)
                }
            `,'errors':expectedErrors([0x4,0x4,0x0,a0_0x5d5156(0xef)])},{'code':unIndent`
                function foo() {
                  bar();
                \t\t}
            `,'output':unIndent`
                function foo() {
                  bar();
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,a0_0x5d5156(0xdb),a0_0x5d5156(0xbd),a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function foo() {
                  return (
                    1
                    )
                }
            `,'output':unIndent`
                function foo() {
                  return (
                    1
                  )
                }
            `,'options':[0x2],'errors':expectedErrors([[0x4,0x2,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function foo() {
                  return (
                    1
                    );
                }
            `,'output':unIndent`
                function foo() {
                  return (
                    1
                  );
                }
            `,'options':[0x2],'errors':expectedErrors([[0x4,0x2,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function foo() {
                  bar();
                \t\t}
            `,'output':unIndent`
                function foo() {
                  bar();
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,a0_0x5d5156(0xdb),a0_0x5d5156(0xbd),a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function test(){
                  switch(length){
                    case 1: return function(a){
                    return fn.call(that, a);
                    };
                  }
                }
            `,'output':unIndent`
                function test(){
                  switch(length){
                    case 1: return function(a){
                      return fn.call(that, a);
                    };
                  }
                }
            `,'options':[0x2,{'VariableDeclarator':0x2,'SwitchCase':0x1}],'errors':expectedErrors([[0x4,0x6,0x4,a0_0x5d5156(0xef)]])},{'code':unIndent`
                function foo() {
                   return 1
                }
            `,'output':unIndent`
                function foo() {
                  return 1
                }
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x3,'Keyword']])},{'code':unIndent`
                foo(
                bar,
                  baz,
                    qux);
            `,'output':unIndent`
                foo(
                  bar,
                  baz,
                  qux);
            `,'options':[0x2,{'CallExpression':{'arguments':0x1}}],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)],[0x4,0x2,0x4,'Identifier']])},{'code':unIndent`
                foo(
                \tbar,
                \tbaz);
            `,'output':unIndent`
                foo(
                    bar,
                    baz);
            `,'options':[0x2,{'CallExpression':{'arguments':0x2}}],'errors':expectedErrors([[0x2,a0_0x5d5156(0xd9),a0_0x5d5156(0xf4),a0_0x5d5156(0xe5)],[0x3,a0_0x5d5156(0xd9),a0_0x5d5156(0xf4),'Identifier']])},{'code':unIndent`
                foo(bar,
                \t\tbaz,
                \t\tqux);
            `,'output':unIndent`
                foo(bar,
                \tbaz,
                \tqux);
            `,'options':[a0_0x5d5156(0xd4),{'CallExpression':{'arguments':0x1}}],'errors':expectedErrors('tab',[[0x2,0x1,0x2,'Identifier'],[0x3,0x1,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                foo(bar, baz,
                         qux);
            `,'output':unIndent`
                foo(bar, baz,
                    qux);
            `,'options':[0x2,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}],'errors':expectedErrors([0x2,0x4,0x9,a0_0x5d5156(0xe5)])},{'code':unIndent`
                foo(
                          bar,
                    baz);
            `,'output':unIndent`
                foo(
                  bar,
                  baz);
            `,'options':[0x2,{'CallExpression':{'arguments':'first'}}],'errors':expectedErrors([[0x2,0x2,0xa,a0_0x5d5156(0xe5)],[0x3,0x2,0x4,'Identifier']])},{'code':unIndent`
                foo(bar,
                  1 + 2,
                              !baz,
                        new Car('!')
                );
            `,'output':unIndent`
                foo(bar,
                      1 + 2,
                      !baz,
                      new Car('!')
                );
            `,'options':[0x2,{'CallExpression':{'arguments':0x3}}],'errors':expectedErrors([[0x2,0x6,0x2,'Numeric'],[0x3,0x6,0xe,a0_0x5d5156(0xcb)],[0x4,0x6,0x8,a0_0x5d5156(0xef)]])},{'code':unIndent`
                return (
                    foo
                    );
            `,'output':unIndent`
                return (
                    foo
                );
            `,'parserOptions':{'ecmaFeatures':{'globalReturn':!![]}},'errors':expectedErrors([0x3,0x0,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                return (
                    foo
                    )
            `,'output':unIndent`
                return (
                    foo
                )
            `,'parserOptions':{'ecmaFeatures':{'globalReturn':!![]}},'errors':expectedErrors([0x3,0x0,0x4,'Punctuator'])},{'code':unIndent`
                if (foo) {
                        /* comment */bar();
                }
            `,'output':unIndent`
                if (foo) {
                    /* comment */bar();
                }
            `,'errors':expectedErrors([0x2,0x4,0x8,a0_0x5d5156(0xbb)])},{'code':unIndent`
                foo('bar',
                        /** comment */{
                        ok: true
                    });
            `,'output':unIndent`
                foo('bar',
                    /** comment */{
                        ok: true
                    });
            `,'errors':expectedErrors([0x2,0x4,0x8,'Block'])},{'code':unIndent`
                foo(
                (bar)
                );
            `,'output':unIndent`
                foo(
                    (bar)
                );
            `,'options':[0x4,{'CallExpression':{'arguments':0x1}}],'errors':expectedErrors([0x2,0x4,0x0,a0_0x5d5156(0xcb)])},{'code':unIndent`
                ((
                foo
                ))
            `,'output':unIndent`
                ((
                    foo
                ))
            `,'options':[0x4],'errors':expectedErrors([0x2,0x4,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                foo
                ? bar
                    : baz
            `,'output':unIndent`
                foo
                  ? bar
                  : baz
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xcb)],[0x3,0x2,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                [
                    foo ?
                        bar :
                        baz,
                        qux
                ]
            `,'output':unIndent`
                [
                    foo ?
                        bar :
                        baz,
                    qux
                ]
            `,'errors':expectedErrors([0x5,0x4,0x8,a0_0x5d5156(0xe5)])},{'code':unIndent`
                foo();
                  // comment
                    /* multiline
                  comment */
                bar();
                 // trailing comment
            `,'output':unIndent`
                foo();
                // comment
                /* multiline
                  comment */
                bar();
                // trailing comment
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x0,0x2,'Line'],[0x3,0x0,0x4,'Block'],[0x6,0x0,0x1,'Line']])},{'code':a0_0x5d5156(0xe7),'output':a0_0x5d5156(0xe4),'errors':expectedErrors([0x1,0x0,0x2,a0_0x5d5156(0xce)])},{'code':unIndent`
                foo
                  // comment
            `,'output':unIndent`
                foo
                // comment
            `,'errors':expectedErrors([0x2,0x0,0x2,a0_0x5d5156(0xce)])},{'code':unIndent`
                  // comment
                foo
            `,'output':unIndent`
                // comment
                foo
            `,'errors':expectedErrors([0x1,0x0,0x2,a0_0x5d5156(0xce)])},{'code':unIndent`
                [
                        // no elements
                ]
            `,'output':unIndent`
                [
                    // no elements
                ]
            `,'errors':expectedErrors([0x2,0x4,0x8,a0_0x5d5156(0xce)])},{'code':unIndent`
                var {
                foo,
                  bar,
                    baz: qux,
                      foobar: baz = foobar
                  } = qux;
            `,'output':unIndent`
                var {
                  foo,
                  bar,
                  baz: qux,
                  foobar: baz = foobar
                } = qux;
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)],[0x4,0x2,0x4,'Identifier'],[0x5,0x2,0x6,a0_0x5d5156(0xe5)],[0x6,0x0,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var foo = [
                           bar,
                  baz
                          ]
            `,'output':unIndent`
                var foo = [
                    bar,
                    baz
                ]
            `,'errors':expectedErrors([[0x2,0x4,0xb,a0_0x5d5156(0xe5)],[0x3,0x4,0x2,'Identifier'],[0x4,0x0,0xa,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var foo = [bar,
                baz,
                    qux
                ]
            `,'output':unIndent`
                var foo = [bar,
                    baz,
                    qux
                ]
            `,'errors':expectedErrors([0x2,0x4,0x0,'Identifier'])},{'code':unIndent`
                var foo = [bar,
                  baz,
                  qux
                ]
            `,'output':unIndent`
                var foo = [bar,
                baz,
                qux
                ]
            `,'options':[0x2,{'ArrayExpression':0x0}],'errors':expectedErrors([[0x2,0x0,0x2,'Identifier'],[0x3,0x0,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = [bar,
                  baz,
                  qux
                ]
            `,'output':unIndent`
                var foo = [bar,
                                baz,
                                qux
                ]
            `,'options':[0x2,{'ArrayExpression':0x8}],'errors':expectedErrors([[0x2,0x10,0x2,a0_0x5d5156(0xe5)],[0x3,0x10,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = [bar,
                    baz,
                    qux
                ]
            `,'output':unIndent`
                var foo = [bar,
                           baz,
                           qux
                ]
            `,'options':[0x2,{'ArrayExpression':'first'}],'errors':expectedErrors([[0x2,0xb,0x4,a0_0x5d5156(0xe5)],[0x3,0xb,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var foo = [bar,
                    baz, qux
                ]
            `,'output':unIndent`
                var foo = [bar,
                           baz, qux
                ]
            `,'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf)}],'errors':expectedErrors([0x2,0xb,0x4,'Identifier'])},{'code':unIndent`
                var foo = [
                        { bar: 1,
                            baz: 2 },
                        { bar: 3,
                            qux: 4 }
                ]
            `,'output':unIndent`
                var foo = [
                        { bar: 1,
                          baz: 2 },
                        { bar: 3,
                          qux: 4 }
                ]
            `,'options':[0x4,{'ArrayExpression':0x2,'ObjectExpression':a0_0x5d5156(0xdf)}],'errors':expectedErrors([[0x3,0xa,0xc,a0_0x5d5156(0xe5)],[0x5,0xa,0xc,'Identifier']])},{'code':unIndent`
                var foo = {
                  bar: 1,
                  baz: 2
                };
            `,'output':unIndent`
                var foo = {
                bar: 1,
                baz: 2
                };
            `,'options':[0x2,{'ObjectExpression':0x0}],'errors':expectedErrors([[0x2,0x0,0x2,a0_0x5d5156(0xe5)],[0x3,0x0,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var quux = { foo: 1, bar: 2,
                baz: 3 }
            `,'output':unIndent`
                var quux = { foo: 1, bar: 2,
                             baz: 3 }
            `,'options':[0x2,{'ObjectExpression':a0_0x5d5156(0xdf)}],'errors':expectedErrors([0x2,0xd,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                function foo() {
                    [
                            foo
                    ]
                }
            `,'output':unIndent`
                function foo() {
                  [
                          foo
                  ]
                }
            `,'options':[0x2,{'ArrayExpression':0x4}],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xcb)],[0x3,0xa,0xc,a0_0x5d5156(0xe5)],[0x4,0x2,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var [
                foo,
                  bar,
                    baz,
                      foobar = baz
                  ] = qux;
            `,'output':unIndent`
                var [
                  foo,
                  bar,
                  baz,
                  foobar = baz
                ] = qux;
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xe5)],[0x4,0x2,0x4,'Identifier'],[0x5,0x2,0x6,a0_0x5d5156(0xe5)],[0x6,0x0,0x2,'Punctuator']])},{'code':unIndent`
                import {
                foo,
                  bar,
                    baz
                } from 'qux';
            `,'output':unIndent`
                import {
                    foo,
                    bar,
                    baz
                } from 'qux';
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)},'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                export {
                foo,
                  bar,
                    baz
                };
            `,'output':unIndent`
                export {
                    foo,
                    bar,
                    baz
                };
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)},'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                export {
                foo,
                  bar,
                    baz
                } from 'qux';
            `,'output':unIndent`
                export {
                    foo,
                    bar,
                    baz
                } from 'qux';
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)},'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var folder = filePath
                  .foo()
                      .bar;
            `,'output':unIndent`
                var folder = filePath
                    .foo()
                    .bar;
            `,'options':[0x2,{'MemberExpression':0x2}],'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xcb)],[0x3,0x4,0x6,'Punctuator']])},{'code':unIndent`
                for (const foo of bar)
                    baz();
            `,'output':unIndent`
                for (const foo of bar)
                  baz();
            `,'options':[0x2],'errors':expectedErrors([0x2,0x2,0x4,a0_0x5d5156(0xe5)])},{'code':unIndent`
                var x = () =>
                    5;
            `,'output':unIndent`
                var x = () =>
                  5;
            `,'options':[0x2],'errors':expectedErrors([0x2,0x2,0x4,a0_0x5d5156(0xd0)])},{'code':unIndent`
                foo && (
                        bar
                )
            `,'output':unIndent`
                foo && (
                    bar
                )
            `,'options':[0x4],'errors':expectedErrors([0x2,0x4,0x8,a0_0x5d5156(0xe5)])},{'code':unIndent`
                [
                ] || [
                    ]
            `,'output':unIndent`
                [
                ] || [
                ]
            `,'errors':expectedErrors([0x3,0x0,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                1
                + (
                        1
                    )
            `,'output':unIndent`
                1
                + (
                    1
                )
            `,'errors':expectedErrors([[0x3,0x4,0x8,a0_0x5d5156(0xd0)],[0x4,0x0,0x4,'Punctuator']])},{'code':unIndent`
                \`foo\${
                bar}\`
            `,'output':unIndent`
                \`foo\${
                  bar}\`
            `,'options':[0x2],'errors':expectedErrors([0x2,0x2,0x0,'Identifier'])},{'code':unIndent`
                \`foo\${
                    \`bar\${
                baz}\`}\`
            `,'output':unIndent`
                \`foo\${
                  \`bar\${
                    baz}\`}\`
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x4,'Template'],[0x3,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                \`foo\${
                    \`bar\${
                  baz
                    }\`
                  }\`
            `,'output':unIndent`
                \`foo\${
                  \`bar\${
                    baz
                  }\`
                }\`
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xb6)],[0x3,0x4,0x2,a0_0x5d5156(0xe5)],[0x4,0x2,0x4,a0_0x5d5156(0xb6)],[0x5,0x0,0x2,'Template']])},{'code':unIndent`
                \`foo\${
                (
                  bar
                )
                }\`
            `,'output':unIndent`
                \`foo\${
                  (
                    bar
                  )
                }\`
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x0,a0_0x5d5156(0xcb)],[0x3,0x4,0x2,a0_0x5d5156(0xe5)],[0x4,0x2,0x0,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                function foo() {
                    \`foo\${bar}baz\${
                qux}foo\${
                  bar}baz\`
                }
            `,'output':unIndent`
                function foo() {
                    \`foo\${bar}baz\${
                        qux}foo\${
                        bar}baz\`
                }
            `,'errors':expectedErrors([[0x3,0x8,0x0,a0_0x5d5156(0xe5)],[0x4,0x8,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo() {
                    const template = \`the indentation of
                a curly element in a \${
                        node.type
                    } node is checked.\`;
                }
            `,'output':unIndent`
                function foo() {
                    const template = \`the indentation of
                a curly element in a \${
                    node.type
                } node is checked.\`;
                }
            `,'errors':expectedErrors([[0x4,0x4,0x8,a0_0x5d5156(0xe5)],[0x5,0x0,0x4,'Template']])},{'code':unIndent`
                function foo() {
                    const template = \`this time the
                closing curly is at the end of the line \${
                            foo}
                        so the spaces before this line aren't removed.\`;
                }
            `,'output':unIndent`
                function foo() {
                    const template = \`this time the
                closing curly is at the end of the line \${
                    foo}
                        so the spaces before this line aren't removed.\`;
                }
            `,'errors':expectedErrors([0x4,0x4,0xc,a0_0x5d5156(0xe5)])},{'code':unIndent`
                if (true) {
                    a = (
                1 +
                        2);
                }
            `,'output':unIndent`
                if (true) {
                    a = (
                        1 +
                        2);
                }
            `,'errors':expectedErrors([0x3,0x8,0x0,a0_0x5d5156(0xd0)])},{'code':unIndent`
                if (true) {
                    for (;;) {
                      b();
                  }
                }
            `,'output':unIndent`
                if (true) {
                  for (;;) {
                    b();
                  }
                }
            `,'options':[0x2],'errors':expectedErrors([[0x2,0x2,0x4,a0_0x5d5156(0xef)],[0x3,0x4,0x6,'Identifier']])},{'code':unIndent`
                function f() {
                    return asyncCall()
                    .then(
                               'some string',
                              [
                              1,
                         2,
                                                   3
                                      ]
                );
                 }
            `,'output':unIndent`
                function f() {
                    return asyncCall()
                        .then(
                            'some string',
                            [
                                1,
                                2,
                                3
                            ]
                        );
                }
            `,'options':[0x4,{'MemberExpression':0x1,'CallExpression':{'arguments':0x1}}],'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xcb)],[0x4,0xc,0xf,a0_0x5d5156(0xfb)],[0x5,0xc,0xe,a0_0x5d5156(0xcb)],[0x6,0x10,0xe,a0_0x5d5156(0xd0)],[0x7,0x10,0x9,a0_0x5d5156(0xd0)],[0x8,0x10,0x23,'Numeric'],[0x9,0xc,0x16,a0_0x5d5156(0xcb)],[0xa,0x8,0x0,a0_0x5d5156(0xcb)],[0xb,0x0,0x1,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var x = [
                      [1],
                  [2]
                ]
            `,'output':unIndent`
                var x = [
                    [1],
                    [2]
                ]
            `,'errors':expectedErrors([[0x2,0x4,0x6,'Punctuator'],[0x3,0x4,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                var y = [
                      {a: 1},
                  {b: 2}
                ]
            `,'output':unIndent`
                var y = [
                    {a: 1},
                    {b: 2}
                ]
            `,'errors':expectedErrors([[0x2,0x4,0x6,a0_0x5d5156(0xcb)],[0x3,0x4,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                echo = spawn('cmd.exe',
                            ['foo', 'bar',
                             'baz']);
            `,'output':unIndent`
                echo = spawn('cmd.exe',
                             ['foo', 'bar',
                              'baz']);
            `,'options':[0x2,{'ArrayExpression':'first','CallExpression':{'arguments':a0_0x5d5156(0xdf)}}],'errors':expectedErrors([[0x2,0xd,0xc,'Punctuator'],[0x3,0xe,0xd,'String']])},{'code':unIndent`
                foo(
                  )
            `,'output':unIndent`
                foo(
                )
            `,'errors':expectedErrors([0x2,0x0,0x2,a0_0x5d5156(0xcb)])},{'code':unIndent`
                foo(
                        bar,
                    {
                        baz: 1
                    }
                )
            `,'output':unIndent`
                foo(
                    bar,
                    {
                        baz: 1
                    }
                )
            `,'options':[0x4,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}],'errors':expectedErrors([[0x2,0x4,0x8,a0_0x5d5156(0xe5)]])},{'code':'\x20\x20new\x20Foo','output':a0_0x5d5156(0xf9),'errors':expectedErrors([0x1,0x0,0x2,a0_0x5d5156(0xef)])},{'code':unIndent`
                export {
                foo,
                        bar,
                  baz
                }
            `,'output':unIndent`
                export {
                    foo,
                    bar,
                    baz
                }
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)},'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x8,a0_0x5d5156(0xe5)],[0x4,0x4,0x2,'Identifier']])},{'code':unIndent`
                foo
                    ? bar
                : baz
            `,'output':unIndent`
                foo
                    ? bar
                    : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([0x3,0x4,0x0,'Punctuator'])},{'code':unIndent`
                foo ?
                    bar :
                baz
            `,'output':unIndent`
                foo ?
                    bar :
                    baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([0x3,0x4,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                foo ?
                    bar
                  : baz
            `,'output':unIndent`
                foo ?
                    bar
                    : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([0x3,0x4,0x2,a0_0x5d5156(0xcb)])},{'code':unIndent`
                foo
                    ? bar :
                baz
            `,'output':unIndent`
                foo
                    ? bar :
                    baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([0x3,0x4,0x0,'Identifier'])},{'code':unIndent`
                foo ? bar
                    : baz ? qux
                        : foobar ? boop
                            : beep
            `,'output':unIndent`
                foo ? bar
                    : baz ? qux
                    : foobar ? boop
                    : beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([[0x3,0x4,0x8,'Punctuator'],[0x4,0x4,0xc,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo ? bar :
                    baz ? qux :
                        foobar ? boop :
                            beep
            `,'output':unIndent`
                foo ? bar :
                    baz ? qux :
                    foobar ? boop :
                    beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([[0x3,0x4,0x8,a0_0x5d5156(0xe5)],[0x4,0x4,0xc,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a =
                    foo ? bar :
                      baz ? qux :
                  foobar ? boop :
                    /*else*/ beep
            `,'output':unIndent`
                var a =
                    foo ? bar :
                    baz ? qux :
                    foobar ? boop :
                    /*else*/ beep
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([[0x3,0x4,0x6,a0_0x5d5156(0xe5)],[0x4,0x4,0x2,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                var a =
                    foo
                    ? bar
                    : baz
            `,'output':unIndent`
                var a =
                    foo
                        ? bar
                        : baz
            `,'options':[0x4,{'flatTernaryExpressions':!![]}],'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xcb)],[0x4,0x8,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo ? bar
                    : baz ? qux
                    : foobar ? boop
                    : beep
            `,'output':unIndent`
                foo ? bar
                    : baz ? qux
                        : foobar ? boop
                            : beep
            `,'options':[0x4,{'flatTernaryExpressions':![]}],'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xcb)],[0x4,0xc,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo ? bar :
                    baz ? qux :
                    foobar ? boop :
                    beep
            `,'output':unIndent`
                foo ? bar :
                    baz ? qux :
                        foobar ? boop :
                            beep
            `,'options':[0x4,{'flatTernaryExpressions':![]}],'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xe5)],[0x4,0xc,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                foo
                    ? bar
                    : baz
                    ? qux
                    : foobar
                    ? boop
                    : beep
            `,'output':unIndent`
                foo
                    ? bar
                    : baz
                        ? qux
                        : foobar
                            ? boop
                            : beep
            `,'options':[0x4,{'flatTernaryExpressions':![]}],'errors':expectedErrors([[0x4,0x8,0x4,a0_0x5d5156(0xcb)],[0x5,0x8,0x4,'Punctuator'],[0x6,0xc,0x4,'Punctuator'],[0x7,0xc,0x4,'Punctuator']])},{'code':unIndent`
                foo ?
                    bar :
                    baz ?
                    qux :
                    foobar ?
                    boop :
                    beep
            `,'output':unIndent`
                foo ?
                    bar :
                    baz ?
                        qux :
                        foobar ?
                            boop :
                            beep
            `,'options':[0x4,{'flatTernaryExpressions':![]}],'errors':expectedErrors([[0x4,0x8,0x4,a0_0x5d5156(0xe5)],[0x5,0x8,0x4,'Identifier'],[0x6,0xc,0x4,a0_0x5d5156(0xe5)],[0x7,0xc,0x4,'Identifier']])},{'code':unIndent`
                foo.bar('baz', function(err) {
                          qux;
                });
            `,'output':unIndent`
                foo.bar('baz', function(err) {
                  qux;
                });
            `,'options':[0x2,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}],'errors':expectedErrors([0x2,0x2,0xa,'Identifier'])},{'code':unIndent`
                foo.bar(function() {
                  cookies;
                }).baz(function() {
                    cookies;
                  });
            `,'output':unIndent`
                foo.bar(function() {
                  cookies;
                }).baz(function() {
                  cookies;
                });
            `,'options':[0x2,{'MemberExpression':0x1}],'errors':expectedErrors([[0x4,0x2,0x4,a0_0x5d5156(0xe5)],[0x5,0x0,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo.bar().baz(function() {
                  cookies;
                }).qux(function() {
                    cookies;
                  });
            `,'output':unIndent`
                foo.bar().baz(function() {
                  cookies;
                }).qux(function() {
                  cookies;
                });
            `,'options':[0x2,{'MemberExpression':0x1}],'errors':expectedErrors([[0x4,0x2,0x4,'Identifier'],[0x5,0x0,0x2,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                [ foo,
                  bar ].forEach(function() {
                    baz;
                  })
            `,'output':unIndent`
                [ foo,
                  bar ].forEach(function() {
                  baz;
                })
            `,'options':[0x2,{'ArrayExpression':a0_0x5d5156(0xdf),'MemberExpression':0x1}],'errors':expectedErrors([[0x3,0x2,0x4,a0_0x5d5156(0xe5)],[0x4,0x0,0x2,'Punctuator']])},{'code':unIndent`
                foo[
                    bar
                    ];
            `,'output':unIndent`
                foo[
                    bar
                ];
            `,'options':[0x4,{'MemberExpression':0x1}],'errors':expectedErrors([0x3,0x0,0x4,'Punctuator'])},{'code':unIndent`
                foo({
                bar: 1,
                baz: 2
                })
            `,'output':unIndent`
                foo({
                    bar: 1,
                    baz: 2
                })
            `,'options':[0x4,{'ObjectExpression':'first'}],'errors':expectedErrors([[0x2,0x4,0x0,a0_0x5d5156(0xe5)],[0x3,0x4,0x0,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                foo(
                                        bar, baz,
                                        qux);
            `,'output':unIndent`
                foo(
                  bar, baz,
                  qux);
            `,'options':[0x2,{'CallExpression':{'arguments':a0_0x5d5156(0xdf)}}],'errors':expectedErrors([[0x2,0x2,0x18,a0_0x5d5156(0xe5)],[0x3,0x2,0x18,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                if (foo) bar()

                    ; [1, 2, 3].map(baz)
            `,'output':unIndent`
                if (foo) bar()

                ; [1, 2, 3].map(baz)
            `,'errors':expectedErrors([0x3,0x0,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                import {foo}
                from 'bar';
            `,'output':unIndent`
                import {foo}
                    from 'bar';
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)},'errors':expectedErrors([0x2,0x4,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                export {foo}
                from 'bar';
            `,'output':unIndent`
                export {foo}
                    from 'bar';
            `,'parserOptions':{'sourceType':a0_0x5d5156(0xda)},'errors':expectedErrors([0x2,0x4,0x0,a0_0x5d5156(0xe5)])},{'code':unIndent`
                (
                    a
                ) => b => {
                        c
                    }
            `,'output':unIndent`
                (
                    a
                ) => b => {
                    c
                }
            `,'errors':expectedErrors([[0x4,0x4,0x8,a0_0x5d5156(0xe5)],[0x5,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                (
                    a
                ) => b => c => d => {
                        e
                    }
            `,'output':unIndent`
                (
                    a
                ) => b => c => d => {
                    e
                }
            `,'errors':expectedErrors([[0x4,0x4,0x8,a0_0x5d5156(0xe5)],[0x5,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                if (
                    foo
                ) bar(
                        baz
                    );
            `,'output':unIndent`
                if (
                    foo
                ) bar(
                    baz
                );
            `,'errors':expectedErrors([[0x4,0x4,0x8,a0_0x5d5156(0xe5)],[0x5,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo.
                  bar.
                      baz
            `,'output':unIndent`
                foo.
                    bar.
                    baz
            `,'errors':expectedErrors([[0x2,0x4,0x2,a0_0x5d5156(0xe5)],[0x3,0x4,0x6,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                const foo = a.b(),
                    longName
                    = (baz(
                            'bar',
                            'bar'
                        ));
            `,'output':unIndent`
                const foo = a.b(),
                    longName
                    = (baz(
                        'bar',
                        'bar'
                    ));
            `,'errors':expectedErrors([[0x4,0x8,0xc,a0_0x5d5156(0xfb)],[0x5,0x8,0xc,'String'],[0x6,0x4,0x8,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                const foo = a.b(),
                    longName =
                    (baz(
                            'bar',
                            'bar'
                        ));
            `,'output':unIndent`
                const foo = a.b(),
                    longName =
                    (baz(
                        'bar',
                        'bar'
                    ));
            `,'errors':expectedErrors([[0x4,0x8,0xc,'String'],[0x5,0x8,0xc,a0_0x5d5156(0xfb)],[0x6,0x4,0x8,'Punctuator']])},{'code':unIndent`
                const foo = a.b(),
                    longName
                        =baz(
                            'bar',
                            'bar'
                    );
            `,'output':unIndent`
                const foo = a.b(),
                    longName
                        =baz(
                            'bar',
                            'bar'
                        );
            `,'errors':expectedErrors([[0x6,0x8,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                const foo = a.b(),
                    longName
                        =(
                        'fff'
                        );
            `,'output':unIndent`
                const foo = a.b(),
                    longName
                        =(
                            'fff'
                        );
            `,'errors':expectedErrors([[0x4,0xc,0x8,a0_0x5d5156(0xfb)]])},{'code':unIndent`
                namespace Foo {
                    const bar = 3,
                    baz = 2;

                    if (true) {
                    const bax = 3;
                    }
                }
            `,'output':unIndent`
                namespace Foo {
                    const bar = 3,
                        baz = 2;

                    if (true) {
                        const bax = 3;
                    }
                }
            `,'parser':parser(a0_0x5d5156(0xd3)),'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xe5)],[0x6,0x8,0x4,a0_0x5d5156(0xef)]])},{'code':unIndent`
                abstract class Foo {
                    public bar() {
                        let aaa = 4,
                        boo;

                        if (true) {
                        boo = 3;
                        }

                    boo = 3 + 2;
                    }
                }
            `,'output':unIndent`
                abstract class Foo {
                    public bar() {
                        let aaa = 4,
                            boo;

                        if (true) {
                            boo = 3;
                        }

                        boo = 3 + 2;
                    }
                }
            `,'parser':parser('unknown-nodes/abstract-class-invalid'),'errors':expectedErrors([[0x4,0xc,0x8,a0_0x5d5156(0xe5)],[0x7,0xc,0x8,a0_0x5d5156(0xe5)],[0xa,0x8,0x4,a0_0x5d5156(0xe5)]])},{'code':unIndent`
                function foo() {
                    function bar() {
                        abstract class X {
                        public baz() {
                        if (true) {
                        qux();
                        }
                        }
                        }
                    }
                }
            `,'output':unIndent`
                function foo() {
                    function bar() {
                        abstract class X {
                            public baz() {
                                if (true) {
                                    qux();
                                }
                            }
                        }
                    }
                }
            `,'parser':parser(a0_0x5d5156(0xba)),'errors':expectedErrors([[0x4,0xc,0x8,'Keyword'],[0x5,0x10,0x8,'Keyword'],[0x6,0x14,0x8,a0_0x5d5156(0xe5)],[0x7,0x10,0x8,a0_0x5d5156(0xcb)],[0x8,0xc,0x8,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                namespace Unknown {
                    function foo() {
                    function bar() {
                            abstract class X {
                                public baz() {
                                    if (true) {
                                    qux();
                                    }
                                }
                            }
                        }
                    }
                }
            `,'output':unIndent`
                namespace Unknown {
                    function foo() {
                        function bar() {
                            abstract class X {
                                public baz() {
                                    if (true) {
                                        qux();
                                    }
                                }
                            }
                        }
                    }
                }
            `,'parser':parser(a0_0x5d5156(0xdc)),'errors':expectedErrors([[0x3,0x8,0x4,a0_0x5d5156(0xef)],[0x7,0x18,0x14,'Identifier']])},{'code':unIndent`
                <App>
                  <Foo />
                </App>
            `,'output':unIndent`
                <App>
                    <Foo />
                </App>
            `,'errors':expectedErrors([0x2,0x4,0x2,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <App>
                    <Foo />
                </App>
            `,'output':unIndent`
                <App>
                  <Foo />
                </App>
            `,'options':[0x2],'errors':expectedErrors([0x2,0x2,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <App>
                    <Foo />
                </App>
            `,'output':unIndent`
                <App>
                \t<Foo />
                </App>
            `,'options':[a0_0x5d5156(0xd4)],'errors':expectedErrors([0x2,a0_0x5d5156(0xf4),'4\x20spaces','Punctuator'])},{'code':unIndent`
                function App() {
                  return <App>
                    <Foo />
                         </App>;
                }
            `,'output':unIndent`
                function App() {
                  return <App>
                    <Foo />
                  </App>;
                }
            `,'options':[0x2],'errors':expectedErrors([0x4,0x2,0x9,'Punctuator'])},{'code':unIndent`
                function App() {
                  return (<App>
                    <Foo />
                    </App>);
                }
            `,'output':unIndent`
                function App() {
                  return (<App>
                    <Foo />
                  </App>);
                }
            `,'options':[0x2],'errors':expectedErrors([0x4,0x2,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                function App() {
                  return (
                <App>
                  <Foo />
                </App>
                  );
                }
            `,'output':unIndent`
                function App() {
                  return (
                    <App>
                      <Foo />
                    </App>
                  );
                }
            `,'options':[0x2],'errors':expectedErrors([[0x3,0x4,0x0,a0_0x5d5156(0xcb)],[0x4,0x6,0x2,a0_0x5d5156(0xcb)],[0x5,0x4,0x0,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                <App>
                 {test}
                </App>
            `,'output':unIndent`
                <App>
                    {test}
                </App>
            `,'errors':expectedErrors([0x2,0x4,0x1,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <App>
                    {options.map((option, index) => (
                        <option key={index} value={option.key}>
                           {option.name}
                        </option>
                    ))}
                </App>
            `,'output':unIndent`
                <App>
                    {options.map((option, index) => (
                        <option key={index} value={option.key}>
                            {option.name}
                        </option>
                    ))}
                </App>
            `,'errors':expectedErrors([0x4,0xc,0xb,a0_0x5d5156(0xcb)])},{'code':unIndent`
                [
                  <div />,
                    <div />
                ]
            `,'output':unIndent`
                [
                  <div />,
                  <div />
                ]
            `,'options':[0x2],'errors':expectedErrors([0x3,0x2,0x4,'Punctuator'])},{'code':unIndent`
                <App>

                 <Foo />

                </App>
            `,'output':unIndent`
                <App>

                \t<Foo />

                </App>
            `,'options':[a0_0x5d5156(0xd4)],'errors':expectedErrors([0x3,a0_0x5d5156(0xf4),a0_0x5d5156(0xc0),a0_0x5d5156(0xcb)])},{'code':unIndent`
                foo ?
                    <Foo /> :
                <Bar />
            `,'output':unIndent`
                foo ?
                    <Foo /> :
                    <Bar />
            `,'errors':expectedErrors([0x3,0x4,0x0,a0_0x5d5156(0xcb)])},{'code':unIndent`
                foo ?
                    <Foo />
                :
                <Bar />
            `,'output':unIndent`
                foo ?
                    <Foo />
                    :
                    <Bar />
            `,'errors':expectedErrors([[0x3,0x4,0x0,a0_0x5d5156(0xcb)],[0x4,0x4,0x0,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo ? (
                    <Foo />
                ) :
                <Bar />
            `,'output':unIndent`
                foo ? (
                    <Foo />
                ) :
                    <Bar />
            `,'errors':expectedErrors([0x4,0x4,0x0,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <App
                  foo
                />
            `,'output':unIndent`
                <App
                    foo
                />
            `,'errors':expectedErrors([0x2,0x4,0x2,'JSXIdentifier'])},{'code':unIndent`
                <App
                  foo
                  />
            `,'output':unIndent`
                <App
                  foo
                />
            `,'options':[0x2],'errors':expectedErrors([0x3,0x0,0x2,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <App
                  foo
                  ></App>
            `,'output':unIndent`
                <App
                  foo
                ></App>
            `,'options':[0x2],'errors':expectedErrors([0x3,0x0,0x2,'Punctuator'])},{'code':unIndent`
                const Button = function(props) {
                  return (
                    <Button
                      size={size}
                      onClick={onClick}
                                                    >
                      Button Text
                    </Button>
                  );
                };
            `,'output':unIndent`
                const Button = function(props) {
                  return (
                    <Button
                      size={size}
                      onClick={onClick}
                    >
                      Button Text
                    </Button>
                  );
                };
            `,'options':[0x2],'errors':expectedErrors([0x6,0x4,0x24,'Punctuator'])},{'code':unIndent`
                var x = function() {
                  return <App
                    foo
                         />
                }
            `,'output':unIndent`
                var x = function() {
                  return <App
                    foo
                  />
                }
            `,'options':[0x2],'errors':expectedErrors([0x4,0x2,0x9,'Punctuator'])},{'code':unIndent`
                var x = <App
                  foo
                        />
            `,'output':unIndent`
                var x = <App
                  foo
                />
            `,'options':[0x2],'errors':expectedErrors([0x3,0x0,0x8,a0_0x5d5156(0xcb)])},{'code':unIndent`
                var x = (
                  <Something
                    />
                )
            `,'output':unIndent`
                var x = (
                  <Something
                  />
                )
            `,'options':[0x2],'errors':expectedErrors([0x3,0x2,0x4,'Punctuator'])},{'code':unIndent`
                <App
                \tfoo
                \t/>
            `,'output':unIndent`
                <App
                \tfoo
                />
            `,'options':[a0_0x5d5156(0xd4)],'errors':expectedErrors(a0_0x5d5156(0xd4),[0x3,0x0,0x1,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <App
                \tfoo
                \t></App>
            `,'output':unIndent`
                <App
                \tfoo
                ></App>
            `,'options':['tab'],'errors':expectedErrors(a0_0x5d5156(0xd4),[0x3,0x0,0x1,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <
                    foo
                    .bar
                    .baz
                >
                    foo
                </
                    foo.
                    bar.
                    baz
                >
            `,'output':unIndent`
                <
                    foo
                        .bar
                        .baz
                >
                    foo
                </
                    foo.
                        bar.
                        baz
                >
            `,'errors':expectedErrors([[0x3,0x8,0x4,'Punctuator'],[0x4,0x8,0x4,a0_0x5d5156(0xcb)],[0x9,0x8,0x4,a0_0x5d5156(0xb9)],[0xa,0x8,0x4,a0_0x5d5156(0xb9)]])},{'code':unIndent`
                <
                    input
                    type=
                    "number"
                />
            `,'output':unIndent`
                <
                    input
                    type=
                        "number"
                />
            `,'errors':expectedErrors([0x4,0x8,0x4,'JSXText'])},{'code':unIndent`
                <
                    input
                    type=
                    {'number'}
                />
            `,'output':unIndent`
                <
                    input
                    type=
                        {'number'}
                />
            `,'errors':expectedErrors([0x4,0x8,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                <
                    input
                    type
                    ="number"
                />
            `,'output':unIndent`
                <
                    input
                    type
                        ="number"
                />
            `,'errors':expectedErrors([0x4,0x8,0x4,a0_0x5d5156(0xcb)])},{'code':unIndent`
                foo ? (
                    bar
                ) : (
                        baz
                    )
            `,'output':unIndent`
                foo ? (
                    bar
                ) : (
                    baz
                )
            `,'errors':expectedErrors([[0x4,0x4,0x8,a0_0x5d5156(0xe5)],[0x5,0x0,0x4,a0_0x5d5156(0xcb)]])},{'code':unIndent`
                foo ? (
                    <div>
                    </div>
                ) : (
                        <span>
                        </span>
                    )
            `,'output':unIndent`
                foo ? (
                    <div>
                    </div>
                ) : (
                    <span>
                    </span>
                )
            `,'errors':expectedErrors([[0x5,0x4,0x8,a0_0x5d5156(0xcb)],[0x6,0x4,0x8,a0_0x5d5156(0xcb)],[0x7,0x0,0x4,a0_0x5d5156(0xcb)]])}]});