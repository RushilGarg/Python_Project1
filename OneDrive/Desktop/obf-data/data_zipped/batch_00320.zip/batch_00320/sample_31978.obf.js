/**
 * @license Copyright (C) 2011 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x2ccb9b=a0_0x5133;function a0_0x1911(){var _0x5b9630=['PR_STRING','5626544CWSxmE','PR_PLAIN','760SwsnrC','2BRTMar','379664IcIuYP','873321fXRPhB','registerLangHandler','60GApILD','clj','5990842omhkkE','8155917vVkiqU','820crsYHi','createSimpleLexer','\x09\x0a\x0d\x20\u00a0','96345rDPJei','8ZjVELb','opn','21318sOTqwQ','18xHHPDp',')]}','([{'];a0_0x1911=function(){return _0x5b9630;};return a0_0x1911();}function a0_0x5133(_0x161227,_0x378144){var _0x191194=a0_0x1911();return a0_0x5133=function(_0x5133d7,_0x4a917d){_0x5133d7=_0x5133d7-0x12a;var _0x4b499a=_0x191194[_0x5133d7];return _0x4b499a;},a0_0x5133(_0x161227,_0x378144);}(function(_0x1ce9ce,_0x2802ad){var _0x23f2fe=a0_0x5133,_0x5ad99e=_0x1ce9ce();while(!![]){try{var _0x5cd1a5=parseInt(_0x23f2fe(0x132))/0x1*(-parseInt(_0x23f2fe(0x130))/0x2)+parseInt(_0x23f2fe(0x13f))/0x3*(parseInt(_0x23f2fe(0x131))/0x4)+-parseInt(_0x23f2fe(0x12f))/0x5*(parseInt(_0x23f2fe(0x13e))/0x6)+parseInt(_0x23f2fe(0x12d))/0x7*(-parseInt(_0x23f2fe(0x13c))/0x8)+parseInt(_0x23f2fe(0x13b))/0x9*(-parseInt(_0x23f2fe(0x138))/0xa)+parseInt(_0x23f2fe(0x137))/0xb+parseInt(_0x23f2fe(0x134))/0xc*(parseInt(_0x23f2fe(0x136))/0xd);if(_0x5cd1a5===_0x2802ad)break;else _0x5ad99e['push'](_0x5ad99e['shift']());}catch(_0x567f99){_0x5ad99e['push'](_0x5ad99e['shift']());}}}(a0_0x1911,0x7efc6),PR[a0_0x2ccb9b(0x133)](PR[a0_0x2ccb9b(0x139)]([[a0_0x2ccb9b(0x13d),/^[\(\{\[]+/,null,a0_0x2ccb9b(0x12b)],['clo',/^[\)\}\]]+/,null,a0_0x2ccb9b(0x12a)],[PR['PR_COMMENT'],/^;[^\r\n]*/,null,';'],[PR[a0_0x2ccb9b(0x12e)],/^[\t\n\r \xA0]+/,null,a0_0x2ccb9b(0x13a)],[PR[a0_0x2ccb9b(0x12c)],/^\"(?:[^\"\\]|\\[\s\S])*(?:\"|$)/,null,'\x22']],[[PR['PR_KEYWORD'],/^(?:def|if|do|let|quote|var|fn|loop|recur|throw|try|monitor-enter|monitor-exit|defmacro|defn|defn-|macroexpand|macroexpand-1|for|doseq|dosync|dotimes|and|or|when|not|assert|doto|proxy|defstruct|first|rest|cons|defprotocol|deftype|defrecord|reify|defmulti|defmethod|meta|with-meta|ns|in-ns|create-ns|import|intern|refer|alias|namespace|resolve|ref|deref|refset|new|set!|memfn|to-array|into-array|aset|gen-class|reduce|map|filter|find|nil?|empty?|hash-map|hash-set|vec|vector|seq|flatten|reverse|assoc|dissoc|list|list?|disj|get|union|difference|intersection|extend|extend-type|extend-protocol|prn)\b/,null],[PR['PR_TYPE'],/^:[0-9a-zA-Z\-]+/]]),[a0_0x2ccb9b(0x135)]));