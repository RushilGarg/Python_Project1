/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x21f6(_0x5b078e,_0x11a6ec){var _0x15af3d=a0_0x15af();return a0_0x21f6=function(_0x21f6bb,_0x494c42){_0x21f6bb=_0x21f6bb-0x190;var _0xda72f=_0x15af3d[_0x21f6bb];return _0xda72f;},a0_0x21f6(_0x5b078e,_0x11a6ec);}function a0_0x15af(){var _0x4b6592=['66521aFAgrY','40cmGNIN','656jVsjgD','foam.apps.todo.model.Todo','13040VVxfuC','3872172BSbBmd','TodoCitationView','foam.ui.DetailView','12232050hzTurH','todo-citation','646452aoZfOE','19610dRLWxv','1674753gLVUSZ','foam.apps.todo.ui','2PLYCzz'];a0_0x15af=function(){return _0x4b6592;};return a0_0x15af();}var a0_0x5884b5=a0_0x21f6;(function(_0x189dfb,_0x3cfbc8){var _0x1ef66d=a0_0x21f6,_0x3d3848=_0x189dfb();while(!![]){try{var _0x108e23=-parseInt(_0x1ef66d(0x191))/0x1*(-parseInt(_0x1ef66d(0x196))/0x2)+-parseInt(_0x1ef66d(0x19e))/0x3+parseInt(_0x1ef66d(0x194))/0x4*(-parseInt(_0x1ef66d(0x19d))/0x5)+parseInt(_0x1ef66d(0x197))/0x6+parseInt(_0x1ef66d(0x192))/0x7+parseInt(_0x1ef66d(0x193))/0x8*(-parseInt(_0x1ef66d(0x19c))/0x9)+parseInt(_0x1ef66d(0x19a))/0xa;if(_0x108e23===_0x3cfbc8)break;else _0x3d3848['push'](_0x3d3848['shift']());}catch(_0x15c03a){_0x3d3848['push'](_0x3d3848['shift']());}}}(a0_0x15af,0x50b0f),CLASS({'package':a0_0x5884b5(0x190),'name':a0_0x5884b5(0x198),'extends':a0_0x5884b5(0x199),'requires':[a0_0x5884b5(0x195)],'properties':[{'name':'className','defaultValue':a0_0x5884b5(0x19b)}],'templates':[function CSS(){},function toHTML(){}]}));