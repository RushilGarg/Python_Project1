function a0_0x5575(_0xbc4b0e,_0xa006db){var _0x120306=a0_0x1203();return a0_0x5575=function(_0x557558,_0x159286){_0x557558=_0x557558-0x19b;var _0x56ef11=_0x120306[_0x557558];return _0x56ef11;},a0_0x5575(_0xbc4b0e,_0xa006db);}(function(_0x2e0cc9,_0x3aee5b){var _0x532cad=a0_0x5575,_0x1e4bb5=_0x2e0cc9();while(!![]){try{var _0x5c8e5c=-parseInt(_0x532cad(0x19f))/0x1*(-parseInt(_0x532cad(0x1b8))/0x2)+-parseInt(_0x532cad(0x1b6))/0x3*(parseInt(_0x532cad(0x1b0))/0x4)+-parseInt(_0x532cad(0x1b3))/0x5*(parseInt(_0x532cad(0x1af))/0x6)+-parseInt(_0x532cad(0x1bc))/0x7*(parseInt(_0x532cad(0x1aa))/0x8)+-parseInt(_0x532cad(0x1ac))/0x9*(parseInt(_0x532cad(0x19b))/0xa)+-parseInt(_0x532cad(0x1a5))/0xb+-parseInt(_0x532cad(0x1a0))/0xc*(-parseInt(_0x532cad(0x1b7))/0xd);if(_0x5c8e5c===_0x3aee5b)break;else _0x1e4bb5['push'](_0x1e4bb5['shift']());}catch(_0x1819bb){_0x1e4bb5['push'](_0x1e4bb5['shift']());}}}(a0_0x1203,0x2af6f),$(function(){var _0x541589=a0_0x5575,_0x3c10c9={'icons':[_0x541589(0x19d),_0x541589(0x1a4),_0x541589(0x1ba),_0x541589(0x1b1),'top_rated'],'labels':[_0x541589(0x1a1),'Pictures',_0x541589(0x1be),_0x541589(0x19e),'Favs'],'selected':0x1,'screens':[_0x541589(0x19d),'pictures',_0x541589(0x1b5),'recipes',_0x541589(0x1ad)],'showIcons':![]},_0x52ff4b=new UITabbar(_0x3c10c9);window[_0x541589(0x1bb)]=_0x52ff4b;var _0x25937a=new Component({'element':'#musicList','render':function(_0x5a6985){var _0x1787ef=_0x541589;return html`
        <li>
          <img  data-src="${_0x5a6985[_0x1787ef(0x1b9)]}" height="80px">
          <div>
            <h3>${_0x5a6985[_0x1787ef(0x1a6)]}</h3>
            <h4>${_0x5a6985[_0x1787ef(0x19c)]}</h4>
            <p>${_0x5a6985[_0x1787ef(0x1a2)]}</p>
          </div>
        </li>`;}});_0x25937a[_0x541589(0x1a9)](music);var _0x4a33d2=new Component({'element':_0x541589(0x1b2),'render':function(_0x5cbf8d){return html`
        <img class="col" src="${_0x5cbf8d}">
      `;}});_0x4a33d2[_0x541589(0x1a9)](imageCollection);var _0x4d1511=new Component({'element':'#docsList','render':function(_0x2fb53f){var _0x5ccdc9=_0x541589;return html`
        <li class='center-vertical'>
          <h3>${_0x2fb53f[_0x5ccdc9(0x1a6)]}</h3>
          <h4>${_0x2fb53f[_0x5ccdc9(0x1bf)]}</h4>
          <aside>
            <span class='counter'>${_0x2fb53f[_0x5ccdc9(0x1ab)]}</span>
          </aside>
        </li>`;}});_0x4d1511['render'](docs);var _0x51f122=new Component({'element':_0x541589(0x1ae),'render':function(_0x2d6d5d){var _0x2d4eca=_0x541589;return html`
        <li>
          <div>
            <h3>${_0x2d6d5d[_0x2d4eca(0x1a7)]}</h3>
            <h4>Ingredients</h4>
            <ul>${_0x2d6d5d[_0x2d4eca(0x1b4)][_0x2d4eca(0x1a8)](_0x2aaa3b=>html`<li>!${_0x2aaa3b}</li>`)}
            </ul>
            <h4>Directions</h4>
            <ol>
              ${_0x2d6d5d[_0x2d4eca(0x1bd)][_0x2d4eca(0x1a8)](_0x1247cb=>html`<li>!${_0x1247cb}</li>`)}
            </ol>
          </div>
        </li>`;}});_0x51f122[_0x541589(0x1a9)](recipes),favoritesComponent=new Component({'element':_0x541589(0x1a3),'render':function(_0x232dca){return html`
        <li>
          <h3>${_0x232dca}</h3>
        </li> `;}}),favoritesComponent[_0x541589(0x1a9)](favorites);}));function a0_0x1203(){var _0x4f6fc8=['album','music','Recipes','1jgEWJY','12HKqFoV','Music','description','#favoritesList','pictures','2494382jmBLXi','title','name','map','render','92744zMoGOs','amount','99ykDZbL','favorites','#recipesList','18kZfhIk','20VGCBHn','recipes','#gridOfImages','559930hWWOJO','ingredients','documents','129ZdXbCJ','13811629vGRdCz','301666vtKnNu','image','docs','myTabbar','189MtHslj','directions','Docs','subtitle','146670LwumXI'];a0_0x1203=function(){return _0x4f6fc8;};return a0_0x1203();}