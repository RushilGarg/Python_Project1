/**
 * @license
 * Copyright 2016 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';const a0_0x193a5f=a0_0x3c5e;function a0_0x3c5e(_0x58632c,_0x381c8a){const _0x2d5004=a0_0x2d50();return a0_0x3c5e=function(_0x3c5ee6,_0x201d9c){_0x3c5ee6=_0x3c5ee6-0x1c2;let _0x4a3218=_0x2d5004[_0x3c5ee6];return _0x4a3218;},a0_0x3c5e(_0x58632c,_0x381c8a);}(function(_0x1adc40,_0x33eb8b){const _0x4f6eae=a0_0x3c5e,_0x456d98=_0x1adc40();while(!![]){try{const _0x4f8c22=parseInt(_0x4f6eae(0x1d5))/0x1+parseInt(_0x4f6eae(0x1d8))/0x2*(parseInt(_0x4f6eae(0x1d6))/0x3)+parseInt(_0x4f6eae(0x1d4))/0x4+parseInt(_0x4f6eae(0x1cc))/0x5+-parseInt(_0x4f6eae(0x1cb))/0x6+parseInt(_0x4f6eae(0x1cd))/0x7+parseInt(_0x4f6eae(0x1ca))/0x8*(-parseInt(_0x4f6eae(0x1c3))/0x9);if(_0x4f8c22===_0x33eb8b)break;else _0x456d98['push'](_0x456d98['shift']());}catch(_0x34d0ba){_0x456d98['push'](_0x456d98['shift']());}}}(a0_0x2d50,0xeae0b));const ExtensionProtocol=require('lighthouse-core/driver/drivers/extension'),Runner=require(a0_0x193a5f(0x1d3)),config=require(a0_0x193a5f(0x1d9));function a0_0x2d50(){const _0x32a839=['2106898rLCmBn','lighthouse-core/config/default.json','create','createPageAndPopulate','onMessage','1858509oBdxbM','ready','then','tabs','previousVersion','tab','/pages/report.html','224Qfylwg','1898070RzFFFl','8321630zLBZZA','11511766TMfJwR','runAudits','runtime','onInstalled','run','addListener','lighthouse-core/runner','6107936MMshzI','1171135zFZoQK','3pMoyGv','getCurrentTabURL'];a0_0x2d50=function(){return _0x32a839;};return a0_0x2d50();}window[a0_0x193a5f(0x1db)]=function(_0x4f03de){const _0x2bf820=a0_0x193a5f,_0x2b5a52=chrome['extension']['getURL'](_0x2bf820(0x1c9));chrome[_0x2bf820(0x1c6)][_0x2bf820(0x1da)]({'url':_0x2b5a52},_0x38b1b1=>{const _0x5eadad=_0x2bf820;chrome[_0x5eadad(0x1cf)][_0x5eadad(0x1c2)][_0x5eadad(0x1d2)]((_0x126792,_0x479a71,_0x2ff7c1)=>{const _0x5f03e9=_0x5eadad;if(_0x126792&&_0x126792[_0x5f03e9(0x1c4)]&&_0x479a71[_0x5f03e9(0x1c8)]['id']===_0x38b1b1['id'])return _0x2ff7c1(_0x4f03de);});});},window[a0_0x193a5f(0x1ce)]=function(_0x684258){const _0x3b5bb6=a0_0x193a5f,_0x4a6b82=new ExtensionProtocol();return _0x4a6b82[_0x3b5bb6(0x1d7)]()[_0x3b5bb6(0x1c5)](_0x376c0c=>{const _0x36038b=_0x3b5bb6;return Runner[_0x36038b(0x1d1)](_0x4a6b82,Object['assign']({},_0x684258,{'url':_0x376c0c,'config':config}));});},chrome[a0_0x193a5f(0x1cf)][a0_0x193a5f(0x1d0)][a0_0x193a5f(0x1d2)](_0x343925=>{const _0x55b4a7=a0_0x193a5f;_0x343925['previousVersion']&&console['log'](_0x55b4a7(0x1c7),_0x343925[_0x55b4a7(0x1c7)]);});