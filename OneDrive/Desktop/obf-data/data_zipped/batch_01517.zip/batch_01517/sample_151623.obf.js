'use strict';var a0_0x184ca2=a0_0x340f;(function(_0x206642,_0x46f5df){var _0x3edce2=a0_0x340f,_0x11dad0=_0x206642();while(!![]){try{var _0x3637d0=parseInt(_0x3edce2(0xba))/0x1*(parseInt(_0x3edce2(0x7c))/0x2)+-parseInt(_0x3edce2(0xc1))/0x3*(parseInt(_0x3edce2(0x76))/0x4)+parseInt(_0x3edce2(0xae))/0x5+parseInt(_0x3edce2(0x8c))/0x6+-parseInt(_0x3edce2(0x72))/0x7+-parseInt(_0x3edce2(0x6d))/0x8+parseInt(_0x3edce2(0x9f))/0x9*(parseInt(_0x3edce2(0x84))/0xa);if(_0x3637d0===_0x46f5df)break;else _0x11dad0['push'](_0x11dad0['shift']());}catch(_0x505ae4){_0x11dad0['push'](_0x11dad0['shift']());}}}(a0_0x5d5b,0xf0e6e));var yo=require('yo-yo');const copy=require(a0_0x184ca2(0x8e));var csjs=require('csjs-inject'),remix=require(a0_0x184ca2(0xa5)),styleGuide=remix['ui'][a0_0x184ca2(0x90)],styles=styleGuide(),EventManager=remix[a0_0x184ca2(0xb1)][a0_0x184ca2(0xc9)],helper=require('../../lib/helper'),executionContext=require(a0_0x184ca2(0xb6)),modalDialog=require(a0_0x184ca2(0x97)),typeConversion=require(a0_0x184ca2(0x98)),css=csjs`
  .log {
    display: flex;
    align-items: end;
    justify-content: space-between;
  }
  .tx {
    color: ${styles[a0_0x184ca2(0x7b)][a0_0x184ca2(0x87)]};
    font-weight: bold;
    width: 45%;
  }
  .txTable, .tr, .td {
    border-collapse: collapse;
    font-size: 10px;
    color: ${styles[a0_0x184ca2(0x7b)]['text_Primary']};
    border: 1px solid ${styles[a0_0x184ca2(0x7b)][a0_0x184ca2(0x91)]};
  }
  #txTable {
    margin-top: 1%;
    margin-bottom: 5%;
    align-self: center;
  }
  .tr, .td {
    padding: 4px;
  }
  .tableTitle {
    width: 25%;
  }
  .buttons {
    display: flex;
  }
  .debug {
    ${styles[a0_0x184ca2(0x7b)][a0_0x184ca2(0x8f)]}
  }
  .details {
    ${styles[a0_0x184ca2(0x7b)][a0_0x184ca2(0xad)]}
  }
  .debug, .details {
    min-height: 18px;
    max-height: 18px;
    width: 45px;
    min-width: 45px;
    font-size: 10px;
    margin-left: 5px;
  }
  .clipboardCopy {
    margin-right: 0.5em;
    cursor: pointer;
    color: ${styles[a0_0x184ca2(0x7b)][a0_0x184ca2(0xc5)]};
  }
  .clipboardCopy:hover {
    color: ${styles[a0_0x184ca2(0x7b)]['icon_HoverColor_CopyToClipboard']};
  }
  `;class TxLogger{constructor(_0x3da9fc={}){var _0x34487c=a0_0x184ca2;this[_0x34487c(0xa1)]=new EventManager(),this[_0x34487c(0xb5)]=_0x3da9fc,this[_0x34487c(0xb2)]=_0x3da9fc[_0x34487c(0x82)][_0x34487c(0x9a)][_0x34487c(0xb4)](_0x34487c(0x8a),(_0x4ed2fe,_0x4a5a9c,_0x10657f)=>{var _0x577eb0=_0x34487c,_0x294871=_0x4ed2fe[0x0],_0x514c1d;_0x294871['tx'][_0x577eb0(0x7d)]?_0x514c1d=renderCall(this,_0x294871):_0x514c1d=renderKnownTransaction(this,_0x294871),_0x10657f(_0x514c1d);},{'activate':!![]}),this[_0x34487c(0x86)]=_0x3da9fc[_0x34487c(0x82)][_0x34487c(0x9a)][_0x34487c(0xb4)](_0x34487c(0xa3),(_0x2e6c25,_0x36f56d,_0x472ce4)=>{var _0x2204a8=_0x2e6c25[0x0],_0x29d080=renderUnknownTransaction(this,_0x2204a8);_0x472ce4(_0x29d080);},{'activate':![]}),this['logEmptyBlock']=_0x3da9fc[_0x34487c(0x82)][_0x34487c(0x9a)][_0x34487c(0xb4)](_0x34487c(0x85),(_0x3301dd,_0x5b6bd3,_0x38ae66)=>{var _0x58605b=_0x3301dd[0x0],_0x283a95=renderEmptyBlock(this,_0x58605b);_0x38ae66(_0x283a95);},{'activate':!![]}),_0x3da9fc[_0x34487c(0x82)][_0x34487c(0x9a)][_0x34487c(0xa1)]['register'](_0x34487c(0xab),(_0x588c2c,_0x208b92)=>{var _0x1f4c4c=_0x34487c;if(_0x588c2c==='deselect'){if(_0x208b92===_0x1f4c4c(0xa8))_0x3da9fc[_0x1f4c4c(0x82)][_0x1f4c4c(0x9a)][_0x1f4c4c(0x6f)]({'type':_0x1f4c4c(0xbf),'value':_0x1f4c4c(0xa3)});else _0x208b92===_0x1f4c4c(0x92)&&_0x3da9fc[_0x1f4c4c(0x82)]['editorpanel'][_0x1f4c4c(0x6f)]({'type':_0x1f4c4c(0xb0),'value':_0x1f4c4c(0xa3)});}else{if(_0x588c2c===_0x1f4c4c(0xbf)){if(_0x208b92==='only\x20remix\x20transactions')_0x3da9fc['api']['editorpanel']['updateTerminalFilter']({'type':_0x1f4c4c(0xb0),'value':_0x1f4c4c(0xa3)});else _0x208b92===_0x1f4c4c(0x92)&&_0x3da9fc['api']['editorpanel']['updateTerminalFilter']({'type':_0x1f4c4c(0xbf),'value':_0x1f4c4c(0xa3)});}}}),_0x3da9fc[_0x34487c(0xb7)][_0x34487c(0xc4)][_0x34487c(0xa4)](_0x34487c(0x74),_0x5786bf=>{var _0x2bac01=_0x34487c;!_0x5786bf[_0x2bac01(0xc7)][_0x2bac01(0x9b)]&&this['logEmptyBlock']({'block':_0x5786bf});}),_0x3da9fc['events'][_0x34487c(0xc4)][_0x34487c(0xa4)]('newTransaction',_0x10dec3=>{log(this,_0x10dec3,_0x3da9fc['api']);}),_0x3da9fc[_0x34487c(0xb7)][_0x34487c(0xc4)][_0x34487c(0xa4)](_0x34487c(0x99),_0x194018=>{var _0x159748=_0x34487c;log(this,_0x194018,_0x3da9fc[_0x159748(0x82)]);});}}function log(_0x364948,_0x1ca886,_0x243ad5){var _0xe941e=a0_0x184ca2,_0x53977b=_0x243ad5[_0xe941e(0xac)](_0x1ca886[_0xe941e(0x71)]);_0x53977b?_0x243ad5['parseLogs'](_0x1ca886,_0x53977b['contractName'],_0x243ad5['compiledContracts'](),(_0x8f0267,_0x112cb3)=>{var _0x287b32=_0xe941e;!_0x8f0267&&_0x364948[_0x287b32(0xb2)]({'tx':_0x1ca886,'resolvedData':_0x53977b,'logs':_0x112cb3});}):_0x364948['logUnknownTX']({'tx':_0x1ca886});}function renderKnownTransaction(_0x360d00,_0x28571c){var _0x2391bf=a0_0x184ca2,_0x56a509=_0x28571c['tx']['from'],_0x2d2a16=_0x28571c[_0x2391bf(0xca)][_0x2391bf(0xa6)]+'.'+_0x28571c[_0x2391bf(0xca)]['fn'];function _0x43dd33(){var _0x4ba6af=_0x2391bf;_0x360d00[_0x4ba6af(0xa1)]['trigger']('debugRequested',[_0x28571c['tx']['hash']]);}var _0x272674=yo`
    <span id="tx${_0x28571c['tx'][_0x2391bf(0x71)]}">
      <div class="${css[_0x2391bf(0xb9)]}">
        ${context(_0x360d00,{'from':_0x56a509,'to':_0x2d2a16,'data':_0x28571c})}
        <div class=${css[_0x2391bf(0x93)]}>
        <button class=${css[_0x2391bf(0xbd)]} onclick=${_0x75c9eb}>Details</button>
        <button class=${css[_0x2391bf(0x78)]} onclick=${_0x43dd33}>Debug</button>
        </div>
      </div>
    </span>
  `,_0x548a73;function _0x75c9eb(){var _0x323404=_0x2391bf;_0x548a73&&_0x548a73[_0x323404(0xa2)]?_0x272674[_0x323404(0x8b)](_0x548a73):(_0x548a73=createTable({'contractAddress':_0x28571c['tx'][_0x323404(0xc2)],'data':_0x28571c['tx'],'from':_0x56a509,'to':_0x2d2a16,'gas':_0x28571c['tx'][_0x323404(0xcb)],'hash':_0x28571c['tx'][_0x323404(0x71)],'input':_0x28571c['tx'][_0x323404(0x6c)],'decoded\x20input':_0x28571c[_0x323404(0xca)]&&_0x28571c[_0x323404(0xca)]['params']?JSON[_0x323404(0x80)](typeConversion[_0x323404(0x80)](_0x28571c['resolvedData'][_0x323404(0xbc)]),null,'\x09'):'\x20-\x20','decoded\x20output':_0x28571c[_0x323404(0xca)]&&_0x28571c[_0x323404(0xca)][_0x323404(0xc6)]?JSON['stringify'](typeConversion[_0x323404(0x80)](_0x28571c[_0x323404(0xca)][_0x323404(0xc6)]),null,'\x09'):'\x20-\x20','logs':_0x28571c[_0x323404(0x79)],'val':_0x28571c['tx'][_0x323404(0x95)],'transactionCost':_0x28571c['tx']['transactionCost'],'executionCost':_0x28571c['tx'][_0x323404(0x73)],'status':_0x28571c['tx'][_0x323404(0xa7)]}),_0x272674['appendChild'](_0x548a73));}return _0x272674;}function renderCall(_0x5b1723,_0x52fac6){var _0x4eb800=a0_0x184ca2;function _0x302658(){var _0x5d5e35=a0_0x340f;_0x52fac6['tx']['envMode']==='vm'?_0x5b1723[_0x5d5e35(0xa1)][_0x5d5e35(0x7e)]('debugRequested',[_0x52fac6['tx'][_0x5d5e35(0x71)]]):modalDialog[_0x5d5e35(0x9e)](_0x5d5e35(0xc3));}var _0x1a5671=_0x52fac6[_0x4eb800(0xca)][_0x4eb800(0xa6)]+'.'+_0x52fac6['resolvedData']['fn'],_0x3f564b=_0x52fac6['tx']['from']?_0x52fac6['tx']['from']:_0x4eb800(0xb3),_0x2b4c37=_0x52fac6['tx'][_0x4eb800(0x6c)]?helper['shortenHexData'](_0x52fac6['tx'][_0x4eb800(0x6c)]):'',_0x3c411f=yo`
    <span id="tx${_0x52fac6['tx'][_0x4eb800(0x71)]}">
      <div class="${css[_0x4eb800(0xb9)]}">
        <span><span class=${css['tx']}>[call]</span> from:${_0x3f564b}, to:${_0x1a5671}, data:${_0x2b4c37}, return: </span>
        <div class=${css[_0x4eb800(0x93)]}>
          <button class=${css[_0x4eb800(0xbd)]} onclick=${_0x3b4b8a}>Details</button>
          <button class=${css['debug']} onclick=${_0x302658}>Debug</button>
        </div>
      </div>
      <div> ${JSON[_0x4eb800(0x80)](typeConversion[_0x4eb800(0x80)](_0x52fac6['resolvedData'][_0x4eb800(0xc6)]),null,'\x09')}</div>
    </span>
  `,_0x388686;function _0x3b4b8a(){var _0x4e9a4d=_0x4eb800;_0x388686&&_0x388686[_0x4e9a4d(0xa2)]?_0x3c411f['removeChild'](_0x388686):(_0x388686=createTable({'isCall':_0x52fac6['tx']['isCall'],'contractAddress':_0x52fac6['tx'][_0x4e9a4d(0xc2)],'data':_0x52fac6['tx'],'from':_0x3f564b,'to':_0x1a5671,'gas':_0x52fac6['tx'][_0x4e9a4d(0xcb)],'input':_0x52fac6['tx'][_0x4e9a4d(0x6c)],'decoded\x20input':_0x52fac6[_0x4e9a4d(0xca)]&&_0x52fac6[_0x4e9a4d(0xca)]['params']?JSON[_0x4e9a4d(0x80)](typeConversion[_0x4e9a4d(0x80)](_0x52fac6[_0x4e9a4d(0xca)][_0x4e9a4d(0xbc)]),null,'\x09'):_0x4e9a4d(0xb3),'decoded\x20output':_0x52fac6[_0x4e9a4d(0xca)]&&_0x52fac6[_0x4e9a4d(0xca)]['decodedReturnValue']?JSON[_0x4e9a4d(0x80)](typeConversion[_0x4e9a4d(0x80)](_0x52fac6[_0x4e9a4d(0xca)][_0x4e9a4d(0xc6)]),null,'\x09'):_0x4e9a4d(0xb3),'logs':_0x52fac6['logs'],'val':_0x52fac6['tx'][_0x4e9a4d(0x95)],'transactionCost':_0x52fac6['tx'][_0x4e9a4d(0xa9)],'executionCost':_0x52fac6['tx'][_0x4e9a4d(0x73)]}),_0x3c411f['appendChild'](_0x388686));}return _0x3c411f;}function renderUnknownTransaction(_0x3b0b75,_0x1f5678){var _0x3c5fe5=a0_0x184ca2,_0x26889e=_0x1f5678['tx'][_0x3c5fe5(0xbb)],_0x4549ae=_0x1f5678['tx']['to'];function _0x60a881(){var _0x50bdda=_0x3c5fe5;_0x3b0b75['event'][_0x50bdda(0x7e)](_0x50bdda(0x7a),[_0x1f5678['tx'][_0x50bdda(0x71)]]);}var _0x34b550=yo`
    <span id="tx${_0x1f5678['tx'][_0x3c5fe5(0x71)]}">
      <div class="${css[_0x3c5fe5(0xb9)]}">
        ${context(_0x3b0b75,{'from':_0x26889e,'to':_0x4549ae,'data':_0x1f5678})}
        <div class=${css[_0x3c5fe5(0x93)]}>
          <button class=${css['details']} onclick=${_0x6ae1bf}>Details</button>
          <button class=${css[_0x3c5fe5(0x78)]} onclick=${_0x60a881}>Debug</button>
        </div>
      </div>
    </span>
  `,_0x4e45cc;function _0x6ae1bf(){var _0x4e284a=_0x3c5fe5;_0x4e45cc&&_0x4e45cc[_0x4e284a(0xa2)]?_0x34b550[_0x4e284a(0x8b)](_0x4e45cc):(_0x4e45cc=createTable({'data':_0x1f5678['tx'],'from':_0x26889e,'to':_0x4549ae,'val':_0x1f5678['tx'][_0x4e284a(0x95)],'input':_0x1f5678['tx']['input'],'hash':_0x1f5678['tx']['hash'],'gas':_0x1f5678['tx'][_0x4e284a(0xcb)],'logs':_0x1f5678[_0x4e284a(0x79)],'transactionCost':_0x1f5678['tx'][_0x4e284a(0xa9)],'executionCost':_0x1f5678['tx'][_0x4e284a(0x73)],'status':_0x1f5678['tx'][_0x4e284a(0xa7)]}),_0x34b550[_0x4e284a(0x7f)](_0x4e45cc));}return _0x34b550;}function renderEmptyBlock(_0x519585,_0x1047f1){return yo`<span><span class='${css['tx']}'>[block:${_0x1047f1['block']['number']} - 0 transactions]</span></span>`;}function context(_0x58d75e,_0x31a506){var _0x48f6e5=a0_0x184ca2,_0x1609d5=_0x31a506[_0x48f6e5(0x6e)]||'',_0x3e65ad=_0x31a506[_0x48f6e5(0xbb)]?helper[_0x48f6e5(0x9d)](_0x31a506['from']):'',_0x9837e2=_0x31a506['to'];if(_0x1609d5['tx']['to'])_0x9837e2=_0x9837e2+'\x20'+helper[_0x48f6e5(0x9d)](_0x1609d5['tx']['to']);var _0xf1a87=_0x1609d5['tx']['value'],_0x19509b=_0x1609d5['tx'][_0x48f6e5(0x71)]?helper['shortenHexData'](_0x1609d5['tx'][_0x48f6e5(0x71)]):'',_0x12ffbf=_0x1609d5['tx'][_0x48f6e5(0x6c)]?helper[_0x48f6e5(0x9d)](_0x1609d5['tx'][_0x48f6e5(0x6c)]):'',_0x1430dc=_0x1609d5[_0x48f6e5(0x79)]&&_0x1609d5[_0x48f6e5(0x79)][_0x48f6e5(0xaf)]?_0x1609d5[_0x48f6e5(0x79)][_0x48f6e5(0xaf)][_0x48f6e5(0x9b)]:0x0,_0x4369b4=_0x1609d5['tx'][_0x48f6e5(0x94)]||'',_0x3eafb7=_0x1609d5['tx'][_0x48f6e5(0x8d)],_0x754b80=_0xf1a87?typeConversion[_0x48f6e5(0xc8)](_0xf1a87):0x0;if(executionContext[_0x48f6e5(0xb8)]()==='vm')return yo`<span><span class=${css['tx']}>[vm]</span> from:${_0x3e65ad}, to:${_0x9837e2}, value:${_0x754b80} wei, data:${_0x12ffbf}, ${_0x1430dc} logs, hash:${_0x19509b}</span>`;else return executionContext[_0x48f6e5(0xb8)]()!=='vm'&&_0x1609d5[_0x48f6e5(0xca)]?yo`<span><span class='${css['tx']}'>[block:${_0x4369b4} txIndex:${_0x3eafb7}]</span> from:${_0x3e65ad}, to:${_0x9837e2}, value:${_0x754b80} wei, ${_0x1430dc} logs, data:${_0x12ffbf}, hash:${_0x19509b}</span>`:(_0x9837e2=helper['shortenHexData'](_0x9837e2),_0x19509b=helper[_0x48f6e5(0x9d)](_0x1609d5['tx'][_0x48f6e5(0xa0)]),yo`<span><span class='${css['tx']}'>[block:${_0x4369b4} txIndex:${_0x3eafb7}]</span> from:${_0x3e65ad}, to:${_0x9837e2}, value:${_0x754b80} wei</span>`);}function a0_0x5d5b(){var _0x2ae150=['resolvedData','gas','input','8976752jXQcVr','data','updateTerminalFilter','decoded\x20output','hash','4223135mVqoXA','executionCost','newBlock','val','68IRzFTM','exports','debug','logs','debugRequested','terminal','90796OHUmMG','isCall','trigger','appendChild','stringify','tableTitle','api','(Cost\x20only\x20applies\x20when\x20called\x20by\x20a\x20contract)','680PDwiTA','emptyBlock','logUnknownTX','text_Title_TransactionLog','\x20Transaction\x20mined\x20but\x20execution\x20failed','0x0','knownTransaction','removeChild','2309184LIiUTQ','transactionIndex','clipboard-copy','button_Log_Debug','styleGuide','text_Primary','all\x20transactions','buttons','blockNumber','value','clipboardCopy','../ui/modal-dialog-custom','../../lib/typeConversion','newCall','editorpanel','length','raw','shortenHexData','alert','440379pgTSGK','blockHash','event','parentNode','unknownTransaction','register','ethereum-remix','contractName','status','only\x20remix\x20transactions','transactionCost','txTable','terminalFilterChanged','resolvedTransaction','button_Log_Details','4605105QRPwZO','decoded','deselect','lib','logKnownTX','\x20-\x20','registerCommand','opts','../../execution-context','events','getProvider','log','1QXERtA','from','params','details','decoded\x20input','select','0x1','347022rWbiwk','contractAddress','Cannot\x20debug\x20this\x20call.\x20Debugging\x20calls\x20is\x20only\x20possible\x20in\x20JavaScript\x20VM\x20mode.','txListener','icon_Color_CopyToClipboard','decodedReturnValue','transactions','toInt','EventManager'];a0_0x5d5b=function(){return _0x2ae150;};return a0_0x5d5b();}function a0_0x340f(_0x4fddf3,_0x512412){var _0x5d5b9c=a0_0x5d5b();return a0_0x340f=function(_0x340fb5,_0x5180cd){_0x340fb5=_0x340fb5-0x6c;var _0x509bd7=_0x5d5b9c[_0x340fb5];return _0x509bd7;},a0_0x340f(_0x4fddf3,_0x512412);}module[a0_0x184ca2(0x77)]=TxLogger;function createTable(_0x4faf3f){var _0x17cfe1=a0_0x184ca2,_0x58d156=yo`<table class="${css[_0x17cfe1(0xaa)]}" id="txTable"></table>`;if(_0x4faf3f['status']){var _0x2dbfa9='';if(_0x4faf3f[_0x17cfe1(0xa7)]===_0x17cfe1(0x89))_0x2dbfa9=_0x17cfe1(0x88);else _0x4faf3f[_0x17cfe1(0xa7)]===_0x17cfe1(0xc0)&&(_0x2dbfa9='\x20Transaction\x20mined\x20and\x20execution\x20succeed');_0x58d156['appendChild'](yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> status </td>
      <td class="${css['td']}">${_0x4faf3f['status']}${_0x2dbfa9}</td>
    </tr class="${css['tr']}">`);}var _0x3ac431=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> contractAddress </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0x23c5d7=_0x17cfe1;copy(_0x4faf3f[_0x23c5d7(0xc2)]);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0xc2)]}</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f['contractAddress'])_0x58d156[_0x17cfe1(0x7f)](_0x3ac431);var _0xa51476=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']} ${css[_0x17cfe1(0x81)]}"> from </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0xa932ba=_0x17cfe1;copy(_0x4faf3f[_0xa932ba(0xbb)]);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0xbb)]}</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f[_0x17cfe1(0xbb)])_0x58d156[_0x17cfe1(0x7f)](_0xa51476);var _0x25d284,_0x696019=_0x4faf3f[_0x17cfe1(0x6e)];_0x696019['to']?_0x25d284=_0x4faf3f['to']+'\x20'+_0x696019['to']:_0x25d284=_0x4faf3f['to'];var _0x1dcbae=yo`
    <tr class="${css['tr']}">
    <td class="${css['td']}"> to </td>
    <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){copy(_0x696019['to']?_0x696019['to']:_0x25d284);}} title='Copy to clipboard'></i>${_0x25d284}</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f['to'])_0x58d156[_0x17cfe1(0x7f)](_0x1dcbae);var _0x22fc67=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> gas </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0x4f8756=_0x17cfe1;copy(_0x4faf3f[_0x4f8756(0xcb)]);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0xcb)]} gas</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f[_0x17cfe1(0xcb)])_0x58d156[_0x17cfe1(0x7f)](_0x22fc67);var _0x2f61ac='';_0x4faf3f[_0x17cfe1(0x7d)]&&(_0x2f61ac=_0x17cfe1(0x83));_0x4faf3f[_0x17cfe1(0xa9)]&&_0x58d156[_0x17cfe1(0x7f)](yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> transaction cost </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css['clipboardCopy']}" aria-hidden="true" onclick=${function(){var _0x242dbf=_0x17cfe1;copy(_0x4faf3f[_0x242dbf(0xa9)]);}} title='Copy to clipboard'></i>${_0x4faf3f['transactionCost']} gas ${_0x2f61ac}</td>
    </tr class="${css['tr']}">`);_0x4faf3f['executionCost']&&_0x58d156['appendChild'](yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> execution cost </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0x4a1839=_0x17cfe1;copy(_0x4faf3f[_0x4a1839(0x73)]);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0x73)]} gas ${_0x2f61ac}</td>
    </tr class="${css['tr']}">`);var _0xd12951=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> hash </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css['clipboardCopy']}" aria-hidden="true" onclick=${function(){var _0x44d659=_0x17cfe1;copy(_0x4faf3f[_0x44d659(0x71)]);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0x71)]}</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f[_0x17cfe1(0x71)])_0x58d156[_0x17cfe1(0x7f)](_0xd12951);var _0x4aa49c=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> input </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){copy(_0x4faf3f['input']);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0x6c)]}</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f[_0x17cfe1(0x6c)])_0x58d156[_0x17cfe1(0x7f)](_0x4aa49c);if(_0x4faf3f[_0x17cfe1(0xbe)]){var _0x4f669c=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> decoded input </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0x4b964e=_0x17cfe1;copy(_0x4faf3f[_0x4b964e(0xbe)]);}} title='Copy to clipboard'></i>${_0x4faf3f[_0x17cfe1(0xbe)]}</td>
    </tr class="${css['tr']}">`;_0x58d156[_0x17cfe1(0x7f)](_0x4f669c);}if(_0x4faf3f[_0x17cfe1(0x70)]){var _0xb8e944=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> decoded output </td>
      <td class="${css['td']}" id="decodedoutput" >${_0x4faf3f[_0x17cfe1(0x70)]}</td>
    </tr class="${css['tr']}">`;_0x58d156[_0x17cfe1(0x7f)](_0xb8e944);}var _0x2ea097='\x20-\x20';_0x4faf3f['logs'][_0x17cfe1(0xaf)]&&(_0x2ea097=typeConversion[_0x17cfe1(0x80)](_0x4faf3f[_0x17cfe1(0x79)][_0x17cfe1(0xaf)]));var _0x562766=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> logs </td>
      <td class="${css['td']}" id="logs">
      <i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0x534206=_0x17cfe1;copy(JSON[_0x534206(0x80)](_0x2ea097,null,'\x09'));}} title='Copy Logs to clipboard'></i>
      <i class="fa fa-clipboard ${css[_0x17cfe1(0x96)]}" aria-hidden="true" onclick=${function(){var _0x27f9af=_0x17cfe1;copy(JSON[_0x27f9af(0x80)](_0x4faf3f['logs'][_0x27f9af(0x9c)]||'0'));}} title='Copy Raw Logs to clipboard'></i>${JSON['stringify'](_0x2ea097,null,'\x09')}</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f['logs'])_0x58d156[_0x17cfe1(0x7f)](_0x562766);var _0x459c61=_0x4faf3f['val']!=null?typeConversion[_0x17cfe1(0xc8)](_0x4faf3f['val']):0x0;_0x459c61=yo`
    <tr class="${css['tr']}">
      <td class="${css['td']}"> value </td>
      <td class="${css['td']}"><i class="fa fa-clipboard ${css['clipboardCopy']}" aria-hidden="true" onclick=${function(){copy(_0x459c61+'\x20wei');}} title='Copy to clipboard'></i>${_0x459c61} wei</td>
    </tr class="${css['tr']}">
  `;if(_0x4faf3f[_0x17cfe1(0x75)])_0x58d156[_0x17cfe1(0x7f)](_0x459c61);return _0x58d156;}