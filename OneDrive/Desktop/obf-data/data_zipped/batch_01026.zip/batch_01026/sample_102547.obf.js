/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x83d4(_0x2dbb36,_0x4b547b){var _0x2b3d2a=a0_0x2b3d();return a0_0x83d4=function(_0x83d461,_0x21e72e){_0x83d461=_0x83d461-0x1df;var _0x3b6fd8=_0x2b3d2a[_0x83d461];return _0x3b6fd8;},a0_0x83d4(_0x2dbb36,_0x4b547b);}var a0_0x42a8c2=a0_0x83d4;function a0_0x2b3d(){var _0xcb0ee=['exports','2756650tQkgCC','65bEujhe','243jLtItL','./../src/addon.node','172606FbXtas','463002qVtFJb','16468089EzrHdz','38658LxWEmO','32ylZeEa','415640nIttHY','1062902elxMpX','40jZuuBI'];a0_0x2b3d=function(){return _0xcb0ee;};return a0_0x2b3d();}(function(_0x5be72a,_0x4fc9a5){var _0x5502eb=a0_0x83d4,_0x5504f4=_0x5be72a();while(!![]){try{var _0x38bedd=parseInt(_0x5502eb(0x1df))/0x1+parseInt(_0x5502eb(0x1e2))/0x2+-parseInt(_0x5502eb(0x1e7))/0x3*(-parseInt(_0x5502eb(0x1ea))/0x4)+-parseInt(_0x5502eb(0x1e3))/0x5*(parseInt(_0x5502eb(0x1e9))/0x6)+-parseInt(_0x5502eb(0x1e6))/0x7*(parseInt(_0x5502eb(0x1e0))/0x8)+parseInt(_0x5502eb(0x1e4))/0x9*(-parseInt(_0x5502eb(0x1eb))/0xa)+-parseInt(_0x5502eb(0x1e8))/0xb;if(_0x38bedd===_0x4fc9a5)break;else _0x5504f4['push'](_0x5504f4['shift']());}catch(_0x4a5596){_0x5504f4['push'](_0x5504f4['shift']());}}}(a0_0x2b3d,0xcf673));var addon=require(a0_0x42a8c2(0x1e5));function scumaxabs(_0xfcdb6a,_0x3d4601,_0x546fa2,_0x34d4e5,_0x39bc98){return addon(_0xfcdb6a,_0x3d4601,_0x546fa2,_0x34d4e5,_0x39bc98),_0x34d4e5;}module[a0_0x42a8c2(0x1e1)]=scumaxabs;