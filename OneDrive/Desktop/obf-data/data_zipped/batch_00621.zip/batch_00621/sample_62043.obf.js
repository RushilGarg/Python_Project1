const a0_0x460897=a0_0x5659;(function(_0x55baeb,_0x427892){const _0x11f59e=a0_0x5659,_0x12f9c8=_0x55baeb();while(!![]){try{const _0x3bfb2f=-parseInt(_0x11f59e(0xa8))/0x1*(parseInt(_0x11f59e(0xc4))/0x2)+parseInt(_0x11f59e(0xc0))/0x3*(-parseInt(_0x11f59e(0xbf))/0x4)+parseInt(_0x11f59e(0xb5))/0x5*(parseInt(_0x11f59e(0xc3))/0x6)+parseInt(_0x11f59e(0xaa))/0x7+-parseInt(_0x11f59e(0xc9))/0x8+parseInt(_0x11f59e(0xc2))/0x9+-parseInt(_0x11f59e(0xad))/0xa;if(_0x3bfb2f===_0x427892)break;else _0x12f9c8['push'](_0x12f9c8['shift']());}catch(_0x185e3d){_0x12f9c8['push'](_0x12f9c8['shift']());}}}(a0_0x424d,0x75864));import{expect}from'chai';import{$hook,initialize as a0_0x58d7b2}from'ember-hook';import{integration}from'ember-test-utils/test-support/setup-component-test';import a0_0x28662d from'htmlbars-inline-precompile';import{afterEach,beforeEach,describe,it}from'mocha';import a0_0x35c9bf from'sinon';function a0_0x5659(_0x3a1f6f,_0xecf262){const _0x424dad=a0_0x424d();return a0_0x5659=function(_0x5659d1,_0x1cfd2a){_0x5659d1=_0x5659d1-0xa7;let _0x2d6bba=_0x424dad[_0x5659d1];return _0x2d6bba;},a0_0x5659(_0x3a1f6f,_0xecf262);}function a0_0x424d(){const _0x6a0e36=['render','16363qXgdOT','should\x20fire\x20onExpandAll\x20closure\x20action','6614636xJiVUs','equal','myExpansion-expand-all','4908450BNSmUq','concatenates\x20the\x20hook\x20property','Expand\x20all','should\x20set\x20-collapse-all\x20hook\x20correctly','trim','sandbox','click','Collapse\x20all','5xyuTOG','have','label','expandAllAction','myExpansion-collapse-all','length','should\x20render\x20with\x20default\x20class','restore','spy','setup','808GguXbz','10872TjUwie','callCount','6831549PyCDaX','1764786yxWGPr','6ZMKhzA','collapseAllAction','.frost-list-expansion','text','trigger','1958224ZOXzON'];a0_0x424d=function(){return _0x6a0e36;};return a0_0x424d();}const test=integration('frost-list-expansion');describe(test[a0_0x460897(0xb7)],function(){const _0x297044=a0_0x460897;test[_0x297044(0xbe)]();let _0x3cdf1d;beforeEach(function(){const _0x2515cf=_0x297044;a0_0x58d7b2(),_0x3cdf1d=a0_0x35c9bf[_0x2515cf(0xb2)]['create']();}),afterEach(function(){const _0x49d96d=_0x297044;_0x3cdf1d[_0x49d96d(0xbc)]();}),it(_0x297044(0xbb),function(){const _0x3085af=_0x297044;this[_0x3085af(0xa7)](a0_0x28662d`
      {{frost-list-expansion
        hook='myExpansion'
        onCollapseAll='onCollapseAll'
        onExpandAll='onExpandAll'
      }}
    `),expect(this['$'](_0x3085af(0xc6)))['to']['be'][_0x3085af(0xba)](0x1);}),it('should\x20fire\x20onCollapseAll\x20closure\x20action',function(){const _0x32e06b=_0x297044,_0x1cc662=_0x3cdf1d[_0x32e06b(0xbd)]();this['on'](_0x32e06b(0xc5),_0x1cc662),this[_0x32e06b(0xa7)](a0_0x28662d`
      {{frost-list-expansion
        hook='myExpansion'
        onCollapseAll=(action 'collapseAllAction')
        onExpandAll='onExpandAll'
      }}
    `),$hook(_0x32e06b(0xb9))[_0x32e06b(0xc8)](_0x32e06b(0xb3)),expect(_0x1cc662)['have'][_0x32e06b(0xc1)](0x1);}),it(_0x297044(0xa9),function(){const _0x35241a=_0x297044,_0x3bc4c3=_0x3cdf1d[_0x35241a(0xbd)]();this['on'](_0x35241a(0xb8),_0x3bc4c3),this[_0x35241a(0xa7)](a0_0x28662d`
      {{frost-list-expansion
        hook='myExpansion'
        onCollapseAll='onCollapseAll'
        onExpandAll=(action 'expandAllAction')
      }}
    `),$hook(_0x35241a(0xac))['trigger'](_0x35241a(0xb3)),expect(_0x3bc4c3)[_0x35241a(0xb6)]['callCount'](0x1);}),describe(_0x297044(0xae),function(){const _0x50b122=_0x297044;beforeEach(function(){this['render'](a0_0x28662d`
        {{frost-list-expansion
          hook='myExpansion'
          onCollapseAll='onCollapseAll'
          onExpandAll='onExpandAll'
        }}
      `);}),it(_0x50b122(0xb0),function(){const _0x1fd1c6=_0x50b122;expect($hook(_0x1fd1c6(0xb9))[_0x1fd1c6(0xc7)]()[_0x1fd1c6(0xb1)]())['to'][_0x1fd1c6(0xab)](_0x1fd1c6(0xb4));}),it('should\x20set\x20-expand-all\x20hook\x20correctly',function(){const _0x3e45cd=_0x50b122;expect($hook('myExpansion-expand-all')[_0x3e45cd(0xc7)]()[_0x3e45cd(0xb1)]())['to'][_0x3e45cd(0xab)](_0x3e45cd(0xaf));});});});