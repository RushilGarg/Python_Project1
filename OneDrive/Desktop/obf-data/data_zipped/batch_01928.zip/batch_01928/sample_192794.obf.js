const a0_0x245fe4=a0_0x4f5d;(function(_0xbab32b,_0x151545){const _0x1b87df=a0_0x4f5d,_0x24dcb9=_0xbab32b();while(!![]){try{const _0x37558d=-parseInt(_0x1b87df(0xcb))/0x1+parseInt(_0x1b87df(0x107))/0x2+parseInt(_0x1b87df(0xe2))/0x3*(parseInt(_0x1b87df(0xc4))/0x4)+-parseInt(_0x1b87df(0x105))/0x5*(parseInt(_0x1b87df(0xd8))/0x6)+-parseInt(_0x1b87df(0x13d))/0x7*(parseInt(_0x1b87df(0x13a))/0x8)+-parseInt(_0x1b87df(0x139))/0x9+-parseInt(_0x1b87df(0xe7))/0xa*(-parseInt(_0x1b87df(0xea))/0xb);if(_0x37558d===_0x151545)break;else _0x24dcb9['push'](_0x24dcb9['shift']());}catch(_0x1e9348){_0x24dcb9['push'](_0x24dcb9['shift']());}}}(a0_0x2f98,0x9cb3b));function a0_0x4f5d(_0x40cca0,_0x51e8a8){const _0x2f9822=a0_0x2f98();return a0_0x4f5d=function(_0x4f5d71,_0x57bdaf){_0x4f5d71=_0x4f5d71-0xbd;let _0x68cc94=_0x2f9822[_0x4f5d71];return _0x68cc94;},a0_0x4f5d(_0x40cca0,_0x51e8a8);}function a0_0x2f98(){const _0x348aa8=['\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Biz\x20implements\x20SomeInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20name:\x20String\x0a\x20\x20\x20\x20\x20\x20\x20\x20some:\x20SomeInterface\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','does\x20not\x20allow\x20extending\x20a\x20non-object\x20type','EnumWithDeprecatedValue','QUERY','can\x20be\x20used\x20for\x20limited\x20execution','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20foo:\x20Foo\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','Foo','TestUnion','not\x20used\x20anymore','may\x20extend\x20mutations\x20and\x20subscriptions','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20UnknownType\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','getValue','extends\x20objects\x20with\x20deprecated\x20fields','does\x20not\x20allow\x20replacing\x20a\x20default\x20directive','in\x20this\x20type\x20definition.','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Foo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20deprecatedField:\x20String\x20@deprecated(reason:\x20\x22not\x20used\x20anymore\x22)\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','tag','extends\x20without\x20altering\x20original\x20schema','\x0a\x20\x20\x20\x20\x20\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20dummyField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','oneMoreNewField:\x20TestUnion','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','contain','may\x20extend\x20directives\x20with\x20new\x20simple\x20directive','sets\x20correct\x20description\x20using\x20legacy\x20comments','extensionASTNodes','Cannot\x20extend\x20non-object\x20type\x20\x22SomeInterface\x22.','not\x20an\x20interface','isDeprecated','extends\x20objects\x20by\x20adding\x20new\x20fields\x20with\x20arguments','Mutation','defined\x20in\x20this\x20type\x20extension.','New\x20field\x20description.','deprecationReason','may\x20extend\x20directives\x20with\x20new\x20complex\x20directive','2598300SyTLsV','48ZJHYpl','args','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Foo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newObject:\x20NewObject\x0a\x20\x20\x20\x20\x20\x20\x20\x20newInterface:\x20NewInterface\x0a\x20\x20\x20\x20\x20\x20\x20\x20newUnion:\x20NewUnion\x0a\x20\x20\x20\x20\x20\x20\x20\x20newScalar:\x20NewScalar\x0a\x20\x20\x20\x20\x20\x20\x20\x20newEnum:\x20NewEnum\x0a\x20\x20\x20\x20\x20\x20\x20\x20newTree:\x20[Foo]!\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20type\x20NewObject\x20implements\x20NewInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20type\x20NewOtherObject\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20fizz:\x20Int\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20interface\x20NewInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20union\x20NewUnion\x20=\x20NewObject\x20|\x20NewOtherObject\x0a\x0a\x20\x20\x20\x20\x20\x20scalar\x20NewScalar\x0a\x0a\x20\x20\x20\x20\x20\x20enum\x20NewEnum\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20OPTION_A\x0a\x20\x20\x20\x20\x20\x20\x20\x20OPTION_B\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','1077965vZwFxh','extends\x20objects\x20by\x20adding\x20new\x20unused\x20types','not','extends\x20objects\x20by\x20adding\x20implemented\x20new\x20interfaces','does\x20not\x20allow\x20extending\x20an\x20unknown\x20type','\x0a\x20\x20\x20\x20\x20\x20type\x20Unused\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20someField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','type','profile','{\x20newField\x20}','4HRfJPl','extends\x20objects\x20by\x20adding\x20implemented\x20interfaces','DEPRECATED','extends\x20objects\x20by\x20including\x20new\x20types','does\x20not\x20allow\x20replacing\x20a\x20custom\x20directive','length','getDirective','515281KBZhBT','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20#\x20New\x20field\x20description.\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','\x0a\x20\x20\x20\x20\x20\x20directive\x20@neat\x20on\x20QUERY\x0a\x20\x20\x20\x20','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Foo\x20implements\x20NewInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20interface\x20NewInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','newField(testArg:\x20TestInput):\x20TestEnum','original\x20schema,\x20or\x20is\x20added\x20in\x20a\x20type\x20definition.','lengthOf','can\x20describe\x20the\x20extended\x20fields\x20with\x20legacy\x20comments','testArg:\x20TestInput','does\x20not\x20allow\x20replacing\x20an\x20existing\x20field','testInputField','description','data','5994sDpEWv','interfaceField','\x0a\x20\x20\x20\x20\x20\x20directive\x20@include(if:\x20Boolean!)\x20on\x20FIELD\x20|\x20FRAGMENT_SPREAD\x0a\x20\x20\x20\x20','TestEnum','sets\x20correct\x20description\x20when\x20extending\x20with\x20a\x20new\x20directive','locations','equal','deep','can\x20describe\x20the\x20extended\x20fields','newDeprecatedField','244857WWZMfj','deprecatedField','Cannot\x20extend\x20type\x20\x22UnknownType\x22\x20because\x20it\x20does\x20not\x20exist\x20in\x20the\x20','astNode','builds\x20types\x20with\x20deprecated\x20fields/values','490WvLmQB','have','testInputField:\x20TestEnum','474914HzFsvm','existing\x20schema.','\x0a\x20\x20\x20\x20\x20\x20directive\x20@meow(if:\x20Boolean!)\x20on\x20FIELD\x20|\x20FRAGMENT_SPREAD\x0a\x20\x20\x20\x20','getFields','extendSchema','newField','extends\x20objects\x20by\x20adding\x20new\x20fields','enable','TypeWithDeprecatedField','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20oneMoreNewField:\x20TestUnion\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20union\x20TestUnion\x20=\x20TestType\x0a\x0a\x20\x20\x20\x20\x20\x20interface\x20TestInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20interfaceField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20type\x20TestType\x20implements\x20TestInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20interfaceField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20directive\x20@test(arg:\x20Int)\x20on\x20FIELD\x0a\x20\x20\x20\x20','TEST_VALUE','Type\x20\x22Bar\x22\x20already\x20exists\x20in\x20the\x20schema.\x20It\x20cannot\x20also\x20be\x20defined\x20','redefined.','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20quix:\x20Quix\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','throw','returns\x20the\x20original\x20schema\x20when\x20there\x20are\x20no\x20type\x20definitions','getType','Bar','do\x20not\x20use','Biz','extends\x20objects\x20multiple\x20times','Subscription','oneMoreNewField','does\x20not\x20allow\x20referencing\x20an\x20unknown\x20type','\x0a\x20\x20\x20\x20\x20\x20directive\x20@profile(enable:\x20Boolean!\x20tag:\x20String)\x20on\x20QUERY\x20|\x20FIELD\x0a\x20\x20\x20\x20','name','new','5VjOnpX','123','347312xRyDgE','not\x20a\x20scalar','Field\x20\x22Bar.foo\x22\x20already\x20exists\x20in\x20the\x20schema.\x20It\x20cannot\x20also\x20be\x20','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Foo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField(arg1:\x20SomeEnum!):\x20SomeEnum\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Biz\x20implements\x20NewInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20buzz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Biz\x20implements\x20SomeInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20name:\x20String\x0a\x20\x20\x20\x20\x20\x20\x20\x20some:\x20SomeInterface\x0a\x20\x20\x20\x20\x20\x20\x20\x20newFieldA:\x20Int\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Biz\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newFieldA:\x20Int\x0a\x20\x20\x20\x20\x20\x20\x20\x20newFieldB:\x20Float\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20interface\x20NewInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20buzz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField(testArg:\x20TestInput):\x20TestEnum\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20enum\x20TestEnum\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20TEST_VALUE\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20input\x20TestInput\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20testInputField:\x20TestEnum\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','Actually\x20use\x20this\x20description.','interfaceField:\x20String','Unknown\x20type:\x20\x22Quix\x22.\x20Ensure\x20that\x20this\x20type\x20exists\x20either\x20in\x20the\x20','new\x20directive','extends\x20objects\x20by\x20adding\x20new\x20fields\x20with\x20existing\x20types','SomeUnion','Query','neat','\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x22New\x20field\x20description.\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20','{\x20field\x20}'];a0_0x2f98=function(){return _0x348aa8;};return a0_0x2f98();}import{describe,it}from'mocha';import{expect}from'chai';import a0_0x2f72cd from'../../jsutils/dedent';import{buildSchema}from'../buildASTSchema';import{extendSchema}from'../extendSchema';import{execute}from'../../execution';import{parse,print}from'../../language';import{printSchema}from'../schemaPrinter';import{GraphQLSchema,GraphQLObjectType,GraphQLInterfaceType,GraphQLUnionType,GraphQLID,GraphQLString,GraphQLEnumType,GraphQLNonNull,GraphQLList,isScalarType,isNonNullType}from'../../type';const SomeInterfaceType=new GraphQLInterfaceType({'name':'SomeInterface','fields':()=>({'name':{'type':GraphQLString},'some':{'type':SomeInterfaceType}})}),FooType=new GraphQLObjectType({'name':a0_0x245fe4(0x11d),'interfaces':[SomeInterfaceType],'fields':()=>({'name':{'type':GraphQLString},'some':{'type':SomeInterfaceType},'tree':{'type':GraphQLNonNull(GraphQLList(FooType))}})}),BarType=new GraphQLObjectType({'name':a0_0x245fe4(0xfb),'interfaces':[SomeInterfaceType],'fields':()=>({'name':{'type':GraphQLString},'some':{'type':SomeInterfaceType},'foo':{'type':FooType}})}),BizType=new GraphQLObjectType({'name':a0_0x245fe4(0xfd),'fields':()=>({'fizz':{'type':GraphQLString}})}),SomeUnionType=new GraphQLUnionType({'name':a0_0x245fe4(0x112),'types':[FooType,BizType]}),SomeEnumType=new GraphQLEnumType({'name':'SomeEnum','values':{'ONE':{'value':0x1},'TWO':{'value':0x2}}}),testSchema=new GraphQLSchema({'query':new GraphQLObjectType({'name':a0_0x245fe4(0x113),'fields':()=>({'foo':{'type':FooType},'someUnion':{'type':SomeUnionType},'someEnum':{'type':SomeEnumType},'someInterface':{'args':{'id':{'type':GraphQLNonNull(GraphQLID)}},'type':SomeInterfaceType}})}),'types':[FooType,BarType]});describe(a0_0x245fe4(0xee),()=>{const _0x459237=a0_0x245fe4;it(_0x459237(0xf9),()=>{const _0x5a4cb5=_0x459237,_0x5a7bc5=parse(_0x5a4cb5(0x116)),_0xe29d98=extendSchema(testSchema,_0x5a7bc5);expect(_0xe29d98)['to']['equal'](testSchema);}),it(_0x459237(0x128),()=>{const _0x1ff530=_0x459237,_0x399ce4=parse(_0x1ff530(0x12b)),_0x3c8bdd=printSchema(testSchema),_0x45d3f7=extendSchema(testSchema,_0x399ce4);expect(_0x45d3f7)['to'][_0x1ff530(0xbd)][_0x1ff530(0xde)](testSchema),expect(printSchema(testSchema))['to'][_0x1ff530(0xde)](_0x3c8bdd),expect(printSchema(_0x45d3f7))['to'][_0x1ff530(0x12c)](_0x1ff530(0xef)),expect(printSchema(testSchema))['to']['not'][_0x1ff530(0x12c)](_0x1ff530(0xef));}),it(_0x459237(0x11b),async()=>{const _0x3af6dc=_0x459237,_0x503cc6=parse(_0x3af6dc(0x12b)),_0x585966=extendSchema(testSchema,_0x503cc6),_0x597e2d=parse(_0x3af6dc(0xc3)),_0x2d561f=await execute(_0x585966,_0x597e2d,{'newField':0x7b});expect(_0x2d561f[_0x3af6dc(0xd7)])['to'][_0x3af6dc(0xdf)][_0x3af6dc(0xde)]({'newField':_0x3af6dc(0x106)});}),it(_0x459237(0xe0),async()=>{const _0x3321f0=_0x459237,_0x1d6926=parse(_0x3321f0(0x115)),_0x504cc0=extendSchema(testSchema,_0x1d6926);expect(_0x504cc0[_0x3321f0(0xfa)](_0x3321f0(0x113))[_0x3321f0(0xed)]()['newField'][_0x3321f0(0xd6)])['to'][_0x3321f0(0xde)](_0x3321f0(0x136));}),it(_0x459237(0xd2),async()=>{const _0x24bda1=_0x459237,_0x2ca273=parse(_0x24bda1(0xcc)),_0x5c6c00=extendSchema(testSchema,_0x2ca273,{'commentDescriptions':!![]});expect(_0x5c6c00[_0x24bda1(0xfa)](_0x24bda1(0x113))['getFields']()[_0x24bda1(0xef)][_0x24bda1(0xd6)])['to'][_0x24bda1(0xde)](_0x24bda1(0x136));}),it('describes\x20extended\x20fields\x20with\x20strings\x20when\x20present',async()=>{const _0x3215c5=_0x459237,_0x3c0144=parse('\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20#\x20New\x20field\x20description.\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x22Actually\x20use\x20this\x20description.\x22\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20'),_0xef3481=extendSchema(testSchema,_0x3c0144,{'commentDescriptions':!![]});expect(_0xef3481[_0x3215c5(0xfa)](_0x3215c5(0x113))[_0x3215c5(0xed)]()[_0x3215c5(0xef)]['description'])['to'][_0x3215c5(0xde)](_0x3215c5(0x10d));}),it(_0x459237(0xf0),()=>{const _0x229ca2=_0x459237,_0x1e0caa=parse('\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Foo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20'),_0x569a3c=printSchema(testSchema),_0x3ba0a6=extendSchema(testSchema,_0x1e0caa);expect(_0x3ba0a6)['to'][_0x229ca2(0xbd)][_0x229ca2(0xde)](testSchema),expect(printSchema(testSchema))['to'][_0x229ca2(0xde)](_0x569a3c),expect(printSchema(_0x3ba0a6))['to'][_0x229ca2(0xde)](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz {
        fizz: String
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
        newField: String
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it('correctly\x20assign\x20AST\x20nodes\x20to\x20new\x20and\x20extended\x20types',()=>{const _0x236664=_0x459237,_0x4fb38b=buildSchema(_0x236664(0x129)),_0x28d4c7=parse(_0x236664(0x10c)),_0x54eab0=extendSchema(_0x4fb38b,_0x28d4c7),_0x14a28a=parse(_0x236664(0xf3)),_0x2701aa=extendSchema(_0x54eab0,_0x14a28a),_0x431332=_0x2701aa['getType'](_0x236664(0x113)),_0x3f1c0e=_0x2701aa[_0x236664(0xfa)]('TestInput'),_0x2e7498=_0x2701aa[_0x236664(0xfa)](_0x236664(0xdb)),_0x2a74bc=_0x2701aa[_0x236664(0xfa)](_0x236664(0x11e)),_0x5d4b58=_0x2701aa[_0x236664(0xfa)]('TestInterface'),_0x34f003=_0x2701aa['getType']('TestType'),_0x490e6a=_0x2701aa[_0x236664(0xca)]('test');expect(_0x431332['extensionASTNodes'])['to'][_0x236664(0xe8)][_0x236664(0xd1)](0x2),expect(_0x34f003[_0x236664(0x12f)])['to']['equal'](undefined);const _0x1a3929=parse(print(_0x431332['extensionASTNodes'][0x0])+'\x0a'+print(_0x431332['extensionASTNodes'][0x1])+'\x0a'+print(_0x3f1c0e[_0x236664(0xe5)])+'\x0a'+print(_0x2e7498[_0x236664(0xe5)])+'\x0a'+print(_0x2a74bc[_0x236664(0xe5)])+'\x0a'+print(_0x5d4b58['astNode'])+'\x0a'+print(_0x34f003[_0x236664(0xe5)])+'\x0a'+print(_0x490e6a[_0x236664(0xe5)]));expect(printSchema(extendSchema(_0x4fb38b,_0x1a3929)))['to']['be']['equal'](printSchema(_0x2701aa));const _0x1e9de0=_0x431332[_0x236664(0xed)]()[_0x236664(0xef)];expect(print(_0x1e9de0[_0x236664(0xe5)]))['to']['equal'](_0x236664(0xcf)),expect(print(_0x1e9de0[_0x236664(0x13b)][0x0][_0x236664(0xe5)]))['to'][_0x236664(0xde)](_0x236664(0xd3)),expect(print(_0x431332[_0x236664(0xed)]()[_0x236664(0x100)][_0x236664(0xe5)]))['to'][_0x236664(0xde)](_0x236664(0x12a)),expect(print(_0x3f1c0e[_0x236664(0xed)]()[_0x236664(0xd5)][_0x236664(0xe5)]))['to'][_0x236664(0xde)](_0x236664(0xe9)),expect(print(_0x2e7498['getValue']('TEST_VALUE')[_0x236664(0xe5)]))['to'][_0x236664(0xde)](_0x236664(0xf4)),expect(print(_0x5d4b58[_0x236664(0xed)]()['interfaceField'][_0x236664(0xe5)]))['to'][_0x236664(0xde)](_0x236664(0x10e)),expect(print(_0x34f003[_0x236664(0xed)]()[_0x236664(0xd9)]['astNode']))['to']['equal']('interfaceField:\x20String'),expect(print(_0x490e6a['args'][0x0][_0x236664(0xe5)]))['to'][_0x236664(0xde)]('arg:\x20Int');}),it(_0x459237(0xe6),()=>{const _0x499d4b=_0x459237,_0x2cea29=parse('\x0a\x20\x20\x20\x20\x20\x20type\x20TypeWithDeprecatedField\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newDeprecatedField:\x20String\x20@deprecated(reason:\x20\x22not\x20used\x20anymore\x22)\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20enum\x20EnumWithDeprecatedValue\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20DEPRECATED\x20@deprecated(reason:\x20\x22do\x20not\x20use\x22)\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20'),_0x36911b=extendSchema(testSchema,_0x2cea29),_0x50de63=_0x36911b['getType'](_0x499d4b(0xf2))[_0x499d4b(0xed)]()[_0x499d4b(0xe1)];expect(_0x50de63[_0x499d4b(0x132)])['to'][_0x499d4b(0xde)](!![]),expect(_0x50de63[_0x499d4b(0x137)])['to'][_0x499d4b(0xde)](_0x499d4b(0x11f));const _0x43ff40=_0x36911b[_0x499d4b(0xfa)](_0x499d4b(0x119))[_0x499d4b(0x122)](_0x499d4b(0xc6));expect(_0x43ff40[_0x499d4b(0x132)])['to'][_0x499d4b(0xde)](!![]),expect(_0x43ff40[_0x499d4b(0x137)])['to']['equal'](_0x499d4b(0xfc));}),it(_0x459237(0x123),()=>{const _0x68337d=_0x459237,_0x464ad6=parse(_0x68337d(0x126)),_0x246262=extendSchema(testSchema,_0x464ad6),_0x26848b=_0x246262[_0x68337d(0xfa)]('Foo')['getFields']()[_0x68337d(0xe3)];expect(_0x26848b[_0x68337d(0x132)])['to'][_0x68337d(0xde)](!![]),expect(_0x26848b[_0x68337d(0x137)])['to'][_0x68337d(0xde)](_0x68337d(0x11f));}),it(_0x459237(0x13e),()=>{const _0x123cf0=_0x459237,_0x4f2894=parse(_0x123cf0(0xc0)),_0x29d206=printSchema(testSchema),_0x17ebe9=extendSchema(testSchema,_0x4f2894);expect(_0x17ebe9)['to'][_0x123cf0(0xbd)]['equal'](testSchema),expect(printSchema(testSchema))['to'][_0x123cf0(0xde)](_0x29d206),expect(printSchema(_0x17ebe9))['to']['equal'](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz {
        fizz: String
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz

      type Unused {
        someField: String
      }
    `);}),it(_0x459237(0x133),()=>{const _0x55e068=_0x459237,_0x13e368=parse('\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Foo\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newField(arg1:\x20String,\x20arg2:\x20NewInputObj!):\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20input\x20NewInputObj\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20field1:\x20Int\x0a\x20\x20\x20\x20\x20\x20\x20\x20field2:\x20[Float]\x0a\x20\x20\x20\x20\x20\x20\x20\x20field3:\x20String!\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20'),_0x126781=printSchema(testSchema),_0x150eda=extendSchema(testSchema,_0x13e368);expect(_0x150eda)['to'][_0x55e068(0xbd)][_0x55e068(0xde)](testSchema),expect(printSchema(testSchema))['to'][_0x55e068(0xde)](_0x126781),expect(printSchema(_0x150eda))['to']['equal'](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz {
        fizz: String
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
        newField(arg1: String, arg2: NewInputObj!): String
      }

      input NewInputObj {
        field1: Int
        field2: [Float]
        field3: String!
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it(_0x459237(0x111),()=>{const _0x5ccf4e=_0x459237,_0x2ff0d6=parse(_0x5ccf4e(0x10a)),_0x50db32=printSchema(testSchema),_0x27cac3=extendSchema(testSchema,_0x2ff0d6);expect(_0x27cac3)['to'][_0x5ccf4e(0xbd)]['equal'](testSchema),expect(printSchema(testSchema))['to'][_0x5ccf4e(0xde)](_0x50db32),expect(printSchema(_0x27cac3))['to'][_0x5ccf4e(0xde)](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz {
        fizz: String
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
        newField(arg1: SomeEnum!): SomeEnum
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it(_0x459237(0xc5),()=>{const _0x450d15=_0x459237,_0x55c2ad=parse(_0x450d15(0x117)),_0x3cef37=printSchema(testSchema),_0x460839=extendSchema(testSchema,_0x55c2ad);expect(_0x460839)['to']['not'][_0x450d15(0xde)](testSchema),expect(printSchema(testSchema))['to'][_0x450d15(0xde)](_0x3cef37),expect(printSchema(_0x460839))['to'][_0x450d15(0xde)](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz implements SomeInterface {
        fizz: String
        name: String
        some: SomeInterface
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it(_0x459237(0xc7),()=>{const _0x424cc1=_0x459237,_0x1bab13=parse(_0x424cc1(0x13c)),_0xf2e5b3=printSchema(testSchema),_0x4a8de4=extendSchema(testSchema,_0x1bab13);expect(_0x4a8de4)['to'][_0x424cc1(0xbd)]['equal'](testSchema),expect(printSchema(testSchema))['to']['equal'](_0xf2e5b3),expect(printSchema(_0x4a8de4))['to']['equal'](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz {
        fizz: String
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
        newObject: NewObject
        newInterface: NewInterface
        newUnion: NewUnion
        newScalar: NewScalar
        newEnum: NewEnum
        newTree: [Foo]!
      }

      enum NewEnum {
        OPTION_A
        OPTION_B
      }

      interface NewInterface {
        baz: String
      }

      type NewObject implements NewInterface {
        baz: String
      }

      type NewOtherObject {
        fizz: Int
      }

      scalar NewScalar

      union NewUnion = NewObject | NewOtherObject

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it(_0x459237(0xbe),()=>{const _0x35e377=_0x459237,_0x3034c3=parse(_0x35e377(0xce)),_0x26fd00=printSchema(testSchema),_0x4283c0=extendSchema(testSchema,_0x3034c3);expect(_0x4283c0)['to'][_0x35e377(0xbd)]['equal'](testSchema),expect(printSchema(testSchema))['to'][_0x35e377(0xde)](_0x26fd00),expect(printSchema(_0x4283c0))['to']['equal'](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz {
        fizz: String
      }

      type Foo implements SomeInterface & NewInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
        baz: String
      }

      interface NewInterface {
        baz: String
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it(_0x459237(0xfe),()=>{const _0x56132c=_0x459237,_0x4dc648=parse(_0x56132c(0x10b)),_0x192628=printSchema(testSchema),_0x1ca26e=extendSchema(testSchema,_0x4dc648);expect(_0x1ca26e)['to'][_0x56132c(0xbd)][_0x56132c(0xde)](testSchema),expect(printSchema(testSchema))['to'][_0x56132c(0xde)](_0x192628),expect(printSchema(_0x1ca26e))['to'][_0x56132c(0xde)](a0_0x2f72cd`
      type Bar implements SomeInterface {
        name: String
        some: SomeInterface
        foo: Foo
      }

      type Biz implements NewInterface & SomeInterface {
        fizz: String
        buzz: String
        name: String
        some: SomeInterface
        newFieldA: Int
        newFieldB: Float
      }

      type Foo implements SomeInterface {
        name: String
        some: SomeInterface
        tree: [Foo]!
      }

      interface NewInterface {
        buzz: String
      }

      type Query {
        foo: Foo
        someUnion: SomeUnion
        someEnum: SomeEnum
        someInterface(id: ID!): SomeInterface
      }

      enum SomeEnum {
        ONE
        TWO
      }

      interface SomeInterface {
        name: String
        some: SomeInterface
      }

      union SomeUnion = Foo | Biz
    `);}),it(_0x459237(0x120),()=>{const _0x3a80cc=_0x459237,_0x3fdad7=new GraphQLSchema({'query':new GraphQLObjectType({'name':_0x3a80cc(0x113),'fields':()=>({'queryField':{'type':GraphQLString}})}),'mutation':new GraphQLObjectType({'name':_0x3a80cc(0x134),'fields':()=>({'mutationField':{'type':GraphQLString}})}),'subscription':new GraphQLObjectType({'name':_0x3a80cc(0xff),'fields':()=>({'subscriptionField':{'type':GraphQLString}})})}),_0x26d7a0=parse('\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Query\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newQueryField:\x20Int\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Mutation\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newMutationField:\x20Int\x0a\x20\x20\x20\x20\x20\x20}\x0a\x0a\x20\x20\x20\x20\x20\x20extend\x20type\x20Subscription\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20newSubscriptionField:\x20Int\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20'),_0x3b33c8=printSchema(_0x3fdad7),_0x1418c0=extendSchema(_0x3fdad7,_0x26d7a0);expect(_0x1418c0)['to'][_0x3a80cc(0xbd)][_0x3a80cc(0xde)](_0x3fdad7),expect(printSchema(_0x3fdad7))['to'][_0x3a80cc(0xde)](_0x3b33c8),expect(printSchema(_0x1418c0))['to'][_0x3a80cc(0xde)](a0_0x2f72cd`
      type Mutation {
        mutationField: String
        newMutationField: Int
      }

      type Query {
        queryField: String
        newQueryField: Int
      }

      type Subscription {
        subscriptionField: String
        newSubscriptionField: Int
      }
    `);}),it(_0x459237(0x12d),()=>{const _0x445e1c=_0x459237,_0x3df206=parse(_0x445e1c(0xcd)),_0x2feea2=extendSchema(testSchema,_0x3df206),_0x3805b0=_0x2feea2[_0x445e1c(0xca)](_0x445e1c(0x114));expect(_0x3805b0[_0x445e1c(0x103)])['to'][_0x445e1c(0xde)](_0x445e1c(0x114)),expect(_0x3805b0['locations'])['to'][_0x445e1c(0x12c)](_0x445e1c(0x11a));}),it(_0x459237(0xdc),()=>{const _0x51fe5f=_0x459237,_0x282635=parse('\x0a\x20\x20\x20\x20\x20\x20\x22\x22\x22\x0a\x20\x20\x20\x20\x20\x20new\x20directive\x0a\x20\x20\x20\x20\x20\x20\x22\x22\x22\x0a\x20\x20\x20\x20\x20\x20directive\x20@new\x20on\x20QUERY\x0a\x20\x20\x20\x20'),_0x516aa6=extendSchema(testSchema,_0x282635),_0x5d6015=_0x516aa6[_0x51fe5f(0xca)](_0x51fe5f(0x104));expect(_0x5d6015[_0x51fe5f(0xd6)])['to'][_0x51fe5f(0xde)](_0x51fe5f(0x110));}),it(_0x459237(0x12e),()=>{const _0x1e8d4d=_0x459237,_0x31a749=parse('\x0a\x20\x20\x20\x20\x20\x20#\x20new\x20directive\x0a\x20\x20\x20\x20\x20\x20directive\x20@new\x20on\x20QUERY\x0a\x20\x20\x20\x20'),_0xcab372=extendSchema(testSchema,_0x31a749,{'commentDescriptions':!![]}),_0x342cfe=_0xcab372[_0x1e8d4d(0xca)](_0x1e8d4d(0x104));expect(_0x342cfe[_0x1e8d4d(0xd6)])['to'][_0x1e8d4d(0xde)](_0x1e8d4d(0x110));}),it(_0x459237(0x138),()=>{const _0xdc2b45=_0x459237,_0x5baec1=parse(_0xdc2b45(0x102)),_0x32f7b5=extendSchema(testSchema,_0x5baec1),_0x2538e2=_0x32f7b5['getDirective'](_0xdc2b45(0xc2));expect(_0x2538e2[_0xdc2b45(0xdd)])['to']['contain']('QUERY'),expect(_0x2538e2['locations'])['to']['contain']('FIELD');const _0x50cac1=_0x2538e2[_0xdc2b45(0x13b)],_0x1e34c3=_0x50cac1[0x0],_0xa3da6d=_0x50cac1[0x1];expect(_0x50cac1[_0xdc2b45(0xc9)])['to'][_0xdc2b45(0xde)](0x2),expect(_0x1e34c3[_0xdc2b45(0x103)])['to'][_0xdc2b45(0xde)](_0xdc2b45(0xf1)),expect(isNonNullType(_0x1e34c3['type']))['to'][_0xdc2b45(0xde)](!![]),expect(isScalarType(_0x1e34c3[_0xdc2b45(0xc1)]['ofType']))['to'][_0xdc2b45(0xde)](!![]),expect(_0xa3da6d[_0xdc2b45(0x103)])['to'][_0xdc2b45(0xde)](_0xdc2b45(0x127)),expect(isScalarType(_0xa3da6d['type']))['to'][_0xdc2b45(0xde)](!![]);}),it(_0x459237(0x124),()=>{const _0x349f6a=_0x459237,_0x3e5f12=parse(_0x349f6a(0xda));expect(()=>extendSchema(testSchema,_0x3e5f12))['to'][_0x349f6a(0xf8)]('Directive\x20\x22include\x22\x20already\x20exists\x20in\x20the\x20schema.\x20It\x20cannot\x20be\x20'+_0x349f6a(0xf6));}),it(_0x459237(0xc8),()=>{const _0x2399b4=_0x459237,_0x860aea=parse(_0x2399b4(0xec)),_0x2aab0c=extendSchema(testSchema,_0x860aea),_0x438174=parse('\x0a\x20\x20\x20\x20\x20\x20directive\x20@meow(if:\x20Boolean!)\x20on\x20FIELD\x20|\x20QUERY\x0a\x20\x20\x20\x20');expect(()=>extendSchema(_0x2aab0c,_0x438174))['to'][_0x2399b4(0xf8)]('Directive\x20\x22meow\x22\x20already\x20exists\x20in\x20the\x20schema.\x20It\x20cannot\x20be\x20'+'redefined.');}),it('does\x20not\x20allow\x20replacing\x20an\x20existing\x20type',()=>{const _0x9a8f97=_0x459237,_0x57bbc9=parse('\x0a\x20\x20\x20\x20\x20\x20type\x20Bar\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20');expect(()=>extendSchema(testSchema,_0x57bbc9))['to'][_0x9a8f97(0xf8)](_0x9a8f97(0xf5)+_0x9a8f97(0x125));}),it(_0x459237(0xd4),()=>{const _0x2147d8=_0x459237,_0x4f252f=parse(_0x2147d8(0x11c));expect(()=>extendSchema(testSchema,_0x4f252f))['to'][_0x2147d8(0xf8)](_0x2147d8(0x109)+_0x2147d8(0x135));}),it(_0x459237(0x101),()=>{const _0x43fbd6=_0x459237,_0x5e3695=parse(_0x43fbd6(0xf7));expect(()=>extendSchema(testSchema,_0x5e3695))['to'][_0x43fbd6(0xf8)](_0x43fbd6(0x10f)+_0x43fbd6(0xd0));}),it(_0x459237(0xbf),()=>{const _0x11272b=_0x459237,_0x534672=parse(_0x11272b(0x121));expect(()=>extendSchema(testSchema,_0x534672))['to'][_0x11272b(0xf8)](_0x11272b(0xe4)+_0x11272b(0xeb));}),describe(_0x459237(0x118),()=>{const _0x2767e4=_0x459237;it(_0x2767e4(0x131),()=>{const _0x3d77d8=_0x2767e4,_0x14c929=parse('\x0a\x20\x20\x20\x20\x20\x20\x20\x20extend\x20type\x20SomeInterface\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20');expect(()=>extendSchema(testSchema,_0x14c929))['to'][_0x3d77d8(0xf8)](_0x3d77d8(0x130));}),it(_0x2767e4(0x108),()=>{const _0x180b5b=parse('\x0a\x20\x20\x20\x20\x20\x20\x20\x20extend\x20type\x20String\x20{\x0a\x20\x20\x20\x20\x20\x20\x20\x20\x20\x20baz:\x20String\x0a\x20\x20\x20\x20\x20\x20\x20\x20}\x0a\x20\x20\x20\x20\x20\x20');expect(()=>extendSchema(testSchema,_0x180b5b))['to']['throw']('Cannot\x20extend\x20non-object\x20type\x20\x22String\x22.');});});});