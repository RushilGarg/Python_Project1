/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x6a5db7=a0_0x3c4e;(function(_0x461388,_0x81c474){var _0x2a7a69=a0_0x3c4e,_0x49f816=_0x461388();while(!![]){try{var _0xcfe7d9=-parseInt(_0x2a7a69(0x76))/0x1+-parseInt(_0x2a7a69(0x7a))/0x2+parseInt(_0x2a7a69(0x7c))/0x3*(parseInt(_0x2a7a69(0x7e))/0x4)+-parseInt(_0x2a7a69(0x7d))/0x5*(parseInt(_0x2a7a69(0x78))/0x6)+parseInt(_0x2a7a69(0x79))/0x7*(parseInt(_0x2a7a69(0x73))/0x8)+-parseInt(_0x2a7a69(0x74))/0x9+parseInt(_0x2a7a69(0x7b))/0xa;if(_0xcfe7d9===_0x81c474)break;else _0x49f816['push'](_0x49f816['shift']());}catch(_0x24be7d){_0x49f816['push'](_0x49f816['shift']());}}}(a0_0x3ba9,0x48542));function a0_0x3ba9(){var _0x206b2f=['1958612ROOyMB','40nayeSC','3159252WrSSoj','./main.js','136848KKmhZx','exports','72978ccPsMy','516747cMkZjf','977178MeHKuM','8761590alscSP','3yxrSsO','190ZWwEaO'];a0_0x3ba9=function(){return _0x206b2f;};return a0_0x3ba9();}var iterator=require(a0_0x6a5db7(0x75));function a0_0x3c4e(_0x4de475,_0x57f5fa){var _0x3ba92e=a0_0x3ba9();return a0_0x3c4e=function(_0x3c4e4d,_0x464c28){_0x3c4e4d=_0x3c4e4d-0x73;var _0x1a54ca=_0x3ba92e[_0x3c4e4d];return _0x1a54ca;},a0_0x3c4e(_0x4de475,_0x57f5fa);}module[a0_0x6a5db7(0x77)]=iterator;