/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xea4015=a0_0x284b;(function(_0x30e5f0,_0x1e5576){var _0x3761ee=a0_0x284b,_0x313f7d=_0x30e5f0();while(!![]){try{var _0x14a65d=parseInt(_0x3761ee(0x1d8))/0x1*(-parseInt(_0x3761ee(0x1ec))/0x2)+parseInt(_0x3761ee(0x1da))/0x3*(parseInt(_0x3761ee(0x1ee))/0x4)+parseInt(_0x3761ee(0x1e5))/0x5+-parseInt(_0x3761ee(0x1d6))/0x6*(-parseInt(_0x3761ee(0x1e8))/0x7)+-parseInt(_0x3761ee(0x1ef))/0x8*(parseInt(_0x3761ee(0x1d7))/0x9)+-parseInt(_0x3761ee(0x1dd))/0xa+parseInt(_0x3761ee(0x1e4))/0xb;if(_0x14a65d===_0x1e5576)break;else _0x313f7d['push'](_0x313f7d['shift']());}catch(_0x2c4f41){_0x313f7d['push'](_0x313f7d['shift']());}}}(a0_0x49e9,0x6ecd7));var logger=require(a0_0xea4015(0x1d9)),h=require(a0_0xea4015(0x1f1)),dy=require(a0_0xea4015(0x1e3)),xAttr=require(a0_0xea4015(0x1e6)),yAttr=require(a0_0xea4015(0x1e2)),debug=logger(a0_0xea4015(0x1e0)),ELEMENT='text';function render(_0x45b2de,_0x5e9c04){var _0x3f0e01=a0_0xea4015,_0x47775f,_0x3c4310,_0x193742,_0x4f9652,_0x413f5a;return _0x47775f=_0x45b2de[_0x3f0e01(0x1e7)],debug(_0x3f0e01(0x1e1),_0x47775f),_0x3c4310={'namespace':_0x3f0e01(0x1e9),'attributes':{'fill':_0x3f0e01(0x1ed),'dy':dy(_0x47775f)}},_0x4f9652=xAttr(_0x47775f),_0x413f5a=yAttr(_0x47775f),_0x3c4310[_0x3f0e01(0x1dc)][_0x4f9652]=_0x45b2de[_0x3f0e01(0x1ea)]*_0x45b2de[_0x3f0e01(0x1eb)],_0x3c4310['attributes'][_0x413f5a]=0.5,_0x193742=_0x45b2de[_0x3f0e01(0x1df)](_0x5e9c04),debug(_0x3f0e01(0x1db),_0x193742),debug(_0x3f0e01(0x1de),ELEMENT,JSON[_0x3f0e01(0x1f0)](_0x3c4310)),h(ELEMENT,_0x3c4310,_0x193742);}module['exports']=render;function a0_0x284b(_0x1c7599,_0x54e3ad){var _0x49e964=a0_0x49e9();return a0_0x284b=function(_0x284b1f,_0x10723f){_0x284b1f=_0x284b1f-0x1d6;var _0x4a479a=_0x49e964[_0x284b1f];return _0x4a479a;},a0_0x284b(_0x1c7599,_0x54e3ad);}function a0_0x49e9(){var _0x75529e=['tickDir','tickSpacing','227706mfZMXn','#000','580lekZcY','4264yBzfwA','stringify','virtual-dom/h','36762QNFtxX','15192rkIndo','5uewcut','debug','9519unfeWR','Tick\x20text:\x20%s.','attributes','3928790iQXlRo','Generating\x20a\x20virtual\x20DOM\x20tree\x20(%s)\x20with\x20properties:\x20%s.','tickFormat','axis:components:text','Axis\x20orientation:\x20%s.','./../utils/y_attr.js','./../utils/text_dy.js','11841203hzZSqN','740280CQnFmJ','./../utils/x_attr.js','_orientation','721GkrcTJ','http://www.w3.org/2000/svg'];a0_0x49e9=function(){return _0x75529e;};return a0_0x49e9();}