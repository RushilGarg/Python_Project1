/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x28a555=a0_0x597b;(function(_0x97a993,_0x463efe){var _0x2ab861=a0_0x597b,_0x3a7eee=_0x97a993();while(!![]){try{var _0x352d0f=-parseInt(_0x2ab861(0xa0))/0x1*(parseInt(_0x2ab861(0x9e))/0x2)+-parseInt(_0x2ab861(0xa2))/0x3*(-parseInt(_0x2ab861(0x9c))/0x4)+-parseInt(_0x2ab861(0xa1))/0x5+-parseInt(_0x2ab861(0xa3))/0x6+-parseInt(_0x2ab861(0xa6))/0x7+parseInt(_0x2ab861(0xa5))/0x8*(-parseInt(_0x2ab861(0x9d))/0x9)+parseInt(_0x2ab861(0x9f))/0xa;if(_0x352d0f===_0x463efe)break;else _0x3a7eee['push'](_0x3a7eee['shift']());}catch(_0x48368a){_0x3a7eee['push'](_0x3a7eee['shift']());}}}(a0_0x481e,0x37151));function create(_0x284506){return new Array(_0x284506);}function a0_0x597b(_0x344637,_0x5d5d02){var _0x481ef2=a0_0x481e();return a0_0x597b=function(_0x597b06,_0x40d0fb){_0x597b06=_0x597b06-0x9c;var _0x3e9292=_0x481ef2[_0x597b06];return _0x3e9292;},a0_0x597b(_0x344637,_0x5d5d02);}function a0_0x481e(){var _0x542779=['288nljYEw','1018qDYRaC','12080690igVdps','346AQhrRJ','1326460gzOGCa','57021ALJwsi','774306JcLzjt','exports','77400IXhOTi','1382010AwZUfs','20gbRnmg'];a0_0x481e=function(){return _0x542779;};return a0_0x481e();}module[a0_0x28a555(0xa4)]=create;