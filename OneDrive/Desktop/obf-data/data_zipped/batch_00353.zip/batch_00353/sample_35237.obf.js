function a0_0x3f53(_0x495f44,_0x406569){var _0x53bb77=a0_0x53bb();return a0_0x3f53=function(_0x3f53f8,_0x1032e2){_0x3f53f8=_0x3f53f8-0xd9;var _0x144109=_0x53bb77[_0x3f53f8];return _0x144109;},a0_0x3f53(_0x495f44,_0x406569);}var a0_0x2249f3=a0_0x3f53;function a0_0x53bb(){var _0x39f3a7=['template','8129SClWkl','2895mLJoTy','3611694uLyJXX','define','bnb-divider','836iUCeNr','11768121TwluKl','11GmtJYD','5bTLHXS','164jtdWyT','7424030ihkHPW','5055400frpmww','customElements','4835496zmDhqk'];a0_0x53bb=function(){return _0x39f3a7;};return a0_0x53bb();}(function(_0x1242a7,_0x377771){var _0x3438bf=a0_0x3f53,_0x21b490=_0x1242a7();while(!![]){try{var _0x46325b=parseInt(_0x3438bf(0xdc))/0x1*(-parseInt(_0x3438bf(0xe5))/0x2)+-parseInt(_0x3438bf(0xdd))/0x3*(-parseInt(_0x3438bf(0xe1))/0x4)+parseInt(_0x3438bf(0xe4))/0x5*(-parseInt(_0x3438bf(0xde))/0x6)+-parseInt(_0x3438bf(0xe7))/0x7+parseInt(_0x3438bf(0xda))/0x8+parseInt(_0x3438bf(0xe2))/0x9+parseInt(_0x3438bf(0xe6))/0xa*(parseInt(_0x3438bf(0xe3))/0xb);if(_0x46325b===_0x377771)break;else _0x21b490['push'](_0x21b490['shift']());}catch(_0x5f186d){_0x21b490['push'](_0x21b490['shift']());}}}(a0_0x53bb,0xd3457));import{PolymerElement,html}from'@polymer/polymer/polymer-element';class BnbDivider extends PolymerElement{static get[a0_0x2249f3(0xdb)](){return html`
    <style>
      :host {
        display: inline-block;
        height: 1px;
        min-height: 1px;
        max-height: 1px;
        background-color: var(--paper-divider-color, #000);
        opacity: 0.12;
        width: 100%;
        @apply --paper-divider;
      }
    </style>
    `;}}window[a0_0x2249f3(0xd9)][a0_0x2249f3(0xdf)](a0_0x2249f3(0xe0),BnbDivider);