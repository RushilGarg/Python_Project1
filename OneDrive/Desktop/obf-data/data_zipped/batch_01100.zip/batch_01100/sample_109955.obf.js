(function(_0x2f93e5,_0x17debe){const _0x129807=a0_0x52b7,_0x1e0be1=_0x2f93e5();while(!![]){try{const _0x2ad4cd=-parseInt(_0x129807(0x1e7))/0x1*(-parseInt(_0x129807(0x1e1))/0x2)+parseInt(_0x129807(0x1e3))/0x3*(parseInt(_0x129807(0x1de))/0x4)+parseInt(_0x129807(0x1e8))/0x5+parseInt(_0x129807(0x1e0))/0x6+-parseInt(_0x129807(0x1e5))/0x7*(-parseInt(_0x129807(0x1e2))/0x8)+-parseInt(_0x129807(0x1e4))/0x9*(-parseInt(_0x129807(0x1e6))/0xa)+-parseInt(_0x129807(0x1df))/0xb;if(_0x2ad4cd===_0x17debe)break;else _0x1e0be1['push'](_0x1e0be1['shift']());}catch(_0x507785){_0x1e0be1['push'](_0x1e0be1['shift']());}}}(a0_0x1c0f,0xdc6df));import a0_0xdc67dc from'../../components/EmployeePage';import{graphql}from'gatsby';function a0_0x52b7(_0x2945a3,_0xd5303b){const _0x1c0fe3=a0_0x1c0f();return a0_0x52b7=function(_0x52b7b1,_0x3d7ce6){_0x52b7b1=_0x52b7b1-0x1de;let _0x374abf=_0x1c0fe3[_0x52b7b1];return _0x374abf;},a0_0x52b7(_0x2945a3,_0xd5303b);}export const query=graphql`
    query {
        EmployeeImages: allFile(
            sort: { order: ASC, fields: [absolutePath] }
            filter: { relativePath: { regex: "/mugshots/larsfredrik.jpg/" } }
        ) {
            edges {
                node {
                    relativePath
                    name
                    childImageSharp {
                        fluid(maxWidth: 1000) {
                            ...GatsbyImageSharpFluid
                        }
                    }
                }
            }
        }
    }
`;export default a0_0xdc67dc;function a0_0x1c0f(){const _0x216181=['7982504geOemG','1594833dcKjKg','440289nMuPca','7krOzCD','30noXGJV','1LnoJCX','4624290OLYBFM','12zRwSri','36127256XoGQUW','960426nwoVTb','725674aAKXQY'];a0_0x1c0f=function(){return _0x216181;};return a0_0x1c0f();}