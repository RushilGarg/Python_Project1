'use strict';const a0_0x3a25ee=a0_0x184b;(function(_0x3fe794,_0x33b9e7){const _0x29cf7c=a0_0x184b,_0x2cda7c=_0x3fe794();while(!![]){try{const _0x31128d=parseInt(_0x29cf7c(0xa9))/0x1*(parseInt(_0x29cf7c(0xbb))/0x2)+-parseInt(_0x29cf7c(0xb6))/0x3+parseInt(_0x29cf7c(0xb3))/0x4*(-parseInt(_0x29cf7c(0xbe))/0x5)+parseInt(_0x29cf7c(0xd5))/0x6*(-parseInt(_0x29cf7c(0xd7))/0x7)+parseInt(_0x29cf7c(0xbf))/0x8+-parseInt(_0x29cf7c(0xbd))/0x9+parseInt(_0x29cf7c(0xdc))/0xa;if(_0x31128d===_0x33b9e7)break;else _0x2cda7c['push'](_0x2cda7c['shift']());}catch(_0x4487c4){_0x2cda7c['push'](_0x2cda7c['shift']());}}}(a0_0x1bd3,0xa02b8));function a0_0x184b(_0x4e78b8,_0x35edec){const _0x1bd3c9=a0_0x1bd3();return a0_0x184b=function(_0x184bb0,_0x32110c){_0x184bb0=_0x184bb0-0xa7;let _0x4dad61=_0x1bd3c9[_0x184bb0];return _0x4dad61;},a0_0x184b(_0x4e78b8,_0x35edec);}require('configureForRelayOSS'),jest['unmock'](a0_0x3a25ee(0xdb))[a0_0x3a25ee(0xb7)]('GraphQLSegment');const Relay=require('Relay'),RelayConnectionInterface=require(a0_0x3a25ee(0xb5)),RelayEnvironment=require(a0_0x3a25ee(0xac)),RelayQueryPath=require(a0_0x3a25ee(0xcd)),RelayTestUtils=require(a0_0x3a25ee(0xaf)),readRelayQueryData=require(a0_0x3a25ee(0xcb)),writeRelayGraphModeResponse=require('writeRelayGraphModeResponse'),{HAS_NEXT_PAGE,PAGE_INFO}=RelayConnectionInterface;describe(a0_0x3a25ee(0xdf),()=>{const _0xe00018=a0_0x3a25ee,{getNode:_0x226bf8}=RelayTestUtils;let _0x176795,_0x500b15,_0x1dafb3,_0x465b87;beforeEach(()=>{const _0x360593=a0_0x184b;jest['resetModuleRegistry'](),_0x176795=new RelayEnvironment(),_0x1dafb3=_0x176795['getStoreData'](),_0x500b15=_0x1dafb3[_0x360593(0xca)]();const _0x3a06fc=_0x1dafb3[_0x360593(0xa7)]();_0x465b87=_0x4fbcad=>{const _0x1774ab=_0x360593,_0x1f49bd=writeRelayGraphModeResponse(_0x500b15,_0x3a06fc,_0x4fbcad);return _0x1f49bd[_0x1774ab(0xaa)]();};}),describe(_0xe00018(0xc1),()=>{const _0x4e2157=_0xe00018;it('writes\x20argument-less\x20root\x20fields\x20without\x20an\x20id',()=>{const _0x241cd4=a0_0x184b,_0xe463e6=[{'op':'putRoot','args':null,'field':_0x241cd4(0xd6),'root':{'actor':{'__ref':_0x241cd4(0xc3)}}},{'op':'putNodes','nodes':{0x7b:{'id':_0x241cd4(0xc3)}}}],_0x45b74c=_0x465b87(_0xe463e6);expect(_0x45b74c)['toEqual']({'created':{'client:1':!![],'123':!![]},'updated':{}}),expect(_0x500b15[_0x241cd4(0xc4)](_0x241cd4(0xd6),null))[_0x241cd4(0xd9)](_0x241cd4(0xb4));const _0x1ec1ab=_0x176795[_0x241cd4(0xcc)](_0x226bf8(Relay['QL']`
        query {
          viewer {
            actor {
              id
            }
          }
        }
      `));expect(_0x1ec1ab[0x0])[_0x241cd4(0xd4)]({'__dataID__':_0x241cd4(0xb4),'actor':{'__dataID__':'123','id':_0x241cd4(0xc3)}});}),it('writes\x20paths\x20to\x20id-less\x20root\x20fields',()=>{const _0x3fbb84=a0_0x184b,_0x44f206=_0x226bf8(Relay['QL']`query{viewer{actor{id}}}`),_0x4a6f1f=RelayQueryPath['create'](_0x44f206),_0x280ddc=[{'op':_0x3fbb84(0xb0),'args':null,'field':_0x3fbb84(0xd6),'root':{'__path__':_0x4a6f1f}}];_0x465b87(_0x280ddc),expect(_0x500b15[_0x3fbb84(0xc4)](_0x3fbb84(0xd6),null))[_0x3fbb84(0xd9)]('client:1'),expect(_0x500b15[_0x3fbb84(0xa8)]('client:1'))['toBe'](_0x4a6f1f);}),it(_0x4e2157(0xc9),()=>{const _0x3867cf=_0x4e2157,_0x194779=[{'op':_0x3867cf(0xb0),'args':null,'field':'me','root':{'__ref':'123'}},{'op':_0x3867cf(0xb2),'nodes':{0x7b:{'id':_0x3867cf(0xc3)}}}],_0x412381=_0x465b87(_0x194779);expect(_0x412381)[_0x3867cf(0xd4)]({'created':{'123':!![]},'updated':{}}),expect(_0x500b15[_0x3867cf(0xc4)]('me',null))[_0x3867cf(0xd9)](_0x3867cf(0xc3));const _0x4cd084=_0x176795['readQuery'](_0x226bf8(Relay['QL']`
        query {
          me {
            id
          }
        }
      `));expect(_0x4cd084[0x0])['toEqual']({'__dataID__':'123','id':'123'});}),it('writes\x20root\x20fields\x20with\x20arguments',()=>{const _0x4f37c2=_0x4e2157,_0xf4b696=[{'op':'putRoot','identifier':0x7b,'field':_0x4f37c2(0xc5),'root':{'title':_0x4f37c2(0xab)}}],_0x38cce7=_0x465b87(_0xf4b696);expect(_0x38cce7)[_0x4f37c2(0xd4)]({'created':{'client:1':!![]},'updated':{}}),expect(_0x500b15[_0x4f37c2(0xc4)]('task','123'))[_0x4f37c2(0xd9)](_0x4f37c2(0xb4));const _0x4faaa9=_0x176795[_0x4f37c2(0xcc)](_0x226bf8(Relay['QL']`
        query {
          task(number: 123) {
            title
          }
        }
      `));expect(_0x4faaa9[0x0])[_0x4f37c2(0xd4)]({'__dataID__':_0x4f37c2(0xb4),'title':_0x4f37c2(0xab)});});}),describe('nodes',()=>{const _0x3896af=_0xe00018;it('writes\x20nodes\x20with\x20scalar\x20fields',()=>{const _0x1eba7c=a0_0x184b,_0x430ab1=[{'op':_0x1eba7c(0xb2),'nodes':{0x7b:{'id':_0x1eba7c(0xc3),'name':'Alice'}}}],_0x5020af=_0x465b87(_0x430ab1);expect(_0x5020af)[_0x1eba7c(0xd4)]({'created':{0x7b:!![]},'updated':{}});const {data:_0x4470c7}=readRelayQueryData(_0x1dafb3,_0x226bf8(Relay['QL']`
          fragment on User {
            id
            name
          }
        `),'123');expect(_0x4470c7)[_0x1eba7c(0xd4)]({'__dataID__':_0x1eba7c(0xc3),'id':_0x1eba7c(0xc3),'name':_0x1eba7c(0xde)});}),it(_0x3896af(0xda),()=>{const _0x2afe57=_0x3896af,_0x2ac4cb=[{'op':_0x2afe57(0xb2),'nodes':{0x7b:{'id':'123','hometown':{'__ref':'456'},'name':'Alice'},0x1c8:{'id':'456','name':'Menlo\x20Park'}}}],_0x403f03=_0x465b87(_0x2ac4cb);expect(_0x403f03)[_0x2afe57(0xd4)]({'created':{0x7b:!![],0x1c8:!![]},'updated':{}});const {data:_0x299890}=readRelayQueryData(_0x1dafb3,_0x226bf8(Relay['QL']`
          fragment on User {
            id
            hometown {
              id
              name
            }
            name
          }
        `),_0x2afe57(0xc3));expect(_0x299890)[_0x2afe57(0xd4)]({'__dataID__':_0x2afe57(0xc3),'id':_0x2afe57(0xc3),'hometown':{'__dataID__':'456','id':_0x2afe57(0xc0),'name':'Menlo\x20Park'},'name':'Alice'});}),it(_0x3896af(0xc7),()=>{const _0x3a9eac=_0x3896af,_0x2cfca8=[{'op':'putNodes','nodes':{0x7b:{'id':_0x3a9eac(0xc3),'hometown':{'name':_0x3a9eac(0xd0)},'name':_0x3a9eac(0xde)}}}],_0x39bdbe=_0x465b87(_0x2cfca8);expect(_0x39bdbe)[_0x3a9eac(0xd4)]({'created':{0x7b:!![],'client:1':!![]},'updated':{}});const {data:_0x4c053a}=readRelayQueryData(_0x1dafb3,_0x226bf8(Relay['QL']`
          fragment on User {
            id
            hometown {
              name
            }
            name
          }
        `),_0x3a9eac(0xc3));expect(_0x4c053a)[_0x3a9eac(0xd4)]({'__dataID__':_0x3a9eac(0xc3),'id':_0x3a9eac(0xc3),'hometown':{'__dataID__':_0x3a9eac(0xb4),'name':'Menlo\x20Park'},'name':'Alice'});}),it(_0x3896af(0xc2),()=>{const _0xeae1e1=_0x3896af,_0x4ceb7a=_0x226bf8(Relay['QL']`query{me{hometown}}`),_0x1d4b5e=RelayQueryPath[_0xeae1e1(0xd8)](RelayQueryPath[_0xeae1e1(0xcf)](_0x4ceb7a),_0x4ceb7a['getFieldByStorageKey'](_0xeae1e1(0xba)),null),_0x53fef8=[{'op':_0xeae1e1(0xb2),'nodes':{0x7b:{'id':_0xeae1e1(0xc3),'hometown':{'__path__':_0x1d4b5e}}}}];_0x465b87(_0x53fef8),expect(_0x500b15['getLinkedRecordID']('123',_0xeae1e1(0xba)))['toBe'](_0xeae1e1(0xb4)),expect(_0x500b15[_0xeae1e1(0xa8)](_0xeae1e1(0xb4)))[_0xeae1e1(0xd9)](_0x1d4b5e);}),it('writes\x20nodes\x20with\x20plural\x20linked\x20records',()=>{const _0x5caa27=_0x3896af,_0x4b73f6=[{'op':'putNodes','nodes':{0x7b:{'actors':[{'__ref':'456'}],'id':_0x5caa27(0xc3),'name':_0x5caa27(0xde)},0x1c8:{'id':_0x5caa27(0xc0),'name':'Bob'}}}],_0x1f1280=_0x465b87(_0x4b73f6);expect(_0x1f1280)['toEqual']({'created':{0x7b:!![],0x1c8:!![]},'updated':{}});const {data:_0x267f50}=readRelayQueryData(_0x1dafb3,_0x226bf8(Relay['QL']`
          fragment on User {
            actors {
              id
              name
            }
            id
            name
          }
        `),'123');expect(_0x267f50)[_0x5caa27(0xd4)]({'__dataID__':_0x5caa27(0xc3),'actors':[{'__dataID__':_0x5caa27(0xc0),'id':_0x5caa27(0xc0),'name':_0x5caa27(0xb1)}],'id':'123','name':_0x5caa27(0xde)});}),it(_0x3896af(0xae),()=>{const _0x2b0c2b=_0x3896af,_0x356003=[{'op':_0x2b0c2b(0xb2),'nodes':{0x7b:{'actors':[{'name':'Bob'}],'id':'123','name':_0x2b0c2b(0xde)}}}],_0x163e77=_0x465b87(_0x356003);expect(_0x163e77)['toEqual']({'created':{0x7b:!![],'client:1':!![]},'updated':{}});const {data:_0x4a0cb5}=readRelayQueryData(_0x1dafb3,_0x226bf8(Relay['QL']`
          fragment on User {
            actors {
              name
            }
            id
            name
          }
        `),_0x2b0c2b(0xc3));expect(_0x4a0cb5)[_0x2b0c2b(0xd4)]({'__dataID__':_0x2b0c2b(0xc3),'actors':[{'__dataID__':_0x2b0c2b(0xb4),'name':'Bob'}],'id':_0x2b0c2b(0xc3),'name':'Alice'});}),describe(_0x3896af(0xd3),()=>{const _0x2bc5d7=_0x3896af;it(_0x2bc5d7(0xb8),()=>{const _0x4e0ff3=_0x2bc5d7,_0x285338=[{'op':'putNodes','nodes':{0x7b:{'id':_0x4e0ff3(0xc3),'friends':{'__key':_0x4e0ff3(0xce),'count':0x1388}},0x1c8:{'id':_0x4e0ff3(0xc0),'name':_0x4e0ff3(0xb1)},0x315:{'id':_0x4e0ff3(0xc8),'name':'Claire'}}},{'op':_0x4e0ff3(0xd2),'args':[{'name':_0x4e0ff3(0xdd),'value':0x2}],'edges':[{'cursor':_0x4e0ff3(0xd1),'node':{'__ref':_0x4e0ff3(0xc0)}},{'cursor':_0x4e0ff3(0xb9),'node':{'__ref':_0x4e0ff3(0xc8)}}],'pageInfo':{[HAS_NEXT_PAGE]:!![]},'range':{'__key':'__123_friends'}}],_0x2a49f9=_0x465b87(_0x285338);expect(_0x2a49f9)[_0x4e0ff3(0xd4)]({'created':{0x7b:!![],0x1c8:!![],0x315:!![],'client:1':!![],'client:client:1:456':!![],'client:client:1:789':!![]},'updated':{}});const {data:_0x3fd669}=readRelayQueryData(_0x1dafb3,_0x226bf8(Relay['QL']`
            fragment on User {
              friends(first: "2") {
                count
                edges {
                  cursor
                  node {
                    id
                    name
                  }
                }
                pageInfo {
                  hasNextPage
                }
              }
            }
          `),_0x4e0ff3(0xc3));expect(_0x3fd669)[_0x4e0ff3(0xd4)]({'__dataID__':'123','friends':{'__dataID__':_0x4e0ff3(0xc6),'count':0x1388,'edges':[{'__dataID__':_0x4e0ff3(0xbc),'cursor':_0x4e0ff3(0xd1),'node':{'__dataID__':_0x4e0ff3(0xc0),'id':_0x4e0ff3(0xc0),'name':'Bob'}},{'__dataID__':'client:client:1:789','cursor':'edge789','node':{'__dataID__':_0x4e0ff3(0xc8),'id':_0x4e0ff3(0xc8),'name':_0x4e0ff3(0xad)}}],[PAGE_INFO]:{[HAS_NEXT_PAGE]:!![]}}});});});});});function a0_0x1bd3(){const _0x558b40=['client:1','RelayConnectionInterface','864744fzKllx','unmock','writes\x20connection\x20edges','edge789','hometown','14604RLYIvY','client:client:1:456','8752950BxaSiI','1965XcSAWk','6761104vhYUey','456','roots','writes\x20paths\x20to\x20id-less\x20records','123','getDataID','task','client:1_first(2)','writes\x20nodes\x20with\x20linked\x20client\x20records','789','writes\x20argument-less\x20root\x20fields\x20with\x20an\x20id','getQueuedStore','readRelayQueryData','readQuery','RelayQueryPath','__123_friends','create','Menlo\x20Park','edge456','putEdges','edges','toEqual','12eqMYrm','viewer','1512763BighHF','getPath','toBe','writes\x20nodes\x20with\x20linked\x20records','GraphQLRange','20596390rwiaDj','first','Alice','writeRelayGraphModeResponse()','getRecordWriter','getPathToRecord','81tOcYcs','getChangeSet','Implement\x20GraphMode','RelayEnvironment','Claire','writes\x20nodes\x20with\x20plural\x20linked\x20client\x20records','RelayTestUtils','putRoot','Bob','putNodes','11676JHnSPq'];a0_0x1bd3=function(){return _0x558b40;};return a0_0x1bd3();}