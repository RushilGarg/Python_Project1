/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x35754a=a0_0x2765;(function(_0x32f9f4,_0x3dde4c){var _0x5229e9=a0_0x2765,_0x14bf75=_0x32f9f4();while(!![]){try{var _0x1ec011=-parseInt(_0x5229e9(0xb6))/0x1*(-parseInt(_0x5229e9(0xab))/0x2)+parseInt(_0x5229e9(0xad))/0x3*(parseInt(_0x5229e9(0xb0))/0x4)+-parseInt(_0x5229e9(0xb2))/0x5+-parseInt(_0x5229e9(0xaf))/0x6*(-parseInt(_0x5229e9(0xb9))/0x7)+parseInt(_0x5229e9(0xb7))/0x8*(parseInt(_0x5229e9(0xae))/0x9)+parseInt(_0x5229e9(0xb4))/0xa*(parseInt(_0x5229e9(0xb8))/0xb)+-parseInt(_0x5229e9(0xb3))/0xc;if(_0x1ec011===_0x3dde4c)break;else _0x14bf75['push'](_0x14bf75['shift']());}catch(_0x703966){_0x14bf75['push'](_0x14bf75['shift']());}}}(a0_0x112a,0x5c8d1),CLASS({'package':'foam.documentation','name':a0_0x35754a(0xb5),'extends':a0_0x35754a(0xb1),'requires':['foam.documentation.DocFeatureModelDataRefView'],'properties':[{'name':a0_0x35754a(0xac),'hidden':![]}],'templates':[function toInnerHTML(){}]}));function a0_0x2765(_0x50fe97,_0x36fdb8){var _0x112a16=a0_0x112a();return a0_0x2765=function(_0x27651b,_0x2dcda1){_0x27651b=_0x27651b-0xab;var _0x5bd0f6=_0x112a16[_0x27651b];return _0x5bd0f6;},a0_0x2765(_0x50fe97,_0x36fdb8);}function a0_0x112a(){var _0x3d936a=['1172426fhGHdI','data','1353eoTsYe','6667317oCnAQJ','54pevMxu','3292UQgvEP','foam.documentation.DocOptionalView','3172075riOrXg','19264368qBNHCQ','100FaZJSx','SubModelOptionalView','1ukCxbF','8WsXTLX','820567aaizGk','135877EjNtUB'];a0_0x112a=function(){return _0x3d936a;};return a0_0x112a();}