/**
 * Hype Commerce
 *
 * @package     Hype
 * @module      Auth
 * @version     1.0.0
 * @author      Hype Commerce Team <team@hypejs.com>
 * @copyright   Copyright (c) 2014, Hype Commerce, Inc. (http://www.hypejs.com/)
 * @license     http://www.hypejs.com/license
 */
function a0_0x4322(){var _0x13bcba=['/lib/icon.jpg','5568060lGbOmx','5FzVQhV','470ABkUXy','15048774jBkNpv','4232711oUGcCi','exports','Auth','747397PdDnDw','./lib/auth','4350676vXRZdD','48334jukuno','8HlvoqJ','16707MolHqy','1370OdRIkX','Kurtis\x20Kemple'];a0_0x4322=function(){return _0x13bcba;};return a0_0x4322();}var a0_0x102bca=a0_0x4796;function a0_0x4796(_0x15012f,_0x3ac7e1){var _0x43222b=a0_0x4322();return a0_0x4796=function(_0x479653,_0x175951){_0x479653=_0x479653-0x1a8;var _0x11985b=_0x43222b[_0x479653];return _0x11985b;},a0_0x4796(_0x15012f,_0x3ac7e1);}(function(_0x99e5d5,_0xafe399){var _0x33cf9e=a0_0x4796,_0x1146ee=_0x99e5d5();while(!![]){try{var _0xb9c525=-parseInt(_0x33cf9e(0x1b3))/0x1+parseInt(_0x33cf9e(0x1ae))/0x2*(parseInt(_0x33cf9e(0x1a8))/0x3)+parseInt(_0x33cf9e(0x1b5))/0x4*(-parseInt(_0x33cf9e(0x1ad))/0x5)+parseInt(_0x33cf9e(0x1ac))/0x6+-parseInt(_0x33cf9e(0x1b0))/0x7*(parseInt(_0x33cf9e(0x1b7))/0x8)+parseInt(_0x33cf9e(0x1af))/0x9+parseInt(_0x33cf9e(0x1a9))/0xa*(-parseInt(_0x33cf9e(0x1b6))/0xb);if(_0xb9c525===_0xafe399)break;else _0x1146ee['push'](_0x1146ee['shift']());}catch(_0x3af4d1){_0x1146ee['push'](_0x1146ee['shift']());}}}(a0_0x4322,0xd3b16),module[a0_0x102bca(0x1b1)]={'name':a0_0x102bca(0x1b2),'enabled':!![],'version':'1.0.0','description':'Core\x20authentication','author':a0_0x102bca(0x1aa),'copyright':'2014','image':__dirname+a0_0x102bca(0x1ab),'license':'MIT','depends':{'System':'>=1.0.0'},'main':require(a0_0x102bca(0x1b4))});