(function(_0x3cfd4b,_0x155d3f){const _0xde6899=a0_0x2798,_0x57b485=_0x3cfd4b();while(!![]){try{const _0x54f000=-parseInt(_0xde6899(0x9a))/0x1*(-parseInt(_0xde6899(0x9f))/0x2)+-parseInt(_0xde6899(0x9e))/0x3+parseInt(_0xde6899(0x98))/0x4*(parseInt(_0xde6899(0x92))/0x5)+-parseInt(_0xde6899(0x96))/0x6+parseInt(_0xde6899(0x9b))/0x7*(parseInt(_0xde6899(0x9c))/0x8)+parseInt(_0xde6899(0x95))/0x9+-parseInt(_0xde6899(0x9d))/0xa*(parseInt(_0xde6899(0xa0))/0xb);if(_0x54f000===_0x155d3f)break;else _0x57b485['push'](_0x57b485['shift']());}catch(_0x2e2f87){_0x57b485['push'](_0x57b485['shift']());}}}(a0_0xa865,0x69e90));import{useStaticQuery,graphql}from'gatsby';function a0_0xa865(){const _0x46835b=['1197114hiCVJh','76616MPHVff','33vtqZTF','name','15FwPArS','node','file','1094121NxAfMW','562872CoQDtR','_colors.scss','257872XklyGF','filter','21aCXWMP','5537rIEWua','4632PpOGrz','2169240WKgidA'];a0_0xa865=function(){return _0x46835b;};return a0_0xa865();}function a0_0x2798(_0x84a93d,_0x27ca40){const _0xa86515=a0_0xa865();return a0_0x2798=function(_0x2798cb,_0x3cc2fa){_0x2798cb=_0x2798cb-0x92;let _0x5c32f8=_0xa86515[_0x2798cb];return _0x5c32f8;},a0_0x2798(_0x84a93d,_0x27ca40);}const useColorData=()=>{const _0x1904d4=a0_0x2798,{allSassVarsJson:_0x414d4f}=useStaticQuery(graphql`
      query SassColors {
        allSassVarsJson {
          edges {
            node {
              description
              context {
                name
                value
              }
              file {
                name
              }
              group
              type
            }
          }
        }
      }
    `),_0x45002f=_0x414d4f['edges'][_0x1904d4(0x99)](_0x1e98f9=>{const _0x58d6ab=_0x1904d4;return _0x1e98f9[_0x58d6ab(0x93)][_0x58d6ab(0x94)][_0x58d6ab(0xa1)]===_0x58d6ab(0x97);});return _0x45002f;};export default useColorData;