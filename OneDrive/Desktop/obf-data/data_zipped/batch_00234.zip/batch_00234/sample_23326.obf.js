/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x224900=a0_0x3699;(function(_0x40ec1c,_0x98bee5){var _0x1b5376=a0_0x3699,_0x322048=_0x40ec1c();while(!![]){try{var _0x2d779b=parseInt(_0x1b5376(0x1c2))/0x1*(-parseInt(_0x1b5376(0x1c9))/0x2)+parseInt(_0x1b5376(0x1cb))/0x3+parseInt(_0x1b5376(0x1c5))/0x4*(-parseInt(_0x1b5376(0x1c4))/0x5)+-parseInt(_0x1b5376(0x1ca))/0x6+-parseInt(_0x1b5376(0x1be))/0x7+parseInt(_0x1b5376(0x1c8))/0x8+parseInt(_0x1b5376(0x1c1))/0x9*(parseInt(_0x1b5376(0x1c3))/0xa);if(_0x2d779b===_0x98bee5)break;else _0x322048['push'](_0x322048['shift']());}catch(_0x3bbc08){_0x322048['push'](_0x322048['shift']());}}}(a0_0x3764,0x212bc));function a0_0x3699(_0x53af92,_0x51dc42){var _0x37645d=a0_0x3764();return a0_0x3699=function(_0x369945,_0x1fa65c){_0x369945=_0x369945-0x1be;var _0x3e90df=_0x37645d[_0x369945];return _0x3e90df;},a0_0x3699(_0x53af92,_0x51dc42);}var linspace=require(a0_0x224900(0x1c6)),acot=require(a0_0x224900(0x1c0)),x=linspace(-0x5,0x5,0x64),i;function a0_0x3764(){var _0x2bd83a=['319968HPmBNP','86agEylF','899604QmkrCt','14064SbFIDA','1762537Vulcrm','log','./../lib','1090251JcDPMx','1117cShzsH','60krgryn','929470yTvyXR','4ujBZsx','@stdlib/array/base/linspace','acot(%d)\x20=\x20%d'];a0_0x3764=function(){return _0x2bd83a;};return a0_0x3764();}for(i=0x0;i<x['length'];i++){console[a0_0x224900(0x1bf)](a0_0x224900(0x1c7),x[i],acot(x[i]));}