/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x3d11ea=a0_0x49d1;function a0_0x2618(){var _0x23abd5=['55158OmNcAa','2771240GXuHVF','3826072BcNYSg','1561SroGLY','78rWiMvo','ndarray','exports','3218567NXMQrb','272FIhQCN','70210ImIPaj','9tgojUv','@stdlib/math/base/special/abs','1087298sqnhYE','6744ZmDMyi'];a0_0x2618=function(){return _0x23abd5;};return a0_0x2618();}(function(_0x1ca017,_0x26f10f){var _0x2cdc70=a0_0x49d1,_0x537eaf=_0x1ca017();while(!![]){try{var _0x17b839=parseInt(_0x2cdc70(0x177))/0x1+parseInt(_0x2cdc70(0x16f))/0x2*(parseInt(_0x2cdc70(0x179))/0x3)+parseInt(_0x2cdc70(0x173))/0x4*(-parseInt(_0x2cdc70(0x174))/0x5)+-parseInt(_0x2cdc70(0x178))/0x6*(-parseInt(_0x2cdc70(0x17c))/0x7)+parseInt(_0x2cdc70(0x17b))/0x8*(-parseInt(_0x2cdc70(0x175))/0x9)+parseInt(_0x2cdc70(0x17a))/0xa+-parseInt(_0x2cdc70(0x172))/0xb;if(_0x17b839===_0x26f10f)break;else _0x537eaf['push'](_0x537eaf['shift']());}catch(_0x499e91){_0x537eaf['push'](_0x537eaf['shift']());}}}(a0_0x2618,0x940d0));var mapBy=require('@stdlib/strided/base/map-by')[a0_0x3d11ea(0x170)],abs=require(a0_0x3d11ea(0x176));function absBy(_0x15532d,_0x49da7b,_0x5b2d99,_0x372041,_0x208b6e,_0x5a7163,_0x8b7b1c,_0x4947b2,_0x6365a2){return mapBy(_0x15532d,_0x49da7b,_0x5b2d99,_0x372041,_0x208b6e,_0x5a7163,_0x8b7b1c,abs,_0x4947b2,_0x6365a2);}function a0_0x49d1(_0x4212ae,_0x2acdbf){var _0x2618e1=a0_0x2618();return a0_0x49d1=function(_0x49d190,_0x60d54f){_0x49d190=_0x49d190-0x16f;var _0x41d5be=_0x2618e1[_0x49d190];return _0x41d5be;},a0_0x49d1(_0x4212ae,_0x2acdbf);}module[a0_0x3d11ea(0x171)]=absBy;