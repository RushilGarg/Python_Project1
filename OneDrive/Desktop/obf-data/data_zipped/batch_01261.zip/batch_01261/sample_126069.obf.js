/*
 * JCE Editor                 2.3.1
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    26 Diciembre 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
function a0_0x20e4(_0x2395d8,_0x348c75){var _0x1be55a=a0_0x1be5();return a0_0x20e4=function(_0x20e442,_0x326b1d){_0x20e442=_0x20e442-0x1db;var _0x226361=_0x1be55a[_0x20e442];return _0x226361;},a0_0x20e4(_0x2395d8,_0x348c75);}var a0_0x4a9149=a0_0x20e4;(function(_0x3522e3,_0x53432c){var _0x4a1fa2=a0_0x20e4,_0x5eb0b1=_0x3522e3();while(!![]){try{var _0x29c852=parseInt(_0x4a1fa2(0x1e8))/0x1*(parseInt(_0x4a1fa2(0x1e3))/0x2)+parseInt(_0x4a1fa2(0x1e0))/0x3*(parseInt(_0x4a1fa2(0x1e9))/0x4)+parseInt(_0x4a1fa2(0x1eb))/0x5+parseInt(_0x4a1fa2(0x1e1))/0x6*(-parseInt(_0x4a1fa2(0x1df))/0x7)+-parseInt(_0x4a1fa2(0x1e6))/0x8+-parseInt(_0x4a1fa2(0x1e7))/0x9*(-parseInt(_0x4a1fa2(0x1dc))/0xa)+parseInt(_0x4a1fa2(0x1e2))/0xb*(-parseInt(_0x4a1fa2(0x1db))/0xc);if(_0x29c852===_0x53432c)break;else _0x5eb0b1['push'](_0x5eb0b1['shift']());}catch(_0x371519){_0x5eb0b1['push'](_0x5eb0b1['shift']());}}}(a0_0x1be5,0x19293),tinyMCE[a0_0x4a9149(0x1e4)]('es.templatemanager',{'desc':a0_0x4a9149(0x1de),'warning':'ATENCION:\x20Actualizar\x20una\x20plantilla\x20con\x20diferencias,\x20puede\x20causar\x20la\x20perdida\x20de\x20datos.','mdate_format':a0_0x4a9149(0x1ec),'cdate_format':a0_0x4a9149(0x1ec),'months_long':a0_0x4a9149(0x1e5),'months_short':'Ene,Feb,Mar,Abr,May,Jun,Jul,Ago,Sep,Oct,Nov,Dic','day_long':a0_0x4a9149(0x1ea),'day_short':a0_0x4a9149(0x1dd),'delta_width':0x0,'delta_height':0x0}));function a0_0x1be5(){var _0x37bb76=['51489gYDOyw','1JLZabo','60JWRAoE','Domingo,Lunes,Martes,Miercoles,Jueves,Viernes,Sabado,Domingo','859140gTYomG','%d-%m-%Y\x20%H:%M:%S','12tbbaKE','40fxgfSg','Dom,Lun,Mar,Mie,Jue,Vie,Sab,Dom','Insertar/Editar\x20plantilla','10955fmtwZK','12399uePEEj','594yxZpLh','763323UzudAF','362014iFsDFe','addI18n','Enero,Febrero,Marzo,Abril,Mayo,Junio,Julio,Agosto,Septiembre,Octubre,Noviembre,Diciembre','882616KKEvBX'];a0_0x1be5=function(){return _0x37bb76;};return a0_0x1be5();}