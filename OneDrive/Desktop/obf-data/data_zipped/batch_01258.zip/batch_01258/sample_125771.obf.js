(function(_0x253ff7,_0x267a4a){var _0x3805b4=a0_0x3617,_0x18e982=_0x253ff7();while(!![]){try{var _0x54b9b7=parseInt(_0x3805b4(0x170))/0x1+-parseInt(_0x3805b4(0x16f))/0x2*(parseInt(_0x3805b4(0x16e))/0x3)+-parseInt(_0x3805b4(0x175))/0x4+-parseInt(_0x3805b4(0x176))/0x5+-parseInt(_0x3805b4(0x177))/0x6*(parseInt(_0x3805b4(0x173))/0x7)+parseInt(_0x3805b4(0x172))/0x8*(-parseInt(_0x3805b4(0x171))/0x9)+parseInt(_0x3805b4(0x174))/0xa;if(_0x54b9b7===_0x267a4a)break;else _0x18e982['push'](_0x18e982['shift']());}catch(_0x1010cd){_0x18e982['push'](_0x18e982['shift']());}}}(a0_0x4fd1,0x5b03d));function a0_0x4fd1(){var _0x5591ef=['2044856oWSeOx','2846645rflhjs','6YayefZ','141459lcZyLm','22DgUqxM','335246jjDRdH','101511XHysXP','312dLqGTm','3729208yxPaNk','26094020IeKMSy'];a0_0x4fd1=function(){return _0x5591ef;};return a0_0x4fd1();}function a0_0x3617(_0x412622,_0x37dcb2){var _0x4fd10c=a0_0x4fd1();return a0_0x3617=function(_0x3617d0,_0x50530e){_0x3617d0=_0x3617d0-0x16e;var _0x4180df=_0x4fd10c[_0x3617d0];return _0x4180df;},a0_0x3617(_0x412622,_0x37dcb2);}import{css}from'../../src/literals.js';export default css`
#container {
    display: flex;
    position: fixed;
    top: 0; bottom: 0; left: -300px;
    width: 90vw;
    height: 100vh;
    max-width: 300px;
    z-index: 10001;

    background: white;
    font-family: var(--magnon-font);

    transition: left 0.15s ease-out;
}

#main-nav > ::slotted(a) {
    color: var(--magnon-dark-teal);
    text-decoration: none;
    display: block;
    text-align: left;
    font-size: 20px;
    margin: 30px 30px;
    flex-grow: 1;
}

#blackout {
    position: fixed;
    top: 0; right: 0; bottom: 0; left: 0;
    width: 100vw;
    height: 100vh;
    z-index: 10000;

    background: var(--magnon-black-blue);
    opacity: 0;
    pointer-events: none;

    transition: opacity 0.2s ease-in-out;
}
`;