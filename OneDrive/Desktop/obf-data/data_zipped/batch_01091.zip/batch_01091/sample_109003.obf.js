/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x382136=a0_0x2eba;function a0_0x2eba(_0x2f4de9,_0x434b4a){var _0x5327a9=a0_0x5327();return a0_0x2eba=function(_0x2eba12,_0x5cdaf4){_0x2eba12=_0x2eba12-0x169;var _0x56be1f=_0x5327a9[_0x2eba12];return _0x56be1f;},a0_0x2eba(_0x2f4de9,_0x434b4a);}function a0_0x5327(){var _0x4b5b2d=['reduce','bind','provide','shaka.util.Functional','indexOf','isNotDuplicate','Functional','3489KJggmL','1670510AkgZME','noop','12BWQaUb','39RUDEut','1692ZUCZXe','54yvAZYs','createFallbackPromiseChain','355236WgRWXk','concat','10ZiOoJa','util','1396571Btoyte','2328gIWgGt','506JruaGh','19576MGXZHO','235585YijujG'];a0_0x5327=function(){return _0x4b5b2d;};return a0_0x5327();}(function(_0x5c42d5,_0xa616a9){var _0x2e4bc9=a0_0x2eba,_0x12ca67=_0x5c42d5();while(!![]){try{var _0x2814e4=parseInt(_0x2e4bc9(0x16a))/0x1*(parseInt(_0x2e4bc9(0x172))/0x2)+-parseInt(_0x2e4bc9(0x17c))/0x3*(-parseInt(_0x2e4bc9(0x171))/0x4)+parseInt(_0x2e4bc9(0x17d))/0x5*(-parseInt(_0x2e4bc9(0x17f))/0x6)+-parseInt(_0x2e4bc9(0x174))/0x7+parseInt(_0x2e4bc9(0x173))/0x8*(parseInt(_0x2e4bc9(0x169))/0x9)+parseInt(_0x2e4bc9(0x16e))/0xa*(-parseInt(_0x2e4bc9(0x170))/0xb)+-parseInt(_0x2e4bc9(0x16c))/0xc*(-parseInt(_0x2e4bc9(0x180))/0xd);if(_0x2814e4===_0xa616a9)break;else _0x12ca67['push'](_0x12ca67['shift']());}catch(_0x2f7845){_0x12ca67['push'](_0x12ca67['shift']());}}}(a0_0x5327,0x643b9),goog[a0_0x382136(0x177)](a0_0x382136(0x178)),shaka[a0_0x382136(0x16f)]['Functional'][a0_0x382136(0x16b)]=function(_0x388342,_0x293793){var _0xa3f7=a0_0x382136;return _0x388342[_0xa3f7(0x175)](function(_0x2c9c77,_0x5707ed,_0x3bca78){var _0x4976b9=_0xa3f7;return _0x5707ed['catch'](_0x2c9c77[_0x4976b9(0x176)](null,_0x3bca78));}['bind'](null,_0x293793),Promise['reject']());},shaka['util']['Functional']['collapseArrays']=function(_0x56fa0f,_0x429e1e){var _0x345209=a0_0x382136;return _0x56fa0f[_0x345209(0x16d)](_0x429e1e);},shaka[a0_0x382136(0x16f)][a0_0x382136(0x17b)][a0_0x382136(0x17e)]=function(){},shaka['util'][a0_0x382136(0x17b)]['isNotNull']=function(_0x21e0b5){return _0x21e0b5!=null;},shaka[a0_0x382136(0x16f)][a0_0x382136(0x17b)][a0_0x382136(0x17a)]=function(_0x2f0a15,_0x10ea26,_0x33edb2){var _0x5dabc4=a0_0x382136;return _0x33edb2[_0x5dabc4(0x179)](_0x2f0a15)==_0x10ea26;});