/**
 * @license
 * Copyright 2020 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const a0_0x10bef2=a0_0x2f22;(function(_0x57cc3f,_0x2f18c6){const _0x2a876a=a0_0x2f22,_0x18bd2f=_0x57cc3f();while(!![]){try{const _0x80c06c=-parseInt(_0x2a876a(0x10e))/0x1*(-parseInt(_0x2a876a(0x110))/0x2)+parseInt(_0x2a876a(0x100))/0x3+-parseInt(_0x2a876a(0xfc))/0x4+-parseInt(_0x2a876a(0x108))/0x5*(-parseInt(_0x2a876a(0x101))/0x6)+parseInt(_0x2a876a(0x109))/0x7+-parseInt(_0x2a876a(0x105))/0x8+parseInt(_0x2a876a(0xf6))/0x9;if(_0x80c06c===_0x2f18c6)break;else _0x18bd2f['push'](_0x18bd2f['shift']());}catch(_0xc452ad){_0x18bd2f['push'](_0x18bd2f['shift']());}}}(a0_0x546d,0xb9889),goog[a0_0x10bef2(0x10a)]('SmartCardClientApp.BuiltInPinDialog.Main'),goog['require'](a0_0x10bef2(0x104)),goog['require'](a0_0x10bef2(0xff)),goog[a0_0x10bef2(0x10b)](a0_0x10bef2(0xf9)),goog['require'](a0_0x10bef2(0x10f)),goog['require'](a0_0x10bef2(0x10c)),goog['scope'](function(){const _0x34e7b1=a0_0x10bef2,_0x206275=GoogleSmartCard;function _0x1c9958(){const _0x2e3a5d=a0_0x2f22,_0x2ab53d=goog['dom'][_0x2e3a5d(0x10d)][_0x2e3a5d(0xf7)](goog[_0x2e3a5d(0x111)][_0x2e3a5d(0xfa)](_0x2e3a5d(0xfd)));_0x206275[_0x2e3a5d(0xf8)]['resolveModalDialog'](_0x2ab53d);}function _0x5a8b32(){const _0xc2f0c7=a0_0x2f22;_0x206275[_0xc2f0c7(0xf8)]['rejectModalDialog'](new Error(_0xc2f0c7(0xfb)));}goog[_0x34e7b1(0x103)][_0x34e7b1(0xfe)](goog[_0x34e7b1(0x111)]['getElement']('ok'),_0x34e7b1(0x106),_0x1c9958),goog[_0x34e7b1(0x103)][_0x34e7b1(0xfe)](goog[_0x34e7b1(0x111)][_0x34e7b1(0xfa)](_0x34e7b1(0x102)),_0x34e7b1(0x106),_0x5a8b32),_0x206275[_0x34e7b1(0xf8)][_0x34e7b1(0x107)]();}));function a0_0x2f22(_0x20d4fb,_0x2ad9a1){const _0x546d0d=a0_0x546d();return a0_0x2f22=function(_0x2f22fd,_0x20debf){_0x2f22fd=_0x2f22fd-0xf6;let _0x331fcb=_0x546d0d[_0x2f22fd];return _0x331fcb;},a0_0x2f22(_0x20d4fb,_0x2ad9a1);}function a0_0x546d(){const _0x4c7d4c=['6jGtDnI','cancel','events','GoogleSmartCard.InPopupMainScript','11728656EzwNuv','click','prepareAndShowAsModalDialog','4803170pAQSoE','1740242YWOqWN','provide','require','goog.events','forms','440AQGHyR','goog.dom.forms','1986vvviPB','dom','1488501IahSrs','getValue','InPopupMainScript','goog.dom','getElement','PIN\x20dialog\x20was\x20canceled','4252008sapNuG','input','listen','GoogleSmartCard.Logging','4432440GiUqqo'];a0_0x546d=function(){return _0x4c7d4c;};return a0_0x546d();}