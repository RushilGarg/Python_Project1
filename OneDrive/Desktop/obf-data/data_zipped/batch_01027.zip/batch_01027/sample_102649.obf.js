/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xc28514=a0_0x51a2;(function(_0x4a2f44,_0x2d0643){var _0x47354d=a0_0x51a2,_0x3a524a=_0x4a2f44();while(!![]){try{var _0x2f7437=parseInt(_0x47354d(0xb7))/0x1*(-parseInt(_0x47354d(0xbf))/0x2)+parseInt(_0x47354d(0xb6))/0x3*(-parseInt(_0x47354d(0xbb))/0x4)+parseInt(_0x47354d(0xb5))/0x5+-parseInt(_0x47354d(0xb4))/0x6*(-parseInt(_0x47354d(0xba))/0x7)+-parseInt(_0x47354d(0xbe))/0x8+parseInt(_0x47354d(0xc2))/0x9*(parseInt(_0x47354d(0xbc))/0xa)+parseInt(_0x47354d(0xc1))/0xb;if(_0x2f7437===_0x2d0643)break;else _0x3a524a['push'](_0x3a524a['shift']());}catch(_0x4b07fe){_0x3a524a['push'](_0x3a524a['shift']());}}}(a0_0x22a8,0xe3c3a));function a0_0x51a2(_0x3bb85b,_0x552454){var _0x22a85c=a0_0x22a8();return a0_0x51a2=function(_0x51a2fd,_0x3ffe7f){_0x51a2fd=_0x51a2fd-0xb2;var _0x565577=_0x22a85c[_0x51a2fd];return _0x565577;},a0_0x51a2(_0x3bb85b,_0x552454);}function a0_0x22a8(){var _0x282568=['27736566SXxSMz','83529XKDVzp','tape','./../lib','4177698sOnbCz','7518000qZXdPm','4159263hPyJqr','41visIpl','end','main\x20export\x20is\x20a\x20function','7zAIewb','4RjLWkf','1050UtWfLe','function','12563352lyemrW','88104mNYbIf','strictEqual'];a0_0x22a8=function(){return _0x282568;};return a0_0x22a8();}var tape=require(a0_0xc28514(0xb2)),dmskmap2=require(a0_0xc28514(0xb3));tape(a0_0xc28514(0xb9),function test(_0x2227ec){var _0x311518=a0_0xc28514;_0x2227ec['ok'](!![],__filename),_0x2227ec[_0x311518(0xc0)](typeof dmskmap2,_0x311518(0xbd),'main\x20export\x20is\x20a\x20function'),_0x2227ec['end']();}),tape('attached\x20to\x20the\x20main\x20export\x20is\x20a\x20method\x20providing\x20an\x20ndarray\x20interface',function test(_0x55c1a8){var _0x4ae135=a0_0xc28514;_0x55c1a8[_0x4ae135(0xc0)](typeof dmskmap2['ndarray'],_0x4ae135(0xbd),'method\x20is\x20a\x20function'),_0x55c1a8[_0x4ae135(0xb8)]();});