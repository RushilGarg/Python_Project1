/*  
 * JCE Editor                 2.2.6
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    19 August 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
function a0_0x14fe(_0x2855de,_0x201488){var _0x1baee2=a0_0x1bae();return a0_0x14fe=function(_0x14fece,_0x571e64){_0x14fece=_0x14fece-0x1c0;var _0x2835a6=_0x1baee2[_0x14fece];return _0x2835a6;},a0_0x14fe(_0x2855de,_0x201488);}function a0_0x1bae(){var _0x2ccda8=['5277496HFmcDi','310039aJxrTZ','title','#jce','jce','removeClass','Legend','5601624BteYQq','focus','attr','4519470cScbNg','17064TVfSIg','1265096SuZwIZ','each','addClass','hover','getElementById','span.profileLayoutContainer','.mceSplitButton\x20.mceIcon','profileLayoutTable','support','document','leadingWhitespace','multiplebg','span[data-name=\x22','4834300aAYFyd','<span/>','50AUFTgx'];a0_0x1bae=function(){return _0x2ccda8;};return a0_0x1bae();}(function(_0x916b96,_0x1d65da){var _0x34822d=a0_0x14fe,_0x5051ed=_0x916b96();while(!![]){try{var _0x9542d8=parseInt(_0x34822d(0x1cf))/0x1+parseInt(_0x34822d(0x1cd))/0x2*(-parseInt(_0x34822d(0x1d9))/0x3)+parseInt(_0x34822d(0x1d5))/0x4+-parseInt(_0x34822d(0x1cb))/0x5+parseInt(_0x34822d(0x1d8))/0x6+-parseInt(_0x34822d(0x1ce))/0x7+parseInt(_0x34822d(0x1da))/0x8;if(_0x9542d8===_0x1d65da)break;else _0x5051ed['push'](_0x5051ed['shift']());}catch(_0x110050){_0x5051ed['push'](_0x5051ed['shift']());}}}(a0_0x1bae,0xb9437),function(_0x5b507a){var _0x2d7757=a0_0x14fe;_0x5b507a[_0x2d7757(0x1d2)][_0x2d7757(0x1d4)]={'init':function(){var _0x288771=_0x2d7757,_0x42bda0=_0x5b507a(_0x288771(0x1c3),parent['window'][_0x288771(0x1c7)][_0x288771(0x1c2)](_0x288771(0x1c5)));_0x5b507a('tr',_0x288771(0x1d1))[_0x288771(0x1c1)](function(){var _0x98d7ae=_0x288771;_0x5b507a('span[data-name=\x22'+_0x5b507a(this)[_0x98d7ae(0x1d7)](_0x98d7ae(0x1d0))+'\x22]',_0x42bda0)[_0x98d7ae(0x1c0)](_0x98d7ae(0x1d6));},function(){var _0x44d8c1=_0x288771;_0x5b507a(_0x44d8c1(0x1ca)+_0x5b507a(this)[_0x44d8c1(0x1d7)](_0x44d8c1(0x1d0))+'\x22]',_0x42bda0)[_0x44d8c1(0x1d3)]('focus');}),!_0x5b507a[_0x288771(0x1c6)][_0x288771(0x1c8)]?_0x5b507a(_0x288771(0x1c4))[_0x288771(0x1db)](function(){var _0x53bb7d=_0x288771;_0x5b507a(_0x53bb7d(0x1cc))['insertAfter'](this);}):_0x5b507a('#jce')[_0x288771(0x1c0)](_0x288771(0x1c9));}};}(jQuery));