/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x565da7=a0_0x36a2;(function(_0x121484,_0xf0fa42){var _0x2d02ce=a0_0x36a2,_0x523c03=_0x121484();while(!![]){try{var _0x1973a1=parseInt(_0x2d02ce(0x155))/0x1+parseInt(_0x2d02ce(0x15e))/0x2*(parseInt(_0x2d02ce(0x158))/0x3)+-parseInt(_0x2d02ce(0x154))/0x4+parseInt(_0x2d02ce(0x156))/0x5*(parseInt(_0x2d02ce(0x157))/0x6)+-parseInt(_0x2d02ce(0x15c))/0x7*(-parseInt(_0x2d02ce(0x159))/0x8)+-parseInt(_0x2d02ce(0x161))/0x9*(parseInt(_0x2d02ce(0x15d))/0xa)+-parseInt(_0x2d02ce(0x15a))/0xb*(parseInt(_0x2d02ce(0x15f))/0xc);if(_0x1973a1===_0xf0fa42)break;else _0x523c03['push'](_0x523c03['shift']());}catch(_0x284d06){_0x523c03['push'](_0x523c03['shift']());}}}(a0_0x1928,0x722c5));var iterMap=require(a0_0x565da7(0x153)),inv=require(a0_0x565da7(0x15b));function iterInv(_0x2a938d){return iterMap(_0x2a938d,inv);}function a0_0x36a2(_0x3dbd8c,_0x5508db){var _0x1928b0=a0_0x1928();return a0_0x36a2=function(_0x36a217,_0x240ee9){_0x36a217=_0x36a217-0x153;var _0x298b63=_0x1928b0[_0x36a217];return _0x298b63;},a0_0x36a2(_0x3dbd8c,_0x5508db);}function a0_0x1928(){var _0x25566a=['1067790fnFRwK','18KFjkMg','3OMdFhJ','31320qBRfFx','3186667AGYeNV','@stdlib/math/base/special/inv','791SaEByh','4023290cDznSa','687202biZLKQ','12xbWQHH','exports','9dbehLU','@stdlib/math/iter/tools/map','3110472DAozao','510627yGXPKw'];a0_0x1928=function(){return _0x25566a;};return a0_0x1928();}module[a0_0x565da7(0x160)]=iterInv;