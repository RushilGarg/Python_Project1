/**
 * @package Graph
 * @file GraphSerializer.js
 * @author Nagy Zoltán (NAZRAAI.ELTE) <abesto0@gmail.com>
 * @license Apache License, Version 2.0
 *
 * Serialize a graph (model and coordinates from the UI) into JSON
 *
 * Copyright 2011 Nagy Zoltán
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x36bb(_0x3797aa,_0x5c2e75){var _0x1c62a0=a0_0x1c62();return a0_0x36bb=function(_0x36bbd6,_0x84aa08){_0x36bbd6=_0x36bbd6-0xda;var _0x25e5e0=_0x1c62a0[_0x36bbd6];return _0x25e5e0;},a0_0x36bb(_0x3797aa,_0x5c2e75);}var a0_0x39f13d=a0_0x36bb;(function(_0x17a7f6,_0x58d951){var _0x542e55=a0_0x36bb,_0x556a83=_0x17a7f6();while(!![]){try{var _0x54532=-parseInt(_0x542e55(0xe9))/0x1+parseInt(_0x542e55(0xe0))/0x2+-parseInt(_0x542e55(0xec))/0x3+parseInt(_0x542e55(0xdb))/0x4+parseInt(_0x542e55(0xe5))/0x5*(-parseInt(_0x542e55(0xdd))/0x6)+parseInt(_0x542e55(0xe8))/0x7+parseInt(_0x542e55(0xe4))/0x8;if(_0x54532===_0x58d951)break;else _0x556a83['push'](_0x556a83['shift']());}catch(_0x4cb06a){_0x556a83['push'](_0x556a83['shift']());}}}(a0_0x1c62,0x83dd4),Namespace(a0_0x39f13d(0xed),{'Serializer':(function(){var _0x5562f5,_0x485d53={};function _0x3a52ac(_0x2de25e){var _0x150e62=a0_0x36bb,_0x2c7ba6=_0x2de25e['ui']['getBBox']();return _0x485d53[_0x2de25e['UID']]=_0x5562f5(),{'SID':_0x485d53[_0x2de25e[_0x150e62(0xe6)]],'x':parseFloat(_0x2c7ba6['x'])+parseFloat((_0x2c7ba6[_0x150e62(0xdc)]/0x2)['toFixed'](0x1)),'y':parseFloat(_0x2c7ba6['y'])+parseFloat((_0x2c7ba6[_0x150e62(0xea)]/0x2)[_0x150e62(0xe7)](0x1))};}function _0xd5db90(_0x6f0eba){var _0x596c78=a0_0x36bb;return{'n1':_0x485d53[_0x6f0eba[_0x596c78(0xe2)]()[_0x596c78(0xe6)]],'n2':_0x485d53[_0x6f0eba['node2']()[_0x596c78(0xe6)]]};}function _0x3ea621(_0x5ef610){var _0x14650f=a0_0x36bb,_0x428834=[],_0x1c84d0=[];return _0x5562f5=new UID[(_0x14650f(0xde))](),console['log'](_0x5ef610),_0x5ef610[_0x14650f(0xdf)]()[_0x14650f(0xe3)](function(_0xee764){var _0x3561ac=_0x14650f;_0x428834[_0x3561ac(0xda)](_0x3a52ac(_0xee764));}),_0x5ef610[_0x14650f(0xeb)]()[_0x14650f(0xe3)](function(_0x191575){_0x1c84d0['push'](_0xd5db90(_0x191575));}),$[_0x14650f(0xe1)]({'nodes':_0x428834,'edges':_0x1c84d0});}return{'serialize':_0x3ea621};}())}));function a0_0x1c62(){var _0x3ad5e7=['nodes','1123330btsNDm','toJSON','node1','each','6689616rqIiQx','10UmUFIh','UID','toFixed','5492774FCffrc','528020lgFjRm','height','edges','2871840Gtslwy','net.abesto.graph','push','2550996UJVclC','width','2384646wfPPyU','Generator'];a0_0x1c62=function(){return _0x3ad5e7;};return a0_0x1c62();}