/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2ff26e=a0_0x26ca;function a0_0x26ca(_0x375c81,_0x36c89f){var _0x2b388c=a0_0x2b38();return a0_0x26ca=function(_0x26ca07,_0x12d48a){_0x26ca07=_0x26ca07-0x1bf;var _0x59ad6e=_0x2b388c[_0x26ca07];return _0x59ad6e;},a0_0x26ca(_0x375c81,_0x36c89f);}(function(_0x117360,_0x4daca6){var _0x33c8db=a0_0x26ca,_0x36c6ad=_0x117360();while(!![]){try{var _0xd0fa25=-parseInt(_0x33c8db(0x1c7))/0x1+-parseInt(_0x33c8db(0x1c0))/0x2*(-parseInt(_0x33c8db(0x1c5))/0x3)+parseInt(_0x33c8db(0x1c4))/0x4*(-parseInt(_0x33c8db(0x1ca))/0x5)+-parseInt(_0x33c8db(0x1ce))/0x6*(-parseInt(_0x33c8db(0x1c3))/0x7)+parseInt(_0x33c8db(0x1c8))/0x8*(-parseInt(_0x33c8db(0x1d3))/0x9)+-parseInt(_0x33c8db(0x1d4))/0xa+parseInt(_0x33c8db(0x1c1))/0xb;if(_0xd0fa25===_0x4daca6)break;else _0x36c6ad['push'](_0x36c6ad['shift']());}catch(_0x44c4ef){_0x36c6ad['push'](_0x36c6ad['shift']());}}}(a0_0x2b38,0x634b4));function a0_0x2b38(){var _0xbeb429=['15148qRjVWz','202780SJlhGL','132LFfVyi',':slice:len=','339883wgtVuG','24AGnBUK','fail','10IEFczf','@stdlib/assert/is-uint16array','@stdlib/bench','name','36IUFNps','./../package.json','object','tic','slice','741141FcCTOg','2196340XDmaYc','benchmark\x20finished','should\x20return\x20a\x20Uint16Array','end','27358TVgBql','7697822FnGEuE','should\x20return\x20an\x20object'];a0_0x2b38=function(){return _0xbeb429;};return a0_0x2b38();}var bench=require(a0_0x2ff26e(0x1cc)),pow=require('@stdlib/math/base/special/pow'),isUint16Array=require(a0_0x2ff26e(0x1cb)),pkg=require(a0_0x2ff26e(0x1cf))[a0_0x2ff26e(0x1cd)],Uint16Array=require('./../lib');function createBenchmark(_0xb15b0a){var _0x440075=new Uint16Array(_0xb15b0a);return _0x490fec;function _0x490fec(_0x5ad16d){var _0x15ea95=a0_0x26ca,_0x217720,_0x4c53eb;_0x5ad16d[_0x15ea95(0x1d1)]();for(_0x4c53eb=0x0;_0x4c53eb<_0x5ad16d['iterations'];_0x4c53eb++){_0x440075[0x0]=_0x4c53eb,_0x217720=_0x440075[_0x15ea95(0x1d2)](),typeof _0x217720!==_0x15ea95(0x1d0)&&_0x5ad16d[_0x15ea95(0x1c9)](_0x15ea95(0x1c2));}_0x5ad16d['toc'](),!isUint16Array(_0x217720)&&_0x5ad16d[_0x15ea95(0x1c9)](_0x15ea95(0x1d6)),_0x5ad16d['pass'](_0x15ea95(0x1d5)),_0x5ad16d[_0x15ea95(0x1bf)]();}}function main(){var _0x15800d=a0_0x2ff26e,_0x5ddfa1,_0x2ec31b,_0x354b19,_0x21309a,_0x3fdfb2;_0x2ec31b=0x1,_0x354b19=0x6;for(_0x3fdfb2=_0x2ec31b;_0x3fdfb2<=_0x354b19;_0x3fdfb2++){_0x5ddfa1=pow(0xa,_0x3fdfb2),_0x21309a=createBenchmark(_0x5ddfa1),bench(pkg+_0x15800d(0x1c6)+_0x5ddfa1,_0x21309a);}}main();