function a0_0x733e(){const _0x366767=['89407SxlyNe','7VPxYtj','469230vZMHvV','977170QGCbdX','16ZvjMLz','13687624RKebwB','225fUqoWT','4432197VBNblT','12rbSvKl','366368IvQcfE','5623764UIKEKf'];a0_0x733e=function(){return _0x366767;};return a0_0x733e();}(function(_0x554659,_0x591e0d){const _0x29e635=a0_0x56ad,_0x3704f0=_0x554659();while(!![]){try{const _0x43c7a2=-parseInt(_0x29e635(0x139))/0x1+-parseInt(_0x29e635(0x137))/0x2*(-parseInt(_0x29e635(0x136))/0x3)+-parseInt(_0x29e635(0x13d))/0x4*(parseInt(_0x29e635(0x13c))/0x5)+parseInt(_0x29e635(0x138))/0x6+parseInt(_0x29e635(0x13a))/0x7*(parseInt(_0x29e635(0x133))/0x8)+parseInt(_0x29e635(0x134))/0x9*(-parseInt(_0x29e635(0x13b))/0xa)+-parseInt(_0x29e635(0x135))/0xb;if(_0x43c7a2===_0x591e0d)break;else _0x3704f0['push'](_0x3704f0['shift']());}catch(_0xf0c1b7){_0x3704f0['push'](_0x3704f0['shift']());}}}(a0_0x733e,0xe3fce));import a0_0x43fb59 from'../../components/EmployeePage';function a0_0x56ad(_0x16be72,_0xc086e9){const _0x733eb7=a0_0x733e();return a0_0x56ad=function(_0x56ad20,_0x16f1ca){_0x56ad20=_0x56ad20-0x133;let _0x3d858e=_0x733eb7[_0x56ad20];return _0x3d858e;},a0_0x56ad(_0x16be72,_0xc086e9);}import{graphql}from'gatsby';export const query=graphql`
    query {
        EmployeeImages: allFile(
            sort: { order: ASC, fields: [absolutePath] }
            filter: { relativePath: { regex: "/mugshots/hallvard.jpg/" } }
        ) {
            edges {
                node {
                    relativePath
                    name
                    childImageSharp {
                        fluid(maxWidth: 1000) {
                            ...GatsbyImageSharpFluid
                        }
                    }
                }
            }
        }
    }
`;export default a0_0x43fb59;