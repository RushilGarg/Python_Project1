/**
 * @license
 * Copyright (c) 2016 Nicholas Nelson
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
 * SOFTWARE.
 */
var a0_0x19ac8e=a0_0x11be;(function(_0x2be5fc,_0x772d6b){var _0xca7763=a0_0x11be,_0x2ddb64=_0x2be5fc();while(!![]){try{var _0x111b28=parseInt(_0xca7763(0x1fa))/0x1*(parseInt(_0xca7763(0x1f6))/0x2)+-parseInt(_0xca7763(0x1fe))/0x3*(-parseInt(_0xca7763(0x1f8))/0x4)+-parseInt(_0xca7763(0x1f9))/0x5*(parseInt(_0xca7763(0x1ff))/0x6)+parseInt(_0xca7763(0x1f4))/0x7*(-parseInt(_0xca7763(0x1fd))/0x8)+-parseInt(_0xca7763(0x202))/0x9+-parseInt(_0xca7763(0x1f7))/0xa+parseInt(_0xca7763(0x1fc))/0xb;if(_0x111b28===_0x772d6b)break;else _0x2ddb64['push'](_0x2ddb64['shift']());}catch(_0x8e16e9){_0x2ddb64['push'](_0x2ddb64['shift']());}}}(a0_0x487b,0x536bc));import a0_0x452439 from'./GameTimer';import a0_0x2bdc62 from'./SceneHandler';function a0_0x11be(_0x30e62d,_0x5ad7df){var _0x487b6c=a0_0x487b();return a0_0x11be=function(_0x11bed4,_0x5329bb){_0x11bed4=_0x11bed4-0x1f3;var _0x3d5ec8=_0x487b6c[_0x11bed4];return _0x3d5ec8;},a0_0x11be(_0x30e62d,_0x5ad7df);}import a0_0x43e0fe from'./ViewRenderer';class Engine{constructor(_0x12e078){var _0x493a8e=a0_0x11be;this[_0x493a8e(0x203)]=new a0_0x452439(),this['sceneHandler']=new a0_0x2bdc62(),this['sceneHandler'][_0x493a8e(0x1f3)](),this[_0x493a8e(0x205)]=new a0_0x43e0fe({'canvas':_0x12e078,'scene':this['sceneHandler']['scene'],'world':this['sceneHandler'][_0x493a8e(0x1f5)]});}[a0_0x19ac8e(0x204)](){var _0x4cc46c=a0_0x19ac8e;this[_0x4cc46c(0x203)]['update'](),this[_0x4cc46c(0x201)][_0x4cc46c(0x200)](this[_0x4cc46c(0x203)][_0x4cc46c(0x1fb)]),this['renderer'][_0x4cc46c(0x200)](),this['renderer']['render'](this[_0x4cc46c(0x201)]);}}function a0_0x487b(){var _0xad7323=['sceneHandler','2118132XAfozS','timer','tick','renderer','init','711641yvrrRI','world','2oXygbi','2750310OMEXEW','74324fkNaGw','7960oAqlLs','111266FaVIjW','deltaTime','5593610ZBgLmi','8oxTqmy','66DtrPSc','282geTZAo','update'];a0_0x487b=function(){return _0xad7323;};return a0_0x487b();}export{Engine as default};