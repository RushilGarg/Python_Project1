/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x1096(){var _0x2384c5=['33165SqjWyW','27359568XrVxow','11103CniZhr','6206900vVHwcw','76138bGGBCX','exports','18IItTfU','152aHONhM','5360729hsOnHS','564AXVyIj','8NtxERc','23CWjfTc','3104157hhSTZS'];a0_0x1096=function(){return _0x2384c5;};return a0_0x1096();}var a0_0x48a6c4=a0_0x5d9b;(function(_0x5c27ec,_0x2bcc51){var _0x5cb184=a0_0x5d9b,_0x4e7a3f=_0x5c27ec();while(!![]){try{var _0x2081bd=parseInt(_0x5cb184(0x15b))/0x1*(parseInt(_0x5cb184(0x161))/0x2)+-parseInt(_0x5cb184(0x15f))/0x3*(-parseInt(_0x5cb184(0x164))/0x4)+parseInt(_0x5cb184(0x15d))/0x5*(parseInt(_0x5cb184(0x166))/0x6)+parseInt(_0x5cb184(0x15c))/0x7*(-parseInt(_0x5cb184(0x167))/0x8)+parseInt(_0x5cb184(0x163))/0x9*(parseInt(_0x5cb184(0x160))/0xa)+parseInt(_0x5cb184(0x165))/0xb+-parseInt(_0x5cb184(0x15e))/0xc;if(_0x2081bd===_0x2bcc51)break;else _0x4e7a3f['push'](_0x4e7a3f['shift']());}catch(_0x58547d){_0x4e7a3f['push'](_0x4e7a3f['shift']());}}}(a0_0x1096,0x9d7a7));function a0_0x5d9b(_0x453dcd,_0x17d98d){var _0x1096f4=a0_0x1096();return a0_0x5d9b=function(_0x5d9bc9,_0x2d8066){_0x5d9bc9=_0x5d9bc9-0x15b;var _0x30ec5c=_0x1096f4[_0x5d9bc9];return _0x30ec5c;},a0_0x5d9b(_0x453dcd,_0x17d98d);}var iterMap=require('@stdlib/math/iter/tools/map'),havercos=require('@stdlib/math/base/special/havercos');function iterHavercos(_0x2e112e){return iterMap(_0x2e112e,havercos);}module[a0_0x48a6c4(0x162)]=iterHavercos;