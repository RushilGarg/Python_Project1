/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x61a8(_0xb7900d,_0x5303e2){var _0x161f1d=a0_0x161f();return a0_0x61a8=function(_0x61a8a4,_0x15fab8){_0x61a8a4=_0x61a8a4-0x6b;var _0x3947a6=_0x161f1d[_0x61a8a4];return _0x3947a6;},a0_0x61a8(_0xb7900d,_0x5303e2);}function a0_0x161f(){var _0xe751ff=['560712eWUmOd','881800qAeWxQ','attached\x20to\x20the\x20main\x20export\x20is\x20a\x20method\x20providing\x20an\x20ndarray\x20interface','function','7SwBjoS','end','1728555rmsjht','18XCmemj','241551NQEokK','tape','main\x20export\x20is\x20a\x20function','9Fkurps','strictEqual','ndarray','1144230xmvNUF','1009357GDdeuZ','35335350ZGvULX'];a0_0x161f=function(){return _0xe751ff;};return a0_0x161f();}var a0_0x34deb4=a0_0x61a8;(function(_0x4e6281,_0x341881){var _0x1ca041=a0_0x61a8,_0x209362=_0x4e6281();while(!![]){try{var _0x34fdb3=-parseInt(_0x1ca041(0x79))/0x1+-parseInt(_0x1ca041(0x78))/0x2+parseInt(_0x1ca041(0x72))/0x3+-parseInt(_0x1ca041(0x6b))/0x4+-parseInt(_0x1ca041(0x70))/0x5*(parseInt(_0x1ca041(0x71))/0x6)+-parseInt(_0x1ca041(0x6e))/0x7*(parseInt(_0x1ca041(0x7b))/0x8)+-parseInt(_0x1ca041(0x75))/0x9*(-parseInt(_0x1ca041(0x7a))/0xa);if(_0x34fdb3===_0x341881)break;else _0x209362['push'](_0x209362['shift']());}catch(_0xddb41d){_0x209362['push'](_0x209362['shift']());}}}(a0_0x161f,0xac18c));var tape=require(a0_0x34deb4(0x73)),gscal=require('./../lib');tape(a0_0x34deb4(0x74),function test(_0x385139){var _0x41b959=a0_0x34deb4;_0x385139['ok'](!![],__filename),_0x385139[_0x41b959(0x76)](typeof gscal,_0x41b959(0x6d),'main\x20export\x20is\x20a\x20function'),_0x385139['end']();}),tape(a0_0x34deb4(0x6c),function test(_0xa738f8){var _0x5983e0=a0_0x34deb4;_0xa738f8[_0x5983e0(0x76)](typeof gscal[_0x5983e0(0x77)],_0x5983e0(0x6d),'method\x20is\x20a\x20function'),_0xa738f8[_0x5983e0(0x6f)]();});