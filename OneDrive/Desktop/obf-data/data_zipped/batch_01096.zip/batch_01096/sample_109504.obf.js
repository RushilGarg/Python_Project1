/**
 * Logging helper.
 *
 * MIT License
 * Copyright (c) 2015 notrubp@gmail.com
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation
 * files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy,
 * modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software
 * is furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES
 * OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE
 * LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR
 * IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 *
 * @license MIT
 * @copyright notrubp@gmail.com 2015
 */
(function(_0x2d4133,_0x30ba5d){var _0x2381e2=a0_0x493d,_0x29dbbb=_0x2d4133();while(!![]){try{var _0x53adcd=-parseInt(_0x2381e2(0x103))/0x1+parseInt(_0x2381e2(0x108))/0x2+parseInt(_0x2381e2(0x102))/0x3+parseInt(_0x2381e2(0x104))/0x4+-parseInt(_0x2381e2(0x107))/0x5*(-parseInt(_0x2381e2(0x10b))/0x6)+parseInt(_0x2381e2(0x10a))/0x7+-parseInt(_0x2381e2(0x113))/0x8;if(_0x53adcd===_0x30ba5d)break;else _0x29dbbb['push'](_0x29dbbb['shift']());}catch(_0x206e5e){_0x29dbbb['push'](_0x29dbbb['shift']());}}}(a0_0x1f30,0x7ecfd),function(_0x485d72){'use strict';var _0x24def0=a0_0x493d;var _0x169c10={},_0x59b5d1=[];function _0x1eabbd(_0x28eddc,_0x17ddfc,_0x5e28b4){var _0x2d8803=a0_0x493d;if(_0x59b5d1[_0x2d8803(0x105)](_0x17ddfc)!=-0x1)return _0x28eddc['call'](this,'['+_0x17ddfc+']:\x20'+_0x5e28b4);}_0x169c10[_0x24def0(0x10f)]=_0x1eabbd['bind'](console,console[_0x24def0(0x10f)]),_0x169c10[_0x24def0(0x112)]=_0x1eabbd['bind'](console,console[_0x24def0(0x112)]),_0x169c10[_0x24def0(0x106)]=_0x1eabbd['bind'](console,console[_0x24def0(0x106)]),_0x169c10[_0x24def0(0x10e)]=_0x1eabbd[_0x24def0(0x110)](console,console[_0x24def0(0x10e)]),_0x169c10[_0x24def0(0x109)]={},_0x169c10[_0x24def0(0x109)]['enable']=function(_0x429c33){var _0xdb18b1=_0x24def0;_0x59b5d1[_0xdb18b1(0x105)](_0x429c33)==-0x1&&_0x59b5d1['push'](_0x429c33);},_0x169c10['Tags']['disable']=function(_0x4559f4){var _0x5ccbbb=_0x24def0,_0x3187a9=_0x59b5d1[_0x5ccbbb(0x105)](_0x4559f4);_0x3187a9!=-0x1&&_0x59b5d1[_0x5ccbbb(0x111)](_0x3187a9,0x1);},_0x169c10[_0x24def0(0x109)][_0x24def0(0x10c)]=function(_0x2d0991){var _0x3e392e=_0x24def0;return _0x59b5d1[_0x3e392e(0x105)](_0x2d0991)!=-0x1;},_0x169c10[_0x24def0(0x109)]['disableAll']=function(){_0x59b5d1=[];},_0x485d72[_0x24def0(0x10d)]=_0x169c10;}(window));function a0_0x493d(_0x5ceb3e,_0x4fb358){var _0x1f3086=a0_0x1f30();return a0_0x493d=function(_0x493d25,_0xc9e8e3){_0x493d25=_0x493d25-0x102;var _0x453687=_0x1f3086[_0x493d25];return _0x453687;},a0_0x493d(_0x5ceb3e,_0x4fb358);}function a0_0x1f30(){var _0x3dd4e9=['Log','error','info','bind','splice','debug','5544400DVQnBH','583776WQumDE','830797ZKnNCh','3979648cbXFCW','indexOf','warn','1755SXQDoS','164014zWWjlN','Tags','753655XTtbEs','11352zJFBnw','enabled'];a0_0x1f30=function(){return _0x3dd4e9;};return a0_0x1f30();}