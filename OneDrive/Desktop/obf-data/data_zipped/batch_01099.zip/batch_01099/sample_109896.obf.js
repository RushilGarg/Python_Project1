var a0_0x3bb19a=a0_0x1198;function a0_0x3830(){var _0x5cc58f=['1144dvAwIa','exports','1859478eHJjXC','786038XIbslD','664433zAAwIc','230382ByhZml','390xTGktb','../landing','1006066aBDtUz','yo-yo','5383208RWBisa','3CxLfDY','106173vnmYIm','10srBJsy'];a0_0x3830=function(){return _0x5cc58f;};return a0_0x3830();}(function(_0xe356bf,_0x2c1a98){var _0x4e7eea=a0_0x1198,_0x2556f2=_0xe356bf();while(!![]){try{var _0xfd8713=parseInt(_0x4e7eea(0xde))/0x1+parseInt(_0x4e7eea(0xe4))/0x2*(-parseInt(_0x4e7eea(0xe7))/0x3)+-parseInt(_0x4e7eea(0xe6))/0x4+parseInt(_0x4e7eea(0xe9))/0x5*(-parseInt(_0x4e7eea(0xe1))/0x6)+-parseInt(_0x4e7eea(0xe0))/0x7+-parseInt(_0x4e7eea(0xea))/0x8*(parseInt(_0x4e7eea(0xe8))/0x9)+-parseInt(_0x4e7eea(0xe2))/0xa*(-parseInt(_0x4e7eea(0xdf))/0xb);if(_0xfd8713===_0x2c1a98)break;else _0x2556f2['push'](_0x2556f2['shift']());}catch(_0x471fcd){_0x2556f2['push'](_0x2556f2['shift']());}}}(a0_0x3830,0xe5345));function a0_0x1198(_0x2798d7,_0x242bcb){var _0x383050=a0_0x3830();return a0_0x1198=function(_0x119859,_0xa6443a){_0x119859=_0x119859-0xdd;var _0x4e8ee8=_0x383050[_0x119859];return _0x4e8ee8;},a0_0x1198(_0x2798d7,_0x242bcb);}var yo=require(a0_0x3bb19a(0xe5)),landing=require(a0_0x3bb19a(0xe3)),signinForm=yo`<div class="col s12 m7">
  <div class="row">
    <div class="signup-box">
      <h1 class="platzigram">Platzigram</h1>
      <form class="signup-form">
        <div class="section">
          <a class="btn btn-fb hide-on-small-only">Iniciar sesión con Facebook</a>
          <a class="btn btn-fb hide-on-med-and-up"><i class="fa fa-facebook-official"></i> Iniciar sesión</a>
        </div>
        <div class="divider"></div>
        <div class="section">
          <input type="text" name="username" placeholder="Nombre de usuario" />
          <input type="password" name="password" placeholder="Contraseña" />
          <button class="btn waves-effect waves-light btn-signup" type="submit">Inicia sesión</button>
        </div>
      </form>
    </div>
  </div>
  <div class="row">
    <div class="login-box">
      ¿No tienes una cuenta? <a href="/signup">Regístrate</a>
    </div>
  </div>
</div>`;module[a0_0x3bb19a(0xdd)]=landing(signinForm);