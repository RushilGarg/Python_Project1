/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x567a(){var _0x5e748f=['168328ObBOOt','4634210mgPhWF','605410QzWoMP','509667laYEoi','./../src/addon.node','9wwOAQX','2335320yelpQa','exports','4OcWkRI','2071620ByflKL','175IpwnGy','161974BjATgm'];a0_0x567a=function(){return _0x5e748f;};return a0_0x567a();}var a0_0x4db1dd=a0_0xd18c;(function(_0x4f336c,_0x460e21){var _0x497c14=a0_0xd18c,_0x3b7c0f=_0x4f336c();while(!![]){try{var _0x208fd7=-parseInt(_0x497c14(0x1d7))/0x1+parseInt(_0x497c14(0x1e0))/0x2+parseInt(_0x497c14(0x1d8))/0x3*(-parseInt(_0x497c14(0x1dd))/0x4)+parseInt(_0x497c14(0x1de))/0x5+-parseInt(_0x497c14(0x1db))/0x6+parseInt(_0x497c14(0x1df))/0x7*(parseInt(_0x497c14(0x1d5))/0x8)+-parseInt(_0x497c14(0x1da))/0x9*(-parseInt(_0x497c14(0x1d6))/0xa);if(_0x208fd7===_0x460e21)break;else _0x3b7c0f['push'](_0x3b7c0f['shift']());}catch(_0x37e601){_0x3b7c0f['push'](_0x3b7c0f['shift']());}}}(a0_0x567a,0x4e2ee));function a0_0xd18c(_0x51f863,_0x47d91d){var _0x567a0a=a0_0x567a();return a0_0xd18c=function(_0xd18c87,_0x1d9192){_0xd18c87=_0xd18c87-0x1d5;var _0x3923be=_0x567a0a[_0xd18c87];return _0x3923be;},a0_0xd18c(_0x51f863,_0x47d91d);}var addon=require(a0_0x4db1dd(0x1d9));function smskrange(_0x64943b,_0x5a01bd,_0xf2ade6,_0x5b1b5a,_0x5be74b){return addon(_0x64943b,_0x5a01bd,_0xf2ade6,_0x5b1b5a,_0x5be74b);}module[a0_0x4db1dd(0x1dc)]=smskrange;