/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x2aad75=a0_0x21ed;function a0_0x577a(){var _0x5d9928=['2BbqhGX','div','10hStWha','label','1805295ddwTfO','delegate','display','model_','title','className','none','15xbdoJj','overlay','block','2589576pIulXO','open','6301rOcnPo','17436dANVFU','opened','Re-renders\x20the\x20overlay\x20and\x20makes\x20sure\x20it\x20is\x20open.\x20Safe\x20to\x20call\x20multiple\x20times.','style','2381561WxdEuR','11344581sczLGU','foam.navigator.views','378964frWKyl'];a0_0x577a=function(){return _0x5d9928;};return a0_0x577a();}function a0_0x21ed(_0x53fbb8,_0x5e0d10){var _0x577aad=a0_0x577a();return a0_0x21ed=function(_0x21ed9c,_0x11e45f){_0x21ed9c=_0x21ed9c-0x17a;var _0x45234f=_0x577aad[_0x21ed9c];return _0x45234f;},a0_0x21ed(_0x53fbb8,_0x5e0d10);}(function(_0x511400,_0x357117){var _0x5ecb52=a0_0x21ed,_0x1fe34f=_0x511400();while(!![]){try{var _0x381ab8=parseInt(_0x5ecb52(0x181))/0x1*(parseInt(_0x5ecb52(0x18a))/0x2)+parseInt(_0x5ecb52(0x17c))/0x3*(parseInt(_0x5ecb52(0x189))/0x4)+parseInt(_0x5ecb52(0x18e))/0x5+-parseInt(_0x5ecb52(0x182))/0x6+parseInt(_0x5ecb52(0x186))/0x7+parseInt(_0x5ecb52(0x17f))/0x8+-parseInt(_0x5ecb52(0x187))/0x9*(parseInt(_0x5ecb52(0x18c))/0xa);if(_0x381ab8===_0x357117)break;else _0x1fe34f['push'](_0x1fe34f['shift']());}catch(_0x18514e){_0x1fe34f['push'](_0x1fe34f['shift']());}}}(a0_0x577a,0x3afa2),CLASS({'name':'OverlayView','package':a0_0x2aad75(0x188),'extendsModel':'foam.ui.View','properties':[{'name':a0_0x2aad75(0x18f)},{'name':a0_0x2aad75(0x192),'defaultValueFn':function(){var _0x4e662b=a0_0x2aad75;return this['delegate']&&(this[_0x4e662b(0x18f)][_0x4e662b(0x18d)]||this[_0x4e662b(0x18f)][_0x4e662b(0x191)]&&this[_0x4e662b(0x18f)]['model_'][_0x4e662b(0x18d)]);}},{'name':a0_0x2aad75(0x183),'defaultValue':![]},{'name':'tagName','defaultValue':a0_0x2aad75(0x18b)},{'name':a0_0x2aad75(0x17a),'defaultValue':a0_0x2aad75(0x17d)}],'listeners':[{'name':a0_0x2aad75(0x180),'documentation':a0_0x2aad75(0x184),'code':function(_0x54deba){var _0x13847b=a0_0x2aad75;if(_0x54deba)this[_0x13847b(0x18f)]=_0x54deba;this[_0x13847b(0x183)]=!![],this['updateHTML'](),this['$'][_0x13847b(0x185)][_0x13847b(0x190)]=_0x13847b(0x17e);}},{'name':'close','code':function(){var _0x13b729=a0_0x2aad75;this[_0x13b729(0x183)]=![],this['$'][_0x13b729(0x185)]['display']=_0x13b729(0x17b);}}],'templates':[function CSS(){},function toInnerHTML(){}]}));