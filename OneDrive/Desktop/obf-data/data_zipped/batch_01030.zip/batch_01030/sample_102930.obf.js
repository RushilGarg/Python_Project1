/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2aad7e=a0_0x3787;function a0_0x44fb(){var _0x408607=['2246632VWoxVr','54fEMdxi','µ:\x20%d,\x20s:\x20%d,\x20mode(X;µ,s):\x20%d','968605sAANfF','46950EFWaIW','toFixed','log','10ZQGLNi','4111479ZDEQEe','./../lib','534513SYXdiP','8481240ttsfAG','374087mXavwZ','4JzDAZU'];a0_0x44fb=function(){return _0x408607;};return a0_0x44fb();}(function(_0x5d2913,_0x4d6919){var _0x55b130=a0_0x3787,_0x1c4998=_0x5d2913();while(!![]){try{var _0x31f1ec=-parseInt(_0x55b130(0x196))/0x1+-parseInt(_0x55b130(0x19a))/0x2*(-parseInt(_0x55b130(0x19d))/0x3)+-parseInt(_0x55b130(0x192))/0x4*(parseInt(_0x55b130(0x197))/0x5)+-parseInt(_0x55b130(0x194))/0x6*(-parseInt(_0x55b130(0x19f))/0x7)+-parseInt(_0x55b130(0x193))/0x8+-parseInt(_0x55b130(0x19b))/0x9+parseInt(_0x55b130(0x19e))/0xa;if(_0x31f1ec===_0x4d6919)break;else _0x1c4998['push'](_0x1c4998['shift']());}catch(_0x3597f6){_0x1c4998['push'](_0x1c4998['shift']());}}}(a0_0x44fb,0x7b1e5));function a0_0x3787(_0x3e6a92,_0x4c1aee){var _0x44fb16=a0_0x44fb();return a0_0x3787=function(_0x3787ce,_0x19b299){_0x3787ce=_0x3787ce-0x192;var _0x57c093=_0x44fb16[_0x3787ce];return _0x57c093;},a0_0x3787(_0x3e6a92,_0x4c1aee);}var randu=require('@stdlib/random/base/randu'),mode=require(a0_0x2aad7e(0x19c)),mu,s,y,i;for(i=0x0;i<0xa;i++){mu=randu()*0xa-0x5,s=randu()*0x14,y=mode(mu,s),console[a0_0x2aad7e(0x199)](a0_0x2aad7e(0x195),mu[a0_0x2aad7e(0x198)](0x4),s[a0_0x2aad7e(0x198)](0x4),y[a0_0x2aad7e(0x198)](0x4));}