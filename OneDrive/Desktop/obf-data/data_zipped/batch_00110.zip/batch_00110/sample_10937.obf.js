/*  
 * JCE Editor                 2.2.0
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    20 June 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
function a0_0x4ad4(_0x4866a8,_0xaecf78){var _0x5d5010=a0_0x5d50();return a0_0x4ad4=function(_0x4ad41b,_0x4cb38b){_0x4ad41b=_0x4ad41b-0x127;var _0x4092c0=_0x5d5010[_0x4ad41b];return _0x4092c0;},a0_0x4ad4(_0x4866a8,_0xaecf78);}(function(_0x786b36,_0x5a037d){var _0x40c98e=a0_0x4ad4,_0x54bae2=_0x786b36();while(!![]){try{var _0x220e51=parseInt(_0x40c98e(0x12a))/0x1+-parseInt(_0x40c98e(0x128))/0x2*(parseInt(_0x40c98e(0x12b))/0x3)+parseInt(_0x40c98e(0x129))/0x4+parseInt(_0x40c98e(0x132))/0x5+-parseInt(_0x40c98e(0x12d))/0x6+parseInt(_0x40c98e(0x12c))/0x7+-parseInt(_0x40c98e(0x130))/0x8*(parseInt(_0x40c98e(0x127))/0x9);if(_0x220e51===_0x5a037d)break;else _0x54bae2['push'](_0x54bae2['shift']());}catch(_0x2fd509){_0x54bae2['push'](_0x54bae2['shift']());}}}(a0_0x5d50,0x44227),(function(){var _0x241ee0={'types':{},'add':function(_0x5d6155,_0x5a27f2){return this[_0x5d6155]=_0x5a27f2,this[_0x5d6155];},'addType':function(_0x43ba4d){this['types'][_0x43ba4d]={};},'addExtension':function(_0x89705c,_0x7d68f5,_0x360025){var _0x5c2cfb=a0_0x4ad4;typeof this['types'][_0x89705c]==_0x5c2cfb(0x133)&&this[_0x5c2cfb(0x12e)](_0x89705c),this[_0x5c2cfb(0x131)][_0x89705c][_0x7d68f5]=_0x360025;},'getType':function(_0x5ccd5b){var _0x169746=a0_0x4ad4;return this[_0x169746(0x131)][_0x5ccd5b]||![];},'getExtension':function(_0x6f5351,_0x1e2b70){var _0x1c5643=a0_0x4ad4,_0x5a8982=this[_0x1c5643(0x12f)](_0x6f5351);return _0x5a8982[_0x1e2b70];}};window['WFExtensions']=_0x241ee0;}()));function a0_0x5d50(){var _0x1265b9=['undefined','3195cZGUUy','10vCKGJX','1269908qknMNI','486138iPsMFE','19707eEbmPD','3024350ungiCT','1150146lyJBeq','addType','getType','21584hvLyPB','types','1128700HUFtFu'];a0_0x5d50=function(){return _0x1265b9;};return a0_0x5d50();}