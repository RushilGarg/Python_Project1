/**
 * @license
 * Visual Blocks Language
 *
 * Copyright 2012 Google Inc.
 * https://developers.google.com/blockly/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';var a0_0x1202b0=a0_0x129b;(function(_0x3bb932,_0x1dc494){var _0x185bd2=a0_0x129b,_0x4dab83=_0x3bb932();while(!![]){try{var _0x44cbf8=-parseInt(_0x185bd2(0x1c8))/0x1*(-parseInt(_0x185bd2(0x1c7))/0x2)+-parseInt(_0x185bd2(0x1be))/0x3+-parseInt(_0x185bd2(0x1c0))/0x4+-parseInt(_0x185bd2(0x1b9))/0x5*(parseInt(_0x185bd2(0x1c3))/0x6)+-parseInt(_0x185bd2(0x1c9))/0x7*(parseInt(_0x185bd2(0x1cd))/0x8)+-parseInt(_0x185bd2(0x1cf))/0x9+parseInt(_0x185bd2(0x1c1))/0xa*(parseInt(_0x185bd2(0x1ba))/0xb);if(_0x44cbf8===_0x1dc494)break;else _0x4dab83['push'](_0x4dab83['shift']());}catch(_0x14f0ff){_0x4dab83['push'](_0x4dab83['shift']());}}}(a0_0x19f6,0xf2b02));function a0_0x129b(_0x22f55f,_0x1f62e4){var _0x19f64a=a0_0x19f6();return a0_0x129b=function(_0x129b04,_0x2d0f86){_0x129b04=_0x129b04-0x1b9;var _0x46e7bc=_0x19f64a[_0x129b04];return _0x46e7bc;},a0_0x129b(_0x22f55f,_0x1f62e4);}goog[a0_0x1202b0(0x1bb)](a0_0x1202b0(0x1c4)),goog[a0_0x1202b0(0x1bd)](a0_0x1202b0(0x1cb)),Blockly['JavaScript'][a0_0x1202b0(0x1d0)]=function(_0x1523dd){var _0x3c0bf7=a0_0x1202b0,_0x37a799=Blockly[_0x3c0bf7(0x1cc)][_0x3c0bf7(0x1d5)][_0x3c0bf7(0x1d4)](_0x1523dd['getFieldValue'](_0x3c0bf7(0x1c2)),Blockly['Variables'][_0x3c0bf7(0x1d2)]);return[_0x37a799,Blockly['JavaScript']['ORDER_ATOMIC']];},Blockly['JavaScript'][a0_0x1202b0(0x1d1)]=function(_0x48b1cf){var _0x3ddf58=a0_0x1202b0,_0x4f1952=Blockly[_0x3ddf58(0x1cc)][_0x3ddf58(0x1bf)](_0x48b1cf,'VALUE',Blockly[_0x3ddf58(0x1cc)][_0x3ddf58(0x1c5)])||'0',_0x5ca25f=Blockly[_0x3ddf58(0x1cc)][_0x3ddf58(0x1d5)][_0x3ddf58(0x1d4)](_0x48b1cf[_0x3ddf58(0x1ce)](_0x3ddf58(0x1c2)),Blockly['Variables'][_0x3ddf58(0x1d2)]);return _0x5ca25f+_0x3ddf58(0x1d3)+_0x4f1952+';\x0a';},Blockly['JavaScript'][a0_0x1202b0(0x1c6)]=function(_0x4b2ca5){var _0x34e6da=a0_0x1202b0;return _0x4b2ca5[_0x34e6da(0x1ca)]()?Blockly['JavaScript'][_0x34e6da(0x1d0)](_0x4b2ca5):'';},Blockly[a0_0x1202b0(0x1cc)][a0_0x1202b0(0x1bc)]=function(_0x3790d4){var _0x374c3c=a0_0x1202b0;return _0x3790d4[_0x374c3c(0x1ca)]()?Blockly[_0x374c3c(0x1cc)][_0x374c3c(0x1d1)](_0x3790d4):'';};function a0_0x19f6(){var _0x8594bc=['variables_set','NAME_TYPE','\x20=\x20','getName','variableDB_','76990Oixwoo','11DlTqMP','provide','local_var_set','require','5842872WTeMls','valueToCode','2059128dDZpks','35318730TuIGrd','VAR','90YdFowK','Blockly.JavaScript.variables','ORDER_ASSIGNMENT','local_var_get','13154ZXphXm','181HeRGhW','3327002SxbwAF','isFromAnyDef','Blockly.JavaScript','JavaScript','16JDsATq','getFieldValue','758808iDPphw','variables_get'];a0_0x19f6=function(){return _0x8594bc;};return a0_0x19f6();}