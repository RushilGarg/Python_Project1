/**
 * @license
 * Copyright 2019 Google LLC.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * Code distributed by Google as part of this project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
function a0_0x44bf(){const _0x52d61e=['removeAttribute','main','7683641zzBMrw','strategy-explorer','stack','1650RwYkiH','customElements','2391702bxcBzJ','append','64881urXKkH','arcs-stores','3GZXZKE','arcs-pec-log','observe','offsetHeight','arcs-tracing','2483892ekPBmT','10533880SuJiFr','arcs-environment','component','arcs-planning','arcs-devtools-app','arcs-overview','7125215CRkpcb','active','hide','template','registerComponent','entries','6DnoLmt','arcs-hcr-list','1355375oQOhLJ','ready','init','createElement','show'];a0_0x44bf=function(){return _0x52d61e;};return a0_0x44bf();}const a0_0x2e6179=a0_0x3470;(function(_0x5668cd,_0x2d48a8){const _0x2a7ac9=a0_0x3470,_0x29655e=_0x5668cd();while(!![]){try{const _0x51d09f=-parseInt(_0x2a7ac9(0x128))/0x1+parseInt(_0x2a7ac9(0x110))/0x2*(-parseInt(_0x2a7ac9(0x114))/0x3)+parseInt(_0x2a7ac9(0x119))/0x4+-parseInt(_0x2a7ac9(0x120))/0x5*(-parseInt(_0x2a7ac9(0x126))/0x6)+parseInt(_0x2a7ac9(0x10b))/0x7+parseInt(_0x2a7ac9(0x11a))/0x8+parseInt(_0x2a7ac9(0x112))/0x9*(-parseInt(_0x2a7ac9(0x10e))/0xa);if(_0x51d09f===_0x2d48a8)break;else _0x29655e['push'](_0x29655e['shift']());}catch(_0x56f9c3){_0x29655e['push'](_0x29655e['shift']());}}}(a0_0x44bf,0xafb57));import{PolymerElement}from'../deps/@polymer/polymer/polymer-element.js';import{MessengerMixin}from'./arcs-shared.js';import{html}from'../deps/@polymer/polymer/lib/utils/html-tag.js';import'../deps/golden-layout/src/css/goldenlayout-base.css.js';import'../deps/golden-layout/src/css/goldenlayout-light-theme.css.js';import'./arcs-overview.js';import'./arcs-stores.js';import'./arcs-planning.js';import'./arcs-communication-channel.js';import'./arcs-environment.js';import'./arcs-notifications.js';import'./arcs-tracing.js';import'./arcs-pec-log.js';import'./arcs-hcr-list.js';import'./arcs-selector.js';import'./strategy-explorer/strategy-explorer.js';import'./arcs-recipe-editor.js';import'./arcs-connection-status.js';class ArcsDevtoolsApp extends MessengerMixin(PolymerElement){static get[a0_0x2e6179(0x123)](){return html`
    <style include="shared-styles goldenlayout-base.css goldenlayout-light-theme.css">
      :host {
        height: 100vh;
        display: flex;
        flex-direction: column;
      }
      header {
        height: 27px;
        flex-grow: 0;
      }
      arcs-notifications:not([visible])  + [divider] {
        display: none;
      }
      #main {
        position: relative;
        flex-grow: 1;
      }
      /* TODO: Create our own golden-layout theme instead of overriding. */
      .lm_content {
        background: white;
        position: relative;
        overflow: auto;
      }
      .lm_header .lm_tab {
        /* Fixing uneven padding caused by missing close button.
           This can be reverted once we allow closing and re-opening tools. */
        padding: 0 10px 4px;
      }
    </style>
    <arcs-communication-channel></arcs-communication-channel>
    <arcs-connection-status></arcs-connection-status>
    <header id="header" class="header">
      <div section>
        <arcs-notifications></arcs-notifications><div divider></div>
        <arcs-selector active-page="[[routeData.page]]"></arcs-selector>
      </div>
    </header>
    <div id="main"></div>
`;}static get['is'](){const _0x511f9f=a0_0x2e6179;return _0x511f9f(0x11e);}[a0_0x2e6179(0x129)](){const _0x50ac0d=a0_0x2e6179;super[_0x50ac0d(0x129)]();const _0x1dcdec={'Overview':_0x50ac0d(0x11f),'Environment':_0x50ac0d(0x11b),'Storage':_0x50ac0d(0x113),'Execution\x20Log':_0x50ac0d(0x115),'Strategizer':_0x50ac0d(0x10c),'Planner':_0x50ac0d(0x11d),'Tracing':_0x50ac0d(0x118),'Editor':'arcs-recipe-editor','HCR':_0x50ac0d(0x127)},_0x33044b=new GoldenLayout({'content':[{'type':_0x50ac0d(0x10d),'content':Object[_0x50ac0d(0x125)](_0x1dcdec)['map'](([_0x2e480d])=>({'type':_0x50ac0d(0x11c),'componentName':_0x2e480d,'isClosable':![]}))}],'settings':{'showPopoutIcon':![]}},this['$'][_0x50ac0d(0x10a)]);for(const [_0x6812cb,_0x25f3a2]of Object[_0x50ac0d(0x125)](_0x1dcdec)){_0x33044b[_0x50ac0d(0x124)](_0x6812cb,function(_0x556422){const _0x60c99d=_0x50ac0d,_0xa9b5b3=document[_0x60c99d(0x12b)](_0x25f3a2);_0x556422['getElement']()[_0x60c99d(0x111)](_0xa9b5b3),_0x556422['on'](_0x60c99d(0x108),()=>_0xa9b5b3['setAttribute'](_0x60c99d(0x121),'')),_0x556422['on'](_0x60c99d(0x122),()=>_0xa9b5b3[_0x60c99d(0x109)](_0x60c99d(0x121)));});}_0x33044b[_0x50ac0d(0x12a)](),new ResizeObserver(_0x5a3823=>{const _0x80ee3a=_0x50ac0d,{height:_0x3d4fd2,width:_0x4c5254}=_0x5a3823[0x0]['contentRect'];_0x33044b['updateSize'](_0x4c5254,_0x3d4fd2-this['$']['header'][_0x80ee3a(0x117)]);})[_0x50ac0d(0x116)](document['body']);}}function a0_0x3470(_0x35afe9,_0x4ca6df){const _0x44bf5e=a0_0x44bf();return a0_0x3470=function(_0x347070,_0xdc6312){_0x347070=_0x347070-0x108;let _0x2eab27=_0x44bf5e[_0x347070];return _0x2eab27;},a0_0x3470(_0x35afe9,_0x4ca6df);}window[a0_0x2e6179(0x10f)]['define'](ArcsDevtoolsApp['is'],ArcsDevtoolsApp);