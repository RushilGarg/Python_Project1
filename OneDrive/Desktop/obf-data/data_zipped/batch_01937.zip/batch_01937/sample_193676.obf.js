/**
 * This file is part of Moodle - http://moodle.org/
 *
 * Moodle is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * Moodle is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with Moodle.  If not, see <http://www.gnu.org/licenses/>.
 *
 * @package   theme_snap
 * @copyright Copyright (c) 2016 Open LMS (https://www.openlms.net)
 * @license   http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
var a0_0x38010d=a0_0x455d;(function(_0x7a8237,_0x53194c){var _0x5b49d9=a0_0x455d,_0x2ad97c=_0x7a8237();while(!![]){try{var _0x161b72=-parseInt(_0x5b49d9(0xbf))/0x1+parseInt(_0x5b49d9(0xc8))/0x2+-parseInt(_0x5b49d9(0xbd))/0x3+parseInt(_0x5b49d9(0xb8))/0x4+parseInt(_0x5b49d9(0xbc))/0x5*(parseInt(_0x5b49d9(0xc4))/0x6)+parseInt(_0x5b49d9(0xba))/0x7+-parseInt(_0x5b49d9(0xc6))/0x8;if(_0x161b72===_0x53194c)break;else _0x2ad97c['push'](_0x2ad97c['shift']());}catch(_0x5acd50){_0x2ad97c['push'](_0x2ad97c['shift']());}}}(a0_0x2628,0xba476),define([a0_0x38010d(0xc0)],function(_0x14d24c){var _0x10a33c=null;return{'whenTrue':function(_0x11ae7d,_0x2ba47e,_0x20e4ee,_0x1bfffb,_0x44f3c6){_0x1bfffb=!_0x1bfffb?0xa:_0x1bfffb,_0x44f3c6=!_0x44f3c6?0x0:_0x44f3c6+0x1;if(_0x44f3c6>_0x1bfffb){_0x20e4ee&&_0x2ba47e();return;}if(_0x11ae7d())_0x2ba47e();else{var _0x78e1b9=this;window['setTimeout'](function(){var _0x47af6e=a0_0x455d;_0x78e1b9[_0x47af6e(0xc3)](_0x11ae7d,_0x2ba47e,_0x20e4ee,_0x1bfffb,_0x44f3c6);},0xc8);}},'scrollToElement':function(_0x3ed511){var _0x5efafb=a0_0x455d,_0x5db65b=_0x14d24c('#mr-nav')['outerHeight']();if(!_0x3ed511[_0x5efafb(0xc1)])return;if(_0x3ed511[_0x5efafb(0xc1)]>0x1)return;var _0x51647f=_0x3ed511[_0x5efafb(0xc5)]()['top']-_0x5db65b;_0x14d24c(_0x5efafb(0xbe))['animate']({'scrollTop':_0x51647f},0x258);},'supportsSessionStorage':function(){var _0x524e20=a0_0x455d;if(_0x10a33c!==null)return _0x10a33c;if(typeof window[_0x524e20(0xc7)]===_0x524e20(0xbb))try{window['sessionStorage'][_0x524e20(0xb9)](_0x524e20(0xc7),0x1),window[_0x524e20(0xc7)][_0x524e20(0xc2)]('sessionStorage'),_0x10a33c=!![];}catch(_0x5a003b){_0x10a33c=![];}return _0x10a33c;}};}));function a0_0x455d(_0x4efa0e,_0x55d66e){var _0x26288b=a0_0x2628();return a0_0x455d=function(_0x455d21,_0x1af096){_0x455d21=_0x455d21-0xb8;var _0x5ee145=_0x26288b[_0x455d21];return _0x5ee145;},a0_0x455d(_0x4efa0e,_0x55d66e);}function a0_0x2628(){var _0x138adf=['setItem','2064853LWmOHv','object','15CgLaDu','2655006Doxtpc','html,\x20body','148823yjeTDD','jquery','length','removeItem','whenTrue','888108uYPTta','offset','3128696FQEJWl','sessionStorage','1166680GgRifb','3462148UAefiV'];a0_0x2628=function(){return _0x138adf;};return a0_0x2628();}