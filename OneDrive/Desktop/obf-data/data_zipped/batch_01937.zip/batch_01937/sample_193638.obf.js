/**
 * EOSS catalog system
 *
 * The model for a sensor entity
 *
 * @summary   The model for a sensor entity
 *
 * @author     Steffen Gebhardt, Thilo Wehrmann
 * @copyright  Copyright 2016, EOSS GmbH
 * @version    1.0.0
 * @license    GPL
 */
var a0_0x2d11ef=a0_0x44eb;function a0_0x44eb(_0x259689,_0x569eec){var _0x2c5489=a0_0x2c54();return a0_0x44eb=function(_0x44eb8c,_0x3c672f){_0x44eb8c=_0x44eb8c-0x17e;var _0x34ee8c=_0x2c5489[_0x44eb8c];return _0x34ee8c;},a0_0x44eb(_0x259689,_0x569eec);}function a0_0x2c54(){var _0x2d78c8=['EossEOCatalog.model.Sensors','165272GZnaDA','12cHtCel','378134vnApAk','1370104ZavuPw','219261yYulVP','169806TQmngX','1403390HbkhTM','name','Ext.data.Model','define','134919ojLrIU'];a0_0x2c54=function(){return _0x2d78c8;};return a0_0x2c54();}(function(_0x4e0a6e,_0x5965e4){var _0x188518=a0_0x44eb,_0x4ddb31=_0x4e0a6e();while(!![]){try{var _0x237d23=-parseInt(_0x188518(0x182))/0x1+-parseInt(_0x188518(0x17f))/0x2+-parseInt(_0x188518(0x187))/0x3+parseInt(_0x188518(0x180))/0x4+parseInt(_0x188518(0x183))/0x5+parseInt(_0x188518(0x17e))/0x6*(-parseInt(_0x188518(0x181))/0x7)+parseInt(_0x188518(0x189))/0x8;if(_0x237d23===_0x5965e4)break;else _0x4ddb31['push'](_0x4ddb31['shift']());}catch(_0x2d61f4){_0x4ddb31['push'](_0x4ddb31['shift']());}}}(a0_0x2c54,0x2b4db),Ext[a0_0x2d11ef(0x186)](a0_0x2d11ef(0x188),{'extend':a0_0x2d11ef(0x185),'fields':[{'name':'id','type':'int'},{'name':a0_0x2d11ef(0x184),'type':'string'}]}));