const a0_0x19c312=a0_0x394f;(function(_0x892264,_0x24882b){const _0x52cb3e=a0_0x394f,_0xb271e5=_0x892264();while(!![]){try{const _0x37acd0=parseInt(_0x52cb3e(0x1cb))/0x1*(-parseInt(_0x52cb3e(0x1d0))/0x2)+parseInt(_0x52cb3e(0x1d7))/0x3+parseInt(_0x52cb3e(0x1d8))/0x4+-parseInt(_0x52cb3e(0x1d4))/0x5+parseInt(_0x52cb3e(0x1cf))/0x6+-parseInt(_0x52cb3e(0x1da))/0x7*(parseInt(_0x52cb3e(0x1cc))/0x8)+parseInt(_0x52cb3e(0x1cd))/0x9;if(_0x37acd0===_0x24882b)break;else _0xb271e5['push'](_0xb271e5['shift']());}catch(_0x53e6e4){_0xb271e5['push'](_0xb271e5['shift']());}}}(a0_0x20da,0x3bddf));function a0_0x394f(_0x49f294,_0x34b755){const _0x20da6d=a0_0x20da();return a0_0x394f=function(_0x394f15,_0xd1662d){_0x394f15=_0x394f15-0x1ca;let _0x35b341=_0x20da6d[_0x394f15];return _0x35b341;},a0_0x394f(_0x49f294,_0x34b755);}import a0_0x34ebff,{keyframes}from'styled-components';const block=a0_0x19c312(0x1d3),Frame=a0_0x34ebff[a0_0x19c312(0x1d9)]`
  margin: auto;
  padding: 10px 0;
  background-color: #d8d8d8;
  h1 {
    margin: 0 0 5px 0;
    ${block}
    font-size: 150%;
    color: #127509;
    user-select: none;
    > img {
      border-radius: 0 0 10px 10px;
    }
    &:hover {
      color: #19aa0b;
      cursor: default;
    }
    > span {
      position: relative;
      top: -15px;
      left: 18px;
    }
  }
  .inspect {
    padding-bottom: ${_0x14a4a=>_0x14a4a['clear']?a0_0x19c312(0x1d5):'0px'};
  }
  .menu-bottom {
    @media print {
      display: none !important;
    }
    /* flex start */
    display: flex;
    flex-direction: row;
    flex-wrap: nowrap;
    justify-content: space-between;
    align-content: center;
    align-items: center;
    /* flex end */

    background: #4a4a4a;
    box-shadow: 0px -2px 16px 0px rgba(0,0,0,0.75);
    height: 35px;
    margin: 0;
    position: fixed;
    top: calc(100vh - 35px);
    width: calc(100%);
    > div:nth-child(1) {
      /* flex start */
      order: 0;
      flex: 0 1 auto !important;
      align-self: auto;
      /* flex end */

      > .socketid {
        background: white;
        color: red;
        cursor: pointer;
        font-family: monospace;
        margin-left: 2px;
        padding: 2px;
        white-space: nowrap;
        &:before {
          content: 'ID: ';
        }
      }
    }
    > div:nth-child(2) {
      /* flex start */
      order: 0;
      flex: 1 1 auto;
      align-self: auto;
      /* flex end */
      background: #4a4a4a;
      height: 35px;
      z-index: 100;
      padding:0 15px;
      > ul.group-title {
        margin: 0;
        padding: 0;
        list-style-type: none;
        white-space: nowrap;
        > li.toggle {
          background: ${_0x2a889a=>_0x2a889a[a0_0x19c312(0x1d1)]?a0_0x19c312(0x1d6):a0_0x19c312(0x1ce)};
        }
        > li {
          background: #7e7e7e;
          border-radius: 2px;
          box-shadow: 1px 1px 6px 0px rgba(0,0,0,0.45);
          box-sizing: border-box;
          cursor: pointer;          
          display: inline-block;
          font-size: 13px;
          height: 26px;
          line-height: 19px;
          margin: 4px 4px 0;
          padding: 4px 10px;
          user-select: none;
          &:hover {
            //background: #626262;
            text-shadow: 0px 0px 6px rgba(255, 255, 255, 1);
            box-shadow: 1px 1px 6px 0px rgba(0,0,0,0.75);
          }
          &:active {
            box-shadow: -1px -1px 6px 0px rgba(0,0,0,0.75);
          }
        }
        > li.none {
          background: none;
          box-shadow: none;
          margin: 0;
          > label {
            div {
              display: table-cell;
              margin: 0 3px;
            }
          }
        }
      }
    }
  }
`,animeProg=keyframes`
  from {
    background-position-x: -92px;
  }
  to {
    background-position-x: 0px;
  }
`,ClearAll=a0_0x34ebff['li']`
  animation: ${_0x27819c=>_0x27819c[a0_0x19c312(0x1db)]?animeProg+a0_0x19c312(0x1ca):a0_0x19c312(0x1d2)};
  background: linear-gradient(
      to right,
      rgb(255, 255, 255) 0%, 
      rgb(196, 196, 196) 100%
    )
    #7e7e7e 
    no-repeat !important;
  background-size: 100% 2px !important;
  background-position: -92px 100% !important;
`,ConfirmClear=a0_0x34ebff['li']`
  color: red;
  margin-left: -3px !important;
  display: ${_0x107203=>_0x107203[a0_0x19c312(0x1db)]?'inline-block\x20!important;':'none\x20!important;'};
`;export{Frame,ClearAll,ConfirmClear};function a0_0x20da(){const _0x476241=['167460iqSfkn','1651020EKXVWh','div','1688092geBOmI','show','\x2010s\x20linear\x20!important','108464FUyJXy','16PAwfim','2348991vxhquI','#7e7e7e','2472114aRcnST','2NnEZHM','toggle','none','\x0a\x20\x20margin:\x200\x2025px;\x0a\x20\x20width:\x20calc(100%\x20-\x2050px);\x0a','1528010Casqrw','30px','#595959'];a0_0x20da=function(){return _0x476241;};return a0_0x20da();}