/**
 * SyntaxHighlighter
 * http://alexgorbatchev.com/
 *
 * SyntaxHighlighter is donationware. If you are using it, please donate.
 * http://alexgorbatchev.com/wiki/SyntaxHighlighter:Donate
 *
 * @version
 * 2.1.382 (June 24 2010)
 * 
 * @copyright
 * Copyright (C) 2004-2009 Alex Gorbatchev.
 *
 * @license
 * This file is part of SyntaxHighlighter.
 * 
 * SyntaxHighlighter is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SyntaxHighlighter is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SyntaxHighlighter.  If not, see <http://www.gnu.org/copyleft/lesser.html>.
 */
function a0_0x3a26(_0x46c139,_0x268aca){var _0x4b406b=a0_0x4b40();return a0_0x3a26=function(_0x3a26c3,_0x39266c){_0x3a26c3=_0x3a26c3-0x155;var _0x8a812b=_0x4b406b[_0x3a26c3];return _0x8a812b;},a0_0x3a26(_0x46c139,_0x268aca);}function a0_0x4b40(){var _0x5ca2bc=['keyword','shell','exec\x20exit\x20expand\x20export\x20expr\x20false\x20fdformat\x20fdisk\x20fg\x20fgrep\x20file\x20find\x20fmt\x20fold\x20format\x20','2671688yjclCU','uname\x20unexpand\x20uniq\x20units\x20unset\x20unshar\x20useradd\x20usermod\x20users\x20uuencode\x20uudecode\x20v\x20vdir\x20','getKeywords','alias\x20apropos\x20awk\x20basename\x20bash\x20bc\x20bg\x20builtin\x20bzip2\x20cal\x20cat\x20cd\x20cfdisk\x20chgrp\x20chmod\x20chown\x20chroot','replace','mv\x20netstat\x20nice\x20nl\x20nohup\x20nslookup\x20open\x20op\x20passwd\x20paste\x20pathchk\x20ping\x20popd\x20pr\x20printcap\x20','bash','14263340fWLfXG','vi\x20watch\x20wc\x20whereis\x20which\x20who\x20whoami\x20Wget\x20xargs\x20yes','findMatches','times\x20touch\x20top\x20traceroute\x20trap\x20tr\x20true\x20tsort\x20tty\x20type\x20ulimit\x20umask\x20umount\x20unalias\x20','36NkxQNx','free\x20fsck\x20ftp\x20gawk\x20getopts\x20grep\x20groups\x20gzip\x20hash\x20head\x20history\x20hostname\x20id\x20ifconfig\x20','5040610TtiCnt','4RdsWpU','Highlighter','194627RoIxLU','import\x20install\x20join\x20kill\x20less\x20let\x20ln\x20local\x20locate\x20logname\x20logout\x20look\x20lpc\x20lpr\x20lprint\x20','string','brushes','cksum\x20clear\x20cmp\x20comm\x20command\x20cp\x20cron\x20crontab\x20csplit\x20cut\x20date\x20dc\x20dd\x20ddrescue\x20declare\x20df\x20','2218686cMUfjm','regexLib','9WzlHwe','2276976UTcGed','Bash','lprintd\x20lprintq\x20lprm\x20ls\x20lsof\x20make\x20man\x20mkdir\x20mkfifo\x20mkisofs\x20mknod\x20more\x20mount\x20mtools\x20','aliases','582617VOUztr','prototype','apply'];a0_0x4b40=function(){return _0x5ca2bc;};return a0_0x4b40();}var a0_0x22d73b=a0_0x3a26;(function(_0x17dc86,_0x34b83f){var _0x2bd8ae=a0_0x3a26,_0x5a38f3=_0x17dc86();while(!![]){try{var _0x3b3cbe=-parseInt(_0x2bd8ae(0x172))/0x1*(-parseInt(_0x2bd8ae(0x170))/0x2)+parseInt(_0x2bd8ae(0x155))/0x3+-parseInt(_0x2bd8ae(0x158))/0x4+-parseInt(_0x2bd8ae(0x16f))/0x5+-parseInt(_0x2bd8ae(0x16d))/0x6*(parseInt(_0x2bd8ae(0x15c))/0x7)+parseInt(_0x2bd8ae(0x162))/0x8*(parseInt(_0x2bd8ae(0x157))/0x9)+parseInt(_0x2bd8ae(0x169))/0xa;if(_0x3b3cbe===_0x34b83f)break;else _0x5a38f3['push'](_0x5a38f3['shift']());}catch(_0x3549c2){_0x5a38f3['push'](_0x5a38f3['shift']());}}}(a0_0x4b40,0xc6547),SyntaxHighlighter[a0_0x22d73b(0x175)][a0_0x22d73b(0x159)]=function(){var _0x8a5a77=a0_0x22d73b,_0x12b07f='if\x20fi\x20then\x20elif\x20else\x20for\x20do\x20done\x20until\x20while\x20break\x20continue\x20case\x20function\x20return\x20in\x20eq\x20ne\x20gt\x20lt\x20ge\x20le',_0x4fe4b5=_0x8a5a77(0x165)+_0x8a5a77(0x176)+'diff\x20diff3\x20dig\x20dir\x20dircolors\x20dirname\x20dirs\x20du\x20echo\x20egrep\x20eject\x20enable\x20env\x20ethtool\x20eval\x20'+_0x8a5a77(0x161)+_0x8a5a77(0x16e)+_0x8a5a77(0x173)+_0x8a5a77(0x15a)+_0x8a5a77(0x167)+'printenv\x20printf\x20ps\x20pushd\x20pwd\x20quota\x20quotacheck\x20quotactl\x20ram\x20rcp\x20read\x20readonly\x20renice\x20'+'remsync\x20rm\x20rmdir\x20rsync\x20screen\x20scp\x20sdiff\x20sed\x20select\x20seq\x20set\x20sftp\x20shift\x20shopt\x20shutdown\x20'+'sleep\x20sort\x20source\x20split\x20ssh\x20strace\x20su\x20sudo\x20sum\x20symlink\x20sync\x20tail\x20tar\x20tee\x20test\x20time\x20'+_0x8a5a77(0x16c)+_0x8a5a77(0x163)+_0x8a5a77(0x16a);this[_0x8a5a77(0x16b)]=function(_0x33c5a3,_0x417e8a){var _0x22af88=_0x8a5a77;return _0x417e8a=_0x417e8a[_0x22af88(0x166)](/&gt;/g,'>')['replace'](/&lt;/g,'<'),this['code']=_0x417e8a,SyntaxHighlighter[_0x22af88(0x171)][_0x22af88(0x15d)][_0x22af88(0x16b)][_0x22af88(0x15e)](this,[_0x33c5a3,_0x417e8a]);},this['regexList']=[{'regex':SyntaxHighlighter['regexLib']['singleLinePerlComments'],'css':'comments'},{'regex':SyntaxHighlighter['regexLib']['doubleQuotedString'],'css':_0x8a5a77(0x174)},{'regex':SyntaxHighlighter[_0x8a5a77(0x156)]['singleQuotedString'],'css':'string'},{'regex':new RegExp(this['getKeywords'](_0x12b07f),'gm'),'css':_0x8a5a77(0x15f)},{'regex':new RegExp(this[_0x8a5a77(0x164)](_0x4fe4b5),'gm'),'css':'functions'}];},SyntaxHighlighter[a0_0x22d73b(0x175)][a0_0x22d73b(0x159)]['prototype']=new SyntaxHighlighter[(a0_0x22d73b(0x171))](),SyntaxHighlighter[a0_0x22d73b(0x175)][a0_0x22d73b(0x159)][a0_0x22d73b(0x15b)]=[a0_0x22d73b(0x168),a0_0x22d73b(0x160)]);