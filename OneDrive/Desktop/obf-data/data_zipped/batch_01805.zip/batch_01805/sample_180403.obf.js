function a0_0xe52f(){const _0x1c851a=['19750896KGbZMz','6974740CxPjFQ','6057093JonAEa','1376913dBTEMJ','416tzViaI','7551YAvUhS','15376PcDbkr','405LjwhZb','78770uswogA','5166ChwOwE','12wnJvvZ'];a0_0xe52f=function(){return _0x1c851a;};return a0_0xe52f();}(function(_0x77727c,_0x459fca){const _0x5aa2c7=a0_0x58d6,_0x20d8a9=_0x77727c();while(!![]){try{const _0xff79ee=parseInt(_0x5aa2c7(0x13a))/0x1+-parseInt(_0x5aa2c7(0x140))/0x2*(-parseInt(_0x5aa2c7(0x13e))/0x3)+-parseInt(_0x5aa2c7(0x13b))/0x4*(parseInt(_0x5aa2c7(0x13f))/0x5)+parseInt(_0x5aa2c7(0x141))/0x6*(parseInt(_0x5aa2c7(0x144))/0x7)+-parseInt(_0x5aa2c7(0x13d))/0x8*(-parseInt(_0x5aa2c7(0x13c))/0x9)+-parseInt(_0x5aa2c7(0x143))/0xa+-parseInt(_0x5aa2c7(0x142))/0xb;if(_0xff79ee===_0x459fca)break;else _0x20d8a9['push'](_0x20d8a9['shift']());}catch(_0x591f93){_0x20d8a9['push'](_0x20d8a9['shift']());}}}(a0_0xe52f,0xe4d84));import a0_0x29f5c5 from'htmlbars-inline-precompile';import a0_0x34cc9e from'../../app/utils/styleguide/product-metadata';export default{'title':'Components|Accordion'};export let Standard=()=>{return{'template':a0_0x29f5c5`
      <h5 class="title is-5">Accordion</h5>
      <ListAccordion @source={{products}} @key="name" as |ac|>
        <ac.head @buttonLabel="details">
          <div class="columns inline-definitions">
            <div class="column is-1">{{ac.item.name}}</div>
            <div class="column is-1">
              <span class="bumper-left badge is-light">{{ac.item.lang}}</span>
            </div>
          </div>
        </ac.head>
        <ac.body>
          <h1 class="title is-4">{{ac.item.name}}</h1>
          <p>{{ac.item.desc}}</p>
          <p><a href="{{ac.item.link}}" target="_parent">Learn more...</a></p>
        </ac.body>
      </ListAccordion>
      `,'context':{'products':a0_0x34cc9e}};};function a0_0x58d6(_0x3b5933,_0x3fd234){const _0xe52ff=a0_0xe52f();return a0_0x58d6=function(_0x58d62e,_0x9050aa){_0x58d62e=_0x58d62e-0x13a;let _0x279208=_0xe52ff[_0x58d62e];return _0x279208;},a0_0x58d6(_0x3b5933,_0x3fd234);}export let OneItem=()=>{return{'template':a0_0x29f5c5`
      <h5 class="title is-5">Accordion, one item</h5>
      <ListAccordion @source={{take 1 products}} @key="name" as |a|>
        <a.head @buttonLabel="details">
          <div class="columns inline-definitions">
            <div class="column is-1">{{a.item.name}}</div>
            <div class="column is-1">
              <span class="bumper-left badge is-light">{{a.item.lang}}</span>
            </div>
          </div>
        </a.head>
        <a.body>
          <h1 class="title is-4">{{a.item.name}}</h1>
          <p>{{a.item.desc}}</p>
          <p><a href="{{a.item.link}}">Learn more...</a></p>
        </a.body>
      </ListAccordion>
      `,'context':{'products':a0_0x34cc9e}};};export let NotExpandable=()=>{return{'template':a0_0x29f5c5`
      <h5 class="title is-5">Accordion, not expandable</h5>
      <ListAccordion @source={{products}} @key="name" as |a|>
        <a.head @buttonLabel="details" @isExpandable={{eq a.item.lang "golang"}}>
          <div class="columns inline-definitions">
            <div class="column is-1">{{a.item.name}}</div>
            <div class="column is-1">
              <span class="bumper-left badge is-light">{{a.item.lang}}</span>
            </div>
          </div>
        </a.head>
        <a.body>
          <h1 class="title is-4">{{a.item.name}}</h1>
          <p>{{a.item.desc}}</p>
          <p><a href="{{a.item.link}}">Learn more...</a></p>
        </a.body>
      </ListAccordion>
      `,'context':{'products':a0_0x34cc9e}};};