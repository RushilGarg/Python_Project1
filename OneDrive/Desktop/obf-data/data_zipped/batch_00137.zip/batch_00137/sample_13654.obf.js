'format cjs';function a0_0x1e50(_0x443e81,_0x45e017){var _0x462a5c=a0_0x462a();return a0_0x1e50=function(_0x1e505c,_0x371d72){_0x1e505c=_0x1e505c-0x1aa;var _0x296365=_0x462a5c[_0x1e505c];return _0x296365;},a0_0x1e50(_0x443e81,_0x45e017);}var a0_0x12ec1b=a0_0x1e50;(function(_0x513028,_0x1cafb9){var _0x3882c4=a0_0x1e50,_0x531677=_0x513028();while(!![]){try{var _0x3283f6=parseInt(_0x3882c4(0x1bd))/0x1*(parseInt(_0x3882c4(0x1aa))/0x2)+parseInt(_0x3882c4(0x1b9))/0x3*(parseInt(_0x3882c4(0x1b2))/0x4)+parseInt(_0x3882c4(0x1b3))/0x5+-parseInt(_0x3882c4(0x1b5))/0x6*(-parseInt(_0x3882c4(0x1b4))/0x7)+-parseInt(_0x3882c4(0x1ac))/0x8+parseInt(_0x3882c4(0x1b7))/0x9+-parseInt(_0x3882c4(0x1b6))/0xa;if(_0x3283f6===_0x1cafb9)break;else _0x531677['push'](_0x531677['shift']());}catch(_0x19b189){_0x531677['push'](_0x531677['shift']());}}}(a0_0x462a,0xd32f0));/**
 * Helps IE run the fake timers. By defining global functions, IE allows
 * them to be overwritten at a later point. If these are not defined like
 * this, overwriting them will result in anything from an exception to browser
 * crash.
 *
 * If you don't require fake timers to work in IE, don't include this file.
 *
 * @author Christian Johansen (christian@cjohansen.no)
 * @license BSD
 *
 * Copyright (c) 2010-2013 Christian Johansen
 */
function setTimeout(){}function clearTimeout(){}function setImmediate(){}function clearImmediate(){}function setInterval(){}function a0_0x462a(){var _0x3923a0=['1290xCtaUX','37381230zGdlPX','13406265jhrFze','clearInterval','36021KrFaLt','clearImmediate','xhr','XMLHttpRequest','471275cNvOcw','XDomainRequest','6ScLuMB','xdr','11261432oNAnmv','timers','setInterval','clearTimeout','Date','setTimeout','428YMddPi','7316930iwzFTC','11697sOtrcf'];a0_0x462a=function(){return _0x3923a0;};return a0_0x462a();}function clearInterval(){}function Date(){}setTimeout=sinon[a0_0x12ec1b(0x1ad)][a0_0x12ec1b(0x1b1)],clearTimeout=sinon['timers'][a0_0x12ec1b(0x1af)],setImmediate=sinon[a0_0x12ec1b(0x1ad)]['setImmediate'],clearImmediate=sinon[a0_0x12ec1b(0x1ad)][a0_0x12ec1b(0x1ba)],setInterval=sinon[a0_0x12ec1b(0x1ad)][a0_0x12ec1b(0x1ae)],clearInterval=sinon[a0_0x12ec1b(0x1ad)][a0_0x12ec1b(0x1b8)],Date=sinon[a0_0x12ec1b(0x1ad)][a0_0x12ec1b(0x1b0)];/**
 * Helps IE run the fake XMLHttpRequest. By defining global functions, IE allows
 * them to be overwritten at a later point. If these are not defined like
 * this, overwriting them will result in anything from an exception to browser
 * crash.
 *
 * If you don't require fake XHR to work in IE, don't include this file.
 *
 * @author Christian Johansen (christian@cjohansen.no)
 * @license BSD
 *
 * Copyright (c) 2010-2013 Christian Johansen
 */
function XMLHttpRequest(){}XMLHttpRequest=sinon[a0_0x12ec1b(0x1bb)][a0_0x12ec1b(0x1bc)]||undefined;function XDomainRequest(){}XDomainRequest=sinon[a0_0x12ec1b(0x1ab)][a0_0x12ec1b(0x1be)]||undefined;