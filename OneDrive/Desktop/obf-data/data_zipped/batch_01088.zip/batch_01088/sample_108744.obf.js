/**
 * Pixelcrush CDN Prestashop Module
 *
 * Copyright 2018 Imagenii, Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @author   Pixelcrush
 * @copyright Copyright (c) 2017 Imagenii Inc. All rights reserved
 * @license http://www.apache.org/licenses/LICENSE-2.0 Apache License, Version 2
 *
 */
function a0_0x24ee(_0x2014be,_0x243ee8){var _0x5cba6c=a0_0x5cba();return a0_0x24ee=function(_0x24ee88,_0x1fc487){_0x24ee88=_0x24ee88-0x94;var _0x2d7831=_0x5cba6c[_0x24ee88];return _0x2d7831;},a0_0x24ee(_0x2014be,_0x243ee8);}var a0_0x59b5cb=a0_0x24ee;(function(_0x1c4dee,_0x422e14){var _0x3f27a4=a0_0x24ee,_0x340ac5=_0x1c4dee();while(!![]){try{var _0x81d978=parseInt(_0x3f27a4(0x98))/0x1*(parseInt(_0x3f27a4(0x94))/0x2)+-parseInt(_0x3f27a4(0x9f))/0x3*(-parseInt(_0x3f27a4(0x96))/0x4)+-parseInt(_0x3f27a4(0x97))/0x5+-parseInt(_0x3f27a4(0x99))/0x6+-parseInt(_0x3f27a4(0x9e))/0x7+-parseInt(_0x3f27a4(0xa0))/0x8+parseInt(_0x3f27a4(0x9a))/0x9;if(_0x81d978===_0x422e14)break;else _0x340ac5['push'](_0x340ac5['shift']());}catch(_0x302ece){_0x340ac5['push'](_0x340ac5['shift']());}}}(a0_0x5cba,0xa6b6d),$(document)[a0_0x59b5cb(0xa2)](function(){var _0x43cb1f=a0_0x59b5cb;if($(_0x43cb1f(0x9b))[_0x43cb1f(0x95)]==0x0){var _0x50f82f='<div\x20class=\x22margin-form\x22>'+_0x43cb1f(0x9c)+'</div><div\x20class=\x22clear\x22></div>';$(_0x43cb1f(0x9d))[_0x43cb1f(0xa1)](_0x50f82f);}}));function a0_0x5cba(){var _0x394cf3=['#pixelcrush-logo-hd','<img\x20id=\x22pixelcrush-logo-hd\x22\x20src=\x22../modules/pixelcrush/views/img/pixelcrush-logo.png\x22\x20/>','FORM#configuration_form\x20FIELDSET\x20LEGEND','6564313PsjIlx','105MJJdQp','9748936NKfjIR','after','ready','2cPKXuq','length','2032sbBWZT','1895970UdGqfh','1364047DJdWhg','1428792iLpHuA','18672624oVwpUY'];a0_0x5cba=function(){return _0x394cf3;};return a0_0x5cba();}