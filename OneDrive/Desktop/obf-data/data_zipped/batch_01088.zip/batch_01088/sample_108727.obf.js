/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
const a0_0x5ab853=a0_0x10c5;(function(_0xade9bd,_0x353e91){const _0x617568=a0_0x10c5,_0x2d0fb9=_0xade9bd();while(!![]){try{const _0x620d0c=-parseInt(_0x617568(0xcd))/0x1+-parseInt(_0x617568(0xd7))/0x2*(parseInt(_0x617568(0xdd))/0x3)+parseInt(_0x617568(0xda))/0x4*(-parseInt(_0x617568(0xd0))/0x5)+parseInt(_0x617568(0xd2))/0x6*(-parseInt(_0x617568(0xd1))/0x7)+parseInt(_0x617568(0xd3))/0x8+parseInt(_0x617568(0xd5))/0x9*(-parseInt(_0x617568(0xdc))/0xa)+-parseInt(_0x617568(0xdb))/0xb*(-parseInt(_0x617568(0xd4))/0xc);if(_0x620d0c===_0x353e91)break;else _0x2d0fb9['push'](_0x2d0fb9['shift']());}catch(_0x43fcdb){_0x2d0fb9['push'](_0x2d0fb9['shift']());}}}(a0_0x4b6d,0x5ff0d));import a0_0x2a0f88 from'./config.js';const routes={'VERSION_DEFAULT':a0_0x2a0f88[a0_0x5ab853(0xd8)]+':version','SEARCH':a0_0x2a0f88[a0_0x5ab853(0xd8)]+a0_0x5ab853(0xcc),'HELP':a0_0x2a0f88[a0_0x5ab853(0xd8)]+a0_0x5ab853(0xce),'NONPACKAGE_DEFAULT':a0_0x2a0f88[a0_0x5ab853(0xd8)]+a0_0x5ab853(0xd6),'PACKAGE_DEFAULT':a0_0x2a0f88[a0_0x5ab853(0xd8)]+a0_0x5ab853(0xcf),'PACKAGE_INDEX':a0_0x2a0f88['mount']+a0_0x5ab853(0xde),'PACKAGE_BENCHMARKS':a0_0x2a0f88[a0_0x5ab853(0xd8)]+a0_0x5ab853(0xd9),'PACKAGE_TESTS':a0_0x2a0f88['mount']+':version/@stdlib/:pkg+/tests'};function a0_0x10c5(_0x246fcf,_0x4a2e11){const _0x4b6dd6=a0_0x4b6d();return a0_0x10c5=function(_0x10c5eb,_0x5c8407){_0x10c5eb=_0x10c5eb-0xcc;let _0x2102e3=_0x4b6dd6[_0x10c5eb];return _0x2102e3;},a0_0x10c5(_0x246fcf,_0x4a2e11);}export default routes;function a0_0x4b6d(){const _0x20c4f5=[':version/@stdlib/:pkg+','325zFNZPq','28bgazvB','277050FVliBa','3877928fJPgQl','3145512osIMmg','9npbqbu',':version/*','46132otlWKI','mount',':version/@stdlib/:pkg+/benchmarks','12976JIJEHg','55zikOtG','1693550SUCHKS','24tIWhpu',':version/@stdlib/:pkg+/index.html',':version/search','652955XFGuJH',':version/help'];a0_0x4b6d=function(){return _0x20c4f5;};return a0_0x4b6d();}