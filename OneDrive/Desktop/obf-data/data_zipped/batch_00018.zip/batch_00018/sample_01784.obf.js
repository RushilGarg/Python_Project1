/*  
 * JCE Editor                 2.2.4
 * @package                 JCE
 * @url                     http://www.joomlacontenteditor.net
 * @copyright               Copyright (C) 2006 - 2012 Ryan Demmer. All rights reserved
 * @license                 GNU/GPL Version 2 or later - http://www.gnu.org/licenses/gpl-2.0.html
 * @date                    16 July 2012
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.

 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * NOTE : Javascript files have been compressed for speed and can be uncompressed using http://jsbeautifier.org/
 */
function a0_0x41d8(_0x12e780,_0x5e589b){var _0x228927=a0_0x2289();return a0_0x41d8=function(_0x41d89a,_0x17ef56){_0x41d89a=_0x41d89a-0x170;var _0x28c963=_0x228927[_0x41d89a];return _0x28c963;},a0_0x41d8(_0x12e780,_0x5e589b);}var a0_0x397d7f=a0_0x41d8;(function(_0x129339,_0x386692){var _0x59bef3=a0_0x41d8,_0x47f493=_0x129339();while(!![]){try{var _0x69e160=parseInt(_0x59bef3(0x17e))/0x1*(-parseInt(_0x59bef3(0x182))/0x2)+parseInt(_0x59bef3(0x17d))/0x3+-parseInt(_0x59bef3(0x185))/0x4+-parseInt(_0x59bef3(0x17b))/0x5*(-parseInt(_0x59bef3(0x183))/0x6)+parseInt(_0x59bef3(0x180))/0x7*(-parseInt(_0x59bef3(0x17f))/0x8)+-parseInt(_0x59bef3(0x175))/0x9*(parseInt(_0x59bef3(0x172))/0xa)+parseInt(_0x59bef3(0x18a))/0xb;if(_0x69e160===_0x386692)break;else _0x47f493['push'](_0x47f493['shift']());}catch(_0x38173b){_0x47f493['push'](_0x47f493['shift']());}}}(a0_0x2289,0xa90d1),tinyMCEPopup['requireLangPack']());var ColorPicker={'settings':{},'init':function(){var _0x1c4fbb=a0_0x41d8,_0x5149c8=this,_0x1381c4=tinyMCEPopup['editor'],_0x50a715=tinyMCEPopup['getWindowArg'](_0x1c4fbb(0x188))||_0x1c4fbb(0x171);$(_0x1c4fbb(0x174))[_0x1c4fbb(0x184)](_0x50a715)[_0x1c4fbb(0x181)]($[_0x1c4fbb(0x177)](this[_0x1c4fbb(0x173)],{'dialog':![],'insert':function(){var _0x284ddd=_0x1c4fbb;return ColorPicker[_0x284ddd(0x178)]();},'close':function(){var _0xb8a20b=_0x1c4fbb;return tinyMCEPopup[_0xb8a20b(0x170)]();}})),$(_0x1c4fbb(0x18e))['button']({'icons':{'primary':_0x1c4fbb(0x176)}}),$(_0x1c4fbb(0x17c))[_0x1c4fbb(0x18d)](_0x1c4fbb(0x187),_0x1c4fbb(0x18b));},'insert':function(){var _0x31753d=a0_0x41d8,_0x489342=$(_0x31753d(0x189))[_0x31753d(0x184)](),_0x53dbf4=tinyMCEPopup[_0x31753d(0x17a)](_0x31753d(0x18c));tinyMCEPopup[_0x31753d(0x179)]();if(_0x53dbf4)_0x53dbf4(_0x489342);tinyMCEPopup['close']();}};function a0_0x2289(){var _0x4bf683=['19061317XwFUYW','block','func','css','button#insert','close','#FFFFFF','1790CBHRKy','settings','#tmp_color','1449CFXHCg','ui-icon-check','extend','insert','restoreSelection','getWindowArg','887195XGTlrN','#jce','2214690OheIfB','443438VMYxEq','26424HGOoRA','847VBstyY','colorpicker','6VQhMRF','6LdxAdH','val','789148dklZcc','add','display','input_color','#colorpicker_color'];a0_0x2289=function(){return _0x4bf683;};return a0_0x2289();}tinyMCEPopup['onInit'][a0_0x397d7f(0x186)](ColorPicker['init'],ColorPicker);