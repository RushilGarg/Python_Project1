/**
 * @file
 * <a href="https://travis-ci.org/Xotic750/has-to-string-tag-x"
 * title="Travis status">
 * <img
 * src="https://travis-ci.org/Xotic750/has-to-string-tag-x.svg?branch=master"
 * alt="Travis status" height="18">
 * </a>
 * <a href="https://david-dm.org/Xotic750/has-to-string-tag-x"
 * title="Dependency status">
 * <img src="https://david-dm.org/Xotic750/has-to-string-tag-x.svg"
 * alt="Dependency status" height="18"/>
 * </a>
 * <a
 * href="https://david-dm.org/Xotic750/has-to-string-tag-x#info=devDependencies"
 * title="devDependency status">
 * <img src="https://david-dm.org/Xotic750/has-to-string-tag-x/dev-status.svg"
 * alt="devDependency status" height="18"/>
 * </a>
 * <a href="https://badge.fury.io/js/has-to-string-tag-x" title="npm version">
 * <img src="https://badge.fury.io/js/has-to-string-tag-x.svg"
 * alt="npm version" height="18">
 * </a>
 *
 * hasToStringTag tests if @@toStringTag is supported. `true` if supported.
 *
 * <h2>ECMAScript compatibility shims for legacy JavaScript engines</h2>
 * `es5-shim.js` monkey-patches a JavaScript context to contain all EcmaScript 5
 * methods that can be faithfully emulated with a legacy JavaScript engine.
 *
 * `es5-sham.js` monkey-patches other ES5 methods as closely as possible.
 * For these methods, as closely as possible to ES5 is not very close.
 * Many of these shams are intended only to allow code to be written to ES5
 * without causing run-time errors in older engines. In many cases,
 * this means that these shams cause many ES5 methods to silently fail.
 * Decide carefully whether this is what you want. Note: es5-sham.js requires
 * es5-shim.js to be able to work properly.
 *
 * `json3.js` monkey-patches the EcmaScript 5 JSON implimentation faithfully.
 *
 * `es6.shim.js` provides compatibility shims so that legacy JavaScript engines
 * behave as closely as possible to ECMAScript 6 (Harmony).
 *
 * @version 1.1.0
 * @author Xotic750 <Xotic750@gmail.com>
 * @copyright  Xotic750
 * @license {@link <https://opensource.org/licenses/MIT> MIT}
 * @module has-to-string-tag-x
 */
function a0_0x5462(){var _0x5b8692=['toStringTag','exports','2PcPHes','7288OHfbDj','5osQtXY','8ztZXgg','1315668PiUgvT','1720730AWbowL','141297WJegDc','symbol','1054773jTxLEp','10QroSBN','185891ltQeMI','5549880MOmcCR','has-symbol-support-x','1946gQwZtg'];a0_0x5462=function(){return _0x5b8692;};return a0_0x5462();}(function(_0x1db761,_0xcb204a){var _0x49195a=a0_0x153d,_0x2351be=_0x1db761();while(!![]){try{var _0x2d440a=-parseInt(_0x49195a(0x1af))/0x1*(parseInt(_0x49195a(0x1b5))/0x2)+-parseInt(_0x49195a(0x1ab))/0x3*(-parseInt(_0x49195a(0x1b8))/0x4)+-parseInt(_0x49195a(0x1b7))/0x5*(parseInt(_0x49195a(0x1a9))/0x6)+parseInt(_0x49195a(0x1b2))/0x7*(parseInt(_0x49195a(0x1b6))/0x8)+parseInt(_0x49195a(0x1ad))/0x9*(-parseInt(_0x49195a(0x1ae))/0xa)+-parseInt(_0x49195a(0x1aa))/0xb+parseInt(_0x49195a(0x1b0))/0xc;if(_0x2d440a===_0xcb204a)break;else _0x2351be['push'](_0x2351be['shift']());}catch(_0x37867a){_0x2351be['push'](_0x2351be['shift']());}}}(a0_0x5462,0x2004e));;function a0_0x153d(_0x375656,_0x58e1b3){var _0x5462cf=a0_0x5462();return a0_0x153d=function(_0x153da5,_0x49fe00){_0x153da5=_0x153da5-0x1a9;var _0xfd61b2=_0x5462cf[_0x153da5];return _0xfd61b2;},a0_0x153d(_0x375656,_0x58e1b3);}(function(){'use strict';var _0x55d0cd=a0_0x153d;module[_0x55d0cd(0x1b4)]=require(_0x55d0cd(0x1b1))&&typeof Symbol[_0x55d0cd(0x1b3)]===_0x55d0cd(0x1ac);}());