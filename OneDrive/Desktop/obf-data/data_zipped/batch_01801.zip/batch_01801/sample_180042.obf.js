/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4cc185=a0_0x8b90;function a0_0x1f59(){var _0x219ebe=['main\x20export\x20is\x20a\x20function','7348Pdoidn','348896JSkPaj','10449MNPvjE','has\x20method','end','7CcPmem','4235710LEAKqB','3845925zuHrFv','tape','730607ZEEwKg','./../lib','strictEqual','function','2430546ffbjhw','2496iIjuKa','15oGDDLl','factory','attached\x20to\x20the\x20main\x20export\x20is\x20a\x20`factory`\x20method'];a0_0x1f59=function(){return _0x219ebe;};return a0_0x1f59();}(function(_0x584060,_0x4448dc){var _0x356f47=a0_0x8b90,_0x4e4647=_0x584060();while(!![]){try{var _0x1ac164=parseInt(_0x356f47(0x16d))/0x1+-parseInt(_0x356f47(0x164))/0x2*(-parseInt(_0x356f47(0x160))/0x3)+parseInt(_0x356f47(0x165))/0x4+-parseInt(_0x356f47(0x16b))/0x5+parseInt(_0x356f47(0x171))/0x6*(parseInt(_0x356f47(0x169))/0x7)+parseInt(_0x356f47(0x15f))/0x8*(parseInt(_0x356f47(0x166))/0x9)+-parseInt(_0x356f47(0x16a))/0xa;if(_0x1ac164===_0x4448dc)break;else _0x4e4647['push'](_0x4e4647['shift']());}catch(_0x1a53be){_0x4e4647['push'](_0x4e4647['shift']());}}}(a0_0x1f59,0x64490));function a0_0x8b90(_0x2cf38f,_0x26f2e1){var _0x1f597d=a0_0x1f59();return a0_0x8b90=function(_0x8b9084,_0x4e21be){_0x8b9084=_0x8b9084-0x15f;var _0xb04c6c=_0x1f597d[_0x8b9084];return _0xb04c6c;},a0_0x8b90(_0x2cf38f,_0x26f2e1);}var tape=require(a0_0x4cc185(0x16c)),countByAsync=require(a0_0x4cc185(0x16e));tape(a0_0x4cc185(0x163),function test(_0xcebee6){var _0x3f47ce=a0_0x4cc185;_0xcebee6['ok'](!![],__filename),_0xcebee6[_0x3f47ce(0x16f)](typeof countByAsync,_0x3f47ce(0x170),_0x3f47ce(0x163)),_0xcebee6['end']();}),tape(a0_0x4cc185(0x162),function test(_0x933495){var _0x14bc09=a0_0x4cc185;_0x933495[_0x14bc09(0x16f)](typeof countByAsync[_0x14bc09(0x161)],_0x14bc09(0x170),_0x14bc09(0x167)),_0x933495[_0x14bc09(0x168)]();});