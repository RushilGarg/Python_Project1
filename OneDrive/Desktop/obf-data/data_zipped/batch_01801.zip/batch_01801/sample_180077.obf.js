/**
 * @license
 * Copyright 2018 Google LLC. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * =============================================================================
 */
const a0_0x4e04a7=a0_0x1d1d;function a0_0x1d1d(_0x8b0362,_0x4c53ef){const _0x18c2fb=a0_0x18c2();return a0_0x1d1d=function(_0x1d1d7e,_0x3356dd){_0x1d1d7e=_0x1d1d7e-0x18e;let _0x14b96b=_0x18c2fb[_0x1d1d7e];return _0x14b96b;},a0_0x1d1d(_0x8b0362,_0x4c53ef);}(function(_0x135eb5,_0x315cba){const _0x54a4ff=a0_0x1d1d,_0x5bdaaf=_0x135eb5();while(!![]){try{const _0x5e0b93=parseInt(_0x54a4ff(0x1a2))/0x1+-parseInt(_0x54a4ff(0x192))/0x2+-parseInt(_0x54a4ff(0x19d))/0x3+-parseInt(_0x54a4ff(0x19f))/0x4*(-parseInt(_0x54a4ff(0x198))/0x5)+-parseInt(_0x54a4ff(0x191))/0x6+-parseInt(_0x54a4ff(0x193))/0x7*(parseInt(_0x54a4ff(0x19b))/0x8)+parseInt(_0x54a4ff(0x190))/0x9;if(_0x5e0b93===_0x315cba)break;else _0x5bdaaf['push'](_0x5bdaaf['shift']());}catch(_0x3e0780){_0x5bdaaf['push'](_0x5bdaaf['shift']());}}}(a0_0x18c2,0xdf588));export const ADD_DREAMING_ELEMENT=a0_0x4e04a7(0x195);export const UPDATE_DREAMING_ELEMENTS=a0_0x4e04a7(0x197);export const REMOVE_DREAMING_ELEMENT=a0_0x4e04a7(0x199);export const CHANGE_DREAMING_ELEMENT_ITERATION=a0_0x4e04a7(0x19c);export const CHANGE_CARD_DIMENSIONS=a0_0x4e04a7(0x1a0);export const CHANGE_SOFTMAX_STATUS=a0_0x4e04a7(0x194);export const CHANGE_PROGRESS_PAGE='CHANGE_PROGRESS_PAGE';export const CHANGE_TOP_WORDS_ITERATION=a0_0x4e04a7(0x19a);export const CHANGE_DREAM_ID=a0_0x4e04a7(0x18e);export const LOAD_DREAM_SUCCESS=a0_0x4e04a7(0x196);export const LOAD_ANNEALING_SUCCESS='LOAD_ANNEALING_SUCCESS';export const LOAD_TOP_WORDS_SUCCESS=a0_0x4e04a7(0x1a1);export const LOAD_SIMILAR_WORDS_SUCCESS=a0_0x4e04a7(0x19e);export const LOAD_RECONSTRUCTION_SUCCESS='LOAD_RECONSTRUCTION_SUCCESS';export const LOAD_SHIFTED_RECONSTRUCTION_SUCCESS=a0_0x4e04a7(0x18f);function a0_0x18c2(){const _0x18b0ff=['LOAD_DREAM_SUCCESS','UPDATE_DREAMING_ELEMENTS','10fPrldi','REMOVE_DREAMING_ELEMENT','CHANGE_TOP_WORDS_ITERATION','10343248DvFAje','CHANGE_DREAMING_ELEMENT_ITERATION','1440972OoVlsX','LOAD_SIMILAR_WORDS_SUCCESS','48192UXHiNw','CHANGE_CARD_DIMENSIONS','LOAD_TOP_WORDS_SUCCESS','1292700OLziPP','CHANGE_DREAM_ID','LOAD_SHIFTED_RECONSTRUCTION_SUCCESS','14283639WrFxpb','535224TxuxQG','253218pVbJTg','7gepPhv','CHANGE_SOFTMAX_STATUS','ADD_DREAMING_ELEMENT'];a0_0x18c2=function(){return _0x18b0ff;};return a0_0x18c2();}