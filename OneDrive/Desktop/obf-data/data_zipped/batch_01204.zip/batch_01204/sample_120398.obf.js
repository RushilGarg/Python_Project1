/**
 * @license
 * Copyright 2016 Google Inc.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x595b00=a0_0x1219;(function(_0x2f1cd4,_0x5c7800){var _0x456078=a0_0x1219,_0x1344a8=_0x2f1cd4();while(!![]){try{var _0x29e493=-parseInt(_0x456078(0x1f9))/0x1+parseInt(_0x456078(0x1f0))/0x2*(parseInt(_0x456078(0x1f2))/0x3)+-parseInt(_0x456078(0x1f5))/0x4+parseInt(_0x456078(0x1f3))/0x5*(-parseInt(_0x456078(0x1ee))/0x6)+-parseInt(_0x456078(0x1fe))/0x7*(-parseInt(_0x456078(0x1fa))/0x8)+parseInt(_0x456078(0x1ef))/0x9+parseInt(_0x456078(0x1fc))/0xa*(-parseInt(_0x456078(0x1f7))/0xb);if(_0x29e493===_0x5c7800)break;else _0x1344a8['push'](_0x1344a8['shift']());}catch(_0x16e083){_0x1344a8['push'](_0x1344a8['shift']());}}}(a0_0x4cfe,0x441c3),HTMLMediaElement[a0_0x595b00(0x1ff)][a0_0x595b00(0x1f1)]=function(_0x5014a2,_0x2c8b82,_0x1a305c,_0x13d4cb){},HTMLMediaElement[a0_0x595b00(0x1ff)][a0_0x595b00(0x204)]=function(_0x2239e8,_0x3e5744){},HTMLMediaElement['prototype'][a0_0x595b00(0x202)]=function(_0x2e5801,_0x5e62aa){},HTMLMediaElement[a0_0x595b00(0x1ff)][a0_0x595b00(0x1f6)]=function(_0x5093b4,_0x245a0f){},HTMLVideoElement[a0_0x595b00(0x1ff)][a0_0x595b00(0x200)]=function(_0x2b726e,_0x2ed76c){});function a0_0x1219(_0x5e912f,_0x2f14ef){var _0x4cfea5=a0_0x4cfe();return a0_0x1219=function(_0x121968,_0xdf8b04){_0x121968=_0x121968-0x1ed;var _0x2f5668=_0x4cfea5[_0x121968];return _0x2f5668;},a0_0x1219(_0x5e912f,_0x2f14ef);}function MediaKeyEvent(_0x163e21,_0x593e88){}function a0_0x4cfe(){var _0x2ff0a0=['keySystem','6OtOkQn','2111355kkQtnF','2ttzrQI','webkitAddKey','1293723znThIh','417940oXvOgg','systemCode','1549424BvXyph','generateKeyRequest','110QHDXXY','errorCode','102625rduxWF','24zgxEir','defaultURL','278990HkzFXw','initData','1086638kHkCuz','prototype','canPlayType','sessionId','webkitGenerateKeyRequest','code','webkitCancelKeyRequest','target'];a0_0x4cfe=function(){return _0x2ff0a0;};return a0_0x4cfe();}MediaKeyEvent[a0_0x595b00(0x1ff)][a0_0x595b00(0x1ed)],MediaKeyEvent[a0_0x595b00(0x1ff)][a0_0x595b00(0x201)],MediaKeyEvent['prototype'][a0_0x595b00(0x1fd)],MediaKeyEvent[a0_0x595b00(0x1ff)]['message'],MediaKeyEvent[a0_0x595b00(0x1ff)][a0_0x595b00(0x1fb)],MediaKeyEvent[a0_0x595b00(0x1ff)][a0_0x595b00(0x1f8)],MediaKeyEvent[a0_0x595b00(0x1ff)][a0_0x595b00(0x1f4)],MediaKeyEvent[a0_0x595b00(0x1ff)][a0_0x595b00(0x205)];function MediaKeyError(){}MediaKeyError[a0_0x595b00(0x1ff)][a0_0x595b00(0x203)],MediaKeyError[a0_0x595b00(0x1ff)][a0_0x595b00(0x1f4)];