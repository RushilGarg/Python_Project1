/***
@title:
Colour Picker

@version:
2.0

@author:
Andreas Lagerkvist

@date:
2008-09-16

@url:
http://andreaslagerkvist.com/jquery/colour-picker/

@license:
http://creativecommons.org/licenses/by/3.0/

@copyright:
2008 Andreas Lagerkvist (andreaslagerkvist.com)

@requires:
jquery, jquery.colourPicker.css, jquery.colourPicker.gif

@does:
Use this plug-in on a normal <select>-element filled with colours to turn it in to a colour-picker widget that allows users to view all the colours in the drop-down as well as enter their own, preferred, custom colour. Only about 1k compressed.

@howto:
jQuery('select[name="colour"]').colourPicker({ico: 'my-icon.gif', title: 'Select a colour from the list'}); Would replace the select with 'my-icon.gif' which, when clicked, would open a dialogue with the title 'Select a colour from the list'.

You can close the colour-picker without selecting a colour by clicking anywhere outside the colour-picker box.

Here's a handy PHP-function to generate a list of "web-safe" colours:

[code]
function gwsc() {
	$cs = array('00', '33', '66', '99', 'CC', 'FF');

	for($i=0; $i<6; $i++) {
		for($j=0; $j<6; $j++) {
			for($k=0; $k<6; $k++) {
				$c = $cs[$i] .$cs[$j] .$cs[$k];
				echo "<option value=\"$c\">#$c</option>\n";
			}
		}
	}
}
[/code]

Use it like this: <select name="colour"><?php gwsc(); ?></select>.

@exampleHTML:
<p>
	<label>
		Pick a colour<br />
		<select name="colour">
			<option value="ffffff">#ffffff</option>
			<option value="ffccc9">#ffccc9</option>
			<option value="ffce93">#ffce93</option>
			<option value="fffc9e">#fffc9e</option>
			<option value="ffffc7">#ffffc7</option>
			<option value="9aff99">#9aff99</option>
			<option value="96fffb">#96fffb</option>
			<option value="cdffff">#cdffff</option>
			<option value="cbcefb">#cbcefb</option>
			<option value="cfcfcf">#cfcfcf</option>
			<option value="fd6864">#fd6864</option>
			<option value="fe996b">#fe996b</option>
			<option value="fffe65">#fffe65</option>
			<option value="fcff2f">#fcff2f</option>
			<option value="67fd9a">#67fd9a</option>
			<option value="38fff8">#38fff8</option>
			<option value="68fdff">#68fdff</option>
			<option value="9698ed">#9698ed</option>
			<option value="c0c0c0">#c0c0c0</option>
			<option value="fe0000">#fe0000</option>
			<option value="f8a102">#f8a102</option>
			<option value="ffcc67">#ffcc67</option>
			<option value="f8ff00">#f8ff00</option>
			<option value="34ff34">#34ff34</option>
			<option value="68cbd0">#68cbd0</option>
			<option value="34cdf9">#34cdf9</option>
			<option value="6665cd">#6665cd</option>
			<option value="9b9b9b">#9b9b9b</option>
			<option value="cb0000">#cb0000</option>
			<option value="f56b00">#f56b00</option>
			<option value="ffcb2f">#ffcb2f</option>
			<option value="ffc702">#ffc702</option>
			<option value="32cb00">#32cb00</option>
			<option value="00d2cb">#00d2cb</option>
			<option value="3166ff">#3166ff</option>
			<option value="6434fc">#6434fc</option>
			<option value="656565">#656565</option>
			<option value="9a0000">#9a0000</option>
			<option value="ce6301">#ce6301</option>
			<option value="cd9934">#cd9934</option>
			<option value="999903">#999903</option>
			<option value="009901">#009901</option>
			<option value="329a9d">#329a9d</option>
			<option value="3531ff">#3531ff</option>
			<option value="6200c9">#6200c9</option>
			<option value="343434">#343434</option>
			<option value="680100">#680100</option>
			<option value="963400">#963400</option>
			<option value="986536" selected="selected">#986536</option>
			<option value="646809">#646809</option>
			<option value="036400">#036400</option>
			<option value="34696d">#34696d</option>
			<option value="00009b">#00009b</option>
			<option value="303498">#303498</option>
			<option value="000000">#000000</option>
			<option value="330001">#330001</option>
			<option value="643403">#643403</option>
			<option value="663234">#663234</option>
			<option value="343300">#343300</option>
			<option value="013300">#013300</option>
			<option value="003532">#003532</option>
			<option value="010066">#010066</option>
			<option value="340096">#340096</option>
		</select>
	</label>
</p>

@exampleJS:
jQuery('#jquery-colour-picker-example select').colourPicker({
	ico:	WEBROOT + 'aFramework/Modules/Base/gfx/jquery.colourPicker.gif', 
	title:	false
});
***/
function a0_0x2443(_0x244efe,_0x1b11ad){var _0x39aed4=a0_0x39ae();return a0_0x2443=function(_0x24438c,_0x2b5451){_0x24438c=_0x24438c-0x6c;var _0x99ada0=_0x39aed4[_0x24438c];return _0x99ada0;},a0_0x2443(_0x244efe,_0x1b11ad);}var a0_0x5cd1ba=a0_0x2443;function a0_0x39ae(){var _0x3c6686=['parents','\x22\x20value=\x22','jquery-colour-picker','top','body','insertAfter','</ul>','ico.gif','rel','left','Pick\x20a\x20colour','5DGkDMe','html','appendTo','1371690PpySGc','remove','attr','change','\x22\x20style=\x22background:\x20#','<ul>','offset','19557912EHiykn','519281mdNOby','each','4460571bekAhu','<a\x20href=\x22#\x22><img\x20src=\x22','4245174NyVTQP','7618602rNOIKj','text','2yXNqNU','colourPicker','4lDdrFz','substr','val','inputBG','click','8HrCTOI','ffffff',';\x20colour:\x20','length','\x22\x20size=\x226\x22\x20/>','title','speed','css','000000','<input\x20type=\x22text\x22\x20name=\x22','8475160MglgyM','\x22></div>','<li><a\x20href=\x22#\x22\x20title=\x22','option','show','absolute','name','\x22\x20alt=\x22','ico','<h2>','extend','hide'];a0_0x39ae=function(){return _0x3c6686;};return a0_0x39ae();}(function(_0x378964,_0x15ad91){var _0x4e5b00=a0_0x2443,_0x3d0432=_0x378964();while(!![]){try{var _0x5e9b68=-parseInt(_0x4e5b00(0x91))/0x1*(-parseInt(_0x4e5b00(0x82))/0x2)+parseInt(_0x4e5b00(0x8e))/0x3*(-parseInt(_0x4e5b00(0x93))/0x4)+-parseInt(_0x4e5b00(0x7f))/0x5*(-parseInt(_0x4e5b00(0x8f))/0x6)+-parseInt(_0x4e5b00(0x8a))/0x7+-parseInt(_0x4e5b00(0x98))/0x8*(-parseInt(_0x4e5b00(0x8c))/0x9)+parseInt(_0x4e5b00(0xa2))/0xa+-parseInt(_0x4e5b00(0x89))/0xb;if(_0x5e9b68===_0x15ad91)break;else _0x3d0432['push'](_0x3d0432['shift']());}catch(_0x188828){_0x3d0432['push'](_0x3d0432['shift']());}}}(a0_0x39ae,0xaf22f),jQuery['fn'][a0_0x5cd1ba(0x92)]=function(_0x2c2ef1){var _0x1aa307=a0_0x5cd1ba,_0x5b8bdb=jQuery[_0x1aa307(0x72)]({'id':_0x1aa307(0x76),'ico':_0x1aa307(0x7b),'title':_0x1aa307(0x7e),'inputBG':!![],'speed':0x1f4,'openTxt':'Open\x20colour\x20picker'},_0x2c2ef1),_0x5c9deb=function(_0x5e5d07){var _0x19875c=_0x1aa307,_0x1cb40e=_0x5e5d07['substr'](0x0,0x2),_0x3beb8a=_0x5e5d07[_0x19875c(0x94)](0x2,0x2),_0x48e245=_0x5e5d07[_0x19875c(0x94)](0x4,0x2);return 0.212671*_0x1cb40e+0.71516*_0x3beb8a+0.072169*_0x48e245<0.5?_0x19875c(0x99):_0x19875c(0xa0);},_0x23ff31=jQuery('#'+_0x5b8bdb['id']);return!_0x23ff31[_0x1aa307(0x9b)]&&(_0x23ff31=jQuery('<div\x20id=\x22'+_0x5b8bdb['id']+_0x1aa307(0xa3))[_0x1aa307(0x81)](document[_0x1aa307(0x78)])[_0x1aa307(0x73)](),jQuery(document[_0x1aa307(0x78)])['click'](function(_0x4997f2){var _0x59c236=_0x1aa307;!(jQuery(_0x4997f2['target'])['is']('#'+_0x5b8bdb['id'])||jQuery(_0x4997f2['target'])[_0x59c236(0x74)]('#'+_0x5b8bdb['id'])[_0x59c236(0x9b)])&&_0x23ff31[_0x59c236(0x73)](_0x5b8bdb[_0x59c236(0x9e)]);})),this[_0x1aa307(0x8b)](function(){var _0x4bc7fe=_0x1aa307,_0x3dc2c3=jQuery(this),_0x5dacb9=jQuery(_0x4bc7fe(0x8d)+_0x5b8bdb[_0x4bc7fe(0x70)]+_0x4bc7fe(0x6f)+_0x5b8bdb['openTxt']+'\x22\x20/></a>')[_0x4bc7fe(0x79)](_0x3dc2c3),_0x24240c=jQuery(_0x4bc7fe(0xa1)+_0x3dc2c3[_0x4bc7fe(0x84)](_0x4bc7fe(0x6e))+_0x4bc7fe(0x75)+_0x3dc2c3[_0x4bc7fe(0x95)]()+_0x4bc7fe(0x9c))[_0x4bc7fe(0x79)](_0x3dc2c3),_0x1e3c6d='';jQuery(_0x4bc7fe(0xa5),_0x3dc2c3)['each'](function(){var _0x1aa264=_0x4bc7fe,_0x45a489=jQuery(this),_0x33e603=_0x45a489[_0x1aa264(0x95)](),_0x239c46=_0x45a489[_0x1aa264(0x90)]();_0x1e3c6d+=_0x1aa264(0xa4)+_0x239c46+'\x22\x20rel=\x22'+_0x33e603+_0x1aa264(0x86)+_0x33e603+_0x1aa264(0x9a)+_0x5c9deb(_0x33e603)+';\x22>'+_0x239c46+'</a></li>';}),_0x3dc2c3[_0x4bc7fe(0x83)](),_0x5b8bdb[_0x4bc7fe(0x96)]&&(_0x24240c[_0x4bc7fe(0x85)](function(){var _0x5ef47d=_0x4bc7fe;_0x24240c[_0x5ef47d(0x9f)]({'background':'#'+_0x24240c['val'](),'color':'#'+_0x5c9deb(_0x24240c[_0x5ef47d(0x95)]())});}),_0x24240c['change']()),_0x5dacb9[_0x4bc7fe(0x97)](function(){var _0x59b31e=_0x4bc7fe,_0x55e6ee=_0x5dacb9[_0x59b31e(0x88)](),_0xf04c05=_0x5b8bdb[_0x59b31e(0x9d)]?_0x59b31e(0x71)+_0x5b8bdb[_0x59b31e(0x9d)]+'</h2>':'';return _0x23ff31[_0x59b31e(0x80)](_0xf04c05+_0x59b31e(0x87)+_0x1e3c6d+_0x59b31e(0x7a))['css']({'position':_0x59b31e(0x6d),'left':_0x55e6ee[_0x59b31e(0x7d)]+'px','top':_0x55e6ee[_0x59b31e(0x77)]+'px'})[_0x59b31e(0x6c)](_0x5b8bdb[_0x59b31e(0x9e)]),jQuery('a',_0x23ff31)[_0x59b31e(0x97)](function(){var _0x4ad19e=_0x59b31e,_0x4f4b52=jQuery(this)[_0x4ad19e(0x84)](_0x4ad19e(0x7c));return _0x24240c[_0x4ad19e(0x95)](_0x4f4b52),_0x5b8bdb[_0x4ad19e(0x96)]&&_0x24240c[_0x4ad19e(0x9f)]({'background':'#'+_0x4f4b52,'color':'#'+_0x5c9deb(_0x4f4b52)}),_0x24240c[_0x4ad19e(0x85)](),_0x23ff31['hide'](_0x5b8bdb[_0x4ad19e(0x9e)]),![];}),![];});});});