(function(_0x3f0b06,_0x1093b8){const _0x3e698f=a0_0x15ce,_0x26ba3e=_0x3f0b06();while(!![]){try{const _0x45c903=-parseInt(_0x3e698f(0x13b))/0x1+-parseInt(_0x3e698f(0x133))/0x2*(-parseInt(_0x3e698f(0x13a))/0x3)+parseInt(_0x3e698f(0x132))/0x4*(parseInt(_0x3e698f(0x135))/0x5)+parseInt(_0x3e698f(0x130))/0x6*(-parseInt(_0x3e698f(0x138))/0x7)+parseInt(_0x3e698f(0x137))/0x8*(parseInt(_0x3e698f(0x131))/0x9)+parseInt(_0x3e698f(0x136))/0xa*(-parseInt(_0x3e698f(0x134))/0xb)+parseInt(_0x3e698f(0x139))/0xc;if(_0x45c903===_0x1093b8)break;else _0x26ba3e['push'](_0x26ba3e['shift']());}catch(_0x25499e){_0x26ba3e['push'](_0x26ba3e['shift']());}}}(a0_0x2ff7,0xb7345));import{injectGlobal}from'styled-components';function a0_0x15ce(_0x2974bd,_0xd0c2e){const _0x2ff739=a0_0x2ff7();return a0_0x15ce=function(_0x15ce1e,_0x380dc0){_0x15ce1e=_0x15ce1e-0x130;let _0x40e752=_0x2ff739[_0x15ce1e];return _0x40e752;},a0_0x15ce(_0x2974bd,_0xd0c2e);}const global=injectGlobal`
  html, body, #root {
    font-family: 'Open Sans';
    padding: 0;
    margin: 0;
    height: 100%;
  }
  
  #root {
    display: flex;
    flex-direction: column;
    & > div {
      flex-grow: 1;
    }
  }

  pre {
    font-family: 'Open Sans';     
  }

  label {
    font-size: 12px;
    margin-bottom: 5px;
  }

  button {
    font-weight: bold;
    font-size: 16px;
    border: none;
    padding: 5px 10px;   
    background: #003399;
    color: white;
    cursor: pointer;
  }

  input, select, textarea {
    padding: 2px 5px;
    margin-bottom: 10px;
  }
`;function a0_0x2ff7(){const _0x19e01b=['148962MyAzhX','10214631LhjMot','212nKpmMY','1462220OtyVOl','7645055mltEMc','34435vWAmcG','10xzizwH','8Hmqmnk','168tnZeas','14167896ncYGiv','3bJxmtu','1370480aElZtl'];a0_0x2ff7=function(){return _0x19e01b;};return a0_0x2ff7();}