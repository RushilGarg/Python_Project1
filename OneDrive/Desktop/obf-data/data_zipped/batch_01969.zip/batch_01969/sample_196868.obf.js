function a0_0x2c24(_0x1f50be,_0x1b809e){var _0x4ebccc=a0_0x4ebc();return a0_0x2c24=function(_0x2c24be,_0x159470){_0x2c24be=_0x2c24be-0xfe;var _0x5d51e9=_0x4ebccc[_0x2c24be];return _0x5d51e9;},a0_0x2c24(_0x1f50be,_0x1b809e);}(function(_0x2c4158,_0x1d9183){var _0x11750d=a0_0x2c24,_0x95d613=_0x2c4158();while(!![]){try{var _0x4782b6=-parseInt(_0x11750d(0xff))/0x1*(-parseInt(_0x11750d(0x106))/0x2)+parseInt(_0x11750d(0x104))/0x3*(parseInt(_0x11750d(0x105))/0x4)+parseInt(_0x11750d(0x107))/0x5+-parseInt(_0x11750d(0x102))/0x6*(parseInt(_0x11750d(0x101))/0x7)+-parseInt(_0x11750d(0x100))/0x8+parseInt(_0x11750d(0xfe))/0x9+-parseInt(_0x11750d(0x103))/0xa;if(_0x4782b6===_0x1d9183)break;else _0x95d613['push'](_0x95d613['shift']());}catch(_0x9d6ab9){_0x95d613['push'](_0x95d613['shift']());}}}(a0_0x4ebc,0xa3165));function a0_0x4ebc(){var _0x5d64f5=['52dTXihF','2EerZXp','1924345GjzHWG','10650339AMQkza','156889mDIZCY','38896GvRecU','2080575yxtyOV','18tPFMkq','5344800fUxdFx','86283bTmRDN'];a0_0x4ebc=function(){return _0x5d64f5;};return a0_0x4ebc();}import{css}from'lit-element';export default css`
  .hljs,
  code[data-filename] {
    display: block;
    overflow-x: auto;
    padding: 1rem;
    background: #1d1f21;
    border-radius: 7px;
    box-shadow: rgba(0, 0, 0, 0.55) 0px 11px 11px 0px;
    font-size: 0.8rem;
    color: #c5c8c6;
  }

  .hljs::selection,
  .hljs span::selection,
  code[data-filename]::selection,
  code[data-filename] span::selection {
    background: #373b41;
  }

  code[data-filename] {
    position: relative;
    padding-top: 22px;
  }

  code[data-filename]:before {
    position: absolute;
    top: 0;
    right: 0;
    font-size: 0.7rem;
    content: attr(data-filename);
    padding: 2px 6px;
    border-radius: 0 0 0 7px;
    border-left: 1px solid #c5c8c6;
    border-bottom: 1px solid #c5c8c6;
    color: #fff;
  }

  .hljs-title,
  .hljs-name {
    color: #f0c674;
  }

  .hljs-comment {
    color: #707880;
  }

  .hljs-meta,
  .hljs-meta .hljs-keyword {
    color: #f0c674;
  }

  .hljs-number,
  .hljs-symbol,
  .hljs-literal,
  .hljs-deletion,
  .hljs-link {
    color: #cc6666
  }

  .hljs-string,
  .hljs-doctag,
  .hljs-addition,
  .hljs-regexp,
  .hljs-selector-attr,
  .hljs-selector-pseudo {
    color: #b5bd68;
  }

  .hljs-attribute,
  .hljs-code,
  .hljs-selector-id {
    color: #b294bb;
  }

  .hljs-keyword,
  .hljs-selector-tag,
  .hljs-bullet,
  .hljs-tag {
    color: #81a2be;
  }

  .hljs-subst,
  .hljs-variable,
  .hljs-template-tag,
  .hljs-template-variable {
    color: #8abeb7;
  }

  .hljs-type,
  .hljs-built_in,
  .hljs-builtin-name,
  .hljs-quote,
  .hljs-section,
  .hljs-selector-class {
    color: #de935f;
  }

  .hljs-emphasis {
    font-style: italic;
  }

  .hljs-strong {
    font-weight: bold;
  }

  @media (min-width: 768px) {
    code[data-filename] {
      padding-top: 1rem;
    }

    code[data-filename]:before {
      font-size: inherit;
      opacity: 0.5;
      transition: opacity .5s;
    }

    code[data-filename]:hover:before {
      opacity: 1;
    }
  }
`;