/*!
 * -----------
 * ITPDB®-Data
 * -----------
 * Data of ITPDB — A manually curated dedicated ion transport proteins database.
 * _____________________________________________________________________________
 *
 * Grunt, http://gruntjs.com/ — The JavaScript Task Runner.
 * _____________________________________________________________________________
 *
 * Architecture and Code Handcrafted by Prabhat Kumar.
 * Architectuur en Code handgemaakt door Prabhat Kumar.
 * @author    : Prabhat Kumar [http://prabhatkumar.org/].
 * @copyright : Prabhat Kumar [http://prabhatkumar.org/].
 * @copyright : Sequømics Research [http://research.sequomics.com/].
 * @copyright : Sequømics Corporation [http://sequomics.com/].
 * _____________________________________________________________________________
 *
 * @date      : 10-Dec-2016
 * @license   : Apache, version 2.0
 * @require   : Node.js®
 * @require   : NPM
 * @require   : package.json
 * @build     : SEED™ — Skövde
 *              └────── A Sequømics Product — http://seed.sequomics.com/.
 * _____________________________________________________________________________
 *
 * --/The Heart of Build System/-- of "ITPDB®-Data".
 * _____________________________________________________________________________
 */
var a0_0x5cadce=a0_0x505d;function a0_0x505d(_0x33aa18,_0x5dcb85){var _0x1fc4dc=a0_0x1fc4();return a0_0x505d=function(_0x505dcc,_0x34961d){_0x505dcc=_0x505dcc-0x158;var _0x16838e=_0x1fc4dc[_0x505dcc];return _0x16838e;},a0_0x505d(_0x33aa18,_0x5dcb85);}function a0_0x1fc4(){var _0x474a11=['slice','2175288WvoYAb','62596KabLmq','./package.json','406889bKYIbH','1160124gpGrjY','9440586YtJpKA','46096450ExXUPq','readFileSync','15FLZQFt','184qIifrH','24opuMAo','exports','utf8','51664mGhsdj','version','charCodeAt','parse'];a0_0x1fc4=function(){return _0x474a11;};return a0_0x1fc4();}(function(_0x213a87,_0x4e056){var _0x4b4b6a=a0_0x505d,_0x20720e=_0x213a87();while(!![]){try{var _0x31812e=-parseInt(_0x4b4b6a(0x15b))/0x1*(parseInt(_0x4b4b6a(0x164))/0x2)+parseInt(_0x4b4b6a(0x15e))/0x3+-parseInt(_0x4b4b6a(0x167))/0x4+parseInt(_0x4b4b6a(0x162))/0x5*(-parseInt(_0x4b4b6a(0x15a))/0x6)+-parseInt(_0x4b4b6a(0x15d))/0x7*(parseInt(_0x4b4b6a(0x163))/0x8)+-parseInt(_0x4b4b6a(0x15f))/0x9+parseInt(_0x4b4b6a(0x160))/0xa;if(_0x31812e===_0x4e056)break;else _0x20720e['push'](_0x20720e['shift']());}catch(_0xf34696){_0x20720e['push'](_0x20720e['shift']());}}}(a0_0x1fc4,0xb93ee));var fs=require('fs');function stripBOM(_0x4a12c4){var _0xcefddf=a0_0x505d;return _0x4a12c4[_0xcefddf(0x169)](0x0)===0xfeff&&(_0x4a12c4=_0x4a12c4[_0xcefddf(0x159)](0x1)),_0x4a12c4;}var pkg=JSON[a0_0x5cadce(0x158)](stripBOM(fs[a0_0x5cadce(0x161)](a0_0x5cadce(0x15c),{'encoding':a0_0x5cadce(0x166)}))),seed=JSON[a0_0x5cadce(0x158)](stripBOM(fs[a0_0x5cadce(0x161)]('./seed.json',{'encoding':a0_0x5cadce(0x166)}))),version={'pkg':pkg['version'],'seed':seed[a0_0x5cadce(0x168)]};module[a0_0x5cadce(0x165)]=version;