/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x6219aa=a0_0x5d86;function a0_0x57fa(){var _0x3949fc=['benchmark\x20finished','path','300864Pgtqwa','2084436WzcqAt','end','::native:len=','should\x20not\x20return\x20NaN','resolve','3866156lJOydn','./../lib/dmediansorted.native.js','pass','20550501YofmPP','@stdlib/math/base/assert/is-nan','3882864kulzXW','@stdlib/array/float64','1715142QorhsZ','8eKYowT','@stdlib/bench','@stdlib/utils/try-require','fail','length','iterations','@stdlib/math/base/special/pow','10TddxXD','toc','9451862uzBBMP','name'];a0_0x57fa=function(){return _0x3949fc;};return a0_0x57fa();}(function(_0x221d90,_0x2af91e){var _0x50513e=a0_0x5d86,_0x562db8=_0x221d90();while(!![]){try{var _0x36daa8=parseInt(_0x50513e(0x88))/0x1+-parseInt(_0x50513e(0x96))/0x2+parseInt(_0x50513e(0x97))/0x3+parseInt(_0x50513e(0x81))/0x4+parseInt(_0x50513e(0x90))/0x5*(-parseInt(_0x50513e(0x86))/0x6)+parseInt(_0x50513e(0x92))/0x7+-parseInt(_0x50513e(0x89))/0x8*(parseInt(_0x50513e(0x84))/0x9);if(_0x36daa8===_0x2af91e)break;else _0x562db8['push'](_0x562db8['shift']());}catch(_0x3a8518){_0x562db8['push'](_0x562db8['shift']());}}}(a0_0x57fa,0xf3cfa));function a0_0x5d86(_0x3560b2,_0x1e5a94){var _0x57fac5=a0_0x57fa();return a0_0x5d86=function(_0x5d8694,_0x37d5b9){_0x5d8694=_0x5d8694-0x7d;var _0x158595=_0x57fac5[_0x5d8694];return _0x158595;},a0_0x5d86(_0x3560b2,_0x1e5a94);}var resolve=require(a0_0x6219aa(0x95))[a0_0x6219aa(0x80)],bench=require(a0_0x6219aa(0x8a)),isnan=require(a0_0x6219aa(0x85)),pow=require(a0_0x6219aa(0x8f)),Float64Array=require(a0_0x6219aa(0x87)),tryRequire=require(a0_0x6219aa(0x8b)),pkg=require('./../package.json')[a0_0x6219aa(0x93)],dmediansorted=tryRequire(resolve(__dirname,a0_0x6219aa(0x82))),opts={'skip':dmediansorted instanceof Error};function createBenchmark(_0x35a0ab){var _0xf20f08=a0_0x6219aa,_0x266e59,_0x23bc6e;_0x266e59=new Float64Array(_0x35a0ab);for(_0x23bc6e=0x0;_0x23bc6e<_0x266e59[_0xf20f08(0x8d)];_0x23bc6e++){_0x266e59[_0x23bc6e]=_0x23bc6e;}return _0x229ac7;function _0x229ac7(_0x411fc5){var _0x496ec4=_0xf20f08,_0x36aa50,_0x1a14bf;_0x411fc5['tic']();for(_0x1a14bf=0x0;_0x1a14bf<_0x411fc5[_0x496ec4(0x8e)];_0x1a14bf++){_0x36aa50=dmediansorted(_0x266e59[_0x496ec4(0x8d)],_0x266e59,0x1),isnan(_0x36aa50)&&_0x411fc5['fail'](_0x496ec4(0x7f));}_0x411fc5[_0x496ec4(0x91)](),isnan(_0x36aa50)&&_0x411fc5[_0x496ec4(0x8c)]('should\x20not\x20return\x20NaN'),_0x411fc5[_0x496ec4(0x83)](_0x496ec4(0x94)),_0x411fc5[_0x496ec4(0x7d)]();}}function main(){var _0x183c70=a0_0x6219aa,_0x4823af,_0x2a7b59,_0x4bb850,_0x36763b,_0x3cbae9;_0x2a7b59=0x1,_0x4bb850=0x6;for(_0x3cbae9=_0x2a7b59;_0x3cbae9<=_0x4bb850;_0x3cbae9++){_0x4823af=pow(0xa,_0x3cbae9),_0x36763b=createBenchmark(_0x4823af),bench(pkg+_0x183c70(0x7e)+_0x4823af,opts,_0x36763b);}}main();