/**
 * @license
 * Copyright 2017 Google Inc. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';const a0_0x4d95fb=a0_0xfabd;(function(_0x56b33e,_0x1ba5c5){const _0x5ce269=a0_0xfabd,_0x443881=_0x56b33e();while(!![]){try{const _0x217f46=-parseInt(_0x5ce269(0x177))/0x1+parseInt(_0x5ce269(0x17e))/0x2+parseInt(_0x5ce269(0x178))/0x3+parseInt(_0x5ce269(0x175))/0x4*(parseInt(_0x5ce269(0x17a))/0x5)+-parseInt(_0x5ce269(0x17c))/0x6+-parseInt(_0x5ce269(0x182))/0x7+parseInt(_0x5ce269(0x181))/0x8;if(_0x217f46===_0x1ba5c5)break;else _0x443881['push'](_0x443881['shift']());}catch(_0x4e62cb){_0x443881['push'](_0x443881['shift']());}}}(a0_0xb3f0,0x7dfb3));function a0_0xb3f0(){const _0x538014=['1545554NoXjQk','rawValue','Accessibility:\x20layout-table\x20audit','6063944mGbiyp','6356588pETFtr','http://example.com/','generates\x20an\x20audit\x20output\x20(single\x20node)','audit','generates\x20an\x20audit\x20output','7452pFKhlV','layout-table','352098YnaUDW','591603HFbmOf','assert','2475jOiFdv','equal','5243730ndiFwU','../../../audits/accessibility/layout-table.js'];a0_0xb3f0=function(){return _0x538014;};return a0_0xb3f0();}function a0_0xfabd(_0x49af4d,_0x28bad2){const _0xb3f0e=a0_0xb3f0();return a0_0xfabd=function(_0xfabdd2,_0x2cda3f){_0xfabdd2=_0xfabdd2-0x175;let _0x318cf7=_0xb3f0e[_0xfabdd2];return _0x318cf7;},a0_0xfabd(_0x49af4d,_0x28bad2);}const Audit=require(a0_0x4d95fb(0x17d)),assert=require(a0_0x4d95fb(0x179));describe(a0_0x4d95fb(0x180),()=>{const _0x24bc0b=a0_0x4d95fb;it(_0x24bc0b(0x186),()=>{const _0x2e10ba=_0x24bc0b,_0x41267f={'Accessibility':{'violations':[{'id':'layout-table','nodes':[],'help':_0x2e10ba(0x183)}]}},_0x4eae94=Audit[_0x2e10ba(0x185)](_0x41267f);assert[_0x2e10ba(0x17b)](_0x4eae94[_0x2e10ba(0x17f)],![]);}),it(_0x24bc0b(0x184),()=>{const _0x410282=_0x24bc0b,_0x14832b={'Accessibility':{'violations':[{'id':_0x410282(0x176),'nodes':[{}],'help':_0x410282(0x183)}]}},_0x5b06ba=Audit[_0x410282(0x185)](_0x14832b);assert[_0x410282(0x17b)](_0x5b06ba[_0x410282(0x17f)],![]);});});