/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x108968=a0_0x4e94;function a0_0x1398(){var _0x58f478=['849678BomdCr',']`.\x20Value:\x20`','2870466WTUGST','plot:base:set:y-axis-orient','change','invalid\x20value.\x20`yAxisOrient`\x20must\x20be\x20one\x20of\x20`[','Current\x20value:\x20%s.','emit','debug','798775zDjxEv','7gBBKmb','New\x20value:\x20%s.','1681488ZSOJDB','111336ayvSNN','364760nzADsr','@stdlib/utils/index-of','_yAxisOrient','join','283467ERlALA'];a0_0x1398=function(){return _0x58f478;};return a0_0x1398();}(function(_0x4d07b8,_0x984438){var _0x1397a0=a0_0x4e94,_0x534bfb=_0x4d07b8();while(!![]){try{var _0x5eb51e=-parseInt(_0x1397a0(0x1b2))/0x1+parseInt(_0x1397a0(0x1ae))/0x2+parseInt(_0x1397a0(0x1b3))/0x3+-parseInt(_0x1397a0(0x1ad))/0x4+-parseInt(_0x1397a0(0x1a9))/0x5+parseInt(_0x1397a0(0x1a2))/0x6*(parseInt(_0x1397a0(0x1aa))/0x7)+-parseInt(_0x1397a0(0x1ac))/0x8;if(_0x5eb51e===_0x984438)break;else _0x534bfb['push'](_0x534bfb['shift']());}catch(_0x45e045){_0x534bfb['push'](_0x534bfb['shift']());}}}(a0_0x1398,0x40277));var logger=require(a0_0x108968(0x1a8)),indexOf=require(a0_0x108968(0x1af)),ORIENTATIONS=require('./orientations.json'),debug=logger(a0_0x108968(0x1a3));function a0_0x4e94(_0x25559d,_0x52c8d6){var _0x13989a=a0_0x1398();return a0_0x4e94=function(_0x4e945b,_0x202ae7){_0x4e945b=_0x4e945b-0x1a1;var _0x2af7fa=_0x13989a[_0x4e945b];return _0x2af7fa;},a0_0x4e94(_0x25559d,_0x52c8d6);}function set(_0x3b333b){var _0x3d82b2=a0_0x108968;if(indexOf(ORIENTATIONS,_0x3b333b)===-0x1)throw new TypeError(_0x3d82b2(0x1a5)+ORIENTATIONS[_0x3d82b2(0x1b1)](',\x20')+_0x3d82b2(0x1a1)+_0x3b333b+'.`');_0x3b333b!==this[_0x3d82b2(0x1b0)]&&(debug(_0x3d82b2(0x1a6),this[_0x3d82b2(0x1b0)]),this[_0x3d82b2(0x1b0)]=_0x3b333b,debug(_0x3d82b2(0x1ab),this[_0x3d82b2(0x1b0)]),this[_0x3d82b2(0x1a7)](_0x3d82b2(0x1a4)));}module['exports']=set;