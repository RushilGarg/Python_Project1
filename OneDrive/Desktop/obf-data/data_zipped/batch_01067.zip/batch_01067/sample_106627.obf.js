/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x481160=a0_0x3b21;(function(_0x4df982,_0x5b1594){var _0x286915=a0_0x3b21,_0x56075a=_0x4df982();while(!![]){try{var _0xf46533=-parseInt(_0x286915(0x82))/0x1*(-parseInt(_0x286915(0x80))/0x2)+parseInt(_0x286915(0x81))/0x3*(-parseInt(_0x286915(0x84))/0x4)+parseInt(_0x286915(0x88))/0x5+parseInt(_0x286915(0x7d))/0x6+parseInt(_0x286915(0x86))/0x7*(-parseInt(_0x286915(0x7f))/0x8)+parseInt(_0x286915(0x85))/0x9+-parseInt(_0x286915(0x7e))/0xa*(-parseInt(_0x286915(0x87))/0xb);if(_0xf46533===_0x5b1594)break;else _0x56075a['push'](_0x56075a['shift']());}catch(_0x4d43b8){_0x56075a['push'](_0x56075a['shift']());}}}(a0_0x5202,0x30ec7));function a0_0x3b21(_0x2fa58a,_0x433891){var _0x520210=a0_0x5202();return a0_0x3b21=function(_0x3b2172,_0x3703d2){_0x3b2172=_0x3b2172-0x7d;var _0x217f06=_0x520210[_0x3b2172];return _0x217f06;},a0_0x3b21(_0x2fa58a,_0x433891);}function a0_0x5202(){var _0x2e8808=['1504359BkeLjZ','1660302pYcJgo','1385593BAdaAz','156275bZcZqU','2232630xBqysH','10qyZXeY','8vYAXDO','115342uEQuGd','84CZGnwF','1krAioD','exports','45224wRIZHJ'];a0_0x5202=function(){return _0x2e8808;};return a0_0x5202();}function abs2(_0x3b0bf0){return _0x3b0bf0*_0x3b0bf0;}module[a0_0x481160(0x83)]=abs2;