/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2e0559=a0_0x4495;function a0_0x4495(_0x576506,_0x1074d8){var _0x56897b=a0_0x5689();return a0_0x4495=function(_0x44959a,_0x360b40){_0x44959a=_0x44959a-0x181;var _0x287b7f=_0x56897b[_0x44959a];return _0x287b7f;},a0_0x4495(_0x576506,_0x1074d8);}(function(_0x216b02,_0x12138e){var _0x10bb22=a0_0x4495,_0x18b2d2=_0x216b02();while(!![]){try{var _0x45c5bc=-parseInt(_0x10bb22(0x18c))/0x1+-parseInt(_0x10bb22(0x18b))/0x2+parseInt(_0x10bb22(0x18d))/0x3*(-parseInt(_0x10bb22(0x184))/0x4)+-parseInt(_0x10bb22(0x181))/0x5+parseInt(_0x10bb22(0x185))/0x6*(parseInt(_0x10bb22(0x189))/0x7)+-parseInt(_0x10bb22(0x187))/0x8*(parseInt(_0x10bb22(0x186))/0x9)+parseInt(_0x10bb22(0x188))/0xa;if(_0x45c5bc===_0x12138e)break;else _0x18b2d2['push'](_0x18b2d2['shift']());}catch(_0x4e76ea){_0x18b2d2['push'](_0x18b2d2['shift']());}}}(a0_0x5689,0xe8544));function a0_0x5689(){var _0x27a557=['4204272nXEPsw','1235511ljaXNO','8IGkbOm','40228340dmXLlC','7khFvPz','exports','2679554TlUzpo','1562820EpsGJB','927hrbSuo','2073535iQnqgG','@stdlib/utils/property-descriptor','boolean','4108QHfoxY'];a0_0x5689=function(){return _0x27a557;};return a0_0x5689();}var propertyDescriptor=require(a0_0x2e0559(0x182));function isDataProperty(_0x2f1638,_0x1fae47){var _0x49599e=a0_0x2e0559,_0x479c52=propertyDescriptor(_0x2f1638,_0x1fae47);return _0x479c52!==null&&typeof _0x479c52['writable']===_0x49599e(0x183);}module[a0_0x2e0559(0x18a)]=isDataProperty;