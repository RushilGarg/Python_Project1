/**
 * Symbol Art Editor
 * 
 * @author malulleybovo (since 2021)
 * @license GNU General Public License v3.0
 *
 * @licstart  The following is the entire license notice for the
 *  JavaScript code in this page.
 *
 * Copyright (C) 2021  Arthur Malulley B. de O.
 *
 *
 * The JavaScript code in this page is free software: you can
 * redistribute it and/or modify it under the terms of the GNU
 * General Public License (GNU GPL) as published by the Free Software
 * Foundation, either version 3 of the License, or (at your option)
 * any later version.  The code is distributed WITHOUT ANY WARRANTY;
 * without even the implied warranty of MERCHANTABILITY or FITNESS
 * FOR A PARTICULAR PURPOSE.  See the GNU GPL for more details.
 *
 * As additional permission under GNU GPL version 3 section 7, you
 * may distribute non-source (e.g., minimized or compacted) forms of
 * that code without the copy of the GNU GPL normally required by
 * section 4, provided you include this license notice and a URL
 * through which recipients can access the Corresponding Source.
 *
 * @licend  The above is the entire license notice
 * for the JavaScript code in this page.
 *
 */
const a0_0x305e59=a0_0x2398;(function(_0x4b3e03,_0x147b5e){const _0x217a9e=a0_0x2398,_0x3dd7ce=_0x4b3e03();while(!![]){try{const _0x25bc98=parseInt(_0x217a9e(0xa8))/0x1+parseInt(_0x217a9e(0xb0))/0x2*(parseInt(_0x217a9e(0xa9))/0x3)+-parseInt(_0x217a9e(0xab))/0x4*(parseInt(_0x217a9e(0xb5))/0x5)+-parseInt(_0x217a9e(0xb4))/0x6+-parseInt(_0x217a9e(0xa5))/0x7*(-parseInt(_0x217a9e(0xb3))/0x8)+parseInt(_0x217a9e(0xa2))/0x9+-parseInt(_0x217a9e(0xb2))/0xa*(parseInt(_0x217a9e(0xae))/0xb);if(_0x25bc98===_0x147b5e)break;else _0x3dd7ce['push'](_0x3dd7ce['shift']());}catch(_0x4b8f05){_0x3dd7ce['push'](_0x3dd7ce['shift']());}}}(a0_0x1a8a,0x918e6));function a0_0x2398(_0x2b9c47,_0x444fab){const _0x1a8ac6=a0_0x1a8a();return a0_0x2398=function(_0x2398ea,_0x4b4605){_0x2398ea=_0x2398ea-0x9f;let _0x41e51a=_0x1a8ac6[_0x2398ea];return _0x41e51a;},a0_0x2398(_0x2b9c47,_0x444fab);}class Layer3D extends THREE[a0_0x305e59(0xa3)]{static ['backgroundMaterial']=new THREE[(a0_0x305e59(0xa1))]({'color':0x3c3c3c,'transparent':!![]});static [a0_0x305e59(0xa0)]=new THREE[(a0_0x305e59(0xac))]({'color':0x808080,'transparent':!![]});static ['selectedOutlineMaterial']=new THREE[(a0_0x305e59(0xac))]({'color':0xff9e2c,'transparent':!![]});static [a0_0x305e59(0xb1)]={};get[a0_0x305e59(0xaa)](){return'';}['_isFocused']=!![];get['isFocused'](){const _0x555eaa=a0_0x305e59;return this[_0x555eaa(0xa6)];}set['isFocused'](_0x1afd16){const _0x25cf85=a0_0x305e59;typeof _0x1afd16==='boolean'&&this[_0x25cf85(0xa6)]!==_0x1afd16&&(this[_0x25cf85(0xa6)]=_0x1afd16,this[_0x25cf85(0xbb)]());}constructor(){super();}static[a0_0x305e59(0xaf)]({usingSymbolArt:_0x490f54}){const _0x568a39=a0_0x305e59;let _0x342f01=[];_0x490f54[_0x568a39(0xb8)][_0x568a39(0xa4)](_0x48d899=>{const _0x34f557=_0x568a39;_0x342f01[_0x34f557(0xb9)](_0x48d899[_0x34f557(0xad)]);});let _0x149196=Object[_0x568a39(0xba)](Layer3D[_0x568a39(0xb1)]),_0x32d3e3=_0x149196[_0x568a39(0xa7)](_0xf725fc=>!_0x342f01[_0x568a39(0x9f)](_0xf725fc));for(var _0xdd1df5 in _0x32d3e3){Layer3D['layersInUse'][_0x32d3e3[_0xdd1df5]]&&Layer3D[_0x568a39(0xb1)][_0x32d3e3[_0xdd1df5]][_0x568a39(0xb7)]&&Layer3D[_0x568a39(0xb1)][_0x32d3e3[_0xdd1df5]]['free'](),delete Layer3D[_0x568a39(0xb1)][_0x32d3e3[_0xdd1df5]];}}[a0_0x305e59(0xbb)](){}[a0_0x305e59(0xb6)]({using:_0x4b1e62}){}[a0_0x305e59(0xb7)](){const _0x347c7d=a0_0x305e59;delete Layer3D[_0x347c7d(0xb1)][this[_0x347c7d(0xaa)]];}}function a0_0x1a8a(){const _0xe44d95=['free','root','push','keys','changedFocus','includes','outlineMaterial','MeshBasicMaterial','8662698AnMihp','Group','depthFirstIterator','973yjoGHv','_isFocused','filter','1184798twTYUn','6prqGEd','layerUuid','2720MBXOXO','LineBasicMaterial','uuid','2155219xyoUwN','freeUnusedLayers','407046IzPgSY','layersInUse','40gjJXCa','24176ShVOGk','2537220JsGsHn','8615lfyIeO','update'];a0_0x1a8a=function(){return _0xe44d95;};return a0_0x1a8a();}