/**
 * Javascript events for the `tool_usertours` subsystem.
 *
 * @module tool_usertours/events
 * @copyright 2021 Andrew Lyons <andrew@nicols.co.uk>
 * @license http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 *
 * @example <caption>Example of listening to a step rendering event and cancelling it.</caption>
 * import {eventTypes as userTourEvents} from 'tool_usertours/events';
 *
 * document.addEventListener(userTourEvents.stepRender, e => {
 *     console.log(e.detail.tour); // The Tour instance
 *     e.preventDefault();
 * });
 */
function a0_0x8ec8(){const _0x3108cc=['36228FdgVDa','1430012nYrwoT','tool_usertours/tourEnd','19695632bXtten','tool_usertours/stepRendered','195303ZKUfFA','5JLhBCP','tool_usertours/stepHide','525EqipZP','15qGIZHY','3154490fOxfMD','9fdjrWL','tool_usertours/tourEnded','5711752wXQbHi','112082diCFKy','tool_usertours/stepHidden','tool_usertours/stepRender'];a0_0x8ec8=function(){return _0x3108cc;};return a0_0x8ec8();}const a0_0x52bb23=a0_0x441c;(function(_0xc0835b,_0x1667eb){const _0x2ce108=a0_0x441c,_0x348db3=_0xc0835b();while(!![]){try{const _0xcc5360=-parseInt(_0x2ce108(0x6e))/0x1+-parseInt(_0x2ce108(0x77))/0x2*(parseInt(_0x2ce108(0x72))/0x3)+-parseInt(_0x2ce108(0x6a))/0x4*(parseInt(_0x2ce108(0x6f))/0x5)+parseInt(_0x2ce108(0x69))/0x6*(parseInt(_0x2ce108(0x71))/0x7)+parseInt(_0x2ce108(0x76))/0x8*(-parseInt(_0x2ce108(0x74))/0x9)+-parseInt(_0x2ce108(0x73))/0xa+parseInt(_0x2ce108(0x6c))/0xb;if(_0xcc5360===_0x1667eb)break;else _0x348db3['push'](_0x348db3['shift']());}catch(_0x4ee201){_0x348db3['push'](_0x348db3['shift']());}}}(a0_0x8ec8,0x5d005));function a0_0x441c(_0x3ddd54,_0x5cdbff){const _0x8ec833=a0_0x8ec8();return a0_0x441c=function(_0x441c1c,_0x415acc){_0x441c1c=_0x441c1c-0x67;let _0x1ca0a6=_0x8ec833[_0x441c1c];return _0x1ca0a6;},a0_0x441c(_0x3ddd54,_0x5cdbff);}export const eventTypes={'stepRender':a0_0x52bb23(0x68),'stepRendered':a0_0x52bb23(0x6d),'tourStart':'tool_usertours/tourStart','tourStarted':'tool_usertours/tourStarted','tourEnd':a0_0x52bb23(0x6b),'tourEnded':a0_0x52bb23(0x75),'stepHide':a0_0x52bb23(0x70),'stepHidden':a0_0x52bb23(0x67)};