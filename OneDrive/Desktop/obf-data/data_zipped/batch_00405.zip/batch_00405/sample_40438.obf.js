const a0_0x5f40cb=a0_0x4a51;(function(_0xd97acc,_0x2d929c){const _0x1558d4=a0_0x4a51,_0x330817=_0xd97acc();while(!![]){try{const _0x2a7612=-parseInt(_0x1558d4(0xbd))/0x1+parseInt(_0x1558d4(0xbf))/0x2+parseInt(_0x1558d4(0xbe))/0x3+-parseInt(_0x1558d4(0xc1))/0x4+parseInt(_0x1558d4(0xb9))/0x5*(-parseInt(_0x1558d4(0xbc))/0x6)+parseInt(_0x1558d4(0xba))/0x7+parseInt(_0x1558d4(0xbb))/0x8*(-parseInt(_0x1558d4(0xc0))/0x9);if(_0x2a7612===_0x2d929c)break;else _0x330817['push'](_0x330817['shift']());}catch(_0x3753f0){_0x330817['push'](_0x330817['shift']());}}}(a0_0x4433,0x86286));import a0_0x525fa9 from'styled-components';function a0_0x4a51(_0x13ace6,_0x1c65f2){const _0x443384=a0_0x4433();return a0_0x4a51=function(_0x4a51f7,_0x27c1e4){_0x4a51f7=_0x4a51f7-0xb9;let _0x1363d6=_0x443384[_0x4a51f7];return _0x1363d6;},a0_0x4a51(_0x13ace6,_0x1c65f2);}export const Article=a0_0x525fa9[a0_0x5f40cb(0xc2)]`
  min-width: 0;
  font-size: 2.5rem;
  line-height: 4rem;

  & h1 {
    font-size: 5rem;
    font-weight: 400;
    line-height: 6rem;
  }
  & h2 {
    font-size: 3.5rem;
    font-weight: 600;
    line-height: 4rem;
    margin: 8rem 0 1rem 0;
  }
  & h3 {
    font-size: 3rem;
    font-weight: 600;
  }
  & h4 {
    font-size: 2.75rem;
    font-weight: 600;
  }
  & p {
    margin-bottom: 3rem;
    max-width: 50ch;
  }
  & ul {
    margin-bottom: 3rem;
    padding-left: 1em;
    list-style: disc;
    & p {
      margin: 0;
    }
  }
  & ol {
    margin-bottom: 3rem;
    & p {
      margin: 0;
    }
    & ol {
      list-style-type: lower-alpha;
      & ol {
        list-style-type: lower-roman;
      }
    }
  }
  & li {
    margin-bottom: 1rem;
  }
  & blockquote {
    font-family: Georgia;
    font-size: 3rem;
    font-style: italic;
    padding: 0 6rem;
  }
  & pre {
    font-size: 1.75rem;
    border-radius: 1rem;
    margin: 0 -2rem 3rem !important;
  }
  & code {
    font-size: 1.75rem;
  }
`;function a0_0x4433(){const _0x1118e7=['1467CAvTiv','660108lCoLRH','article','405JXGucn','6747132Llfdem','40152adLvzx','18996DffXwQ','278694rUhmgE','1932612iiatZz','919388mnfhUV'];a0_0x4433=function(){return _0x1118e7;};return a0_0x4433();}