function a0_0x2fdc(){var _0x764448=['stringify','36QuNrzx','styles','1934384OCeRYT','25765miemqj','12rJcBtg','name','define','3210504BqxIGE','properties','render','mySocket','handleValueChange','21zbNHjl','2091774YdMlNn','min','send','508JmfTDa','1491900vjKJnC','arro-progress','value','2JysyNL','517593Ilbvhc','100','17792951zEnlTW'];a0_0x2fdc=function(){return _0x764448;};return a0_0x2fdc();}var a0_0xfc1a5c=a0_0x4728;(function(_0x169c2e,_0x5192ce){var _0x3aabf1=a0_0x4728,_0x5e4334=_0x169c2e();while(!![]){try{var _0x5629b3=parseInt(_0x3aabf1(0x206))/0x1+parseInt(_0x3aabf1(0x205))/0x2*(-parseInt(_0x3aabf1(0x1fe))/0x3)+-parseInt(_0x3aabf1(0x201))/0x4*(parseInt(_0x3aabf1(0x1f4))/0x5)+-parseInt(_0x3aabf1(0x1f8))/0x6+-parseInt(_0x3aabf1(0x1fd))/0x7*(-parseInt(_0x3aabf1(0x1f3))/0x8)+-parseInt(_0x3aabf1(0x1f1))/0x9*(parseInt(_0x3aabf1(0x202))/0xa)+parseInt(_0x3aabf1(0x1ef))/0xb*(parseInt(_0x3aabf1(0x1f5))/0xc);if(_0x5629b3===_0x5192ce)break;else _0x5e4334['push'](_0x5e4334['shift']());}catch(_0x5143bf){_0x5e4334['push'](_0x5e4334['shift']());}}}(a0_0x2fdc,0x5c0a3));function a0_0x4728(_0x59d95e,_0x4dc08e){var _0x2fdc71=a0_0x2fdc();return a0_0x4728=function(_0x4728de,_0x279fb4){_0x4728de=_0x4728de-0x1ef;var _0x4e8d4b=_0x2fdc71[_0x4728de];return _0x4e8d4b;},a0_0x4728(_0x59d95e,_0x4dc08e);}import{LitElement,html,css}from'lit-element';export class MyProgress extends LitElement{static get[a0_0xfc1a5c(0x1f9)](){return{'id':{'type':String},'name':{'type':String},'min':{'type':String},'max':{'type':String},'value':{'type':String}};}constructor(){var _0x90799b=a0_0xfc1a5c;super(),this['id']='',this['name']='',this[_0x90799b(0x1ff)]='0',this['max']=_0x90799b(0x207),this[_0x90799b(0x204)]='0';}[a0_0xfc1a5c(0x1fc)](_0x1daace){var _0x40bb1d=a0_0xfc1a5c,_0x160175=this['id'],_0x1d3ea4={'address':_0x160175,'data':{'value':this['value']}};Window[_0x40bb1d(0x1fb)][_0x40bb1d(0x200)](JSON[_0x40bb1d(0x1f0)](_0x1d3ea4)+'\x0a');}[a0_0xfc1a5c(0x1fa)](){var _0x1cf3f0=a0_0xfc1a5c;return html`
      <!-- template content -->
      <div class="progresscontainer">
        <p><strong>${this[_0x1cf3f0(0x1f6)]}</strong></p>
        <progress min="${this['min']}" max="${this['max']}" value="${this[_0x1cf3f0(0x204)]}" class="progress" id="myProgress" @input="${this[_0x1cf3f0(0x1fc)]}">
      </div>
    `;}static get[a0_0xfc1a5c(0x1f2)](){return css`
      .progresscontainer {
        width: 100% /* Width of the outisde container */
      }
      .progress {
        opacity: 0.7;
        width: 100%
        background: #4CAF50; /* green */
      }
      .progress:hover {
        opacity: 1; /* Fully shown on mouse-over */
      }
      p { color: blue; }
    `;}}customElements[a0_0xfc1a5c(0x1f7)](a0_0xfc1a5c(0x203),MyProgress);