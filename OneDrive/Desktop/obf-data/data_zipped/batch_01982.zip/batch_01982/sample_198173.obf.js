/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x189a12=a0_0x202d;function a0_0x492b(){var _0x708715=['4816413HllZLo','535284ZeuxQE','foam.graphics.diagram.DiagramItemTrait','28EziKOH','9256877XSkrDm','foam.graphics.CView','1610100aisSwM','foam.graphics.diagram.DiagramRootTrait','33595ukLyIE','DiagramRoot','2661675DQIULR','72622ANQdJQ','1410xMEgEG','16ydCSAf'];a0_0x492b=function(){return _0x708715;};return a0_0x492b();}function a0_0x202d(_0x30c59e,_0x17a910){var _0x492b7b=a0_0x492b();return a0_0x202d=function(_0x202da6,_0xd4be55){_0x202da6=_0x202da6-0xfa;var _0x5e155=_0x492b7b[_0x202da6];return _0x5e155;},a0_0x202d(_0x30c59e,_0x17a910);}(function(_0x289e29,_0x11979a){var _0x46724f=a0_0x202d,_0xd9b30e=_0x289e29();while(!![]){try{var _0x41bf39=-parseInt(_0x46724f(0x107))/0x1*(-parseInt(_0x46724f(0xff))/0x2)+parseInt(_0x46724f(0x106))/0x3+parseInt(_0x46724f(0xfd))/0x4+-parseInt(_0x46724f(0x104))/0x5*(parseInt(_0x46724f(0xfa))/0x6)+parseInt(_0x46724f(0x100))/0x7+-parseInt(_0x46724f(0xfb))/0x8*(parseInt(_0x46724f(0xfc))/0x9)+parseInt(_0x46724f(0x102))/0xa;if(_0x41bf39===_0x11979a)break;else _0xd9b30e['push'](_0xd9b30e['shift']());}catch(_0x437749){_0xd9b30e['push'](_0xd9b30e['shift']());}}}(a0_0x492b,0xd4dd8),CLASS({'name':a0_0x189a12(0x105),'package':'foam.graphics.diagram','extends':a0_0x189a12(0x101),'traits':[a0_0x189a12(0xfe),a0_0x189a12(0x103)],'documentation':function(){}}));