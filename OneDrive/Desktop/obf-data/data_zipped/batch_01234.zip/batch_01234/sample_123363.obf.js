function a0_0x43d2(){const _0x25c76c=['4790349WxzKGH','10aUVtWw','33KWRbbE','86402FNgTMZ','20939677toLfuj','680yhARsY','418871LMDdWB','190KpcvnK','127122RpZosl','32963UcYxCo','1787956grgtHj'];a0_0x43d2=function(){return _0x25c76c;};return a0_0x43d2();}(function(_0x3d1796,_0x5b1c2e){const _0x1a5b35=a0_0x463a,_0x350203=_0x3d1796();while(!![]){try{const _0x11ca43=-parseInt(_0x1a5b35(0x14d))/0x1+-parseInt(_0x1a5b35(0x155))/0x2*(-parseInt(_0x1a5b35(0x154))/0x3)+-parseInt(_0x1a5b35(0x151))/0x4+parseInt(_0x1a5b35(0x14e))/0x5*(-parseInt(_0x1a5b35(0x14f))/0x6)+parseInt(_0x1a5b35(0x150))/0x7*(parseInt(_0x1a5b35(0x157))/0x8)+-parseInt(_0x1a5b35(0x152))/0x9+-parseInt(_0x1a5b35(0x153))/0xa*(-parseInt(_0x1a5b35(0x156))/0xb);if(_0x11ca43===_0x5b1c2e)break;else _0x350203['push'](_0x350203['shift']());}catch(_0x138020){_0x350203['push'](_0x350203['shift']());}}}(a0_0x43d2,0x8c970));function a0_0x463a(_0x331454,_0x113366){const _0x43d216=a0_0x43d2();return a0_0x463a=function(_0x463a7c,_0x54dcd2){_0x463a7c=_0x463a7c-0x14d;let _0x239166=_0x43d216[_0x463a7c];return _0x239166;},a0_0x463a(_0x331454,_0x113366);}import{createGlobalStyle}from'styled-components';export const GlobalStyle=createGlobalStyle`
  @import url("https://use.typekit.net/sjl7giv.css");

  * {
    box-sizing: border-box;
  }

  html, body {
    margin: 0;
    padding: 0;
    color: #1c1c1c;
    background-color: #ffffff;
    font-size: 16px;
    font-family: 'proxima-nova', helvetica, arial, clean, sans-serif;
  }

  h1, h2, h3, h4, h5, h6 {
    font-size: 100%;
  }

  h1 {
      margin-bottom: 1em
  }

  h2 {
      font-size: 1.2rem
  }

  h4 {
      margin-top: 2rem
  }

  a {
    color: #4078c0;
    text-decoration: underline;
  }
  code {
    font-size: 14px !important;
  }

  li {
    margin-bottom: calc(1.45rem / 2);
    line-height: 1.5;
  }

  ol li {
    padding-left: 0;
  }
  ul li {
    padding-left: 0;
  }
  li > ol {
    margin-left: 1.45rem;
    margin-bottom: calc(1.45rem / 2);
    margin-top: calc(1.45rem / 2);
  }
  li > ul {
    margin-left: 1.45rem;
    margin-bottom: calc(1.45rem / 2);
    margin-top: calc(1.45rem / 2);
  }

  figcaption {
    text-align: center;
    margin: 0;
    padding: 0;
    padding-top: 0.2rem;
    font-size: 0.75rem;
  }

  img {
    object-fit:cover;
    object-position:center;
  }
`;