var a0_0x36dcd=a0_0x3e2a;(function(_0x22c600,_0x55e1c9){var _0x2babb5=a0_0x3e2a,_0x499062=_0x22c600();while(!![]){try{var _0x2ba045=parseInt(_0x2babb5(0x1fa))/0x1*(-parseInt(_0x2babb5(0x1f6))/0x2)+-parseInt(_0x2babb5(0x1fc))/0x3+parseInt(_0x2babb5(0x1f5))/0x4+-parseInt(_0x2babb5(0x1f1))/0x5*(-parseInt(_0x2babb5(0x1fb))/0x6)+parseInt(_0x2babb5(0x1f2))/0x7+-parseInt(_0x2babb5(0x1f8))/0x8*(-parseInt(_0x2babb5(0x1f0))/0x9)+-parseInt(_0x2babb5(0x201))/0xa*(parseInt(_0x2babb5(0x1f7))/0xb);if(_0x2ba045===_0x55e1c9)break;else _0x499062['push'](_0x499062['shift']());}catch(_0x2db386){_0x499062['push'](_0x499062['shift']());}}}(a0_0x4aec,0x1ea1b));function a0_0x3e2a(_0x3addaf,_0x231620){var _0x4aecbf=a0_0x4aec();return a0_0x3e2a=function(_0x3e2a4c,_0x1dce25){_0x3e2a4c=_0x3e2a4c-0x1ef;var _0x2d835c=_0x4aecbf[_0x3e2a4c];return _0x2d835c;},a0_0x3e2a(_0x3addaf,_0x231620);}function a0_0x4aec(){var _0x104d6d=['2Nwpvjo','1301872eFywhp','16YVbucL','.falsey','5963TuibBh','250422lUYgcF','414534RzhrWr','element','Integration\x20|\x20Component\x20|\x20animated\x20if','querySelector','it\x20renders\x20inverse\x20block\x20when\x20false','20EeQKaG','it\x20renders\x20when\x20true','it\x20does\x20not\x20render\x20when\x20false','321588ZUcCtT','5QrZMkj','1463700TaXRpH','set','notOk','736044sWqPnd'];a0_0x4aec=function(){return _0x104d6d;};return a0_0x4aec();}import{module,test}from'qunit';import{setupRenderingTest}from'ember-qunit';import{render}from'@ember/test-helpers';import{hbs}from'ember-cli-htmlbars';module(a0_0x36dcd(0x1fe),function(_0x4c5ec0){var _0x40b846=a0_0x36dcd;setupRenderingTest(_0x4c5ec0),test(_0x40b846(0x202),async function(_0x47876f){var _0x57fe17=_0x40b846;this[_0x57fe17(0x1f3)]('x',!![]),await render(hbs`
      {{#animated-if this.x}}
        <div class="truthy"></div>
      {{/animated-if}}
    `),_0x47876f['ok'](this[_0x57fe17(0x1fd)][_0x57fe17(0x1ff)]('.truthy'));}),test(_0x40b846(0x1ef),async function(_0x4365d5){var _0xda400f=_0x40b846;await render(hbs`
      {{#animated-if this.x}}
        <div class="truthy"></div>
      {{/animated-if}}
    `),_0x4365d5[_0xda400f(0x1f4)](this[_0xda400f(0x1fd)][_0xda400f(0x1ff)]('.truthy'));}),test(_0x40b846(0x200),async function(_0x1fc613){var _0x4de2e0=_0x40b846;await render(hbs`
      {{#animated-if this.x}}
        <div class="truthy"></div>
      {{else}}
        <div class="falsey"></div>
      {{/animated-if}}
    `),_0x1fc613['ok'](this[_0x4de2e0(0x1fd)][_0x4de2e0(0x1ff)](_0x4de2e0(0x1f9)));});});