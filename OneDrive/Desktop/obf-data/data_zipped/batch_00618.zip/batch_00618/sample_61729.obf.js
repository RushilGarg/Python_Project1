/**
 * @license
 * Copyright (c) 2017 Google Inc. All rights reserved.
 * This code may only be used under the BSD style license found at
 * http://polymer.github.io/LICENSE.txt
 * Code distributed by Google as part of this project is also
 * subject to an additional IP rights grant found at
 * http://polymer.github.io/PATENTS.txt
 */
'use strict';function a0_0x572c(_0x48825e,_0x3f1127){const _0x2341fe=a0_0x2341();return a0_0x572c=function(_0x572c12,_0x4575cc){_0x572c12=_0x572c12-0x18f;let _0x31c045=_0x2341fe[_0x572c12];return _0x31c045;},a0_0x572c(_0x48825e,_0x3f1127);}function a0_0x2341(){const _0x84e5a2=['14054656uLtKuy','12104KrmtWj','trim','template','5094456mAVwgv','2310784ojVmnx','1859924dICKsg','shouldRender','find','132WCWckF','2485310dtpBne','560385pzbhnG','choices','name'];a0_0x2341=function(){return _0x84e5a2;};return a0_0x2341();}(function(_0x5b8a78,_0x44d4b0){const _0x4248f2=a0_0x572c,_0x5354e3=_0x5b8a78();while(!![]){try{const _0xdc44c3=parseInt(_0x4248f2(0x199))/0x1+-parseInt(_0x4248f2(0x194))/0x2+parseInt(_0x4248f2(0x197))/0x3*(parseInt(_0x4248f2(0x18f))/0x4)+-parseInt(_0x4248f2(0x198))/0x5+-parseInt(_0x4248f2(0x192))/0x6+parseInt(_0x4248f2(0x193))/0x7+parseInt(_0x4248f2(0x19c))/0x8;if(_0xdc44c3===_0x44d4b0)break;else _0x5354e3['push'](_0x5354e3['shift']());}catch(_0x2d2845){_0x5354e3['push'](_0x5354e3['shift']());}}}(a0_0x2341,0x7b235));defineParticle(({UiParticle:_0x20e85f,html:_0x4bb7aa})=>{const _0x2b9d6e=a0_0x572c,_0x3eef05=_0x4bb7aa`

<div hidden="{{notAlsoOn}}" style="padding: 4px 0;">
  <span>Also on:</span> <span unsafe-html="{{choices.description}}"></span>
</div>

  `[_0x2b9d6e(0x190)]();return class extends _0x20e85f{get[_0x2b9d6e(0x191)](){return _0x3eef05;}[_0x2b9d6e(0x195)](_0x5568cc){const _0x1806b3=_0x2b9d6e;return Boolean(_0x5568cc[_0x1806b3(0x19a)]);}['render']({product:_0x5f0122,choices:_0x2e3720}){const _0x3f0c9e=_0x2b9d6e,_0x43ce31=!_0x5f0122||!_0x2e3720[_0x3f0c9e(0x196)](_0x532a00=>_0x532a00[_0x3f0c9e(0x19b)]===_0x5f0122[_0x3f0c9e(0x19b)]);return{'notAlsoOn':_0x43ce31};}};});