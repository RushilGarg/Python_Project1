/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x579a0c=a0_0x3526;(function(_0x4bada9,_0xf90b9a){var _0x1b1e1a=a0_0x3526,_0x4ffbef=_0x4bada9();while(!![]){try{var _0x5d9bea=-parseInt(_0x1b1e1a(0x183))/0x1+parseInt(_0x1b1e1a(0x188))/0x2*(-parseInt(_0x1b1e1a(0x185))/0x3)+-parseInt(_0x1b1e1a(0x184))/0x4*(-parseInt(_0x1b1e1a(0x17f))/0x5)+parseInt(_0x1b1e1a(0x18a))/0x6*(parseInt(_0x1b1e1a(0x187))/0x7)+parseInt(_0x1b1e1a(0x18b))/0x8+parseInt(_0x1b1e1a(0x182))/0x9*(-parseInt(_0x1b1e1a(0x181))/0xa)+parseInt(_0x1b1e1a(0x186))/0xb;if(_0x5d9bea===_0xf90b9a)break;else _0x4ffbef['push'](_0x4ffbef['shift']());}catch(_0x21aa87){_0x4ffbef['push'](_0x4ffbef['shift']());}}}(a0_0x339c,0x48b1d));var addon=require(a0_0x579a0c(0x180));function a0_0x339c(){var _0x4cd247=['68upMrLp','376617MvXEQd','12352857FCLNro','10913YSjcPu','2ELLedb','exports','1194BCVCHP','41128KEfjgX','18065UsuHXq','./../src/addon.node','2541010dMnwoz','18oDvLmu','568292unDLCy'];a0_0x339c=function(){return _0x4cd247;};return a0_0x339c();}function a0_0x3526(_0x24c42c,_0x16e052){var _0x339c6a=a0_0x339c();return a0_0x3526=function(_0x35265d,_0x21bb52){_0x35265d=_0x35265d-0x17f;var _0x3c6a25=_0x339c6a[_0x35265d];return _0x3c6a25;},a0_0x3526(_0x24c42c,_0x16e052);}function sqrt(_0x4d25ca){return addon(_0x4d25ca);}module[a0_0x579a0c(0x189)]=sqrt;