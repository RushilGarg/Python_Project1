/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2b2bc3=a0_0x3725;function a0_0x3725(_0x43067f,_0x4b3360){var _0x6a0f52=a0_0x6a0f();return a0_0x3725=function(_0x37252b,_0x193ef1){_0x37252b=_0x37252b-0x1d7;var _0x228798=_0x6a0f52[_0x37252b];return _0x228798;},a0_0x3725(_0x43067f,_0x4b3360);}(function(_0x45f654,_0x2c1170){var _0xb630cd=a0_0x3725,_0x24f528=_0x45f654();while(!![]){try{var _0x3ec387=-parseInt(_0xb630cd(0x1db))/0x1+-parseInt(_0xb630cd(0x1e3))/0x2+-parseInt(_0xb630cd(0x1f1))/0x3*(-parseInt(_0xb630cd(0x1d9))/0x4)+parseInt(_0xb630cd(0x1e9))/0x5*(-parseInt(_0xb630cd(0x1ef))/0x6)+parseInt(_0xb630cd(0x1e0))/0x7+-parseInt(_0xb630cd(0x1dc))/0x8+-parseInt(_0xb630cd(0x1de))/0x9*(-parseInt(_0xb630cd(0x1eb))/0xa);if(_0x3ec387===_0x2c1170)break;else _0x24f528['push'](_0x24f528['shift']());}catch(_0x2a487d){_0x24f528['push'](_0x24f528['shift']());}}}(a0_0x6a0f,0xbe581));var join=require('path')['join'],Linter=require(a0_0x2b2bc3(0x1df))[a0_0x2b2bc3(0x1e2)],rule=require(a0_0x2b2bc3(0x1e1)),linter=new Linter(),result,config,code;code=['/*',a0_0x2b2bc3(0x1ed),'*/','','//\x20MODULES\x20//','','var\x20setReadOnly\x20=\x20require(\x20\x27@stdlib/utils/define-read-only-property\x27\x20);','','',a0_0x2b2bc3(0x1f2),'',a0_0x2b2bc3(0x1e7),'*\x20Top-level\x20namespace.','*',a0_0x2b2bc3(0x1d8),'*/',a0_0x2b2bc3(0x1d7),'',a0_0x2b2bc3(0x1e7),a0_0x2b2bc3(0x1e5),a0_0x2b2bc3(0x1ec),a0_0x2b2bc3(0x1e8),a0_0x2b2bc3(0x1e6),a0_0x2b2bc3(0x1e4),'*/','setReadOnly(\x20ns,\x20\x27error2json\x27,\x20require(\x20\x27@stdlib/error/to-json\x27\x20)\x20);']['join']('\x0a'),linter[a0_0x2b2bc3(0x1f0)](a0_0x2b2bc3(0x1da),rule),config={'rules':{'namespace-export-all':a0_0x2b2bc3(0x1ea)}},result=linter[a0_0x2b2bc3(0x1ee)](code,config,{'filename':join(__dirname,'fixtures','lib',a0_0x2b2bc3(0x1dd))}),console['log'](result);function a0_0x6a0f(){var _0x3517fa=['315LoNpoA','error','1471930kGuwDs','*\x20@memberof\x20ns','*\x20When\x20adding\x20modules\x20to\x20the\x20namespace,\x20ensure\x20that\x20they\x20are\x20added\x20in\x20alphabetical\x20order\x20according\x20to\x20module\x20name.','verify','37902ZApaVk','defineRule','2797194eriINw','//\x20MAIN\x20//','var\x20ns\x20=\x20{};','*\x20@namespace\x20ns','4BfVVgv','namespace-export-all','913414vuoYzW','5864616BcLIZx','index.js','117cZSHzq','eslint','9236745LAqiiA','./../lib','Linter','2682662OuzQEV','*\x20@see\x20{@link\x20module:@stdlib/error/to-json}','*\x20@name\x20error2json','*\x20@type\x20{Function}','/**','*\x20@readonly'];a0_0x6a0f=function(){return _0x3517fa;};return a0_0x6a0f();}