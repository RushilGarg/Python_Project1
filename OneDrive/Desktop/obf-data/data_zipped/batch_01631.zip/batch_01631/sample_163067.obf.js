/**
 * @license Angular v4.3.4
 * (c) 2010-2017 Google, Inc. https://angular.io/
 * License: MIT
 */
(function(_0x307d5f,_0x428536){const _0x2a65b7=a0_0x58f2,_0x31ca5a=_0x307d5f();while(!![]){try{const _0x11e145=-parseInt(_0x2a65b7(0x16f))/0x1*(-parseInt(_0x2a65b7(0x173))/0x2)+-parseInt(_0x2a65b7(0x164))/0x3*(-parseInt(_0x2a65b7(0x177))/0x4)+parseInt(_0x2a65b7(0x16c))/0x5+parseInt(_0x2a65b7(0x170))/0x6+parseInt(_0x2a65b7(0x171))/0x7+-parseInt(_0x2a65b7(0x16d))/0x8+parseInt(_0x2a65b7(0x165))/0x9*(-parseInt(_0x2a65b7(0x172))/0xa);if(_0x11e145===_0x428536)break;else _0x31ca5a['push'](_0x31ca5a['shift']());}catch(_0x444039){_0x31ca5a['push'](_0x31ca5a['shift']());}}}(a0_0x55d0,0x96d20));import{APP_BOOTSTRAP_LISTENER}from'@angular/core';import{Router}from'@angular/router';import{UpgradeModule}from'@angular/upgrade/static';/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const RouterUpgradeInitializer={'provide':APP_BOOTSTRAP_LISTENER,'multi':!![],'useFactory':locationSyncBootstrapListener,'deps':[UpgradeModule]};function a0_0x58f2(_0x126374,_0x2bfef5){const _0x55d074=a0_0x55d0();return a0_0x58f2=function(_0x58f209,_0x3a1c97){_0x58f209=_0x58f209-0x164;let _0x3c2410=_0x55d074[_0x58f209];return _0x3c2410;},a0_0x58f2(_0x126374,_0x2bfef5);}function a0_0x55d0(){const _0x4d4e77=['$rootScope','309707pfJwao','1504038UduhKw','2082430hRHAcm','735510WtlcRN','4uFzhkr','get','navigateByUrl','$injector','37180yuFJPb','pathname','195hTsLJX','36ewJzoU','\x0a\x20\x20\x20\x20\x20\x20\x20\x20RouterUpgradeInitializer\x20can\x20be\x20used\x20only\x20after\x20UpgradeModule.bootstrap\x20has\x20been\x20called.\x0a\x20\x20\x20\x20\x20\x20\x20\x20Remove\x20RouterUpgradeInitializer\x20and\x20call\x20setUpLocationSync\x20after\x20UpgradeModule.bootstrap.\x0a\x20\x20\x20\x20\x20\x20','search','$locationChangeStart','hash','href','injector','1007955JcHial','8491032EikQOb'];a0_0x55d0=function(){return _0x4d4e77;};return a0_0x55d0();}function locationSyncBootstrapListener(_0x5822bc){return()=>{setUpLocationSync(_0x5822bc);};}function setUpLocationSync(_0x368303){const _0x90e0e8=a0_0x58f2;if(!_0x368303[_0x90e0e8(0x176)])throw new Error(_0x90e0e8(0x166));const _0x16041e=_0x368303[_0x90e0e8(0x16b)][_0x90e0e8(0x174)](Router),_0x37ed7d=document['createElement']('a');_0x368303[_0x90e0e8(0x176)]['get'](_0x90e0e8(0x16e))['$on'](_0x90e0e8(0x168),(_0x2bcc3,_0x53337d,_0x370be6)=>{const _0x1d6553=_0x90e0e8;_0x37ed7d[_0x1d6553(0x16a)]=_0x53337d,_0x16041e[_0x1d6553(0x175)](_0x37ed7d[_0x1d6553(0x178)]+_0x37ed7d[_0x1d6553(0x167)]+_0x37ed7d[_0x1d6553(0x169)]);});}/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export{RouterUpgradeInitializer,locationSyncBootstrapListener,setUpLocationSync};