/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x326c(_0x4c557a,_0x1bb940){var _0x3177ed=a0_0x3177();return a0_0x326c=function(_0x326c41,_0xaec6e4){_0x326c41=_0x326c41-0x173;var _0x3b6901=_0x3177ed[_0x326c41];return _0x3b6901;},a0_0x326c(_0x4c557a,_0x1bb940);}var a0_0x455389=a0_0x326c;function a0_0x3177(){var _0x21f507=['@stdlib/bench','9yhYQTN','end','132208JDvZne','10kGHFXS','./../package.json','@stdlib/assert/is-boolean','282764OAKxOV','514580YCKRMk','@stdlib/random/base/randu','2724402duHeEC','iterations','91021Tatbex','81yncvlU','path','isPrimitive','name','should\x20return\x20a\x20boolean','19075lJblcs','tic','3555112pvJAkh','264mmrFOG','fail','toc','resolve'];a0_0x3177=function(){return _0x21f507;};return a0_0x3177();}(function(_0x2b03e3,_0x34d0d2){var _0x29cb13=a0_0x326c,_0x3ee781=_0x2b03e3();while(!![]){try{var _0x505d02=-parseInt(_0x29cb13(0x175))/0x1+parseInt(_0x29cb13(0x185))/0x2*(-parseInt(_0x29cb13(0x183))/0x3)+-parseInt(_0x29cb13(0x189))/0x4*(-parseInt(_0x29cb13(0x186))/0x5)+parseInt(_0x29cb13(0x173))/0x6+-parseInt(_0x29cb13(0x17b))/0x7*(parseInt(_0x29cb13(0x17e))/0x8)+parseInt(_0x29cb13(0x176))/0x9*(parseInt(_0x29cb13(0x18a))/0xa)+-parseInt(_0x29cb13(0x17d))/0xb;if(_0x505d02===_0x34d0d2)break;else _0x3ee781['push'](_0x3ee781['shift']());}catch(_0x8349c3){_0x3ee781['push'](_0x3ee781['shift']());}}}(a0_0x3177,0x56f19));var resolve=require(a0_0x455389(0x177))[a0_0x455389(0x181)],bench=require(a0_0x455389(0x182)),randu=require(a0_0x455389(0x18b)),isBoolean=require(a0_0x455389(0x188))[a0_0x455389(0x178)],tryRequire=require('@stdlib/utils/try-require'),pkg=require(a0_0x455389(0x187))[a0_0x455389(0x179)],isNegativeZero=tryRequire(resolve(__dirname,'./../lib/native.js')),opts={'skip':isNegativeZero instanceof Error};bench(pkg+'::native',opts,function benchmark(_0x40a67a){var _0x3b25bf=a0_0x455389,_0x303889,_0x18118e,_0x45f53e;_0x40a67a[_0x3b25bf(0x17c)]();for(_0x45f53e=0x0;_0x45f53e<_0x40a67a[_0x3b25bf(0x174)];_0x45f53e++){_0x303889=randu()*0x989680-0x4c4b40,_0x18118e=isNegativeZero(_0x303889),!isBoolean(_0x18118e)&&_0x40a67a[_0x3b25bf(0x17f)](_0x3b25bf(0x17a));}_0x40a67a[_0x3b25bf(0x180)](),!isBoolean(_0x18118e)&&_0x40a67a[_0x3b25bf(0x17f)](_0x3b25bf(0x17a)),_0x40a67a['pass']('benchmark\x20finished'),_0x40a67a[_0x3b25bf(0x184)]();});