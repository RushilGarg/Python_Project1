/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0xfd01(_0x4b1747,_0x205bc2){var _0x159b0c=a0_0x159b();return a0_0xfd01=function(_0xfd01e4,_0x17fe51){_0xfd01e4=_0xfd01e4-0x10f;var _0x1e678f=_0x159b0c[_0xfd01e4];return _0x1e678f;},a0_0xfd01(_0x4b1747,_0x205bc2);}var a0_0x430ac8=a0_0xfd01;(function(_0x39fba9,_0x5e66c6){var _0x54c13f=a0_0xfd01,_0x2e3d64=_0x39fba9();while(!![]){try{var _0x3c69f2=parseInt(_0x54c13f(0x117))/0x1+parseInt(_0x54c13f(0x111))/0x2+parseInt(_0x54c13f(0x112))/0x3*(-parseInt(_0x54c13f(0x10f))/0x4)+parseInt(_0x54c13f(0x118))/0x5*(parseInt(_0x54c13f(0x11a))/0x6)+-parseInt(_0x54c13f(0x113))/0x7+parseInt(_0x54c13f(0x119))/0x8+parseInt(_0x54c13f(0x115))/0x9*(-parseInt(_0x54c13f(0x116))/0xa);if(_0x3c69f2===_0x5e66c6)break;else _0x2e3d64['push'](_0x2e3d64['shift']());}catch(_0x12c307){_0x2e3d64['push'](_0x2e3d64['shift']());}}}(a0_0x159b,0x3a1ea));function a0_0x159b(){var _0x5e460=['192589VHKYQY','310SaUbiu','1235424FfrVfZ','17562gJolil','@stdlib/math/base/assert/is-integer','68kOOGRC','exports','473492EvVzfy','18807rOjrIW','1386560QBYFFo','@stdlib/math/base/assert/is-nan','9bBXicV','2225260vFuduJ'];a0_0x159b=function(){return _0x5e460;};return a0_0x159b();}var isnan=require(a0_0x430ac8(0x114)),isInteger=require(a0_0x430ac8(0x11b));function skewness(_0x35e62b,_0x4da680){if(isnan(_0x35e62b)||isnan(_0x4da680)||!isInteger(_0x35e62b)||!isInteger(_0x4da680)||_0x35e62b>_0x4da680)return NaN;return 0x0;}module[a0_0x430ac8(0x110)]=skewness;