/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x370e73=a0_0x5299;(function(_0x5631e7,_0x389e7d){var _0x5eed06=a0_0x5299,_0x5b8dda=_0x5631e7();while(!![]){try{var _0x52f2ca=parseInt(_0x5eed06(0x135))/0x1*(parseInt(_0x5eed06(0x139))/0x2)+parseInt(_0x5eed06(0x132))/0x3*(-parseInt(_0x5eed06(0x142))/0x4)+parseInt(_0x5eed06(0x137))/0x5*(-parseInt(_0x5eed06(0x141))/0x6)+-parseInt(_0x5eed06(0x13f))/0x7*(-parseInt(_0x5eed06(0x136))/0x8)+parseInt(_0x5eed06(0x143))/0x9+parseInt(_0x5eed06(0x133))/0xa*(parseInt(_0x5eed06(0x13a))/0xb)+parseInt(_0x5eed06(0x13e))/0xc*(-parseInt(_0x5eed06(0x134))/0xd);if(_0x52f2ca===_0x389e7d)break;else _0x5b8dda['push'](_0x5b8dda['shift']());}catch(_0x521d8d){_0x5b8dda['push'](_0x5b8dda['shift']());}}}(a0_0x3199,0x944c1));function a0_0x5299(_0x18f640,_0x487cd0){var _0x319940=a0_0x3199();return a0_0x5299=function(_0x529938,_0x58864a){_0x529938=_0x529938-0x132;var _0x2256a7=_0x319940[_0x529938];return _0x2256a7;},a0_0x5299(_0x18f640,_0x487cd0);}function a0_0x3199(){var _0x4f124d=['31458EGmJvn','@stdlib/utils/try-require','6koGCrt','60qrGOzI','1008990CeKQCm','138543yTBxXu','3970UgZXIF','39WJbTPd','6cioziX','664NhwFaH','234355XfqAQw','join','195766OTOQrb','27214rgzlIH','path','./main.js','./native.js','2830308LUqjcf'];a0_0x3199=function(){return _0x4f124d;};return a0_0x3199();}var join=require(a0_0x370e73(0x13b))[a0_0x370e73(0x138)],tryRequire=require(a0_0x370e73(0x140)),main=require(a0_0x370e73(0x13c)),tmp=tryRequire(join(__dirname,a0_0x370e73(0x13d)));!(tmp instanceof Error)&&(main=tmp);module['exports']=main;