/**
 *  Appshaper XML Parser Module
 *  @module XML
 *  @desc Used to parse XML.
 *  @author Jeroen Reurings
 *
 *  @copyright Copyright © 2015 Jeroen Reurings, all rights reserved.
 *  @license Licensed under the Apache License, Version 2.0 (the "License");
 *  You may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
 *  or see the LICENSE file in the root of the project.
 *  @see https://github.com/appshaper/appshaper
 */
function a0_0x224c(){var _0x4a7552=['ActiveXObject','24jKiBdh','50810UEvoXf','4afFXPB','272gvSxQY','127638kJsjOV','loadXML','10354552RnEIdB','60oGHdcS','text/xml','1256455fgqxEN','parseFromString','360342yZjgFs','415383NvvOws','3124uTbqqA','20kmKRMI','48629ptYNvP'];a0_0x224c=function(){return _0x4a7552;};return a0_0x224c();}function a0_0x39bf(_0x562b1f,_0x5c4904){var _0x224c4a=a0_0x224c();return a0_0x39bf=function(_0x39bf5d,_0x454bd9){_0x39bf5d=_0x39bf5d-0x199;var _0x5d20e1=_0x224c4a[_0x39bf5d];return _0x5d20e1;},a0_0x39bf(_0x562b1f,_0x5c4904);}(function(_0x2b0c63,_0x50a5c6){var _0x5ada4b=a0_0x39bf,_0x2e569e=_0x2b0c63();while(!![]){try{var _0x321129=-parseInt(_0x5ada4b(0x19a))/0x1*(-parseInt(_0x5ada4b(0x19c))/0x2)+parseInt(_0x5ada4b(0x1a4))/0x3*(parseInt(_0x5ada4b(0x1a6))/0x4)+-parseInt(_0x5ada4b(0x1a1))/0x5*(-parseInt(_0x5ada4b(0x1a9))/0x6)+parseInt(_0x5ada4b(0x1a7))/0x7+parseInt(_0x5ada4b(0x19b))/0x8*(parseInt(_0x5ada4b(0x1a3))/0x9)+parseInt(_0x5ada4b(0x199))/0xa*(parseInt(_0x5ada4b(0x1a5))/0xb)+parseInt(_0x5ada4b(0x19f))/0xc*(-parseInt(_0x5ada4b(0x19e))/0xd);if(_0x321129===_0x50a5c6)break;else _0x2e569e['push'](_0x2e569e['shift']());}catch(_0xc7c90e){_0x2e569e['push'](_0x2e569e['shift']());}}}(a0_0x224c,0xbec9c),define(function(){'use strict';var _0x520fe3={'parse':function(_0xdcf572){var _0x12cd0b=a0_0x39bf,_0x3afb0f=window,_0x144d51,_0xec0120;return _0x3afb0f['DOMParser']&&(_0x144d51=new DOMParser(),_0xec0120=_0x144d51[_0x12cd0b(0x1a2)](_0xdcf572['responseText'],_0x12cd0b(0x1a0))),_0x3afb0f[_0x12cd0b(0x1a8)]&&(_0x144d51=new _0x3afb0f[(_0x12cd0b(0x1a8))]('Microsoft.XMLDOM'),_0x144d51['async']=![],_0xec0120=_0x144d51[_0x12cd0b(0x19d)](_0xdcf572['responseText'])),_0xec0120;}};return _0x520fe3;}));