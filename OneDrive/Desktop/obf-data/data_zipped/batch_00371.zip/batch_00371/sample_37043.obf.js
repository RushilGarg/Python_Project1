/**
 * SeekQuarry/Yioop --
 * Open Source Pure PHP Search Engine, Crawler, and Indexer
 *
 * Copyright (C) 2009 - 2015  Chris Pollett chris@pollett.org
 *
 * LICENSE:
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *
 * END LICENSE
 *
 * @author Mallika Perepa
 * @license http://www.gnu.org/licenses/ GPL3
 * @link http://www.seekquarry.com/
 * @copyright 2009 - 2015s
 * @filesource
 */
function a0_0x4e33(_0x17a281,_0x4bc7f9){var _0x26b76e=a0_0x26b7();return a0_0x4e33=function(_0x4e3310,_0x3226fe){_0x4e3310=_0x4e3310-0x195;var _0x5ac332=_0x26b76e[_0x4e3310];return _0x5ac332;},a0_0x4e33(_0x17a281,_0x4bc7f9);}var a0_0x5e278d=a0_0x4e33;(function(_0x357038,_0x2be2c2){var _0x120ae5=a0_0x4e33,_0x4d59ad=_0x357038();while(!![]){try{var _0x2e7f2c=-parseInt(_0x120ae5(0x1e7))/0x1+parseInt(_0x120ae5(0x1ed))/0x2*(parseInt(_0x120ae5(0x1c3))/0x3)+-parseInt(_0x120ae5(0x1da))/0x4*(-parseInt(_0x120ae5(0x1e6))/0x5)+parseInt(_0x120ae5(0x1d0))/0x6+-parseInt(_0x120ae5(0x1a8))/0x7+-parseInt(_0x120ae5(0x1a2))/0x8*(parseInt(_0x120ae5(0x1ae))/0x9)+parseInt(_0x120ae5(0x195))/0xa*(parseInt(_0x120ae5(0x1a6))/0xb);if(_0x2e7f2c===_0x2be2c2)break;else _0x4d59ad['push'](_0x4d59ad['shift']());}catch(_0x3a989f){_0x4d59ad['push'](_0x4d59ad['shift']());}}}(a0_0x26b7,0x7197c));function a0_0x26b7(){var _0x1be622=['ाविवीवुवूवेवैव','ुखूखेखैखो','ःफाफिफीफु','टठ्ठत्तन्नड्ड','ेधैधोधौधंध','क्सक्रश्वक्ष','बाबिबीबुबूबे','444pQTNMy','त्रच्रट्रन्रन्','ेचैचोचौचंचःछ','्हम्बभ्रब्रब्ब','षंक्षःज्ञाज','िगीगुगूगेगैगो','पूपेपैपोपौपंप','थैथोथौथंथःदाद','रारिरीरुरूर','ज्ञूज्ञेज्ञ','ोघौघंघःचच','रज्ञश्रऋा','9560IHpJbp','105716yJNsFU','ूडेडैडोडौडं','ञंज्ञःस्वस्न','स्सस्कक्षत्','ैयोयौयंयः','छेछैछोछौछं','202236bmvxDe','तब्रह्रग्रद्र','151270DWJksG','खखाखिखीख','अआइईउऊऋए','ठूठेठैठोठौठ','िक्षीक्षुक्ष','ब्नह्नग्नद्नप्','ोवौवंवःक्षाक्ष','बैबोबौबंबःभा','रद्धथ्रत्नण्र','न्रन्तध्रद्वद्','ढेढैढोढौ','ःतातितीतुतूत','जूजेजैजोजौ','585088VyDTqe','ैकोकौकंकः','ज्रड्रप्रर्रक्र','ःनानिनीनुनूनेनै','649DeBzTg','कीकुकूकेक','585627qCSDjW','्यख्मक्यक्ल','फबभमयरलव','नस्नक्कट्','छाछिछीछुछू','ण्डण्टढ्रड्रठ','108jTvauq','ढंढःणाण','ेलैलोलौलंलःव','िदीदुदूदे','ेरैरोरौरंरःल','थाथिथीथुथूथे','ठडढणतथदधनप','ूक्षेक्ष','ालिलीलुलूल','ंठःडाडिडीडुड','फ्रफ़्तप्रन्स','्ञिज्ञीज्ञु','िमीमुमूमेमै','र्सर्यर्तर्चम','द्दटमट्मसससक','ग्यग्रग्ञख','छःजाजिजीजु','खौखंखःगगाग','नर्नक्नत्नम्नव्','नोनौनंनःपापिपीपु','गघङचछजझञट','3EFtlfB','यीयुयूयेय','मोमौमंमःयायि','भिभीभुभूभेभ','झौझंझःटाटिटी','िीोौुूेैंकाकि','शषसहर्हर्','ेतैतोतौतंतः','ीघुघूघेघैघ','धाधिधीधुधूध','टंटःठाठिठीठु','स्थस्तस्टस्ज','दैदोदौदंदः','1958652WrVkPN','ाचिचीचुचूच','िणीणुणूण'];a0_0x26b7=function(){return _0x1be622;};return a0_0x26b7();}var alpha=a0_0x5e278d(0x197)+'ऐओऔअंअँकख'+a0_0x5e278d(0x1c2)+a0_0x5e278d(0x1b4)+a0_0x5e278d(0x1aa)+a0_0x5e278d(0x1c9)+'सर्मर्नर्जर्दर्टर्'+a0_0x5e278d(0x1ee)+a0_0x5e278d(0x1a4)+a0_0x5e278d(0x1db)+'रव्रल्रस्रय्र'+a0_0x5e278d(0x19a)+a0_0x5e278d(0x1c0)+a0_0x5e278d(0x1ab)+a0_0x5e278d(0x1d6)+a0_0x5e278d(0x1bc)+a0_0x5e278d(0x1ea)+a0_0x5e278d(0x1e5)+a0_0x5e278d(0x1c8)+a0_0x5e278d(0x1a7)+a0_0x5e278d(0x1a3)+a0_0x5e278d(0x196)+a0_0x5e278d(0x1d4)+a0_0x5e278d(0x1bf)+a0_0x5e278d(0x1df)+'गौगंगःघघाघिघ'+a0_0x5e278d(0x1cb)+a0_0x5e278d(0x1e4)+a0_0x5e278d(0x1d1)+a0_0x5e278d(0x1dc)+a0_0x5e278d(0x1ac)+a0_0x5e278d(0x1ec)+a0_0x5e278d(0x1be)+a0_0x5e278d(0x1a1)+'जंजःझाझिझीझ'+'ुझूझेझैझो'+a0_0x5e278d(0x1c7)+'टुटूटेटैटोटौ'+a0_0x5e278d(0x1cd)+a0_0x5e278d(0x198)+a0_0x5e278d(0x1b7)+a0_0x5e278d(0x1e8)+'डःढाढिढीढुढू'+a0_0x5e278d(0x19f)+a0_0x5e278d(0x1af)+a0_0x5e278d(0x1d2)+'ेणैणोणौणंण'+a0_0x5e278d(0x1a0)+a0_0x5e278d(0x1ca)+a0_0x5e278d(0x1b3)+a0_0x5e278d(0x1e1)+a0_0x5e278d(0x1b1)+a0_0x5e278d(0x1cf)+a0_0x5e278d(0x1cc)+a0_0x5e278d(0x1d7)+a0_0x5e278d(0x1a5)+a0_0x5e278d(0x1c1)+a0_0x5e278d(0x1e0)+a0_0x5e278d(0x1d5)+'फूफेफैफो'+'फौफंफः'+a0_0x5e278d(0x1d9)+a0_0x5e278d(0x19c)+a0_0x5e278d(0x1c6)+'ैभोभौभंभःमाम'+a0_0x5e278d(0x1ba)+a0_0x5e278d(0x1c5)+a0_0x5e278d(0x1c4)+a0_0x5e278d(0x1eb)+a0_0x5e278d(0x1e2)+a0_0x5e278d(0x1b2)+a0_0x5e278d(0x1b6)+a0_0x5e278d(0x1b0)+a0_0x5e278d(0x1d3)+a0_0x5e278d(0x19b)+a0_0x5e278d(0x199)+a0_0x5e278d(0x1b5)+'ैक्षोक्षौक्'+a0_0x5e278d(0x1de)+a0_0x5e278d(0x1b9)+a0_0x5e278d(0x1e3)+'ैज्ञोज्ञौज्'+a0_0x5e278d(0x1e9)+a0_0x5e278d(0x1ce)+'स्कष्रव्रल्मल्द'+a0_0x5e278d(0x1bb)+a0_0x5e278d(0x1dd)+a0_0x5e278d(0x1b8)+a0_0x5e278d(0x19e)+a0_0x5e278d(0x19d)+a0_0x5e278d(0x1ad)+'्रट्रट्टच्छच्च'+a0_0x5e278d(0x1bd)+a0_0x5e278d(0x1a9)+a0_0x5e278d(0x1d8)+'ज्ञत्तत्रद्म'+'द्यन्नश्चश्र',roman_array={};function analyzeQuery(){}