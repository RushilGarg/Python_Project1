/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x370f18=a0_0x284b;(function(_0x4f9e3e,_0x45673c){var _0x1d285b=a0_0x284b,_0x5c74e2=_0x4f9e3e();while(!![]){try{var _0x169409=parseInt(_0x1d285b(0x145))/0x1+parseInt(_0x1d285b(0x14d))/0x2*(parseInt(_0x1d285b(0x144))/0x3)+-parseInt(_0x1d285b(0x147))/0x4+parseInt(_0x1d285b(0x14b))/0x5*(-parseInt(_0x1d285b(0x149))/0x6)+parseInt(_0x1d285b(0x148))/0x7+-parseInt(_0x1d285b(0x143))/0x8+-parseInt(_0x1d285b(0x14c))/0x9;if(_0x169409===_0x45673c)break;else _0x5c74e2['push'](_0x5c74e2['shift']());}catch(_0x54c1d2){_0x5c74e2['push'](_0x5c74e2['shift']());}}}(a0_0x538b,0x618bc));function a0_0x284b(_0x15c34a,_0x1cf757){var _0x538b71=a0_0x538b();return a0_0x284b=function(_0x284bae,_0x4d23e2){_0x284bae=_0x284bae-0x143;var _0x71db85=_0x538b71[_0x284bae];return _0x71db85;},a0_0x284b(_0x15c34a,_0x1cf757);}var setReadOnly=require(a0_0x370f18(0x14f)),mgf=require(a0_0x370f18(0x14a)),factory=require(a0_0x370f18(0x150));function a0_0x538b(){var _0x4cd408=['1378492eCbMgf','4338040bqMmiD','233106aQfDfF','./mgf.js','5zUtJzm','8928216gHqytI','12CIXbmD','exports','@stdlib/utils/define-nonenumerable-read-only-property','./factory.js','1363424dKUONx','360627GzMLjX','604500HiLtRf','factory'];a0_0x538b=function(){return _0x4cd408;};return a0_0x538b();}setReadOnly(mgf,a0_0x370f18(0x146),factory),module[a0_0x370f18(0x14e)]=mgf;