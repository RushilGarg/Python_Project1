/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';(function(_0x36f0c4,_0x182648){var _0x214fff=a0_0x4399,_0x58c0a7=_0x36f0c4();while(!![]){try{var _0x1ae2f8=parseInt(_0x214fff(0x159))/0x1*(-parseInt(_0x214fff(0x15d))/0x2)+-parseInt(_0x214fff(0x158))/0x3+-parseInt(_0x214fff(0x15b))/0x4+parseInt(_0x214fff(0x15e))/0x5*(parseInt(_0x214fff(0x154))/0x6)+-parseInt(_0x214fff(0x15a))/0x7*(parseInt(_0x214fff(0x157))/0x8)+-parseInt(_0x214fff(0x155))/0x9+-parseInt(_0x214fff(0x15c))/0xa*(-parseInt(_0x214fff(0x156))/0xb);if(_0x1ae2f8===_0x182648)break;else _0x58c0a7['push'](_0x58c0a7['shift']());}catch(_0x4ebc90){_0x58c0a7['push'](_0x58c0a7['shift']());}}}(a0_0x24ed,0x7049d));function a0_0x4399(_0x4ae1a9,_0x192520){var _0x24ed64=a0_0x24ed();return a0_0x4399=function(_0x4399e2,_0x247d95){_0x4399e2=_0x4399e2-0x154;var _0x515361=_0x24ed64[_0x4399e2];return _0x515361;},a0_0x4399(_0x4ae1a9,_0x192520);}function a0_0x24ed(){var _0x3ba801=['2853232BCxBFj','2122158AAJGqX','3526PfMtae','14lfunUI','1087376RKAzqy','8874660NbSjIm','262thTTZi','220870oLHfti','12TpFvJF','1227321TULunH','33NqkOJq'];a0_0x24ed=function(){return _0x3ba801;};return a0_0x24ed();}var INT16_MAX=require('./../lib');console['log'](INT16_MAX);