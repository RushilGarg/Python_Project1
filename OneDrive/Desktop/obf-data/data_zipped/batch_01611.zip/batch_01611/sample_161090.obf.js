const a0_0x2bdbbd=a0_0x5d50;(function(_0xa0bf79,_0x21d378){const _0x572a9e=a0_0x5d50,_0x2738f6=_0xa0bf79();while(!![]){try{const _0x5ec839=parseInt(_0x572a9e(0x1ca))/0x1*(-parseInt(_0x572a9e(0x1de))/0x2)+-parseInt(_0x572a9e(0x1da))/0x3+parseInt(_0x572a9e(0x1df))/0x4*(-parseInt(_0x572a9e(0x1d1))/0x5)+-parseInt(_0x572a9e(0x1d9))/0x6*(parseInt(_0x572a9e(0x1c9))/0x7)+-parseInt(_0x572a9e(0x1c2))/0x8+-parseInt(_0x572a9e(0x1d2))/0x9*(-parseInt(_0x572a9e(0x1cf))/0xa)+-parseInt(_0x572a9e(0x1c1))/0xb*(-parseInt(_0x572a9e(0x1d3))/0xc);if(_0x5ec839===_0x21d378)break;else _0x2738f6['push'](_0x2738f6['shift']());}catch(_0x4f4e4d){_0x2738f6['push'](_0x2738f6['shift']());}}}(a0_0x2d13,0x66d58));import{injectGlobal,css}from'styled-components';export const primaryFontFamily=a0_0x2bdbbd(0x1d7);export const secondaryFontFamily=a0_0x2bdbbd(0x1c3);injectGlobal`
  @font-face {

  }
`;export const primaryTypeRegular=css`
  font-family: ${primaryFontFamily}, sans-serif;
  font-style: normal;
  font-weight: 400;
`;export const primaryColour=a0_0x2bdbbd(0x1c7);export const secondaryColour=a0_0x2bdbbd(0x1c6);export const highlightColour=a0_0x2bdbbd(0x1d6);export const easing={'InSine':a0_0x2bdbbd(0x1cc),'OutSine':'cubic-bezier(0.39,\x200.575,\x200.565,\x201)','InOutSine':'cubic-bezier(0.445,\x200.05,\x200.55,\x200.95)','InQuad':'cubic-bezier(0.55,\x200.085,\x200.68,\x200.53)','OutQuad':a0_0x2bdbbd(0x1dd),'InOutQuad':a0_0x2bdbbd(0x1cd),'InCubic':'cubic-bezier(0.55,\x200.055,\x200.675,\x200.19)','OutCubic':a0_0x2bdbbd(0x1c4),'InOutCubic':a0_0x2bdbbd(0x1c5),'InQuart':'cubic-bezier(0.895,\x200.03,\x200.685,\x200.22)','InOutQuart':a0_0x2bdbbd(0x1e0),'InQuint':a0_0x2bdbbd(0x1e1),'OutQuint':a0_0x2bdbbd(0x1db),'InOutQuint':'cubic-bezier(0.86,\x200,\x200.07,\x201)','InExpo':'cubic-bezier(0.95,\x200.05,\x200.795,\x200.035)','OutExpo':a0_0x2bdbbd(0x1d4),'InOutExpo':'cubic-bezier(1,\x200,\x200,\x201)','InCirc':'cubic-bezier(0.6,\x200.04,\x200.98,\x200.335)','OutCirc':a0_0x2bdbbd(0x1dc),'InOutCirc':a0_0x2bdbbd(0x1ce),'InBack':a0_0x2bdbbd(0x1cb),'OutBack':a0_0x2bdbbd(0x1d8),'InOutBack':a0_0x2bdbbd(0x1e2)};export const antialias=css`
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: greyscale;
  font-smoothing: antialiased;
`;export const smMinRaw=0x1a4;export const mdMinRaw=0x300;function a0_0x5d50(_0x2e5524,_0x2519b0){const _0x2d1399=a0_0x2d13();return a0_0x5d50=function(_0x5d5038,_0x968361){_0x5d5038=_0x5d5038-0x1c1;let _0x154e8c=_0x2d1399[_0x5d5038];return _0x154e8c;},a0_0x5d50(_0x2e5524,_0x2519b0);}function a0_0x2d13(){const _0x104309=['21967512jJnZgS','cubic-bezier(0.19,\x201,\x200.22,\x201)','768px','black','Tenor\x20Sans','cubic-bezier(0.175,\x200.885,\x200.32,\x201.275)','5658PKenyT','499611NLXLcX','cubic-bezier(0.23,\x201,\x200.32,\x201)','cubic-bezier(0.075,\x200.82,\x200.165,\x201)','cubic-bezier(0.25,\x200.46,\x200.45,\x200.94)','102gftpYt','1218164NBhMqR','cubic-bezier(0.77,\x200,\x200.175,\x201)','cubic-bezier(0.755,\x200.05,\x200.855,\x200.06)','cubic-bezier(0.68,\x20-0.55,\x200.265,\x201.55)','11zqQQRW','3534440PwYJrJ','Droid\x20Serif','cubic-bezier(0.215,\x200.61,\x200.355,\x201)','cubic-bezier(0.645,\x200.045,\x200.355,\x201)','#1e35a9','lightgrey','420px','3843ezRHRp','9267moMQgq','cubic-bezier(0.6,\x20-0.28,\x200.735,\x200.045)','cubic-bezier(0.47,\x200,\x200.745,\x200.715)','cubic-bezier(0.455,\x200.03,\x200.515,\x200.955)','cubic-bezier(0.785,\x200.135,\x200.15,\x200.86)','10KAZqNW','1600px','5MSgxlL','4444101eMkEfg'];a0_0x2d13=function(){return _0x104309;};return a0_0x2d13();}export const lgMinRaw=0x4b0;export const xlMinRaw=0x898;export const smMin=a0_0x2bdbbd(0x1c8);export const mdMin=a0_0x2bdbbd(0x1d5);export const lgMin='1200px';export const xlMin=a0_0x2bdbbd(0x1d0);export const xsMax=smMinRaw-0x1+'px';export const smMax=mdMinRaw-0x1+'px';export const mdMax=lgMinRaw-0x1+'px';export const lgMax=xlMinRaw-0x1+'px';export const placeholder=_0x401503=>css`
  &::-webkit-input-placeholder {
    ${_0x401503}
  }
  &:-moz-placeholder {
    ${_0x401503}
  }
  &::-moz-placeholder {
    ${_0x401503}
  }
  &:-ms-input-placeholder {
    ${_0x401503}
  }
`;export const title=css`
  ${primaryTypeRegular}
  margin: 0;
  font-size: 3.2rem;
  line-height: 1.1;
`;export const subtitle=css`
  ${primaryTypeRegular}
  margin: 0;
  font-size: 2rem;
  line-height: 1.2;
  transition: opacity 200ms ease-in-out;

  @media screen and (min-width: ${mdMin}){
    display: inline-block;
  }
`;export const defaultCopy=css`
  ${primaryTypeRegular}
  font-size: 1.6rem;
  line-height: 1.5;
`;export const prominentCopy=css`
  ${primaryTypeRegular}
  font-size: 2rem;
  line-height: 1.5;
`;export const navLink=css`
  ${primaryTypeRegular}
  font-size: 1.6rem;
  line-height: 1.7;
  text-decoration: none;
  text-transform: uppercase;

  @media screen and (min-width: ${lgMin}){
    font-size: 1.2rem;
  }

  &:hover {
    cursor: pointer;
  }

  &.active {
    ${primaryTypeRegular}
  }
`;export const linkBehaviour=css`
  &:hover {
    color: ${secondaryColour};
    transition: color 200ms ease-out;
    cursor: pointer;
  }
`;export const markdownContent=css`
  & p {
    ${defaultCopy}

    & + p {
      padding-top: 2rem;
    }
  }

  & blockquote {
    margin: 0;

    & p {
      ${prominentCopy}
      padding-top: 0rem;
      margin-bottom: 2rem;
    }
  }

  & h2 {
    ${subtitle}
    padding-top: 4rem;
    margin-bottom: 1rem;

    & + h3 {
      padding-top: 0;
    }
  }

  & a.gatsby-resp-image-link {
    display: inline-block;
    padding-top: 2rem;
    margin-bottom: 2rem;
  }

  & > p > a {
    border-bottom: 1px dotted;
    border-color: inherit;
    margin-bottom: -4px;
    transition: opacity 250ms cubic-bezier(0,.16,.37,1);

    &:hover, &:focus {
      opacity: 0.6;
      border-bottom: 1px solid;
    }
  }

  & > ol,
  & > ul {
    ${defaultCopy}
  }
`;export const breakpoints={'xs':{'at':0x0,'fluid':!![],'gutter':0x3,'padding':0x8,'width':0x64},'sm':{'at':smMinRaw,'fluid':!![],'gutter':0x3,'padding':0x8,'width':0x64},'md':{'at':mdMinRaw,'fluid':!![],'gutter':1.5,'padding':0xa,'width':0x64},'lg':{'at':lgMinRaw,'fluid':!![],'gutter':1.5,'padding':0xa,'width':0x64},'xl':{'at':xlMinRaw,'fluid':!![],'gutter':1.5,'padding':0x14,'width':0x64}};