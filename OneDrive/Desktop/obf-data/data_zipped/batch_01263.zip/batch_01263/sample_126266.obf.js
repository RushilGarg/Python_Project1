/**
* @license Apache-2.0
*
* Copyright (c) 2019 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x582b32=a0_0x2a2a;(function(_0x4476f5,_0x59519d){var _0x591fbd=a0_0x2a2a,_0x35b966=_0x4476f5();while(!![]){try{var _0x2929de=parseInt(_0x591fbd(0x138))/0x1*(-parseInt(_0x591fbd(0x12f))/0x2)+-parseInt(_0x591fbd(0x132))/0x3*(parseInt(_0x591fbd(0x136))/0x4)+parseInt(_0x591fbd(0x133))/0x5+parseInt(_0x591fbd(0x12e))/0x6+parseInt(_0x591fbd(0x135))/0x7+-parseInt(_0x591fbd(0x139))/0x8*(-parseInt(_0x591fbd(0x130))/0x9)+-parseInt(_0x591fbd(0x131))/0xa;if(_0x2929de===_0x59519d)break;else _0x35b966['push'](_0x35b966['shift']());}catch(_0x21eae2){_0x35b966['push'](_0x35b966['shift']());}}}(a0_0x50a4,0x51460));function a0_0x50a4(){var _0x42ef4b=['19575yZHOXA','3568608mKVWpQ','273420ZmjHhj','20khuMDu','9PHvcpu','4844990JcrMMu','3gXnwWU','2654955NLyRwb','exports','3169103hqVqKu','1848884oFmvWX','@stdlib/utils/define-property'];a0_0x50a4=function(){return _0x42ef4b;};return a0_0x50a4();}var defineProperty=require(a0_0x582b32(0x137));function a0_0x2a2a(_0x474e12,_0x55f724){var _0x50a4f7=a0_0x50a4();return a0_0x2a2a=function(_0x2a2a9f,_0x365505){_0x2a2a9f=_0x2a2a9f-0x12e;var _0x2d83be=_0x50a4f7[_0x2a2a9f];return _0x2d83be;},a0_0x2a2a(_0x474e12,_0x55f724);}function setConfigurableReadOnly(_0x2644de,_0x40b409,_0x3d73cd){defineProperty(_0x2644de,_0x40b409,{'configurable':!![],'enumerable':!![],'writable':![],'value':_0x3d73cd});}module[a0_0x582b32(0x134)]=setConfigurableReadOnly;