function a0_0x2e71(){var _0xc77378=['14HDBskA','1531250ItqUFZ','1376595NZtBys','749YZOsYR','8StQaOB','811290RXbYeR','64081QllUok','1392Nccjgf','9896RCUsHt','50039cXyePX','855INqPEX','18714jslkMa'];a0_0x2e71=function(){return _0xc77378;};return a0_0x2e71();}function a0_0x3d36(_0x1857f8,_0x225d9c){var _0x2e7116=a0_0x2e71();return a0_0x3d36=function(_0x3d3625,_0x4119a4){_0x3d3625=_0x3d3625-0xb6;var _0x14cef3=_0x2e7116[_0x3d3625];return _0x14cef3;},a0_0x3d36(_0x1857f8,_0x225d9c);}(function(_0x3c90a6,_0x55c73c){var _0x4d4498=a0_0x3d36,_0x1818c1=_0x3c90a6();while(!![]){try{var _0x3ee18f=parseInt(_0x4d4498(0xc0))/0x1*(-parseInt(_0x4d4498(0xba))/0x2)+-parseInt(_0x4d4498(0xbf))/0x3*(-parseInt(_0x4d4498(0xbe))/0x4)+-parseInt(_0x4d4498(0xbc))/0x5+-parseInt(_0x4d4498(0xb9))/0x6*(parseInt(_0x4d4498(0xbd))/0x7)+parseInt(_0x4d4498(0xb6))/0x8*(parseInt(_0x4d4498(0xb8))/0x9)+parseInt(_0x4d4498(0xbb))/0xa+-parseInt(_0x4d4498(0xb7))/0xb*(-parseInt(_0x4d4498(0xc1))/0xc);if(_0x3ee18f===_0x55c73c)break;else _0x1818c1['push'](_0x1818c1['shift']());}catch(_0x47f373){_0x1818c1['push'](_0x1818c1['shift']());}}}(a0_0x2e71,0x44bdd));import{gql}from'react-apollo';export default gql`
	query globals {
		worlds {
			id
			region
			lang
			slugs
			en { name slug }
			es { name slug }
			de { name slug }
			fr { name slug }
			zh { name slug }
		}
		langs {
			name
			slug
			label
		}
		objectives {
			id
			type
			map_type
			map_id
			en { name slug }
			es { name slug }
			de { name slug }
			fr { name slug }
			zh { name slug }
		}
	}
`;