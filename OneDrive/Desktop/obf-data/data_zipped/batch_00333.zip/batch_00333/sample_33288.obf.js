/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4dc6c6=a0_0x2a23;(function(_0x3ddb3e,_0x3954c7){var _0x71ed37=a0_0x2a23,_0xb060de=_0x3ddb3e();while(!![]){try{var _0x11f77b=-parseInt(_0x71ed37(0xcd))/0x1*(-parseInt(_0x71ed37(0xd6))/0x2)+parseInt(_0x71ed37(0xcb))/0x3+parseInt(_0x71ed37(0xd2))/0x4*(-parseInt(_0x71ed37(0xd9))/0x5)+-parseInt(_0x71ed37(0xd8))/0x6*(parseInt(_0x71ed37(0xca))/0x7)+-parseInt(_0x71ed37(0xd4))/0x8+-parseInt(_0x71ed37(0xda))/0x9+-parseInt(_0x71ed37(0xd7))/0xa*(-parseInt(_0x71ed37(0xd1))/0xb);if(_0x11f77b===_0x3954c7)break;else _0xb060de['push'](_0xb060de['shift']());}catch(_0x17e968){_0xb060de['push'](_0xb060de['shift']());}}}(a0_0x1474,0x6a656));var randu=require(a0_0x4dc6c6(0xcc)),bernoulli=require(a0_0x4dc6c6(0xd0)),round=require(a0_0x4dc6c6(0xc9)),Float32Array=require(a0_0x4dc6c6(0xdb)),Uint8Array=require(a0_0x4dc6c6(0xcf)),smskmap=require('./../lib');function a0_0x2a23(_0xc5352c,_0x247d23){var _0x14749d=a0_0x1474();return a0_0x2a23=function(_0x2a2344,_0x3b6697){_0x2a2344=_0x2a2344-0xc9;var _0x2df852=_0x14749d[_0x2a2344];return _0x2df852;},a0_0x2a23(_0xc5352c,_0x247d23);}function a0_0x1474(){var _0x54fe5c=['45yfZZdv','5357970dGueEz','@stdlib/array/float32','@stdlib/math/base/special/round','7GwRSgt','2466729JkXmoe','@stdlib/random/base/randu','1OYyDJc','ndarray','@stdlib/array/uint8','@stdlib/random/base/bernoulli','18258823LFHZgD','158608ueNSAS','length','4818312LLgHtC','log','18930muEmla','10lRdXAy','3007896ceOoEa'];a0_0x1474=function(){return _0x54fe5c;};return a0_0x1474();}function scale(_0x943cdd){return _0x943cdd*0xa;}var x=new Float32Array(0xa),m=new Uint8Array(x[a0_0x4dc6c6(0xd3)]),y=new Float32Array(x[a0_0x4dc6c6(0xd3)]),i;for(i=0x0;i<x[a0_0x4dc6c6(0xd3)];i++){x[i]=round(randu()*0xc8-0x64),m[i]=bernoulli(0.2);}console[a0_0x4dc6c6(0xd5)](x),console[a0_0x4dc6c6(0xd5)](m),console[a0_0x4dc6c6(0xd5)](y),smskmap[a0_0x4dc6c6(0xce)](x['length'],x,0x1,0x0,m,0x1,0x0,y,-0x1,y[a0_0x4dc6c6(0xd3)]-0x1,scale),console[a0_0x4dc6c6(0xd5)](y);