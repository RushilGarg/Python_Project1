/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2b76da=a0_0x254c;(function(_0x53c37e,_0x5975a5){var _0x437a80=a0_0x254c,_0x30a72a=_0x53c37e();while(!![]){try{var _0x986fe=parseInt(_0x437a80(0x84))/0x1+parseInt(_0x437a80(0x83))/0x2+-parseInt(_0x437a80(0x90))/0x3+-parseInt(_0x437a80(0x87))/0x4+parseInt(_0x437a80(0x8a))/0x5+-parseInt(_0x437a80(0x85))/0x6+parseInt(_0x437a80(0x8b))/0x7;if(_0x986fe===_0x5975a5)break;else _0x30a72a['push'](_0x30a72a['shift']());}catch(_0x52cc58){_0x30a72a['push'](_0x30a72a['shift']());}}}(a0_0xde46,0x28333));function a0_0xde46(){var _0x298cf7=['822807hGNNnJ','nin','461670IHLPxF','241172aIIMjr','1522578QmwSPl','./meta.json','706544agYbeC','@stdlib/strided/base/dtype-resolve-enum','./data.js','1245295HdyEvJ','1037827EWRwOd','nout','@stdlib/strided/dispatch','./types.json','exports'];a0_0xde46=function(){return _0x298cf7;};return a0_0xde46();}var dispatch=require(a0_0x2b76da(0x8d)),unary=require('@stdlib/strided/base/unary'),resolve=require(a0_0x2b76da(0x88)),types=require(a0_0x2b76da(0x8e)),meta=require(a0_0x2b76da(0x86)),data=require(a0_0x2b76da(0x89)),fcn=dispatch(unary,types,data,meta['nargs'],meta[a0_0x2b76da(0x82)],meta[a0_0x2b76da(0x8c)]);function ceil(_0x2ff06e,_0x51ec3b,_0x562afd,_0x945e47,_0x192a26,_0x12f0d7,_0x468cd4){return fcn(_0x2ff06e,resolve(_0x51ec3b),_0x562afd,_0x945e47,resolve(_0x192a26),_0x12f0d7,_0x468cd4);}function a0_0x254c(_0x22b1b9,_0x3a5a28){var _0xde462b=a0_0xde46();return a0_0x254c=function(_0x254c0e,_0x90932){_0x254c0e=_0x254c0e-0x82;var _0x433494=_0xde462b[_0x254c0e];return _0x433494;},a0_0x254c(_0x22b1b9,_0x3a5a28);}module[a0_0x2b76da(0x8f)]=ceil;