'use strict';const a0_0x5d549c=a0_0x3cf8;(function(_0x92f130,_0x4fd47d){const _0x47c9e1=a0_0x3cf8,_0xc99ac8=_0x92f130();while(!![]){try{const _0xce0926=-parseInt(_0x47c9e1(0x192))/0x1+-parseInt(_0x47c9e1(0x18c))/0x2+parseInt(_0x47c9e1(0x18f))/0x3+parseInt(_0x47c9e1(0x191))/0x4+-parseInt(_0x47c9e1(0x18a))/0x5*(-parseInt(_0x47c9e1(0x18d))/0x6)+parseInt(_0x47c9e1(0x193))/0x7+-parseInt(_0x47c9e1(0x190))/0x8*(parseInt(_0x47c9e1(0x189))/0x9);if(_0xce0926===_0x4fd47d)break;else _0xc99ac8['push'](_0xc99ac8['shift']());}catch(_0x2344ff){_0xc99ac8['push'](_0xc99ac8['shift']());}}}(a0_0x3a62,0x99796));function a0_0x3cf8(_0x5dcebb,_0x5b04e1){const _0x3a627a=a0_0x3a62();return a0_0x3cf8=function(_0x3cf87a,_0x51b86e){_0x3cf87a=_0x3cf87a-0x189;let _0x20b7fe=_0x3a627a[_0x3cf87a];return _0x20b7fe;},a0_0x3cf8(_0x5dcebb,_0x5b04e1);}const {gql}=require(a0_0x5d549c(0x18e));function a0_0x3a62(){const _0x47b878=['1336206DZMXZD','4358392GQOJCx','1803180NRclbh','691317VqaynZ','434WglxKr','9YeTpQN','5canRDM','exports','303182xTMgQb','6720468TWyfqx','apollo-server-micro'];a0_0x3a62=function(){return _0x47b878;};return a0_0x3a62();}module[a0_0x5d549c(0x18b)]=gql`
	"""
	Domains are required to track views. You can create as many domains as you want, but it's recommended to create on domain per project/site. This allows you to view facts and statistics separately.
	"""
	type Domain {
		"""
		Domain identifier.
		"""
		id: ID!
		"""
		Title of the domain.
		"""
		title: String!
		"""
		Facts about a domain. Usually simple data that can be represented in one value.
		"""
		facts: Facts!
		"""
		Statistics of a domain. Usually data that needs to be represented in a list or chart.
		"""
		statistics: DomainStatistics!
		"""
		Identifies the date and time when the object was created.
		"""
		created: DateTime!
		"""
		Identifies the date and time when the object was updated.
		"""
		updated: DateTime!
	}

	input CreateDomainInput {
		"""
		Title of the domain.
		"""
		title: String!
	}

	type CreateDomainPayload {
		"""
		Indicates that the domain creation was successful. Might be 'null' otherwise.
		"""
		success: Boolean
		"""
		The newly created domain.
		"""
		payload: Domain
	}

	input UpdateDomainInput {
		"""
		Title of the domain.
		"""
		title: String!
	}

	type UpdateDomainPayload {
		"""
		Indicates that the domain update was successful. Might be 'null' otherwise.
		"""
		success: Boolean
		"""
		The updated domain.
		"""
		payload: Domain
	}

	type DeleteDomainPayload {
		"""
		Indicates that the domain deletion was successful. Might be 'null' otherwise.
		"""
		success: Boolean
	}

	type Query {
		"""
		Data of a specific domain.
		"""
		domain(id: ID!): Domain
		"""
		Data of all existing domains.
		"""
		domains: [Domain!]
	}

	type Mutation {
		"""
		Create a new domain.
		"""
		createDomain(input: CreateDomainInput!): CreateDomainPayload!
		"""
		Update an existing domain.
		"""
		updateDomain(id: ID!, input: UpdateDomainInput!): UpdateDomainPayload!
		"""
		Delete an existing domain.
		"""
		deleteDomain(id: ID!): DeleteDomainPayload!
	}
`;