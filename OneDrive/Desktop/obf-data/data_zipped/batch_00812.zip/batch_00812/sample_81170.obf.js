/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4e4708=a0_0x2159;function a0_0x2d9a(){var _0x456562=['537885EUzyKL','2264595eydWYi','408QxkfNp','566420fCGZzP','868158NNaJgh','2109075UrSDzJ','2643879GIwIAb','12gBNkCb','./main.js','4086196elezPQ','exports'];a0_0x2d9a=function(){return _0x456562;};return a0_0x2d9a();}(function(_0x2ecc72,_0xe08035){var _0x2d5fdc=a0_0x2159,_0x48dfba=_0x2ecc72();while(!![]){try{var _0x39f7d7=-parseInt(_0x2d5fdc(0x19a))/0x1+-parseInt(_0x2d5fdc(0x19b))/0x2+parseInt(_0x2d5fdc(0x19c))/0x3+-parseInt(_0x2d5fdc(0x195))/0x4+-parseInt(_0x2d5fdc(0x198))/0x5+-parseInt(_0x2d5fdc(0x19e))/0x6*(parseInt(_0x2d5fdc(0x19d))/0x7)+parseInt(_0x2d5fdc(0x199))/0x8*(parseInt(_0x2d5fdc(0x197))/0x9);if(_0x39f7d7===_0xe08035)break;else _0x48dfba['push'](_0x48dfba['shift']());}catch(_0x1c3faf){_0x48dfba['push'](_0x48dfba['shift']());}}}(a0_0x2d9a,0x7f1e7));function a0_0x2159(_0x16da93,_0x55d2a7){var _0x2d9a1e=a0_0x2d9a();return a0_0x2159=function(_0x2159e0,_0xb908b6){_0x2159e0=_0x2159e0-0x195;var _0x5b598e=_0x2d9a1e[_0x2159e0];return _0x5b598e;},a0_0x2159(_0x16da93,_0x55d2a7);}var iterator=require(a0_0x4e4708(0x19f));module[a0_0x4e4708(0x196)]=iterator;