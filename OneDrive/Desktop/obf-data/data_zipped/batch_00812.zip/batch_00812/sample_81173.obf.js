/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x5be891=a0_0x324f;(function(_0x423122,_0x11943a){var _0x61f056=a0_0x324f,_0x30a985=_0x423122();while(!![]){try{var _0x4c44a4=parseInt(_0x61f056(0x1e5))/0x1+parseInt(_0x61f056(0x1f7))/0x2+-parseInt(_0x61f056(0x1e4))/0x3*(parseInt(_0x61f056(0x1e8))/0x4)+parseInt(_0x61f056(0x1e7))/0x5*(parseInt(_0x61f056(0x1f6))/0x6)+-parseInt(_0x61f056(0x1f3))/0x7+-parseInt(_0x61f056(0x1ea))/0x8+-parseInt(_0x61f056(0x1fa))/0x9*(-parseInt(_0x61f056(0x1f0))/0xa);if(_0x4c44a4===_0x11943a)break;else _0x30a985['push'](_0x30a985['shift']());}catch(_0x5b62da){_0x30a985['push'](_0x30a985['shift']());}}}(a0_0xec62,0x44798));function a0_0x324f(_0x190677,_0x24808e){var _0xec624b=a0_0xec62();return a0_0x324f=function(_0x324f00,_0x568aab){_0x324f00=_0x324f00-0x1e4;var _0xebc8=_0xec624b[_0x324f00];return _0xebc8;},a0_0x324f(_0x190677,_0x24808e);}var bench=require(a0_0x5be891(0x1f8)),pkg=require(a0_0x5be891(0x1f4))['name'],Float32Array=require(a0_0x5be891(0x1fb));function a0_0xec62(){var _0x46bbfa=['1738204MbkWgH','iterations','3706288GljRjj','should\x20return\x20an\x20iterator\x20protocol-compliant\x20object','function','benchmark\x20finished','values','fail','22870cuFndg','next',':values','2302986wfGQKI','./../package.json','end','18UhMbjV','1076874ZMUtht','@stdlib/bench','toc','2493AylAYt','./../lib','3TFvHOS','320500ZHAwZl','object','24785binLZo'];a0_0xec62=function(){return _0x46bbfa;};return a0_0xec62();}bench(pkg+a0_0x5be891(0x1f2),function benchmark(_0x166df8){var _0x81c04e=a0_0x5be891,_0x1233b0,_0x42239c,_0x1a945b;_0x42239c=new Float32Array(0x2),_0x166df8['tic']();for(_0x1a945b=0x0;_0x1a945b<_0x166df8[_0x81c04e(0x1e9)];_0x1a945b++){_0x1233b0=_0x42239c[_0x81c04e(0x1ee)](),typeof _0x1233b0!==_0x81c04e(0x1e6)&&_0x166df8[_0x81c04e(0x1ef)]('should\x20return\x20an\x20object');}_0x166df8[_0x81c04e(0x1f9)](),(typeof _0x1233b0!==_0x81c04e(0x1e6)||typeof _0x1233b0[_0x81c04e(0x1f1)]!==_0x81c04e(0x1ec))&&_0x166df8[_0x81c04e(0x1ef)](_0x81c04e(0x1eb)),_0x166df8['pass'](_0x81c04e(0x1ed)),_0x166df8[_0x81c04e(0x1f5)]();});