const a0_0x19637f=a0_0x5d5b;(function(_0x4798f5,_0x353879){const _0x5e4331=a0_0x5d5b,_0x59e818=_0x4798f5();while(!![]){try{const _0x54a101=parseInt(_0x5e4331(0x295))/0x1*(-parseInt(_0x5e4331(0x1cf))/0x2)+parseInt(_0x5e4331(0x2b6))/0x3+parseInt(_0x5e4331(0x2ad))/0x4+-parseInt(_0x5e4331(0x28e))/0x5*(-parseInt(_0x5e4331(0x279))/0x6)+parseInt(_0x5e4331(0x22e))/0x7*(parseInt(_0x5e4331(0x1d4))/0x8)+parseInt(_0x5e4331(0x323))/0x9*(-parseInt(_0x5e4331(0x306))/0xa)+-parseInt(_0x5e4331(0x22d))/0xb;if(_0x54a101===_0x353879)break;else _0x59e818['push'](_0x59e818['shift']());}catch(_0x3ea7bb){_0x59e818['push'](_0x59e818['shift']());}}}(a0_0x1c5d,0xc2153));import{registerVersion,_registerComponent,_getProvider,getApp}from'https://www.gstatic.com/firebasejs/9.6.8/firebase-app.js';/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function isIndexedDBAvailable(){const _0x2e353a=a0_0x5d5b;return typeof indexedDB===_0x2e353a(0x332);}function validateIndexedDBOpenable(){return new Promise((_0x34b35f,_0x5ec196)=>{const _0x1304e5=a0_0x5d5b;try{let _0x21fd0f=!![];const _0x303bb2=_0x1304e5(0x307),_0x4b3609=self[_0x1304e5(0x285)][_0x1304e5(0x2ef)](_0x303bb2);_0x4b3609[_0x1304e5(0x2f9)]=()=>{const _0x35edac=_0x1304e5;_0x4b3609['result'][_0x35edac(0x336)](),!_0x21fd0f&&self[_0x35edac(0x285)][_0x35edac(0x2ed)](_0x303bb2),_0x34b35f(!![]);},_0x4b3609[_0x1304e5(0x2b8)]=()=>{_0x21fd0f=![];},_0x4b3609['onerror']=()=>{var _0x19c2e3;_0x5ec196(((_0x19c2e3=_0x4b3609['error'])===null||_0x19c2e3===void 0x0?void 0x0:_0x19c2e3['message'])||'');};}catch(_0x34e6f2){_0x5ec196(_0x34e6f2);}});}function areCookiesEnabled(){const _0x1e207d=a0_0x5d5b;if(typeof navigator===_0x1e207d(0x222)||!navigator[_0x1e207d(0x2d8)])return![];return!![];}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const ERROR_NAME=a0_0x19637f(0x211);class FirebaseError extends Error{constructor(_0x295522,_0x3d2cfd,_0x520d1d){const _0x4993b8=a0_0x19637f;super(_0x3d2cfd),this['code']=_0x295522,this[_0x4993b8(0x21d)]=_0x520d1d,this['name']=ERROR_NAME,Object['setPrototypeOf'](this,FirebaseError['prototype']),Error[_0x4993b8(0x25c)]&&Error['captureStackTrace'](this,ErrorFactory['prototype'][_0x4993b8(0x2bf)]);}}class ErrorFactory{constructor(_0x173915,_0x5863c4,_0x2192b4){const _0x45f9f4=a0_0x19637f;this['service']=_0x173915,this['serviceName']=_0x5863c4,this[_0x45f9f4(0x2c1)]=_0x2192b4;}[a0_0x19637f(0x2bf)](_0xe77c52,..._0x32ffff){const _0x62ac9f=a0_0x19637f,_0x285f0b=_0x32ffff[0x0]||{},_0x91c960=this[_0x62ac9f(0x22f)]+'/'+_0xe77c52,_0x57fae9=this[_0x62ac9f(0x2c1)][_0xe77c52],_0x13afdf=_0x57fae9?replaceTemplate(_0x57fae9,_0x285f0b):'Error',_0xed269a=this['serviceName']+':\x20'+_0x13afdf+'\x20('+_0x91c960+').',_0x23c7bd=new FirebaseError(_0x91c960,_0xed269a,_0x285f0b);return _0x23c7bd;}}function replaceTemplate(_0x59190c,_0x7ed93f){const _0x24128c=a0_0x19637f;return _0x59190c[_0x24128c(0x2c5)](PATTERN,(_0x33e746,_0x232510)=>{const _0x43a7ea=_0x7ed93f[_0x232510];return _0x43a7ea!=null?String(_0x43a7ea):'<'+_0x232510+'?>';});}const PATTERN=/\{\$([^}]+)}/g;function deepEqual(_0x3fd776,_0x6a61ca){const _0x3b4ae4=a0_0x19637f;if(_0x3fd776===_0x6a61ca)return!![];const _0x850771=Object[_0x3b4ae4(0x1f0)](_0x3fd776),_0x43c049=Object[_0x3b4ae4(0x1f0)](_0x6a61ca);for(const _0x12ded5 of _0x850771){if(!_0x43c049[_0x3b4ae4(0x25b)](_0x12ded5))return![];const _0x271600=_0x3fd776[_0x12ded5],_0x422b59=_0x6a61ca[_0x12ded5];if(isObject(_0x271600)&&isObject(_0x422b59)){if(!deepEqual(_0x271600,_0x422b59))return![];}else{if(_0x271600!==_0x422b59)return![];}}for(const _0x576c04 of _0x43c049){if(!_0x850771[_0x3b4ae4(0x25b)](_0x576c04))return![];}return!![];}function isObject(_0x52045b){const _0x5223ff=a0_0x19637f;return _0x52045b!==null&&typeof _0x52045b===_0x5223ff(0x332);}/**
 * @license
 * Copyright 2021 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function getModularInstance(_0x107a0f){const _0x4ff6a2=a0_0x19637f;return _0x107a0f&&_0x107a0f['_delegate']?_0x107a0f[_0x4ff6a2(0x1e8)]:_0x107a0f;}/**
 * @license
 * Copyright 2017 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var LogLevel;(function(_0x3767a9){const _0x16f615=a0_0x19637f;_0x3767a9[_0x3767a9[_0x16f615(0x2c4)]=0x0]=_0x16f615(0x2c4),_0x3767a9[_0x3767a9[_0x16f615(0x1e0)]=0x1]='VERBOSE',_0x3767a9[_0x3767a9['INFO']=0x2]=_0x16f615(0x2cb),_0x3767a9[_0x3767a9[_0x16f615(0x327)]=0x3]=_0x16f615(0x327),_0x3767a9[_0x3767a9[_0x16f615(0x2c0)]=0x4]=_0x16f615(0x2c0),_0x3767a9[_0x3767a9[_0x16f615(0x23e)]=0x5]='SILENT';}(LogLevel||(LogLevel={})));const levelStringToEnum={'debug':LogLevel[a0_0x19637f(0x2c4)],'verbose':LogLevel[a0_0x19637f(0x1e0)],'info':LogLevel[a0_0x19637f(0x2cb)],'warn':LogLevel['WARN'],'error':LogLevel[a0_0x19637f(0x2c0)],'silent':LogLevel[a0_0x19637f(0x23e)]},defaultLogLevel=LogLevel[a0_0x19637f(0x2cb)],ConsoleMethod={[LogLevel['DEBUG']]:a0_0x19637f(0x26e),[LogLevel[a0_0x19637f(0x1e0)]]:a0_0x19637f(0x26e),[LogLevel[a0_0x19637f(0x2cb)]]:'info',[LogLevel[a0_0x19637f(0x327)]]:a0_0x19637f(0x301),[LogLevel[a0_0x19637f(0x2c0)]]:'error'},defaultLogHandler=(_0x42626a,_0x2a520f,..._0x503cc1)=>{const _0x198b37=a0_0x19637f;if(_0x2a520f<_0x42626a[_0x198b37(0x296)])return;const _0x16b034=new Date()[_0x198b37(0x316)](),_0x59c335=ConsoleMethod[_0x2a520f];if(_0x59c335)console[_0x59c335]('['+_0x16b034+_0x198b37(0x2e6)+_0x42626a[_0x198b37(0x1d5)]+':',..._0x503cc1);else throw new Error(_0x198b37(0x2fc)+_0x2a520f+')');};class Logger{constructor(_0x247d51){const _0x45d1df=a0_0x19637f;this['name']=_0x247d51,this[_0x45d1df(0x1d7)]=defaultLogLevel,this[_0x45d1df(0x2f5)]=defaultLogHandler,this[_0x45d1df(0x1f1)]=null;}get[a0_0x19637f(0x296)](){const _0x1d67ac=a0_0x19637f;return this[_0x1d67ac(0x1d7)];}set['logLevel'](_0x1d55c2){const _0x28222c=a0_0x19637f;if(!(_0x1d55c2 in LogLevel))throw new TypeError('Invalid\x20value\x20\x22'+_0x1d55c2+'\x22\x20assigned\x20to\x20`logLevel`');this[_0x28222c(0x1d7)]=_0x1d55c2;}[a0_0x19637f(0x1db)](_0x5aafcb){const _0x25bc6e=a0_0x19637f;this[_0x25bc6e(0x1d7)]=typeof _0x5aafcb===_0x25bc6e(0x2fe)?levelStringToEnum[_0x5aafcb]:_0x5aafcb;}get[a0_0x19637f(0x292)](){const _0x4c49f2=a0_0x19637f;return this[_0x4c49f2(0x2f5)];}set[a0_0x19637f(0x292)](_0x20c1f3){const _0x2a0c8b=a0_0x19637f;if(typeof _0x20c1f3!==_0x2a0c8b(0x23b))throw new TypeError(_0x2a0c8b(0x271));this['_logHandler']=_0x20c1f3;}get[a0_0x19637f(0x288)](){const _0x42aecc=a0_0x19637f;return this[_0x42aecc(0x1f1)];}set['userLogHandler'](_0x31a095){const _0x2ba82b=a0_0x19637f;this[_0x2ba82b(0x1f1)]=_0x31a095;}['debug'](..._0x15739d){const _0x23d717=a0_0x19637f;this[_0x23d717(0x1f1)]&&this[_0x23d717(0x1f1)](this,LogLevel[_0x23d717(0x2c4)],..._0x15739d),this[_0x23d717(0x2f5)](this,LogLevel[_0x23d717(0x2c4)],..._0x15739d);}[a0_0x19637f(0x26e)](..._0x2d523b){const _0x2e9442=a0_0x19637f;this[_0x2e9442(0x1f1)]&&this[_0x2e9442(0x1f1)](this,LogLevel[_0x2e9442(0x1e0)],..._0x2d523b),this[_0x2e9442(0x2f5)](this,LogLevel[_0x2e9442(0x1e0)],..._0x2d523b);}[a0_0x19637f(0x27c)](..._0x487094){const _0x485ee7=a0_0x19637f;this['_userLogHandler']&&this[_0x485ee7(0x1f1)](this,LogLevel[_0x485ee7(0x2cb)],..._0x487094),this[_0x485ee7(0x2f5)](this,LogLevel[_0x485ee7(0x2cb)],..._0x487094);}[a0_0x19637f(0x301)](..._0x58ddc8){const _0x396937=a0_0x19637f;this[_0x396937(0x1f1)]&&this[_0x396937(0x1f1)](this,LogLevel[_0x396937(0x327)],..._0x58ddc8),this[_0x396937(0x2f5)](this,LogLevel[_0x396937(0x327)],..._0x58ddc8);}[a0_0x19637f(0x1e5)](..._0x5bd2b3){const _0x458a96=a0_0x19637f;this[_0x458a96(0x1f1)]&&this['_userLogHandler'](this,LogLevel[_0x458a96(0x2c0)],..._0x5bd2b3),this[_0x458a96(0x2f5)](this,LogLevel[_0x458a96(0x2c0)],..._0x5bd2b3);}}class Component{constructor(_0x2b4e71,_0x3594bd,_0x31853e){const _0x548318=a0_0x19637f;this[_0x548318(0x1d5)]=_0x2b4e71,this[_0x548318(0x297)]=_0x3594bd,this[_0x548318(0x1cc)]=_0x31853e,this[_0x548318(0x253)]=![],this[_0x548318(0x331)]={},this[_0x548318(0x254)]=_0x548318(0x2b5),this[_0x548318(0x268)]=null;}[a0_0x19637f(0x2e7)](_0x12c6cb){return this['instantiationMode']=_0x12c6cb,this;}['setMultipleInstances'](_0x1cb73f){const _0x16c9b1=a0_0x19637f;return this[_0x16c9b1(0x253)]=_0x1cb73f,this;}[a0_0x19637f(0x322)](_0x394693){const _0x1c5528=a0_0x19637f;return this[_0x1c5528(0x331)]=_0x394693,this;}[a0_0x19637f(0x2cf)](_0x270120){const _0x2f37f0=a0_0x19637f;return this[_0x2f37f0(0x268)]=_0x270120,this;}}function toArray(_0x18f0cc){const _0x59751d=a0_0x19637f;return Array[_0x59751d(0x1e7)][_0x59751d(0x2e8)][_0x59751d(0x210)](_0x18f0cc);}function promisifyRequest(_0x2d0a1e){return new Promise(function(_0x1d04ad,_0x10f1ba){const _0x294482=a0_0x5d5b;_0x2d0a1e[_0x294482(0x2f9)]=function(){_0x1d04ad(_0x2d0a1e['result']);},_0x2d0a1e['onerror']=function(){_0x10f1ba(_0x2d0a1e['error']);};});}function promisifyRequestCall(_0xf94e68,_0x12b14c,_0x1e39e2){const _0x3910ef=a0_0x19637f;var _0x7ae048,_0x2aabfd=new Promise(function(_0x47e4c6,_0x5ce5ec){const _0x94667c=a0_0x5d5b;_0x7ae048=_0xf94e68[_0x12b14c][_0x94667c(0x20f)](_0xf94e68,_0x1e39e2),promisifyRequest(_0x7ae048)['then'](_0x47e4c6,_0x5ce5ec);});return _0x2aabfd[_0x3910ef(0x2a6)]=_0x7ae048,_0x2aabfd;}function promisifyCursorRequestCall(_0x3f31ee,_0x2b0a58,_0x5bb405){const _0x63e274=a0_0x19637f;var _0xedb1ca=promisifyRequestCall(_0x3f31ee,_0x2b0a58,_0x5bb405);return _0xedb1ca[_0x63e274(0x220)](function(_0x48b7f9){const _0x40c6a3=_0x63e274;if(!_0x48b7f9)return;return new Cursor(_0x48b7f9,_0xedb1ca[_0x40c6a3(0x2a6)]);});}function proxyProperties(_0x4e1889,_0x36b7d1,_0x295e2e){const _0x36c451=a0_0x19637f;_0x295e2e[_0x36c451(0x2a2)](function(_0x2a8582){const _0x32f24d=_0x36c451;Object['defineProperty'](_0x4e1889[_0x32f24d(0x1e7)],_0x2a8582,{'get':function(){return this[_0x36b7d1][_0x2a8582];},'set':function(_0x1b40a9){this[_0x36b7d1][_0x2a8582]=_0x1b40a9;}});});}function proxyRequestMethods(_0x23941c,_0x31d96a,_0x1b61ac,_0x34d69b){const _0x7a0565=a0_0x19637f;_0x34d69b[_0x7a0565(0x2a2)](function(_0x2da057){const _0x34e90a=_0x7a0565;if(!(_0x2da057 in _0x1b61ac[_0x34e90a(0x1e7)]))return;_0x23941c[_0x34e90a(0x1e7)][_0x2da057]=function(){return promisifyRequestCall(this[_0x31d96a],_0x2da057,arguments);};});}function proxyMethods(_0x3c87db,_0x1095fb,_0x5e7a11,_0x49a0c6){const _0x4f4600=a0_0x19637f;_0x49a0c6[_0x4f4600(0x2a2)](function(_0x3aa57d){const _0x2f403c=_0x4f4600;if(!(_0x3aa57d in _0x5e7a11[_0x2f403c(0x1e7)]))return;_0x3c87db[_0x2f403c(0x1e7)][_0x3aa57d]=function(){const _0x5cc1e2=_0x2f403c;return this[_0x1095fb][_0x3aa57d][_0x5cc1e2(0x20f)](this[_0x1095fb],arguments);};});}function proxyCursorRequestMethods(_0x891aa4,_0x3a3b84,_0x5997b4,_0xc94638){const _0x190a90=a0_0x19637f;_0xc94638[_0x190a90(0x2a2)](function(_0x5ed4e8){const _0x512ffa=_0x190a90;if(!(_0x5ed4e8 in _0x5997b4['prototype']))return;_0x891aa4[_0x512ffa(0x1e7)][_0x5ed4e8]=function(){return promisifyCursorRequestCall(this[_0x3a3b84],_0x5ed4e8,arguments);};});}function Index(_0x3d7ae7){const _0x1ba21=a0_0x19637f;this[_0x1ba21(0x219)]=_0x3d7ae7;}proxyProperties(Index,'_index',[a0_0x19637f(0x1d5),a0_0x19637f(0x200),'multiEntry','unique']),proxyRequestMethods(Index,a0_0x19637f(0x219),IDBIndex,['get',a0_0x19637f(0x216),a0_0x19637f(0x203),a0_0x19637f(0x1e9),a0_0x19637f(0x330)]),proxyCursorRequestMethods(Index,a0_0x19637f(0x219),IDBIndex,[a0_0x19637f(0x278),a0_0x19637f(0x1e4)]);function Cursor(_0x1084e5,_0x598969){const _0x4cfd06=a0_0x19637f;this[_0x4cfd06(0x32a)]=_0x1084e5,this[_0x4cfd06(0x1cd)]=_0x598969;}proxyProperties(Cursor,a0_0x19637f(0x32a),[a0_0x19637f(0x2e1),a0_0x19637f(0x250),a0_0x19637f(0x257),a0_0x19637f(0x1d9)]),proxyRequestMethods(Cursor,a0_0x19637f(0x32a),IDBCursor,[a0_0x19637f(0x303),a0_0x19637f(0x23c)]),['advance',a0_0x19637f(0x208),a0_0x19637f(0x305)][a0_0x19637f(0x2a2)](function(_0x5118d6){const _0x178e0e=a0_0x19637f;if(!(_0x5118d6 in IDBCursor[_0x178e0e(0x1e7)]))return;Cursor[_0x178e0e(0x1e7)][_0x5118d6]=function(){const _0x28704b=_0x178e0e;var _0x59c412=this,_0x118c65=arguments;return Promise[_0x28704b(0x1f3)]()[_0x28704b(0x220)](function(){const _0x2bfaf7=_0x28704b;return _0x59c412[_0x2bfaf7(0x32a)][_0x5118d6][_0x2bfaf7(0x20f)](_0x59c412['_cursor'],_0x118c65),promisifyRequest(_0x59c412[_0x2bfaf7(0x1cd)])[_0x2bfaf7(0x220)](function(_0xfbef50){const _0x282e58=_0x2bfaf7;if(!_0xfbef50)return;return new Cursor(_0xfbef50,_0x59c412[_0x282e58(0x1cd)]);});});};});function ObjectStore(_0x302d58){this['_store']=_0x302d58;}ObjectStore[a0_0x19637f(0x1e7)][a0_0x19637f(0x1dc)]=function(){const _0xb00219=a0_0x19637f;return new Index(this[_0xb00219(0x2c3)][_0xb00219(0x1dc)]['apply'](this[_0xb00219(0x2c3)],arguments));},ObjectStore['prototype']['index']=function(){const _0x290115=a0_0x19637f;return new Index(this[_0x290115(0x2c3)][_0x290115(0x2a0)][_0x290115(0x20f)](this['_store'],arguments));},proxyProperties(ObjectStore,a0_0x19637f(0x2c3),[a0_0x19637f(0x1d5),a0_0x19637f(0x200),a0_0x19637f(0x298),a0_0x19637f(0x28d)]),proxyRequestMethods(ObjectStore,a0_0x19637f(0x2c3),IDBObjectStore,[a0_0x19637f(0x2d1),a0_0x19637f(0x244),a0_0x19637f(0x23c),a0_0x19637f(0x23d),'get',a0_0x19637f(0x203),'getKey',a0_0x19637f(0x1e9),a0_0x19637f(0x330)]),proxyCursorRequestMethods(ObjectStore,a0_0x19637f(0x2c3),IDBObjectStore,['openCursor',a0_0x19637f(0x1e4)]),proxyMethods(ObjectStore,a0_0x19637f(0x2c3),IDBObjectStore,['deleteIndex']);function Transaction(_0x2275ee){const _0x1f570c=a0_0x19637f;this[_0x1f570c(0x2a9)]=_0x2275ee,this['complete']=new Promise(function(_0x16e258,_0x5375e4){const _0x37b311=_0x1f570c;_0x2275ee[_0x37b311(0x1da)]=function(){_0x16e258();},_0x2275ee[_0x37b311(0x273)]=function(){const _0x360281=_0x37b311;_0x5375e4(_0x2275ee[_0x360281(0x1e5)]);},_0x2275ee['onabort']=function(){_0x5375e4(_0x2275ee['error']);};});}Transaction['prototype'][a0_0x19637f(0x212)]=function(){return new ObjectStore(this['_tx']['objectStore']['apply'](this['_tx'],arguments));},proxyProperties(Transaction,a0_0x19637f(0x2a9),[a0_0x19637f(0x29a),a0_0x19637f(0x2e0)]),proxyMethods(Transaction,a0_0x19637f(0x2a9),IDBTransaction,[a0_0x19637f(0x29b)]);function a0_0x5d5b(_0xaeec05,_0x5dab03){const _0x1c5dab=a0_0x1c5d();return a0_0x5d5b=function(_0x5d5b3b,_0x1e89e9){_0x5d5b3b=_0x5d5b3b-0x1c6;let _0x33cb6e=_0x1c5dab[_0x5d5b3b];return _0x33cb6e;},a0_0x5d5b(_0xaeec05,_0x5dab03);}function a0_0x1c5d(){const _0x3e9777=['/namespaces/fireperf:fetch?key=','no\x20project\x20id','substr','setInstanceCreatedCallback','Trace\x20{$traceName}\x20is\x20not\x20running.','put','\x20already\x20initialized\x20instance.','logSource','installation-not-found','expiresIn','Input\x20for\x20String\x20merger\x20is\x20invalid,\x20contact\x20support\x20team\x20to\x20resolve.','logTraceAfterSampling','cookieEnabled','performanceController','metrics','data','{$requestName}\x20request\x20failed\x20with\x20error\x20\x22{$serverCode}\x20{$serverStatus}:\x20{$serverMessage}\x22','visibilityState','api','getImmediate','mode','direction','fromCharCode','getProvider','request-failed','isAuto',']\x20\x20','setInstantiationMode','slice','hidden','windowLocation','https://firebaseremoteconfig.googleapis.com/v1/projects/','Api\x20key\x20is\x20not\x20available.','deleteDatabase','RC\x20response\x20is\x20not\x20ok','open','result','serverCode','_fid','registrationStatus','FIREBASE_INSTALLATIONS_AUTH','_logHandler','httpMethod','state','assign','onsuccess','HIDDEN','match','Attempted\x20to\x20log\x20a\x20message\x20with\x20an\x20invalid\x20logType\x20(value:\x20','startTimeUs','string','navigator','Custom\x20metric\x20name\x20{$customMetricName}\x20is\x20invalid','warn','timeOrigin','update','incrementMetric','continuePrimaryKey','320Whvuqk','validate-browser-context-for-indexeddb-analytics-module','getEntriesByType','timeToResponseCompletedUs','attributes','RC\x20response\x20not\x20ok','Can\x27t\x20delete\x20installation\x20while\x20there\x20is\x20a\x20pending\x20registration\x20request.','setStartTime','fpr_vc_network_request_sampling_rate','onFirstInputDelay','logResponseDetails','UNKNOWN','join','_fp','counters','App\x20Name','toISOString','installationEntry','getInstance','postMessage','domContentLoadedEventEnd','size','invalid\x20attribute\x20value','no\x20app\x20id','appConfig','Metric\x20value\x20should\x20be\x20an\x20Integer,\x20setting\x20the\x20value\x20as\x20:\x20','tp:/ieaeogn-agolai.o/1frlglgc/o','append','setServiceProps','194931icAFzS','requestStatus','same\x20options\x20as\x20when\x20it\x20was\x20originally\x20called,\x20or\x20call\x20getPerformance()\x20to\x20return\x20the','catch','WARN','requestTime','\x22Fetch\x22\x20and\x20\x22Promise\x22,\x20or\x20cookies\x20are\x20disabled.','_cursor','createUserTimingTrace','localStorage','no\x20window','map','iterate','count','serviceProps','object','already\x20initialized','now','_db','close','fpr_enabled','traceStartMark','creationTime','@firebase/performance/configexpire','x-firebase-client','setItem','type','_request','location','810686Iciupx','addEventListener','domInteractive','performance','max','230152TuYvdP','name','responseEnd','_logLevel','VISIBLE','value','oncomplete','setLogLevel','createIndex','document','fid','[DEFAULT]','VERBOSE','href','stringify','tracesSamplingRate','openKeyCursor','error','startsWith','prototype','_delegate','getAllKeys','url','instrumentationEnabled','getAttribute','eventTime','App\x20Configuration','Create\x20Installation','keys','_userLogHandler','registrationTime','resolve','options','/projects/','status','substring','invalid\x20cc\x20log','oldVersion','Authorization','readyState','missing-app-config-values','FB-PERF-TRACE-STOP','calculateTraceMetrics','_fcp','keyPath','Installations','startTime','getAll','random','BroadcastChannel','resource','first-paint','continue','getFlTransportFullUrl','get','logEndPointUrl','app','responsePayloadBytes','getOptions','apply','call','FirebaseError','objectStore','window','getItem','onmessage','getKey','https://firebaselogging.googleapis.com/v0cc/log?format=json_proto','readwrite','_index','setDuration','perfMetrics','_wt_','customData','paint','Could\x20not\x20process\x20request.\x20Application\x20offline.','then','requiredApisAvailable','undefined','registrationPromise','https://firebaseinstallations.googleapis.com/v1','navigationStart','not-registered','000','randomId','push','POST','serviceWorker','floor','9769958ImPkCJ','70TuYQut','service','@firebase/performance/config','apiKey','putMetric','indexOf','code','loggingEnabled','fpr_log_endpoint_url','refreshToken','[Firebase]\x20FID\x20Change','Call\x20to\x20Firebase\x20backend\x20failed.','^[a-zA-Z]\x5cw*$','function','delete','clear','SILENT','nonpositive\x20trace\x20duration','test','Performance','application/json','appName','add','0.5.5','installations','onLine','token','complete','Tries\x20left:\x20','some','concat','0.0.1','deleteObjectStore','installations-internal','key','visible','dataCollectionEnabled','multipleInstances','instantiationMode','loadEventEnd','IndexedDB\x20is\x20not\x20supported\x20by\x20current\x20browswer','primaryKey','hts/frbslgigp.ogepscmv/ieo/eaylg','traceMeasure','putAttribute','includes','captureStackTrace','version','FB-PERF-TRACE-START','RETRY_REQUEST_LATER','flTransportEndpointUrl','getRandomValues','Trace\x20{$traceName}\x20duration\x20should\x20be\x20positive.','Missing\x20App\x20configuration\x20value:\x20\x22{$valueName}\x22','fpr_vc_trace_sampling_rate','navigation','entries','nextRequestWaitMillis','onInstanceCreated','PerformanceObserver','getAttributes','FIS_v2','trace\x20started','projectId','log','authToken','configTimeToLive','Value\x20assigned\x20to\x20`logHandler`\x20must\x20be\x20a\x20function','getUrl','onerror','Environment\x20doesn\x27t\x20support\x20IndexedDB:\x20','length','PRIVATE','setupObserver','openCursor','2985852pzzlZD','/installations','invalid\x20String\x20merger\x20input','info','start','delete-pending-registration','responseAction','split','FB\x20not\x20default','message','Performance\x20can\x20only\x20start\x20when\x20Firebase\x20app\x20instance\x20is\x20the\x20default\x20one.','createObjectStore','indexedDB','fpr_log_transport_key','find','userLogHandler','getTimeOrigin','charAt','getEntriesByName','observe','autoIncrement','10kNNrNB','initialized','getMetric','Generate\x20Auth\x20Token','logHandler','traceStopMark','Trace\x20{$traceName}\x20was\x20started\x20before.','1uNnfun','logLevel','instanceFactory','indexNames','networkRequestsSamplingRate','objectStoreNames','abort','transportKey','app-offline','timing','firebase-installations-database','index','readystatechange','forEach','@firebase/performance','nonpositive\x20trace\x20startTime','transaction','request','trace\x20stopped','different\x20options.\x20To\x20avoid\x20this\x20error,\x20call\x20initializePerformance()\x20with\x20the\x20','_tx','mark','invalid\x20attribute\x20name','invalid\x20custom\x20metric\x20name','2025960DlMAyI','getPlatformInfoString','Iayx0u-XT3vksVM-pIV','logNetworkAfterSampling','getToken','responseStart','Window\x20is\x20not\x20available.','reject','LAZY','2976324lWNWkK','no\x20api\x20key','onupgradeneeded','durationUs','firebase_','json','appId','Attribute\x20name\x20{$attributeName}\x20is\x20invalid.','customAttributes','create','ERROR','errors','createOobTrace','_store','DEBUG','replace','measure','duration','crypto','FB-PERF-TRACE-MEASURE','esm2017','INFO'];a0_0x1c5d=function(){return _0x3e9777;};return a0_0x1c5d();}function UpgradeDB(_0x4cfe36,_0x1afea6,_0x486543){const _0x413504=a0_0x19637f;this['_db']=_0x4cfe36,this[_0x413504(0x1f9)]=_0x1afea6,this[_0x413504(0x2a5)]=new Transaction(_0x486543);}UpgradeDB[a0_0x19637f(0x1e7)][a0_0x19637f(0x284)]=function(){const _0x527088=a0_0x19637f;return new ObjectStore(this['_db']['createObjectStore'][_0x527088(0x20f)](this[_0x527088(0x335)],arguments));},proxyProperties(UpgradeDB,a0_0x19637f(0x335),[a0_0x19637f(0x1d5),a0_0x19637f(0x25d),a0_0x19637f(0x29a)]),proxyMethods(UpgradeDB,'_db',IDBDatabase,[a0_0x19637f(0x24e),a0_0x19637f(0x336)]);function DB(_0x19930b){const _0x6e42d8=a0_0x19637f;this[_0x6e42d8(0x335)]=_0x19930b;}DB[a0_0x19637f(0x1e7)][a0_0x19637f(0x2a5)]=function(){const _0x286c42=a0_0x19637f;return new Transaction(this[_0x286c42(0x335)]['transaction'][_0x286c42(0x20f)](this[_0x286c42(0x335)],arguments));},proxyProperties(DB,a0_0x19637f(0x335),[a0_0x19637f(0x1d5),a0_0x19637f(0x25d),a0_0x19637f(0x29a)]),proxyMethods(DB,a0_0x19637f(0x335),IDBDatabase,[a0_0x19637f(0x336)]),[a0_0x19637f(0x278),a0_0x19637f(0x1e4)][a0_0x19637f(0x2a2)](function(_0x564190){const _0x263dc2=a0_0x19637f;[ObjectStore,Index][_0x263dc2(0x2a2)](function(_0x28c0b0){const _0x4a7786=_0x263dc2;if(!(_0x564190 in _0x28c0b0[_0x4a7786(0x1e7)]))return;_0x28c0b0[_0x4a7786(0x1e7)][_0x564190['replace']('open',_0x4a7786(0x32f))]=function(){const _0xa3e053=_0x4a7786;var _0x223a16=toArray(arguments),_0x304f4e=_0x223a16[_0x223a16[_0xa3e053(0x275)]-0x1],_0x393288=this[_0xa3e053(0x2c3)]||this[_0xa3e053(0x219)],_0x3e72b6=_0x393288[_0x564190][_0xa3e053(0x20f)](_0x393288,_0x223a16[_0xa3e053(0x2e8)](0x0,-0x1));_0x3e72b6['onsuccess']=function(){const _0x28f4f9=_0xa3e053;_0x304f4e(_0x3e72b6[_0x28f4f9(0x2f0)]);};};});}),[Index,ObjectStore][a0_0x19637f(0x2a2)](function(_0x2575bd){const _0x5eaa3f=a0_0x19637f;if(_0x2575bd[_0x5eaa3f(0x1e7)][_0x5eaa3f(0x203)])return;_0x2575bd[_0x5eaa3f(0x1e7)][_0x5eaa3f(0x203)]=function(_0x15fd65,_0x1f836d){var _0x4cca8c=this,_0x578f83=[];return new Promise(function(_0x41192d){_0x4cca8c['iterateCursor'](_0x15fd65,function(_0x2468a2){const _0x22856e=a0_0x5d5b;if(!_0x2468a2){_0x41192d(_0x578f83);return;}_0x578f83[_0x22856e(0x229)](_0x2468a2[_0x22856e(0x1d9)]);if(_0x1f836d!==undefined&&_0x578f83['length']==_0x1f836d){_0x41192d(_0x578f83);return;}_0x2468a2[_0x22856e(0x208)]();});});};});function openDb(_0x51eb69,_0x684eb5,_0x1b191f){const _0x4c5f53=a0_0x19637f;var _0x3ab8ae=promisifyRequestCall(indexedDB,_0x4c5f53(0x2ef),[_0x51eb69,_0x684eb5]),_0x26ce19=_0x3ab8ae[_0x4c5f53(0x2a6)];return _0x26ce19&&(_0x26ce19['onupgradeneeded']=function(_0x4e2c1f){const _0x409615=_0x4c5f53;_0x1b191f&&_0x1b191f(new UpgradeDB(_0x26ce19[_0x409615(0x2f0)],_0x4e2c1f[_0x409615(0x1f9)],_0x26ce19[_0x409615(0x2a5)]));}),_0x3ab8ae[_0x4c5f53(0x220)](function(_0x1b8be0){return new DB(_0x1b8be0);});}const name$1='@firebase/installations',version$1=a0_0x19637f(0x245),PENDING_TIMEOUT_MS=0x2710,PACKAGE_VERSION='w:'+version$1,INTERNAL_AUTH_VERSION=a0_0x19637f(0x26b),INSTALLATIONS_API_URL=a0_0x19637f(0x224),TOKEN_EXPIRATION_BUFFER=0x3c*0x3c*0x3e8,SERVICE$1=a0_0x19637f(0x246),SERVICE_NAME$1=a0_0x19637f(0x201),ERROR_DESCRIPTION_MAP$1={[a0_0x19637f(0x1fc)]:a0_0x19637f(0x263),[a0_0x19637f(0x226)]:'Firebase\x20Installation\x20is\x20not\x20registered.',[a0_0x19637f(0x2d4)]:'Firebase\x20Installation\x20not\x20found.',[a0_0x19637f(0x2e4)]:a0_0x19637f(0x2dc),[a0_0x19637f(0x29d)]:a0_0x19637f(0x21f),[a0_0x19637f(0x27e)]:a0_0x19637f(0x30c)},ERROR_FACTORY$1=new ErrorFactory(SERVICE$1,SERVICE_NAME$1,ERROR_DESCRIPTION_MAP$1);function isServerError(_0x36b149){const _0x1bfa9f=a0_0x19637f;return _0x36b149 instanceof FirebaseError&&_0x36b149[_0x1bfa9f(0x234)]['includes'](_0x1bfa9f(0x2e4));}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function getInstallationsEndpoint({projectId:_0x2de9b0}){const _0x4fcd11=a0_0x19637f;return INSTALLATIONS_API_URL+_0x4fcd11(0x1f5)+_0x2de9b0+_0x4fcd11(0x27a);}function extractAuthTokenInfoFromResponse(_0x5235b2){const _0x508826=a0_0x19637f;return{'token':_0x5235b2[_0x508826(0x248)],'requestStatus':0x2,'expiresIn':getExpiresInFromResponseExpiresIn(_0x5235b2[_0x508826(0x2d5)]),'creationTime':Date['now']()};}async function getErrorFromResponse(_0x534603,_0x438263){const _0x116e04=a0_0x19637f,_0x179e31=await _0x438263[_0x116e04(0x2bb)](),_0x4efeae=_0x179e31[_0x116e04(0x1e5)];return ERROR_FACTORY$1[_0x116e04(0x2bf)](_0x116e04(0x2e4),{'requestName':_0x534603,'serverCode':_0x4efeae[_0x116e04(0x234)],'serverMessage':_0x4efeae[_0x116e04(0x282)],'serverStatus':_0x4efeae[_0x116e04(0x1f6)]});}function getHeaders({apiKey:_0x119fb5}){const _0x531bda=a0_0x19637f;return new Headers({'Content-Type':_0x531bda(0x242),'Accept':_0x531bda(0x242),'x-goog-api-key':_0x119fb5});}function getHeadersWithAuth(_0x25b944,{refreshToken:_0x181b17}){const _0x57bb74=a0_0x19637f,_0x55fac9=getHeaders(_0x25b944);return _0x55fac9[_0x57bb74(0x321)](_0x57bb74(0x1fa),getAuthorizationHeader(_0x181b17)),_0x55fac9;}async function retryIfServerError(_0x1b2ab5){const _0x1537c8=a0_0x19637f,_0xfc1856=await _0x1b2ab5();if(_0xfc1856[_0x1537c8(0x1f6)]>=0x1f4&&_0xfc1856[_0x1537c8(0x1f6)]<0x258)return _0x1b2ab5();return _0xfc1856;}function getExpiresInFromResponseExpiresIn(_0x5cd961){const _0x237a36=a0_0x19637f;return Number(_0x5cd961[_0x237a36(0x2c5)]('s',_0x237a36(0x227)));}function getAuthorizationHeader(_0x427026){return INTERNAL_AUTH_VERSION+'\x20'+_0x427026;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function createInstallationRequest(_0x161abd,{fid:_0x1c1aeb}){const _0x1131da=a0_0x19637f,_0x3df929=getInstallationsEndpoint(_0x161abd),_0x1c791b=getHeaders(_0x161abd),_0x183f02={'fid':_0x1c1aeb,'authVersion':INTERNAL_AUTH_VERSION,'appId':_0x161abd['appId'],'sdkVersion':PACKAGE_VERSION},_0xcca2a8={'method':_0x1131da(0x22a),'headers':_0x1c791b,'body':JSON[_0x1131da(0x1e2)](_0x183f02)},_0x232eeb=await retryIfServerError(()=>fetch(_0x3df929,_0xcca2a8));if(_0x232eeb['ok']){const _0x3154f2=await _0x232eeb['json'](),_0x3cdfc4={'fid':_0x3154f2[_0x1131da(0x1de)]||_0x1c1aeb,'registrationStatus':0x2,'refreshToken':_0x3154f2[_0x1131da(0x237)],'authToken':extractAuthTokenInfoFromResponse(_0x3154f2[_0x1131da(0x26f)])};return _0x3cdfc4;}else throw await getErrorFromResponse(_0x1131da(0x1ef),_0x232eeb);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function sleep(_0x27b799){return new Promise(_0x16818e=>{setTimeout(_0x16818e,_0x27b799);});}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function bufferToBase64UrlSafe(_0x18d7f1){const _0x345f63=a0_0x19637f,_0x4cd1ea=btoa(String[_0x345f63(0x2e2)](..._0x18d7f1));return _0x4cd1ea[_0x345f63(0x2c5)](/\+/g,'-')['replace'](/\//g,'_');}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const VALID_FID_PATTERN=/^[cdef][\w-]{21}$/,INVALID_FID='';function generateFid(){const _0x1f84d7=a0_0x19637f;try{const _0x15cca0=new Uint8Array(0x11),_0x1bfd7b=self[_0x1f84d7(0x2c8)]||self['msCrypto'];_0x1bfd7b[_0x1f84d7(0x261)](_0x15cca0),_0x15cca0[0x0]=0x70+_0x15cca0[0x0]%0x10;const _0x4b1b7e=encode(_0x15cca0);return VALID_FID_PATTERN[_0x1f84d7(0x240)](_0x4b1b7e)?_0x4b1b7e:INVALID_FID;}catch(_0x4429d8){return INVALID_FID;}}function encode(_0xeb051a){const _0x383200=a0_0x19637f,_0x4addeb=bufferToBase64UrlSafe(_0xeb051a);return _0x4addeb[_0x383200(0x2ce)](0x0,0x16);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function getKey(_0x5bbfcd){const _0x533ffd=a0_0x19637f;return _0x5bbfcd[_0x533ffd(0x243)]+'!'+_0x5bbfcd['appId'];}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const fidChangeCallbacks=new Map();function fidChanged(_0x696f46,_0xae459){const _0x3a6aa9=getKey(_0x696f46);callFidChangeCallbacks(_0x3a6aa9,_0xae459),broadcastFidChange(_0x3a6aa9,_0xae459);}function callFidChangeCallbacks(_0x56adb9,_0x84f9b9){const _0x21c5c5=fidChangeCallbacks['get'](_0x56adb9);if(!_0x21c5c5)return;for(const _0x5c5021 of _0x21c5c5){_0x5c5021(_0x84f9b9);}}function broadcastFidChange(_0x46acc6,_0x10555b){const _0xb79017=a0_0x19637f,_0xdecb21=getBroadcastChannel();_0xdecb21&&_0xdecb21[_0xb79017(0x319)]({'key':_0x46acc6,'fid':_0x10555b}),closeBroadcastChannel();}let broadcastChannel=null;function getBroadcastChannel(){const _0x4cb83f=a0_0x19637f;return!broadcastChannel&&_0x4cb83f(0x205)in self&&(broadcastChannel=new BroadcastChannel(_0x4cb83f(0x238)),broadcastChannel[_0x4cb83f(0x215)]=_0x3dd8d4=>{const _0x193440=_0x4cb83f;callFidChangeCallbacks(_0x3dd8d4['data'][_0x193440(0x250)],_0x3dd8d4[_0x193440(0x2db)][_0x193440(0x1de)]);}),broadcastChannel;}function closeBroadcastChannel(){const _0x497ba5=a0_0x19637f;fidChangeCallbacks[_0x497ba5(0x31b)]===0x0&&broadcastChannel&&(broadcastChannel[_0x497ba5(0x336)](),broadcastChannel=null);}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const DATABASE_NAME=a0_0x19637f(0x29f),DATABASE_VERSION=0x1,OBJECT_STORE_NAME='firebase-installations-store';let dbPromise=null;function getDbPromise(){return!dbPromise&&(dbPromise=openDb(DATABASE_NAME,DATABASE_VERSION,_0x527c90=>{const _0x20d667=a0_0x5d5b;switch(_0x527c90[_0x20d667(0x1f9)]){case 0x0:_0x527c90['createObjectStore'](OBJECT_STORE_NAME);}})),dbPromise;}async function set(_0x1aac40,_0x407346){const _0x51f848=a0_0x19637f,_0x157485=getKey(_0x1aac40),_0x2a2ff3=await getDbPromise(),_0xacef39=_0x2a2ff3['transaction'](OBJECT_STORE_NAME,'readwrite'),_0x52971a=_0xacef39['objectStore'](OBJECT_STORE_NAME),_0x40a7cc=await _0x52971a[_0x51f848(0x20a)](_0x157485);return await _0x52971a['put'](_0x407346,_0x157485),await _0xacef39['complete'],(!_0x40a7cc||_0x40a7cc[_0x51f848(0x1de)]!==_0x407346[_0x51f848(0x1de)])&&fidChanged(_0x1aac40,_0x407346['fid']),_0x407346;}async function remove(_0x387853){const _0x399f58=a0_0x19637f,_0x1619e9=getKey(_0x387853),_0x4aefbf=await getDbPromise(),_0x4ed00b=_0x4aefbf[_0x399f58(0x2a5)](OBJECT_STORE_NAME,_0x399f58(0x218));await _0x4ed00b[_0x399f58(0x212)](OBJECT_STORE_NAME)['delete'](_0x1619e9),await _0x4ed00b[_0x399f58(0x249)];}async function update(_0x366ef8,_0x45f664){const _0xb69394=a0_0x19637f,_0x4b0ccf=getKey(_0x366ef8),_0x43c2f6=await getDbPromise(),_0x1182f5=_0x43c2f6[_0xb69394(0x2a5)](OBJECT_STORE_NAME,_0xb69394(0x218)),_0x49341c=_0x1182f5[_0xb69394(0x212)](OBJECT_STORE_NAME),_0x2fa777=await _0x49341c[_0xb69394(0x20a)](_0x4b0ccf),_0xa29e0d=_0x45f664(_0x2fa777);return _0xa29e0d===undefined?await _0x49341c[_0xb69394(0x23c)](_0x4b0ccf):await _0x49341c[_0xb69394(0x2d1)](_0xa29e0d,_0x4b0ccf),await _0x1182f5['complete'],_0xa29e0d&&(!_0x2fa777||_0x2fa777[_0xb69394(0x1de)]!==_0xa29e0d[_0xb69394(0x1de)])&&fidChanged(_0x366ef8,_0xa29e0d['fid']),_0xa29e0d;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function getInstallationEntry(_0x12a744){const _0xad09fa=a0_0x19637f;let _0x41010e;const _0x2201a2=await update(_0x12a744,_0x130e1f=>{const _0x7bd3a4=a0_0x5d5b,_0x4a82b3=updateOrCreateInstallationEntry(_0x130e1f),_0x5187aa=triggerRegistrationIfNecessary(_0x12a744,_0x4a82b3);return _0x41010e=_0x5187aa[_0x7bd3a4(0x223)],_0x5187aa[_0x7bd3a4(0x317)];});if(_0x2201a2[_0xad09fa(0x1de)]===INVALID_FID)return{'installationEntry':await _0x41010e};return{'installationEntry':_0x2201a2,'registrationPromise':_0x41010e};}function updateOrCreateInstallationEntry(_0x4aebf8){const _0x34b890=_0x4aebf8||{'fid':generateFid(),'registrationStatus':0x0};return clearTimedOutRequest(_0x34b890);}function triggerRegistrationIfNecessary(_0x46c5f1,_0xf29f11){const _0x4434b5=a0_0x19637f;if(_0xf29f11[_0x4434b5(0x2f3)]===0x0){if(!navigator[_0x4434b5(0x247)]){const _0x12ed97=Promise[_0x4434b5(0x2b4)](ERROR_FACTORY$1['create'](_0x4434b5(0x29d)));return{'installationEntry':_0xf29f11,'registrationPromise':_0x12ed97};}const _0x1b652f={'fid':_0xf29f11[_0x4434b5(0x1de)],'registrationStatus':0x1,'registrationTime':Date['now']()},_0x287770=registerInstallation(_0x46c5f1,_0x1b652f);return{'installationEntry':_0x1b652f,'registrationPromise':_0x287770};}else return _0xf29f11[_0x4434b5(0x2f3)]===0x1?{'installationEntry':_0xf29f11,'registrationPromise':waitUntilFidRegistration(_0x46c5f1)}:{'installationEntry':_0xf29f11};}async function registerInstallation(_0x1fabdc,_0x2a2f8e){const _0x5ca09f=a0_0x19637f;try{const _0x4a0b7c=await createInstallationRequest(_0x1fabdc,_0x2a2f8e);return set(_0x1fabdc,_0x4a0b7c);}catch(_0x22b59){isServerError(_0x22b59)&&_0x22b59[_0x5ca09f(0x21d)]['serverCode']===0x199?await remove(_0x1fabdc):await set(_0x1fabdc,{'fid':_0x2a2f8e[_0x5ca09f(0x1de)],'registrationStatus':0x0});throw _0x22b59;}}async function waitUntilFidRegistration(_0x5fdc9f){const _0xd8261=a0_0x19637f;let _0x613ec1=await updateInstallationRequest(_0x5fdc9f);while(_0x613ec1[_0xd8261(0x2f3)]===0x1){await sleep(0x64),_0x613ec1=await updateInstallationRequest(_0x5fdc9f);}if(_0x613ec1['registrationStatus']===0x0){const {installationEntry:_0x33302b,registrationPromise:_0x32225b}=await getInstallationEntry(_0x5fdc9f);return _0x32225b?_0x32225b:_0x33302b;}return _0x613ec1;}function updateInstallationRequest(_0x235303){return update(_0x235303,_0x31eef3=>{const _0x33ad06=a0_0x5d5b;if(!_0x31eef3)throw ERROR_FACTORY$1[_0x33ad06(0x2bf)](_0x33ad06(0x2d4));return clearTimedOutRequest(_0x31eef3);});}function clearTimedOutRequest(_0x350e8f){const _0x2b5744=a0_0x19637f;if(hasInstallationRequestTimedOut(_0x350e8f))return{'fid':_0x350e8f[_0x2b5744(0x1de)],'registrationStatus':0x0};return _0x350e8f;}function hasInstallationRequestTimedOut(_0x14afe9){const _0x37906f=a0_0x19637f;return _0x14afe9[_0x37906f(0x2f3)]===0x1&&_0x14afe9[_0x37906f(0x1f2)]+PENDING_TIMEOUT_MS<Date[_0x37906f(0x334)]();}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function generateAuthTokenRequest({appConfig:_0x2da983,platformLoggerProvider:_0x5b57c9},_0x563254){const _0x2eedbf=a0_0x19637f,_0x742bca=getGenerateAuthTokenEndpoint(_0x2da983,_0x563254),_0x455d4c=getHeadersWithAuth(_0x2da983,_0x563254),_0x57c5f0=_0x5b57c9['getImmediate']({'optional':!![]});_0x57c5f0&&_0x455d4c[_0x2eedbf(0x321)](_0x2eedbf(0x1ca),_0x57c5f0[_0x2eedbf(0x2ae)]());const _0x980d92={'installation':{'sdkVersion':PACKAGE_VERSION}},_0x54d760={'method':_0x2eedbf(0x22a),'headers':_0x455d4c,'body':JSON[_0x2eedbf(0x1e2)](_0x980d92)},_0x8f1a72=await retryIfServerError(()=>fetch(_0x742bca,_0x54d760));if(_0x8f1a72['ok']){const _0x3e690a=await _0x8f1a72[_0x2eedbf(0x2bb)](),_0x33e9e3=extractAuthTokenInfoFromResponse(_0x3e690a);return _0x33e9e3;}else throw await getErrorFromResponse(_0x2eedbf(0x291),_0x8f1a72);}function getGenerateAuthTokenEndpoint(_0x413ec2,{fid:_0x4f0d2d}){return getInstallationsEndpoint(_0x413ec2)+'/'+_0x4f0d2d+'/authTokens:generate';}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function refreshAuthToken(_0x7498e7,_0x34ee11=![]){const _0x200558=a0_0x19637f;let _0x5be70c;const _0x5b36e0=await update(_0x7498e7[_0x200558(0x31e)],_0x159bd3=>{const _0x4f56c3=_0x200558;if(!isEntryRegistered(_0x159bd3))throw ERROR_FACTORY$1[_0x4f56c3(0x2bf)](_0x4f56c3(0x226));const _0x1078cd=_0x159bd3['authToken'];if(!_0x34ee11&&isAuthTokenValid(_0x1078cd))return _0x159bd3;else{if(_0x1078cd[_0x4f56c3(0x324)]===0x1)return _0x5be70c=waitUntilAuthTokenRequest(_0x7498e7,_0x34ee11),_0x159bd3;else{if(!navigator['onLine'])throw ERROR_FACTORY$1[_0x4f56c3(0x2bf)]('app-offline');const _0x3bd864=makeAuthTokenRequestInProgressEntry(_0x159bd3);return _0x5be70c=fetchAuthTokenFromServer(_0x7498e7,_0x3bd864),_0x3bd864;}}}),_0x45f7b9=_0x5be70c?await _0x5be70c:_0x5b36e0[_0x200558(0x26f)];return _0x45f7b9;}async function waitUntilAuthTokenRequest(_0x4757f1,_0x13cf4f){const _0x1a0a9d=a0_0x19637f;let _0x19fd0e=await updateAuthTokenRequest(_0x4757f1[_0x1a0a9d(0x31e)]);while(_0x19fd0e['authToken'][_0x1a0a9d(0x324)]===0x1){await sleep(0x64),_0x19fd0e=await updateAuthTokenRequest(_0x4757f1['appConfig']);}const _0xff873c=_0x19fd0e[_0x1a0a9d(0x26f)];return _0xff873c[_0x1a0a9d(0x324)]===0x0?refreshAuthToken(_0x4757f1,_0x13cf4f):_0xff873c;}function updateAuthTokenRequest(_0x5029e8){return update(_0x5029e8,_0x1a6952=>{const _0x457536=a0_0x5d5b;if(!isEntryRegistered(_0x1a6952))throw ERROR_FACTORY$1[_0x457536(0x2bf)](_0x457536(0x226));const _0x1c6523=_0x1a6952['authToken'];if(hasAuthTokenRequestTimedOut(_0x1c6523))return Object[_0x457536(0x2f8)](Object['assign']({},_0x1a6952),{'authToken':{'requestStatus':0x0}});return _0x1a6952;});}async function fetchAuthTokenFromServer(_0x452f20,_0x2d9ad0){const _0x36f8e9=a0_0x19637f;try{const _0x14caf5=await generateAuthTokenRequest(_0x452f20,_0x2d9ad0),_0x29f8cd=Object[_0x36f8e9(0x2f8)](Object[_0x36f8e9(0x2f8)]({},_0x2d9ad0),{'authToken':_0x14caf5});return await set(_0x452f20['appConfig'],_0x29f8cd),_0x14caf5;}catch(_0x247e5a){if(isServerError(_0x247e5a)&&(_0x247e5a[_0x36f8e9(0x21d)][_0x36f8e9(0x2f1)]===0x191||_0x247e5a[_0x36f8e9(0x21d)]['serverCode']===0x194))await remove(_0x452f20['appConfig']);else{const _0x2c74c2=Object[_0x36f8e9(0x2f8)](Object[_0x36f8e9(0x2f8)]({},_0x2d9ad0),{'authToken':{'requestStatus':0x0}});await set(_0x452f20['appConfig'],_0x2c74c2);}throw _0x247e5a;}}function isEntryRegistered(_0x579f33){const _0x1e5a11=a0_0x19637f;return _0x579f33!==undefined&&_0x579f33[_0x1e5a11(0x2f3)]===0x2;}function isAuthTokenValid(_0x67bfac){const _0x274faf=a0_0x19637f;return _0x67bfac[_0x274faf(0x324)]===0x2&&!isAuthTokenExpired(_0x67bfac);}function isAuthTokenExpired(_0x44656e){const _0x410d48=a0_0x19637f,_0xe7ad2f=Date['now']();return _0xe7ad2f<_0x44656e[_0x410d48(0x1c8)]||_0x44656e[_0x410d48(0x1c8)]+_0x44656e[_0x410d48(0x2d5)]<_0xe7ad2f+TOKEN_EXPIRATION_BUFFER;}function makeAuthTokenRequestInProgressEntry(_0x2b0e3d){const _0x49195e=a0_0x19637f,_0x26f4d5={'requestStatus':0x1,'requestTime':Date['now']()};return Object[_0x49195e(0x2f8)](Object[_0x49195e(0x2f8)]({},_0x2b0e3d),{'authToken':_0x26f4d5});}function hasAuthTokenRequestTimedOut(_0x37d212){const _0x311d5f=a0_0x19637f;return _0x37d212[_0x311d5f(0x324)]===0x1&&_0x37d212[_0x311d5f(0x328)]+PENDING_TIMEOUT_MS<Date[_0x311d5f(0x334)]();}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function getId(_0x5e32d4){const _0x33e4cd=a0_0x19637f,_0x2419cc=_0x5e32d4,{installationEntry:_0x56d8cc,registrationPromise:_0x4b8613}=await getInstallationEntry(_0x2419cc[_0x33e4cd(0x31e)]);return _0x4b8613?_0x4b8613[_0x33e4cd(0x326)](console[_0x33e4cd(0x1e5)]):refreshAuthToken(_0x2419cc)[_0x33e4cd(0x326)](console[_0x33e4cd(0x1e5)]),_0x56d8cc[_0x33e4cd(0x1de)];}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
async function getToken(_0x54269d,_0x508ce3=![]){const _0x1d4119=a0_0x19637f,_0x14c774=_0x54269d;await completeInstallationRegistration(_0x14c774[_0x1d4119(0x31e)]);const _0x4f669c=await refreshAuthToken(_0x14c774,_0x508ce3);return _0x4f669c[_0x1d4119(0x248)];}async function completeInstallationRegistration(_0x583826){const {registrationPromise:_0x1c9503}=await getInstallationEntry(_0x583826);_0x1c9503&&await _0x1c9503;}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function extractAppConfig(_0x399084){const _0x143233=a0_0x19637f;if(!_0x399084||!_0x399084[_0x143233(0x1f4)])throw getMissingValueError(_0x143233(0x1ee));if(!_0x399084[_0x143233(0x1d5)])throw getMissingValueError(_0x143233(0x315));const _0x1cbaf0=[_0x143233(0x26d),_0x143233(0x231),_0x143233(0x2bc)];for(const _0x2ce1eb of _0x1cbaf0){if(!_0x399084[_0x143233(0x1f4)][_0x2ce1eb])throw getMissingValueError(_0x2ce1eb);}return{'appName':_0x399084[_0x143233(0x1d5)],'projectId':_0x399084[_0x143233(0x1f4)][_0x143233(0x26d)],'apiKey':_0x399084['options'][_0x143233(0x231)],'appId':_0x399084[_0x143233(0x1f4)][_0x143233(0x2bc)]};}function getMissingValueError(_0x58c819){const _0x58f97=a0_0x19637f;return ERROR_FACTORY$1[_0x58f97(0x2bf)](_0x58f97(0x1fc),{'valueName':_0x58c819});}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const INSTALLATIONS_NAME='installations',INSTALLATIONS_NAME_INTERNAL=a0_0x19637f(0x24f),publicFactory=_0x2aca2b=>{const _0x249ef9=a0_0x19637f,_0x2d82b7=_0x2aca2b[_0x249ef9(0x2e3)](_0x249ef9(0x20c))[_0x249ef9(0x2df)](),_0x29fedb=extractAppConfig(_0x2d82b7),_0x537b60=_getProvider(_0x2d82b7,'platform-logger'),_0xf91d05={'app':_0x2d82b7,'appConfig':_0x29fedb,'platformLoggerProvider':_0x537b60,'_delete':()=>Promise[_0x249ef9(0x1f3)]()};return _0xf91d05;},internalFactory=_0x273075=>{const _0x18195e=a0_0x19637f,_0x907ec2=_0x273075[_0x18195e(0x2e3)]('app')['getImmediate'](),_0x2a8a48=_getProvider(_0x907ec2,INSTALLATIONS_NAME)[_0x18195e(0x2df)](),_0x35f8d1={'getId':()=>getId(_0x2a8a48),'getToken':_0x47da95=>getToken(_0x2a8a48,_0x47da95)};return _0x35f8d1;};function registerInstallations(){const _0x3fec86=a0_0x19637f;_registerComponent(new Component(INSTALLATIONS_NAME,publicFactory,'PUBLIC')),_registerComponent(new Component(INSTALLATIONS_NAME_INTERNAL,internalFactory,_0x3fec86(0x276)));}registerInstallations(),registerVersion(name$1,version$1),registerVersion(name$1,version$1,'esm2017');const name=a0_0x19637f(0x2a3),version=a0_0x19637f(0x245),SDK_VERSION=version,TRACE_START_MARK_PREFIX=a0_0x19637f(0x25e),TRACE_STOP_MARK_PREFIX=a0_0x19637f(0x1fd),TRACE_MEASURE_PREFIX=a0_0x19637f(0x2c9),OOB_TRACE_PAGE_LOAD_PREFIX=a0_0x19637f(0x21c),FIRST_PAINT_COUNTER_NAME=a0_0x19637f(0x313),FIRST_CONTENTFUL_PAINT_COUNTER_NAME=a0_0x19637f(0x1ff),FIRST_INPUT_DELAY_COUNTER_NAME=a0_0x19637f(0x2f2),CONFIG_LOCAL_STORAGE_KEY=a0_0x19637f(0x230),CONFIG_EXPIRY_LOCAL_STORAGE_KEY=a0_0x19637f(0x1c9),SERVICE='performance',SERVICE_NAME=a0_0x19637f(0x241),ERROR_DESCRIPTION_MAP={[a0_0x19637f(0x26c)]:a0_0x19637f(0x294),[a0_0x19637f(0x2a7)]:a0_0x19637f(0x2d0),[a0_0x19637f(0x2a4)]:'Trace\x20{$traceName}\x20startTime\x20should\x20be\x20positive.',[a0_0x19637f(0x23f)]:a0_0x19637f(0x262),[a0_0x19637f(0x32d)]:a0_0x19637f(0x2b3),[a0_0x19637f(0x31d)]:'App\x20id\x20is\x20not\x20available.',[a0_0x19637f(0x2cd)]:'Project\x20id\x20is\x20not\x20available.',[a0_0x19637f(0x2b7)]:a0_0x19637f(0x2ec),[a0_0x19637f(0x1f8)]:'Attempted\x20to\x20queue\x20invalid\x20cc\x20event',['FB\x20not\x20default']:a0_0x19637f(0x283),[a0_0x19637f(0x30b)]:a0_0x19637f(0x2ee),[a0_0x19637f(0x2ab)]:a0_0x19637f(0x2bd),[a0_0x19637f(0x31c)]:'Attribute\x20value\x20{$attributeValue}\x20is\x20invalid.',[a0_0x19637f(0x2ac)]:a0_0x19637f(0x300),[a0_0x19637f(0x27b)]:a0_0x19637f(0x2d6),[a0_0x19637f(0x333)]:'initializePerformance()\x20has\x20already\x20been\x20called\x20with\x20'+a0_0x19637f(0x2a8)+a0_0x19637f(0x325)+a0_0x19637f(0x2d2)},ERROR_FACTORY=new ErrorFactory(SERVICE,SERVICE_NAME,ERROR_DESCRIPTION_MAP),consoleLogger=new Logger(SERVICE_NAME);consoleLogger[a0_0x19637f(0x296)]=LogLevel[a0_0x19637f(0x2cb)];/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let apiInstance,windowInstance;class Api{constructor(_0x2b6872){const _0x10c6a1=a0_0x19637f;this[_0x10c6a1(0x213)]=_0x2b6872;if(!_0x2b6872)throw ERROR_FACTORY[_0x10c6a1(0x2bf)](_0x10c6a1(0x32d));this['performance']=_0x2b6872[_0x10c6a1(0x1d2)],this[_0x10c6a1(0x269)]=_0x2b6872[_0x10c6a1(0x269)],this['windowLocation']=_0x2b6872[_0x10c6a1(0x1ce)],this[_0x10c6a1(0x2ff)]=_0x2b6872['navigator'],this[_0x10c6a1(0x1dd)]=_0x2b6872[_0x10c6a1(0x1dd)],this[_0x10c6a1(0x2ff)]&&this['navigator']['cookieEnabled']&&(this['localStorage']=_0x2b6872[_0x10c6a1(0x32c)]),_0x2b6872[_0x10c6a1(0x21b)]&&_0x2b6872[_0x10c6a1(0x21b)][_0x10c6a1(0x30f)]&&(this[_0x10c6a1(0x30f)]=_0x2b6872[_0x10c6a1(0x21b)][_0x10c6a1(0x30f)]);}[a0_0x19637f(0x272)](){const _0x1deb1f=a0_0x19637f;return this[_0x1deb1f(0x2ea)][_0x1deb1f(0x1e1)][_0x1deb1f(0x280)]('?')[0x0];}['mark'](_0x71224f){const _0x23a67d=a0_0x19637f;if(!this[_0x23a67d(0x1d2)]||!this[_0x23a67d(0x1d2)][_0x23a67d(0x2aa)])return;this[_0x23a67d(0x1d2)]['mark'](_0x71224f);}['measure'](_0x31e2f6,_0x27012c,_0x21e017){const _0x21b1b7=a0_0x19637f;if(!this[_0x21b1b7(0x1d2)]||!this[_0x21b1b7(0x1d2)]['measure'])return;this[_0x21b1b7(0x1d2)][_0x21b1b7(0x2c6)](_0x31e2f6,_0x27012c,_0x21e017);}[a0_0x19637f(0x308)](_0x5b3342){const _0x120825=a0_0x19637f;if(!this[_0x120825(0x1d2)]||!this[_0x120825(0x1d2)][_0x120825(0x308)])return[];return this[_0x120825(0x1d2)]['getEntriesByType'](_0x5b3342);}[a0_0x19637f(0x28b)](_0x3b4a26){const _0x262ed9=a0_0x19637f;if(!this[_0x262ed9(0x1d2)]||!this[_0x262ed9(0x1d2)][_0x262ed9(0x28b)])return[];return this[_0x262ed9(0x1d2)][_0x262ed9(0x28b)](_0x3b4a26);}[a0_0x19637f(0x289)](){const _0x4c4f78=a0_0x19637f;return this[_0x4c4f78(0x1d2)]&&(this[_0x4c4f78(0x1d2)][_0x4c4f78(0x302)]||this['performance'][_0x4c4f78(0x29e)][_0x4c4f78(0x225)]);}[a0_0x19637f(0x221)](){const _0x21eb5d=a0_0x19637f;if(!fetch||!Promise||!areCookiesEnabled())return consoleLogger[_0x21eb5d(0x27c)]('Firebase\x20Performance\x20cannot\x20start\x20if\x20browser\x20does\x20not\x20support\x20fetch\x20and\x20Promise\x20or\x20cookie\x20is\x20disabled.'),![];if(!isIndexedDBAvailable())return consoleLogger[_0x21eb5d(0x27c)](_0x21eb5d(0x256)),![];return!![];}[a0_0x19637f(0x277)](_0x20d9bf,_0x1a2649){const _0x3d72a5=a0_0x19637f;if(!this[_0x3d72a5(0x269)])return;const _0x1cf2c0=new this['PerformanceObserver'](_0x2139a5=>{for(const _0x4b0519 of _0x2139a5['getEntries']()){_0x1a2649(_0x4b0519);}});_0x1cf2c0[_0x3d72a5(0x28c)]({'entryTypes':[_0x20d9bf]});}static['getInstance'](){return apiInstance===undefined&&(apiInstance=new Api(windowInstance)),apiInstance;}}function setupApi(_0x12646e){windowInstance=_0x12646e;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let iid;function getIidPromise(_0x20c39b){const _0x58840c=a0_0x19637f,_0x2b508b=_0x20c39b['getId']();return _0x2b508b[_0x58840c(0x220)](_0x133f98=>{iid=_0x133f98;}),_0x2b508b;}function getIid(){return iid;}function getAuthTokenPromise(_0x46b240){const _0x411e8c=a0_0x19637f,_0x4c10a2=_0x46b240[_0x411e8c(0x2b1)]();return _0x4c10a2[_0x411e8c(0x220)](_0x117320=>{}),_0x4c10a2;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function mergeStrings(_0x5e9b21,_0x429f64){const _0xd63d8b=a0_0x19637f,_0x3a336f=_0x5e9b21[_0xd63d8b(0x275)]-_0x429f64[_0xd63d8b(0x275)];if(_0x3a336f<0x0||_0x3a336f>0x1)throw ERROR_FACTORY[_0xd63d8b(0x2bf)](_0xd63d8b(0x27b));const _0x4203d5=[];for(let _0xfcbe9c=0x0;_0xfcbe9c<_0x5e9b21[_0xd63d8b(0x275)];_0xfcbe9c++){_0x4203d5['push'](_0x5e9b21[_0xd63d8b(0x28a)](_0xfcbe9c)),_0x429f64['length']>_0xfcbe9c&&_0x4203d5[_0xd63d8b(0x229)](_0x429f64[_0xd63d8b(0x28a)](_0xfcbe9c));}return _0x4203d5[_0xd63d8b(0x312)]('');}/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let settingsServiceInstance;class SettingsService{constructor(){const _0x5de854=a0_0x19637f;this[_0x5de854(0x1eb)]=!![],this[_0x5de854(0x252)]=!![],this[_0x5de854(0x235)]=![],this['tracesSamplingRate']=0x1,this[_0x5de854(0x299)]=0x1,this[_0x5de854(0x20b)]=_0x5de854(0x217),this[_0x5de854(0x260)]=mergeStrings(_0x5de854(0x258),_0x5de854(0x320)),this[_0x5de854(0x29c)]=mergeStrings('AzSC8r6ReiGqFMyfvgow',_0x5de854(0x2af)),this[_0x5de854(0x2d3)]=0x1ce,this[_0x5de854(0x2d7)]=![],this[_0x5de854(0x2b0)]=![],this[_0x5de854(0x270)]=0xc;}[a0_0x19637f(0x209)](){const _0x673dd3=a0_0x19637f;return this['flTransportEndpointUrl'][_0x673dd3(0x24c)]('?key=',this[_0x673dd3(0x29c)]);}static[a0_0x19637f(0x318)](){return settingsServiceInstance===undefined&&(settingsServiceInstance=new SettingsService()),settingsServiceInstance;}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var VisibilityState;(function(_0x1df17d){const _0x1c4abc=a0_0x19637f;_0x1df17d[_0x1df17d['UNKNOWN']=0x0]=_0x1c4abc(0x311),_0x1df17d[_0x1df17d[_0x1c4abc(0x1d8)]=0x1]=_0x1c4abc(0x1d8),_0x1df17d[_0x1df17d[_0x1c4abc(0x2fa)]=0x2]='HIDDEN';}(VisibilityState||(VisibilityState={})));const RESERVED_ATTRIBUTE_PREFIXES=[a0_0x19637f(0x2ba),'google_','ga_'],ATTRIBUTE_FORMAT_REGEX=new RegExp(a0_0x19637f(0x23a)),MAX_ATTRIBUTE_NAME_LENGTH=0x28,MAX_ATTRIBUTE_VALUE_LENGTH=0x64;function getServiceWorkerStatus(){const _0x2702b5=a0_0x19637f,_0x49a99e=Api[_0x2702b5(0x318)]()[_0x2702b5(0x2ff)];return _0x2702b5(0x22b)in _0x49a99e?_0x49a99e[_0x2702b5(0x22b)]['controller']?0x2:0x3:0x1;}function getVisibilityState(){const _0x1d3ba4=a0_0x19637f,_0x4b8906=Api[_0x1d3ba4(0x318)]()[_0x1d3ba4(0x1dd)],_0x4c3260=_0x4b8906[_0x1d3ba4(0x2dd)];switch(_0x4c3260){case _0x1d3ba4(0x251):return VisibilityState['VISIBLE'];case _0x1d3ba4(0x2e9):return VisibilityState[_0x1d3ba4(0x2fa)];default:return VisibilityState['UNKNOWN'];}}function getEffectiveConnectionType(){const _0x30ada0=a0_0x19637f,_0x27df48=Api[_0x30ada0(0x318)]()['navigator'],_0x4dc455=_0x27df48['connection'],_0x2e3114=_0x4dc455&&_0x4dc455['effectiveType'];switch(_0x2e3114){case'slow-2g':return 0x1;case'2g':return 0x2;case'3g':return 0x3;case'4g':return 0x4;default:return 0x0;}}function isValidCustomAttributeName(_0x3c3678){const _0x268756=a0_0x19637f;if(_0x3c3678['length']===0x0||_0x3c3678[_0x268756(0x275)]>MAX_ATTRIBUTE_NAME_LENGTH)return![];const _0x569f51=RESERVED_ATTRIBUTE_PREFIXES[_0x268756(0x24b)](_0x2899fe=>_0x3c3678[_0x268756(0x1e6)](_0x2899fe));return!_0x569f51&&!!_0x3c3678[_0x268756(0x2fb)](ATTRIBUTE_FORMAT_REGEX);}function isValidCustomAttributeValue(_0x39ecad){const _0x21423d=a0_0x19637f;return _0x39ecad['length']!==0x0&&_0x39ecad[_0x21423d(0x275)]<=MAX_ATTRIBUTE_VALUE_LENGTH;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function getAppId(_0x23b5a7){const _0x49ae07=a0_0x19637f;var _0x1990d0;const _0x19eb9e=(_0x1990d0=_0x23b5a7[_0x49ae07(0x1f4)])===null||_0x1990d0===void 0x0?void 0x0:_0x1990d0[_0x49ae07(0x2bc)];if(!_0x19eb9e)throw ERROR_FACTORY[_0x49ae07(0x2bf)]('no\x20app\x20id');return _0x19eb9e;}function getProjectId(_0x50ebae){const _0x4d1363=a0_0x19637f;var _0x588cbc;const _0x28aeaf=(_0x588cbc=_0x50ebae[_0x4d1363(0x1f4)])===null||_0x588cbc===void 0x0?void 0x0:_0x588cbc[_0x4d1363(0x26d)];if(!_0x28aeaf)throw ERROR_FACTORY[_0x4d1363(0x2bf)](_0x4d1363(0x2cd));return _0x28aeaf;}function getApiKey(_0x4e1a2c){const _0x4ba645=a0_0x19637f;var _0x65d76e;const _0x5c0d0b=(_0x65d76e=_0x4e1a2c['options'])===null||_0x65d76e===void 0x0?void 0x0:_0x65d76e[_0x4ba645(0x231)];if(!_0x5c0d0b)throw ERROR_FACTORY['create'](_0x4ba645(0x2b7));return _0x5c0d0b;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const REMOTE_CONFIG_SDK_VERSION=a0_0x19637f(0x24d),DEFAULT_CONFIGS={'loggingEnabled':!![]},FIS_AUTH_PREFIX=a0_0x19637f(0x2f4);function getConfig(_0x41a299,_0x51703e){const _0x5a7e09=a0_0x19637f,_0x2fd28f=getStoredConfig();if(_0x2fd28f)return processConfig(_0x2fd28f),Promise[_0x5a7e09(0x1f3)]();return getRemoteConfig(_0x41a299,_0x51703e)[_0x5a7e09(0x220)](processConfig)[_0x5a7e09(0x220)](_0x1be04a=>storeConfig(_0x1be04a),()=>{});}function getStoredConfig(){const _0x12ad2f=a0_0x19637f,_0x46739f=Api[_0x12ad2f(0x318)]()[_0x12ad2f(0x32c)];if(!_0x46739f)return;const _0x5b639c=_0x46739f['getItem'](CONFIG_EXPIRY_LOCAL_STORAGE_KEY);if(!_0x5b639c||!configValid(_0x5b639c))return;const _0x30b19c=_0x46739f[_0x12ad2f(0x214)](CONFIG_LOCAL_STORAGE_KEY);if(!_0x30b19c)return;try{const _0x11734d=JSON['parse'](_0x30b19c);return _0x11734d;}catch(_0x295edd){return;}}function storeConfig(_0x1bfbc8){const _0x5b7c06=a0_0x19637f,_0x463175=Api[_0x5b7c06(0x318)]()[_0x5b7c06(0x32c)];if(!_0x1bfbc8||!_0x463175)return;_0x463175[_0x5b7c06(0x1cb)](CONFIG_LOCAL_STORAGE_KEY,JSON[_0x5b7c06(0x1e2)](_0x1bfbc8)),_0x463175[_0x5b7c06(0x1cb)](CONFIG_EXPIRY_LOCAL_STORAGE_KEY,String(Date[_0x5b7c06(0x334)]()+SettingsService['getInstance']()[_0x5b7c06(0x270)]*0x3c*0x3c*0x3e8));}const COULD_NOT_GET_CONFIG_MSG='Could\x20not\x20fetch\x20config,\x20will\x20use\x20default\x20configs';function getRemoteConfig(_0x360f4d,_0x520a9e){const _0x346f84=a0_0x19637f;return getAuthTokenPromise(_0x360f4d[_0x346f84(0x246)])[_0x346f84(0x220)](_0x1a29f7=>{const _0x31083a=_0x346f84,_0x34475b=getProjectId(_0x360f4d['app']),_0x48a0ce=getApiKey(_0x360f4d[_0x31083a(0x20c)]),_0x100cfc=_0x31083a(0x2eb)+_0x34475b+_0x31083a(0x2cc)+_0x48a0ce,_0x42fcb2=new Request(_0x100cfc,{'method':_0x31083a(0x22a),'headers':{'Authorization':FIS_AUTH_PREFIX+'\x20'+_0x1a29f7},'body':JSON['stringify']({'app_instance_id':_0x520a9e,'app_instance_id_token':_0x1a29f7,'app_id':getAppId(_0x360f4d[_0x31083a(0x20c)]),'app_version':SDK_VERSION,'sdk_version':REMOTE_CONFIG_SDK_VERSION})});return fetch(_0x42fcb2)['then'](_0x3c2434=>{const _0xcbd666=_0x31083a;if(_0x3c2434['ok'])return _0x3c2434[_0xcbd666(0x2bb)]();throw ERROR_FACTORY['create'](_0xcbd666(0x30b));});})['catch'](()=>{const _0x5ac7f6=_0x346f84;return consoleLogger[_0x5ac7f6(0x27c)](COULD_NOT_GET_CONFIG_MSG),undefined;});}function processConfig(_0xb8bef5){const _0x131882=a0_0x19637f;if(!_0xb8bef5)return _0xb8bef5;const _0x27eee6=SettingsService[_0x131882(0x318)](),_0x475e80=_0xb8bef5[_0x131882(0x266)]||{};return _0x475e80[_0x131882(0x1c6)]!==undefined?_0x27eee6['loggingEnabled']=String(_0x475e80[_0x131882(0x1c6)])==='true':_0x27eee6[_0x131882(0x235)]=DEFAULT_CONFIGS[_0x131882(0x235)],_0x475e80['fpr_log_source']&&(_0x27eee6[_0x131882(0x2d3)]=Number(_0x475e80['fpr_log_source'])),_0x475e80[_0x131882(0x236)]&&(_0x27eee6['logEndPointUrl']=_0x475e80[_0x131882(0x236)]),_0x475e80[_0x131882(0x286)]&&(_0x27eee6[_0x131882(0x29c)]=_0x475e80[_0x131882(0x286)]),_0x475e80[_0x131882(0x30e)]!==undefined&&(_0x27eee6[_0x131882(0x299)]=Number(_0x475e80[_0x131882(0x30e)])),_0x475e80[_0x131882(0x264)]!==undefined&&(_0x27eee6[_0x131882(0x1e3)]=Number(_0x475e80['fpr_vc_trace_sampling_rate'])),_0x27eee6['logTraceAfterSampling']=shouldLogAfterSampling(_0x27eee6[_0x131882(0x1e3)]),_0x27eee6[_0x131882(0x2b0)]=shouldLogAfterSampling(_0x27eee6[_0x131882(0x299)]),_0xb8bef5;}function configValid(_0x272078){const _0x508d98=a0_0x19637f;return Number(_0x272078)>Date[_0x508d98(0x334)]();}function shouldLogAfterSampling(_0x481019){const _0x4c082d=a0_0x19637f;return Math[_0x4c082d(0x204)]()<=_0x481019;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let initializationStatus=0x1,initializationPromise;function getInitializationPromise(_0x3eb046){return initializationStatus=0x2,initializationPromise=initializationPromise||initializePerf(_0x3eb046),initializationPromise;}function isPerfInitialized(){return initializationStatus===0x3;}function initializePerf(_0x3b7817){const _0x26bd3d=a0_0x19637f;return getDocumentReadyComplete()[_0x26bd3d(0x220)](()=>getIidPromise(_0x3b7817[_0x26bd3d(0x246)]))['then'](_0x1bb6ff=>getConfig(_0x3b7817,_0x1bb6ff))[_0x26bd3d(0x220)](()=>changeInitializationStatus(),()=>changeInitializationStatus());}function getDocumentReadyComplete(){const _0x5642de=a0_0x19637f,_0x289150=Api[_0x5642de(0x318)]()['document'];return new Promise(_0x2c2b38=>{const _0x3046a4=_0x5642de;if(_0x289150&&_0x289150[_0x3046a4(0x1fb)]!=='complete'){const _0x1f9b24=()=>{const _0x8f4dbe=_0x3046a4;_0x289150['readyState']==='complete'&&(_0x289150['removeEventListener'](_0x8f4dbe(0x2a1),_0x1f9b24),_0x2c2b38());};_0x289150[_0x3046a4(0x1d0)](_0x3046a4(0x2a1),_0x1f9b24);}else _0x2c2b38();});}function changeInitializationStatus(){initializationStatus=0x3;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const DEFAULT_SEND_INTERVAL_MS=0xa*0x3e8,INITIAL_SEND_TIME_DELAY_MS=5.5*0x3e8,DEFAULT_REMAINING_TRIES=0x3,MAX_EVENT_COUNT_PER_REQUEST=0x3e8;let remainingTries=DEFAULT_REMAINING_TRIES,queue=[],isTransportSetup=![];function setupTransportService(){!isTransportSetup&&(processQueue(INITIAL_SEND_TIME_DELAY_MS),isTransportSetup=!![]);}function processQueue(_0x512669){setTimeout(()=>{const _0x334262=a0_0x5d5b;if(remainingTries===0x0)return;if(!queue[_0x334262(0x275)])return processQueue(DEFAULT_SEND_INTERVAL_MS);dispatchQueueEvents();},_0x512669);}function dispatchQueueEvents(){const _0x305d2c=a0_0x19637f,_0x32a97b=queue['splice'](0x0,MAX_EVENT_COUNT_PER_REQUEST),_0x3c2519=_0x32a97b[_0x305d2c(0x32e)](_0xd087c3=>({'source_extension_json_proto3':_0xd087c3[_0x305d2c(0x282)],'event_time_ms':String(_0xd087c3[_0x305d2c(0x1ed)])})),_0x551326={'request_time_ms':String(Date[_0x305d2c(0x334)]()),'client_info':{'client_type':0x1,'js_client_info':{}},'log_source':SettingsService[_0x305d2c(0x318)]()['logSource'],'log_event':_0x3c2519};sendEventsToFl(_0x551326,_0x32a97b)[_0x305d2c(0x326)](()=>{const _0x459f91=_0x305d2c;queue=[..._0x32a97b,...queue],remainingTries--,consoleLogger[_0x459f91(0x27c)](_0x459f91(0x24a)+remainingTries+'.'),processQueue(DEFAULT_SEND_INTERVAL_MS);});}function sendEventsToFl(_0x274ccf,_0x2a75ea){const _0x416550=a0_0x19637f;return postToFlEndpoint(_0x274ccf)[_0x416550(0x220)](_0x2c07df=>{const _0x5a9e2b=_0x416550;return!_0x2c07df['ok']&&consoleLogger[_0x5a9e2b(0x27c)](_0x5a9e2b(0x239)),_0x2c07df[_0x5a9e2b(0x2bb)]();})[_0x416550(0x220)](_0x4bb4c0=>{const _0x169356=_0x416550,_0x42d48c=Number(_0x4bb4c0[_0x169356(0x267)]);let _0x285816=DEFAULT_SEND_INTERVAL_MS;!isNaN(_0x42d48c)&&(_0x285816=Math[_0x169356(0x1d3)](_0x42d48c,_0x285816));const _0x1409b0=_0x4bb4c0[_0x169356(0x310)];Array['isArray'](_0x1409b0)&&_0x1409b0[_0x169356(0x275)]>0x0&&_0x1409b0[0x0][_0x169356(0x27f)]===_0x169356(0x25f)&&(queue=[..._0x2a75ea,...queue],consoleLogger[_0x169356(0x27c)]('Retry\x20transport\x20request\x20later.')),remainingTries=DEFAULT_REMAINING_TRIES,processQueue(_0x285816);});}function postToFlEndpoint(_0x30c4d3){const _0x2109a6=a0_0x19637f,_0x1c5411=SettingsService[_0x2109a6(0x318)]()[_0x2109a6(0x209)]();return fetch(_0x1c5411,{'method':_0x2109a6(0x22a),'body':JSON[_0x2109a6(0x1e2)](_0x30c4d3)});}function addToQueue(_0x4e4b5){const _0x34a582=a0_0x19637f;if(!_0x4e4b5['eventTime']||!_0x4e4b5['message'])throw ERROR_FACTORY['create'](_0x34a582(0x1f8));queue=[...queue,_0x4e4b5];}function transportHandler(_0x2528c5){return(..._0x56550b)=>{const _0x3c56bd=_0x2528c5(..._0x56550b);addToQueue({'message':_0x3c56bd,'eventTime':Date['now']()});};}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
let logger;function sendLog(_0x3c6bd3,_0x369abd){!logger&&(logger=transportHandler(serializer)),logger(_0x3c6bd3,_0x369abd);}function logTrace(_0x45afa1){const _0x2d4578=a0_0x19637f,_0xf9cf6=SettingsService['getInstance']();if(!_0xf9cf6[_0x2d4578(0x1eb)]&&_0x45afa1[_0x2d4578(0x2e5)])return;if(!_0xf9cf6[_0x2d4578(0x252)]&&!_0x45afa1[_0x2d4578(0x2e5)])return;if(!Api['getInstance']()['requiredApisAvailable']())return;if(_0x45afa1[_0x2d4578(0x2e5)]&&getVisibilityState()!==VisibilityState[_0x2d4578(0x1d8)])return;isPerfInitialized()?sendTraceLog(_0x45afa1):getInitializationPromise(_0x45afa1['performanceController'])[_0x2d4578(0x220)](()=>sendTraceLog(_0x45afa1),()=>sendTraceLog(_0x45afa1));}function sendTraceLog(_0x2d07b7){const _0x111420=a0_0x19637f;if(!getIid())return;const _0x384d34=SettingsService[_0x111420(0x318)]();if(!_0x384d34[_0x111420(0x235)]||!_0x384d34[_0x111420(0x2d7)])return;setTimeout(()=>sendLog(_0x2d07b7,0x1),0x0);}function logNetworkRequest(_0x3961c1){const _0x352b14=a0_0x19637f,_0x454fca=SettingsService[_0x352b14(0x318)]();if(!_0x454fca[_0x352b14(0x1eb)])return;const _0x4f6a6f=_0x3961c1['url'],_0x3557bb=_0x454fca[_0x352b14(0x20b)][_0x352b14(0x280)]('?')[0x0],_0xb0cd88=_0x454fca[_0x352b14(0x260)]['split']('?')[0x0];if(_0x4f6a6f===_0x3557bb||_0x4f6a6f===_0xb0cd88)return;if(!_0x454fca['loggingEnabled']||!_0x454fca['logNetworkAfterSampling'])return;setTimeout(()=>sendLog(_0x3961c1,0x0),0x0);}function serializer(_0x57a033,_0x4e4ced){if(_0x4e4ced===0x0)return serializeNetworkRequest(_0x57a033);return serializeTrace(_0x57a033);}function serializeNetworkRequest(_0x270803){const _0x2d1f51=a0_0x19637f,_0x2d5a0d={'url':_0x270803[_0x2d1f51(0x1ea)],'http_method':_0x270803[_0x2d1f51(0x2f6)]||0x0,'http_response_code':0xc8,'response_payload_bytes':_0x270803[_0x2d1f51(0x20d)],'client_start_time_us':_0x270803[_0x2d1f51(0x2fd)],'time_to_response_initiated_us':_0x270803['timeToResponseInitiatedUs'],'time_to_response_completed_us':_0x270803[_0x2d1f51(0x309)]},_0x2ce474={'application_info':getApplicationInfo(_0x270803[_0x2d1f51(0x2d9)]['app']),'network_request_metric':_0x2d5a0d};return JSON[_0x2d1f51(0x1e2)](_0x2ce474);}function serializeTrace(_0x2ae32d){const _0x207e14=a0_0x19637f,_0x43106d={'name':_0x2ae32d[_0x207e14(0x1d5)],'is_auto':_0x2ae32d[_0x207e14(0x2e5)],'client_start_time_us':_0x2ae32d[_0x207e14(0x2fd)],'duration_us':_0x2ae32d['durationUs']};Object[_0x207e14(0x1f0)](_0x2ae32d[_0x207e14(0x314)])[_0x207e14(0x275)]!==0x0&&(_0x43106d['counters']=_0x2ae32d['counters']);const _0x24834a=_0x2ae32d[_0x207e14(0x26a)]();Object[_0x207e14(0x1f0)](_0x24834a)[_0x207e14(0x275)]!==0x0&&(_0x43106d['custom_attributes']=_0x24834a);const _0x14e4d3={'application_info':getApplicationInfo(_0x2ae32d[_0x207e14(0x2d9)]['app']),'trace_metric':_0x43106d};return JSON[_0x207e14(0x1e2)](_0x14e4d3);}function getApplicationInfo(_0x5111aa){const _0x1d4a8b=a0_0x19637f;return{'google_app_id':getAppId(_0x5111aa),'app_instance_id':getIid(),'web_app_info':{'sdk_version':SDK_VERSION,'page_url':Api[_0x1d4a8b(0x318)]()[_0x1d4a8b(0x272)](),'service_worker_status':getServiceWorkerStatus(),'visibility_state':getVisibilityState(),'effective_connection_type':getEffectiveConnectionType()},'application_process_state':0x0};}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const MAX_METRIC_NAME_LENGTH=0x64,RESERVED_AUTO_PREFIX='_',oobMetrics=[FIRST_PAINT_COUNTER_NAME,FIRST_CONTENTFUL_PAINT_COUNTER_NAME,FIRST_INPUT_DELAY_COUNTER_NAME];function isValidMetricName(_0x38b8b0,_0x1d1c94){const _0x2334ec=a0_0x19637f;if(_0x38b8b0[_0x2334ec(0x275)]===0x0||_0x38b8b0[_0x2334ec(0x275)]>MAX_METRIC_NAME_LENGTH)return![];return _0x1d1c94&&_0x1d1c94[_0x2334ec(0x1e6)](OOB_TRACE_PAGE_LOAD_PREFIX)&&oobMetrics[_0x2334ec(0x233)](_0x38b8b0)>-0x1||!_0x38b8b0['startsWith'](RESERVED_AUTO_PREFIX);}function convertMetricValueToInteger(_0x5b978d){const _0xd901f8=a0_0x19637f,_0xf1e7f4=Math['floor'](_0x5b978d);return _0xf1e7f4<_0x5b978d&&consoleLogger['info'](_0xd901f8(0x31f)+_0xf1e7f4+'.'),_0xf1e7f4;}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class Trace{constructor(_0x2e3835,_0x2783ef,_0x37eef3=![],_0x1be2ad){const _0xab28a4=a0_0x19637f;this[_0xab28a4(0x2d9)]=_0x2e3835,this[_0xab28a4(0x1d5)]=_0x2783ef,this[_0xab28a4(0x2e5)]=_0x37eef3,this[_0xab28a4(0x2f7)]=0x1,this[_0xab28a4(0x2be)]={},this['counters']={},this['api']=Api[_0xab28a4(0x318)](),this[_0xab28a4(0x228)]=Math['floor'](Math[_0xab28a4(0x204)]()*0xf4240),!this[_0xab28a4(0x2e5)]&&(this[_0xab28a4(0x1c7)]=TRACE_START_MARK_PREFIX+'-'+this[_0xab28a4(0x228)]+'-'+this[_0xab28a4(0x1d5)],this[_0xab28a4(0x293)]=TRACE_STOP_MARK_PREFIX+'-'+this['randomId']+'-'+this[_0xab28a4(0x1d5)],this[_0xab28a4(0x259)]=_0x1be2ad||TRACE_MEASURE_PREFIX+'-'+this[_0xab28a4(0x228)]+'-'+this[_0xab28a4(0x1d5)],_0x1be2ad&&this[_0xab28a4(0x1fe)]());}[a0_0x19637f(0x27d)](){const _0x22343c=a0_0x19637f;if(this[_0x22343c(0x2f7)]!==0x1)throw ERROR_FACTORY[_0x22343c(0x2bf)]('trace\x20started',{'traceName':this[_0x22343c(0x1d5)]});this[_0x22343c(0x2de)][_0x22343c(0x2aa)](this[_0x22343c(0x1c7)]),this[_0x22343c(0x2f7)]=0x2;}['stop'](){const _0x2d8ad3=a0_0x19637f;if(this[_0x2d8ad3(0x2f7)]!==0x2)throw ERROR_FACTORY['create'](_0x2d8ad3(0x2a7),{'traceName':this['name']});this[_0x2d8ad3(0x2f7)]=0x3,this[_0x2d8ad3(0x2de)][_0x2d8ad3(0x2aa)](this['traceStopMark']),this[_0x2d8ad3(0x2de)]['measure'](this['traceMeasure'],this[_0x2d8ad3(0x1c7)],this['traceStopMark']),this['calculateTraceMetrics'](),logTrace(this);}['record'](_0x3d7d5d,_0x3a0e2f,_0x43d7f9){const _0x3893ec=a0_0x19637f;if(_0x3d7d5d<=0x0)throw ERROR_FACTORY['create']('nonpositive\x20trace\x20startTime',{'traceName':this['name']});if(_0x3a0e2f<=0x0)throw ERROR_FACTORY[_0x3893ec(0x2bf)](_0x3893ec(0x23f),{'traceName':this[_0x3893ec(0x1d5)]});this[_0x3893ec(0x2b9)]=Math[_0x3893ec(0x22c)](_0x3a0e2f*0x3e8),this[_0x3893ec(0x2fd)]=Math[_0x3893ec(0x22c)](_0x3d7d5d*0x3e8);_0x43d7f9&&_0x43d7f9[_0x3893ec(0x30a)]&&(this['customAttributes']=Object[_0x3893ec(0x2f8)]({},_0x43d7f9[_0x3893ec(0x30a)]));if(_0x43d7f9&&_0x43d7f9['metrics'])for(const _0x366463 of Object[_0x3893ec(0x1f0)](_0x43d7f9[_0x3893ec(0x2da)])){!isNaN(Number(_0x43d7f9[_0x3893ec(0x2da)][_0x366463]))&&(this[_0x3893ec(0x314)][_0x366463]=Math[_0x3893ec(0x22c)](Number(_0x43d7f9['metrics'][_0x366463])));}logTrace(this);}[a0_0x19637f(0x304)](_0x4764bb,_0x4c36d9=0x1){const _0x577a05=a0_0x19637f;this['counters'][_0x4764bb]===undefined?this[_0x577a05(0x232)](_0x4764bb,_0x4c36d9):this[_0x577a05(0x232)](_0x4764bb,this['counters'][_0x4764bb]+_0x4c36d9);}[a0_0x19637f(0x232)](_0x3cf84b,_0x4cc6ee){const _0x234491=a0_0x19637f;if(isValidMetricName(_0x3cf84b,this['name']))this[_0x234491(0x314)][_0x3cf84b]=convertMetricValueToInteger(_0x4cc6ee!==null&&_0x4cc6ee!==void 0x0?_0x4cc6ee:0x0);else throw ERROR_FACTORY[_0x234491(0x2bf)]('invalid\x20custom\x20metric\x20name',{'customMetricName':_0x3cf84b});}[a0_0x19637f(0x290)](_0x39330d){return this['counters'][_0x39330d]||0x0;}[a0_0x19637f(0x25a)](_0x199999,_0x5c8bcc){const _0x1f5115=a0_0x19637f,_0x15c109=isValidCustomAttributeName(_0x199999),_0x1321cf=isValidCustomAttributeValue(_0x5c8bcc);if(_0x15c109&&_0x1321cf){this[_0x1f5115(0x2be)][_0x199999]=_0x5c8bcc;return;}if(!_0x15c109)throw ERROR_FACTORY[_0x1f5115(0x2bf)](_0x1f5115(0x2ab),{'attributeName':_0x199999});if(!_0x1321cf)throw ERROR_FACTORY['create'](_0x1f5115(0x31c),{'attributeValue':_0x5c8bcc});}[a0_0x19637f(0x1ec)](_0x1953b3){const _0x5b1e46=a0_0x19637f;return this[_0x5b1e46(0x2be)][_0x1953b3];}['removeAttribute'](_0x128044){const _0x1a2187=a0_0x19637f;if(this[_0x1a2187(0x2be)][_0x128044]===undefined)return;delete this['customAttributes'][_0x128044];}['getAttributes'](){const _0x46b842=a0_0x19637f;return Object[_0x46b842(0x2f8)]({},this[_0x46b842(0x2be)]);}[a0_0x19637f(0x30d)](_0x217de0){const _0x2250a8=a0_0x19637f;this[_0x2250a8(0x2fd)]=_0x217de0;}[a0_0x19637f(0x21a)](_0x1af0a1){const _0x1e62ca=a0_0x19637f;this[_0x1e62ca(0x2b9)]=_0x1af0a1;}[a0_0x19637f(0x1fe)](){const _0x503883=a0_0x19637f,_0x2537b2=this[_0x503883(0x2de)][_0x503883(0x28b)](this['traceMeasure']),_0x250491=_0x2537b2&&_0x2537b2[0x0];_0x250491&&(this[_0x503883(0x2b9)]=Math[_0x503883(0x22c)](_0x250491['duration']*0x3e8),this[_0x503883(0x2fd)]=Math[_0x503883(0x22c)]((_0x250491[_0x503883(0x202)]+this[_0x503883(0x2de)]['getTimeOrigin']())*0x3e8));}static[a0_0x19637f(0x2c2)](_0x4ed24f,_0x7b52fd,_0x509ea4,_0x280920){const _0x2e57e9=a0_0x19637f,_0x4787fc=Api['getInstance']()[_0x2e57e9(0x272)]();if(!_0x4787fc)return;const _0x69ae5d=new Trace(_0x4ed24f,OOB_TRACE_PAGE_LOAD_PREFIX+_0x4787fc,!![]),_0x37ebcf=Math[_0x2e57e9(0x22c)](Api[_0x2e57e9(0x318)]()[_0x2e57e9(0x289)]()*0x3e8);_0x69ae5d[_0x2e57e9(0x30d)](_0x37ebcf);_0x7b52fd&&_0x7b52fd[0x0]&&(_0x69ae5d['setDuration'](Math[_0x2e57e9(0x22c)](_0x7b52fd[0x0][_0x2e57e9(0x2c7)]*0x3e8)),_0x69ae5d[_0x2e57e9(0x232)]('domInteractive',Math[_0x2e57e9(0x22c)](_0x7b52fd[0x0][_0x2e57e9(0x1d1)]*0x3e8)),_0x69ae5d[_0x2e57e9(0x232)](_0x2e57e9(0x31a),Math[_0x2e57e9(0x22c)](_0x7b52fd[0x0][_0x2e57e9(0x31a)]*0x3e8)),_0x69ae5d[_0x2e57e9(0x232)](_0x2e57e9(0x255),Math['floor'](_0x7b52fd[0x0][_0x2e57e9(0x255)]*0x3e8)));const _0x38fabc=_0x2e57e9(0x207),_0x3e12a5='first-contentful-paint';if(_0x509ea4){const _0x1ab492=_0x509ea4[_0x2e57e9(0x287)](_0x2c7c9a=>_0x2c7c9a[_0x2e57e9(0x1d5)]===_0x38fabc);_0x1ab492&&_0x1ab492[_0x2e57e9(0x202)]&&_0x69ae5d[_0x2e57e9(0x232)](FIRST_PAINT_COUNTER_NAME,Math['floor'](_0x1ab492[_0x2e57e9(0x202)]*0x3e8));const _0x445641=_0x509ea4['find'](_0x6310cb=>_0x6310cb[_0x2e57e9(0x1d5)]===_0x3e12a5);_0x445641&&_0x445641[_0x2e57e9(0x202)]&&_0x69ae5d[_0x2e57e9(0x232)](FIRST_CONTENTFUL_PAINT_COUNTER_NAME,Math[_0x2e57e9(0x22c)](_0x445641[_0x2e57e9(0x202)]*0x3e8)),_0x280920&&_0x69ae5d[_0x2e57e9(0x232)](FIRST_INPUT_DELAY_COUNTER_NAME,Math[_0x2e57e9(0x22c)](_0x280920*0x3e8));}logTrace(_0x69ae5d);}static[a0_0x19637f(0x32b)](_0x4f56c7,_0x23d80c){const _0x4cfbfb=new Trace(_0x4f56c7,_0x23d80c,![],_0x23d80c);logTrace(_0x4cfbfb);}}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function createNetworkRequestEntry(_0x3816eb,_0x390989){const _0x546a2f=a0_0x19637f,_0x39b8eb=_0x390989;if(!_0x39b8eb||_0x39b8eb['responseStart']===undefined)return;const _0x85e663=Api[_0x546a2f(0x318)]()[_0x546a2f(0x289)](),_0x4ea107=Math['floor']((_0x39b8eb['startTime']+_0x85e663)*0x3e8),_0x408274=_0x39b8eb[_0x546a2f(0x2b2)]?Math[_0x546a2f(0x22c)]((_0x39b8eb[_0x546a2f(0x2b2)]-_0x39b8eb[_0x546a2f(0x202)])*0x3e8):undefined,_0x5e280c=Math[_0x546a2f(0x22c)]((_0x39b8eb[_0x546a2f(0x1d6)]-_0x39b8eb['startTime'])*0x3e8),_0x438ec5=_0x39b8eb[_0x546a2f(0x1d5)]&&_0x39b8eb[_0x546a2f(0x1d5)][_0x546a2f(0x280)]('?')[0x0],_0x305172={'performanceController':_0x3816eb,'url':_0x438ec5,'responsePayloadBytes':_0x39b8eb['transferSize'],'startTimeUs':_0x4ea107,'timeToResponseInitiatedUs':_0x408274,'timeToResponseCompletedUs':_0x5e280c};logNetworkRequest(_0x305172);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const FID_WAIT_TIME_MS=0x1388;function setupOobResources(_0x12de12){if(!getIid())return;setTimeout(()=>setupOobTraces(_0x12de12),0x0),setTimeout(()=>setupNetworkRequests(_0x12de12),0x0),setTimeout(()=>setupUserTimingTraces(_0x12de12),0x0);}function setupNetworkRequests(_0x38510a){const _0xd9e6f0=a0_0x19637f,_0x53e912=Api[_0xd9e6f0(0x318)](),_0x1632ca=_0x53e912['getEntriesByType'](_0xd9e6f0(0x206));for(const _0x1336e6 of _0x1632ca){createNetworkRequestEntry(_0x38510a,_0x1336e6);}_0x53e912[_0xd9e6f0(0x277)](_0xd9e6f0(0x206),_0x4c30eb=>createNetworkRequestEntry(_0x38510a,_0x4c30eb));}function setupOobTraces(_0x6a73bc){const _0x299224=a0_0x19637f,_0x200ad0=Api[_0x299224(0x318)](),_0x541879=_0x200ad0['getEntriesByType'](_0x299224(0x265)),_0x2eaf46=_0x200ad0['getEntriesByType'](_0x299224(0x21e));if(_0x200ad0[_0x299224(0x30f)]){let _0x139120=setTimeout(()=>{Trace['createOobTrace'](_0x6a73bc,_0x541879,_0x2eaf46),_0x139120=undefined;},FID_WAIT_TIME_MS);_0x200ad0[_0x299224(0x30f)](_0x5239f9=>{const _0x4a8b85=_0x299224;_0x139120&&(clearTimeout(_0x139120),Trace[_0x4a8b85(0x2c2)](_0x6a73bc,_0x541879,_0x2eaf46,_0x5239f9));});}else Trace[_0x299224(0x2c2)](_0x6a73bc,_0x541879,_0x2eaf46);}function setupUserTimingTraces(_0x4eb9e8){const _0x4445e4=a0_0x19637f,_0x3bc523=Api[_0x4445e4(0x318)](),_0x319e3f=_0x3bc523[_0x4445e4(0x308)](_0x4445e4(0x2c6));for(const _0x2e0433 of _0x319e3f){createUserTimingTrace(_0x4eb9e8,_0x2e0433);}_0x3bc523[_0x4445e4(0x277)](_0x4445e4(0x2c6),_0x2b2f63=>createUserTimingTrace(_0x4eb9e8,_0x2b2f63));}function createUserTimingTrace(_0x30dfb3,_0x231042){const _0x5ad1ee=a0_0x19637f,_0x7a140a=_0x231042[_0x5ad1ee(0x1d5)];if(_0x7a140a[_0x5ad1ee(0x1f7)](0x0,TRACE_MEASURE_PREFIX[_0x5ad1ee(0x275)])===TRACE_MEASURE_PREFIX)return;Trace[_0x5ad1ee(0x32b)](_0x30dfb3,_0x7a140a);}/**
 * @license
 * Copyright 2020 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
class PerformanceController{constructor(_0x4d83d3,_0x46f431){const _0xdf8d0b=a0_0x19637f;this[_0xdf8d0b(0x20c)]=_0x4d83d3,this['installations']=_0x46f431,this['initialized']=![];}['_init'](_0x306955){const _0x1cd20b=a0_0x19637f;if(this[_0x1cd20b(0x28f)])return;(_0x306955===null||_0x306955===void 0x0?void 0x0:_0x306955[_0x1cd20b(0x252)])!==undefined&&(this[_0x1cd20b(0x252)]=_0x306955[_0x1cd20b(0x252)]),(_0x306955===null||_0x306955===void 0x0?void 0x0:_0x306955['instrumentationEnabled'])!==undefined&&(this[_0x1cd20b(0x1eb)]=_0x306955[_0x1cd20b(0x1eb)]),Api[_0x1cd20b(0x318)]()['requiredApisAvailable']()?validateIndexedDBOpenable()[_0x1cd20b(0x220)](_0x2ae77e=>{const _0x127fa3=_0x1cd20b;_0x2ae77e&&(setupTransportService(),getInitializationPromise(this)[_0x127fa3(0x220)](()=>setupOobResources(this),()=>setupOobResources(this)),this[_0x127fa3(0x28f)]=!![]);})['catch'](_0x5841f9=>{const _0x2ee3ad=_0x1cd20b;consoleLogger[_0x2ee3ad(0x27c)](_0x2ee3ad(0x274)+_0x5841f9);}):consoleLogger[_0x1cd20b(0x27c)]('Firebase\x20Performance\x20cannot\x20start\x20if\x20the\x20browser\x20does\x20not\x20support\x20'+_0x1cd20b(0x329));}set[a0_0x19637f(0x1eb)](_0x6614e9){const _0xc59ebb=a0_0x19637f;SettingsService[_0xc59ebb(0x318)]()[_0xc59ebb(0x1eb)]=_0x6614e9;}get[a0_0x19637f(0x1eb)](){const _0x4300d3=a0_0x19637f;return SettingsService[_0x4300d3(0x318)]()[_0x4300d3(0x1eb)];}set[a0_0x19637f(0x252)](_0x48536f){const _0x21476b=a0_0x19637f;SettingsService[_0x21476b(0x318)]()[_0x21476b(0x252)]=_0x48536f;}get[a0_0x19637f(0x252)](){const _0x51c6a6=a0_0x19637f;return SettingsService[_0x51c6a6(0x318)]()['dataCollectionEnabled'];}}const DEFAULT_ENTRY_NAME=a0_0x19637f(0x1df);function getPerformance(_0x3aca54=getApp()){const _0x4b151a=a0_0x19637f;_0x3aca54=getModularInstance(_0x3aca54);const _0x4025c7=_getProvider(_0x3aca54,'performance'),_0x14496e=_0x4025c7[_0x4b151a(0x2df)]();return _0x14496e;}function initializePerformance(_0x320962,_0x157716){const _0xb23746=a0_0x19637f;_0x320962=getModularInstance(_0x320962);const _0x27f97d=_getProvider(_0x320962,_0xb23746(0x1d2));if(_0x27f97d['isInitialized']()){const _0x36b952=_0x27f97d[_0xb23746(0x2df)](),_0x3bd52e=_0x27f97d[_0xb23746(0x20e)]();if(deepEqual(_0x3bd52e,_0x157716!==null&&_0x157716!==void 0x0?_0x157716:{}))return _0x36b952;else throw ERROR_FACTORY[_0xb23746(0x2bf)]('already\x20initialized');}const _0x3a69a3=_0x27f97d['initialize']({'options':_0x157716});return _0x3a69a3;}function trace(_0x38b445,_0x1a0d79){return _0x38b445=getModularInstance(_0x38b445),new Trace(_0x38b445,_0x1a0d79);}const factory=(_0x572a75,{options:_0x4aba9f})=>{const _0x59a366=a0_0x19637f,_0x26212a=_0x572a75[_0x59a366(0x2e3)]('app')['getImmediate'](),_0x4459c5=_0x572a75['getProvider']('installations-internal')[_0x59a366(0x2df)]();if(_0x26212a['name']!==DEFAULT_ENTRY_NAME)throw ERROR_FACTORY[_0x59a366(0x2bf)](_0x59a366(0x281));if(typeof window===_0x59a366(0x222))throw ERROR_FACTORY[_0x59a366(0x2bf)]('no\x20window');setupApi(window);const _0xbbf286=new PerformanceController(_0x26212a,_0x4459c5);return _0xbbf286['_init'](_0x4aba9f),_0xbbf286;};function registerPerformance(){const _0x8a442a=a0_0x19637f;_registerComponent(new Component(_0x8a442a(0x1d2),factory,'PUBLIC')),registerVersion(name,version),registerVersion(name,version,_0x8a442a(0x2ca));}registerPerformance();export{getPerformance,initializePerformance,trace};