/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x2955(_0x43d3eb,_0x652619){var _0x219bcd=a0_0x219b();return a0_0x2955=function(_0x295534,_0x1e2c44){_0x295534=_0x295534-0x6e;var _0x47daf5=_0x219bcd[_0x295534];return _0x47daf5;},a0_0x2955(_0x43d3eb,_0x652619);}var a0_0x3c2707=a0_0x2955;function a0_0x219b(){var _0x47b183=['OrthoMatrix4','projectionMatrix','9227490lslQci','foam.graphics.webgl.flat','Scene','18QmzkDL','20cBLsMN','145289WwJONM','3737536mAWgZz','644163PaubGZ','2dEgibT','7909286pzDJMs','1795pcWvpU','498rEYueB','11svHDGn','10346724ZwOHFd','create'];a0_0x219b=function(){return _0x47b183;};return a0_0x219b();}(function(_0x1c5a8c,_0x1bd261){var _0x27e39e=a0_0x2955,_0x1ba450=_0x1c5a8c();while(!![]){try{var _0xc45068=-parseInt(_0x27e39e(0x7a))/0x1*(parseInt(_0x27e39e(0x7d))/0x2)+parseInt(_0x27e39e(0x7c))/0x3*(parseInt(_0x27e39e(0x79))/0x4)+-parseInt(_0x27e39e(0x6e))/0x5*(parseInt(_0x27e39e(0x6f))/0x6)+-parseInt(_0x27e39e(0x7e))/0x7+parseInt(_0x27e39e(0x7b))/0x8*(parseInt(_0x27e39e(0x78))/0x9)+parseInt(_0x27e39e(0x75))/0xa*(-parseInt(_0x27e39e(0x70))/0xb)+parseInt(_0x27e39e(0x71))/0xc;if(_0xc45068===_0x1bd261)break;else _0x1ba450['push'](_0x1ba450['shift']());}catch(_0x4f52ad){_0x1ba450['push'](_0x1ba450['shift']());}}}(a0_0x219b,0x9cdb3),CLASS({'package':a0_0x3c2707(0x76),'name':a0_0x3c2707(0x77),'extends':'foam.graphics.webgl.core.Scene','requires':['foam.graphics.webgl.matrix.OrthoMatrix4'],'properties':[{'name':a0_0x3c2707(0x74),'factory':function(){var _0x56161=a0_0x3c2707;return this[_0x56161(0x73)][_0x56161(0x72)]({'znear':-0x7d0,'zfar':0x7d0});}}]}));