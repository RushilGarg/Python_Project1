(function(_0x18e0c8,_0x24ce9c){const _0x369f72=a0_0x3e95,_0x289ff2=_0x18e0c8();while(!![]){try{const _0x553fbb=-parseInt(_0x369f72(0xdf))/0x1+parseInt(_0x369f72(0xda))/0x2+parseInt(_0x369f72(0xd9))/0x3+-parseInt(_0x369f72(0xdc))/0x4+parseInt(_0x369f72(0xdb))/0x5*(parseInt(_0x369f72(0xdd))/0x6)+parseInt(_0x369f72(0xde))/0x7*(parseInt(_0x369f72(0xe0))/0x8)+-parseInt(_0x369f72(0xd8))/0x9;if(_0x553fbb===_0x24ce9c)break;else _0x289ff2['push'](_0x289ff2['shift']());}catch(_0x1d7d52){_0x289ff2['push'](_0x289ff2['shift']());}}}(a0_0x319d,0x2da99));import a0_0x35fe59 from'../../components/EmployeePage';import{graphql}from'gatsby';function a0_0x3e95(_0x16244b,_0x465f31){const _0x319d8f=a0_0x319d();return a0_0x3e95=function(_0x3e9558,_0x16bbaa){_0x3e9558=_0x3e9558-0xd8;let _0x15a0b8=_0x319d8f[_0x3e9558];return _0x15a0b8;},a0_0x3e95(_0x16244b,_0x465f31);}export const query=graphql`
    query {
        EmployeeImages: allFile(
            sort: { order: ASC, fields: [absolutePath] }
            filter: { relativePath: { regex: "/mugshots/ismar.jpg/" } }
        ) {
            edges {
                node {
                    relativePath
                    name
                    childImageSharp {
                        fluid(maxWidth: 1000) {
                            ...GatsbyImageSharpFluid
                        }
                    }
                }
            }
        }
    }
`;export default a0_0x35fe59;function a0_0x319d(){const _0x118596=['413114CdTHZz','65qCbcDG','549108JhePxS','113718aIqSNs','1956899pbAHbJ','165598SuBWIK','8syqWQt','3538845flmvRP','451830AzwaZv'];a0_0x319d=function(){return _0x118596;};return a0_0x319d();}