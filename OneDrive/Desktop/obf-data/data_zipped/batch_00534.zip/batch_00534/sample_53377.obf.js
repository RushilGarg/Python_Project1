/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x47d2(_0x51f388,_0xad095e){var _0x336e33=a0_0x336e();return a0_0x47d2=function(_0x47d2b7,_0x35e87a){_0x47d2b7=_0x47d2b7-0x1c0;var _0x401482=_0x336e33[_0x47d2b7];return _0x401482;},a0_0x47d2(_0x51f388,_0xad095e);}var a0_0x4f2952=a0_0x47d2;(function(_0x3e8184,_0xe192ad){var _0x26a8d6=a0_0x47d2,_0x415a64=_0x3e8184();while(!![]){try{var _0x156f46=parseInt(_0x26a8d6(0x1d2))/0x1+parseInt(_0x26a8d6(0x1ce))/0x2*(-parseInt(_0x26a8d6(0x1d1))/0x3)+parseInt(_0x26a8d6(0x1cd))/0x4+-parseInt(_0x26a8d6(0x1cb))/0x5*(-parseInt(_0x26a8d6(0x1c2))/0x6)+parseInt(_0x26a8d6(0x1c3))/0x7+-parseInt(_0x26a8d6(0x1c7))/0x8*(-parseInt(_0x26a8d6(0x1c4))/0x9)+-parseInt(_0x26a8d6(0x1c6))/0xa;if(_0x156f46===_0xe192ad)break;else _0x415a64['push'](_0x415a64['shift']());}catch(_0x36d472){_0x415a64['push'](_0x415a64['shift']());}}}(a0_0x336e,0x6ecb2));function a0_0x336e(){var _0x1aa0da=['473651YUhnBS','generic','@stdlib/array/filled','807492GzurDR','2975336vYBawa','19287WvrHDz','length','12357210ZQBUob','3080QpbDUB','log','ndarray','factory','20yNKqRX','@stdlib/array/dtypes','805996rxRviu','4XbgnhU','./../lib','@stdlib/array/filled-by','1161075udDSTP'];a0_0x336e=function(){return _0x1aa0da;};return a0_0x336e();}var uniform=require('@stdlib/random/base/uniform')[a0_0x4f2952(0x1ca)],filledarray=require(a0_0x4f2952(0x1c1)),filledarrayBy=require(a0_0x4f2952(0x1d0)),dtypes=require(a0_0x4f2952(0x1cc)),ceil=require(a0_0x4f2952(0x1cf)),dt,x,y,i;dt=dtypes();for(i=0x0;i<dt[a0_0x4f2952(0x1c5)];i++){x=filledarrayBy(0xa,dt[i],uniform(-0x64,0x64)),console[a0_0x4f2952(0x1c8)](x),y=filledarray(0x0,x['length'],a0_0x4f2952(0x1c0)),console['log'](y),ceil[a0_0x4f2952(0x1c9)](x[a0_0x4f2952(0x1c5)],dt[i],x,0x1,0x0,a0_0x4f2952(0x1c0),y,-0x1,y[a0_0x4f2952(0x1c5)]-0x1),console[a0_0x4f2952(0x1c8)](y),console[a0_0x4f2952(0x1c8)]('');}