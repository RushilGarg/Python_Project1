/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x4d06(){var _0x4dccac=['224NMnTKO','exports','24FfNTvp','path','5295762udHHeZ','8JXXlEy','6vypOpD','4889620qBdDUd','25044vTZsGt','@stdlib/fs/read-json','utf8','31662AOfrHN','resolve','2605065BlNLly','4056990qzXQZQ','1724305ADJAAH','data','sync'];a0_0x4d06=function(){return _0x4dccac;};return a0_0x4d06();}var a0_0x5d9c61=a0_0x27f2;(function(_0x2abfcf,_0xaf6de1){var _0x486629=a0_0x27f2,_0x146327=_0x2abfcf();while(!![]){try{var _0x469579=parseInt(_0x486629(0x14d))/0x1*(-parseInt(_0x486629(0x144))/0x2)+parseInt(_0x486629(0x141))/0x3*(-parseInt(_0x486629(0x14b))/0x4)+-parseInt(_0x486629(0x146))/0x5*(-parseInt(_0x486629(0x151))/0x6)+-parseInt(_0x486629(0x147))/0x7+parseInt(_0x486629(0x150))/0x8*(parseInt(_0x486629(0x14f))/0x9)+parseInt(_0x486629(0x152))/0xa+parseInt(_0x486629(0x148))/0xb;if(_0x469579===_0xaf6de1)break;else _0x146327['push'](_0x146327['shift']());}catch(_0x47bdd0){_0x146327['push'](_0x146327['shift']());}}}(a0_0x4d06,0x501d2));var resolve=require(a0_0x5d9c61(0x14e))[a0_0x5d9c61(0x145)],readJSON=require(a0_0x5d9c61(0x142))[a0_0x5d9c61(0x14a)],fpath=resolve(__dirname,'..',a0_0x5d9c61(0x149),'words.json'),opts={'encoding':a0_0x5d9c61(0x143)};function a0_0x27f2(_0x40fbd3,_0x261361){var _0x4d0629=a0_0x4d06();return a0_0x27f2=function(_0x27f29c,_0xbff36){_0x27f29c=_0x27f29c-0x141;var _0x39bcbf=_0x4d0629[_0x27f29c];return _0x39bcbf;},a0_0x27f2(_0x40fbd3,_0x261361);}function stopwords(){var _0x6d5267=readJSON(fpath,opts);if(_0x6d5267 instanceof Error)throw _0x6d5267;return _0x6d5267;}module[a0_0x5d9c61(0x14c)]=stopwords;