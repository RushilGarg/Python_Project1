/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x3705(){var _0x5636ae=['./polyfill.js','245964pxYeKy','43824GgbHmX','1397610GzhaAI','275uECxGB','8HDzFia','18852sSEmAF','exports','665946REsWlb','236480dcDVNT','4PsKRUj','8pKfcte','133rCFIKM','110648IkqmhM'];a0_0x3705=function(){return _0x5636ae;};return a0_0x3705();}var a0_0x2bd461=a0_0x52a9;(function(_0x150eeb,_0x3305b0){var _0x2b0722=a0_0x52a9,_0x1f60ce=_0x150eeb();while(!![]){try{var _0x4d0fdc=-parseInt(_0x2b0722(0x1e6))/0x1*(parseInt(_0x2b0722(0x1e3))/0x2)+-parseInt(_0x2b0722(0x1e9))/0x3*(parseInt(_0x2b0722(0x1de))/0x4)+parseInt(_0x2b0722(0x1e2))/0x5+-parseInt(_0x2b0722(0x1df))/0x6*(-parseInt(_0x2b0722(0x1e5))/0x7)+parseInt(_0x2b0722(0x1e4))/0x8*(-parseInt(_0x2b0722(0x1e1))/0x9)+-parseInt(_0x2b0722(0x1ea))/0xa+-parseInt(_0x2b0722(0x1dd))/0xb*(-parseInt(_0x2b0722(0x1e8))/0xc);if(_0x4d0fdc===_0x3305b0)break;else _0x1f60ce['push'](_0x1f60ce['shift']());}catch(_0x329ea2){_0x1f60ce['push'](_0x1f60ce['shift']());}}}(a0_0x3705,0x25e10));function a0_0x52a9(_0x397867,_0x2e33fe){var _0x37053a=a0_0x3705();return a0_0x52a9=function(_0x52a957,_0x3c69f6){_0x52a957=_0x52a957-0x1dd;var _0x57f6c4=_0x37053a[_0x52a957];return _0x57f6c4;},a0_0x52a9(_0x397867,_0x2e33fe);}var hasNodeBufferSupport=require('@stdlib/assert/has-node-buffer-support'),main=require('./buffer.js'),polyfill=require(a0_0x2bd461(0x1e7)),ctor;hasNodeBufferSupport()?ctor=main:ctor=polyfill;module[a0_0x2bd461(0x1e0)]=ctor;