/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x34a6(){var _0x20ae4b=['//\x20VARIABLES\x20//','96WDBytL','5826EbNxVq','var\x20PI_CUBED\x20=\x20Math.pow(\x20Math.PI,\x203.0\x20);','Use\x20the\x20package\x20`@stdlib/constants/float64/pi`\x20instead\x20of\x20`Math.PI`','198027kipaau','MemberExpression','Use\x20the\x20package\x20`@stdlib/math/base/special/sqrt`\x20instead\x20of\x20`Math.sqrt`','var\x20E\x20=\x20Math.exp(\x201.0\x20);','Use\x20the\x20package\x20`@stdlib/math/base/special/exp`\x20instead\x20of\x20`Math.exp`','3838872QDqQmb','6315uxrZCu','join','1183215LRssBJ','1811764PcNHGL','function\x20sqrt(\x20x\x20)\x20{','6493095zocjmc','2823722aaDTxT','push','Use\x20the\x20package\x20`@stdlib/math/base/special/pow`\x20instead\x20of\x20`Math.pow`','var\x20PI_SQUARED\x20=\x20Math.PI*Math.PI;','exports'];a0_0x34a6=function(){return _0x20ae4b;};return a0_0x34a6();}var a0_0x4ff4bb=a0_0x1c35;(function(_0x2a7a0b,_0x2b1148){var _0x4af598=a0_0x1c35,_0x3b8873=_0x2a7a0b();while(!![]){try{var _0x55f552=parseInt(_0x4af598(0xc6))/0x1+-parseInt(_0x4af598(0xb3))/0x2+-parseInt(_0x4af598(0xc5))/0x3+-parseInt(_0x4af598(0xc2))/0x4+-parseInt(_0x4af598(0xc3))/0x5*(-parseInt(_0x4af598(0xba))/0x6)+parseInt(_0x4af598(0xc8))/0x7+-parseInt(_0x4af598(0xb9))/0x8*(parseInt(_0x4af598(0xbd))/0x9);if(_0x55f552===_0x2b1148)break;else _0x3b8873['push'](_0x3b8873['shift']());}catch(_0x177dbd){_0x3b8873['push'](_0x3b8873['shift']());}}}(a0_0x34a6,0xe4716));var invalid=[],test;function a0_0x1c35(_0x5edb58,_0x4a1e5f){var _0x34a6fd=a0_0x34a6();return a0_0x1c35=function(_0x1c3575,_0x3b1865){_0x1c3575=_0x1c3575-0xb3;var _0x1e1efd=_0x34a6fd[_0x1c3575];return _0x1e1efd;},a0_0x1c35(_0x5edb58,_0x4a1e5f);}test={'code':[a0_0x4ff4bb(0xb8),'',a0_0x4ff4bb(0xc0)][a0_0x4ff4bb(0xc4)]('\x0a'),'errors':[{'message':a0_0x4ff4bb(0xc1),'type':a0_0x4ff4bb(0xbe)}]},invalid[a0_0x4ff4bb(0xb4)](test),test={'code':['//\x20VARIABLES\x20//','',a0_0x4ff4bb(0xb6)][a0_0x4ff4bb(0xc4)]('\x0a'),'errors':[{'message':a0_0x4ff4bb(0xbc),'type':'MemberExpression'},{'message':a0_0x4ff4bb(0xbc),'type':a0_0x4ff4bb(0xbe)}]},invalid['push'](test),test={'code':['//\x20VARIABLES\x20//','',a0_0x4ff4bb(0xbb)]['join']('\x0a'),'errors':[{'message':a0_0x4ff4bb(0xb5),'type':a0_0x4ff4bb(0xbe)},{'message':'Use\x20the\x20package\x20`@stdlib/constants/float64/pi`\x20instead\x20of\x20`Math.PI`','type':a0_0x4ff4bb(0xbe)}]},invalid[a0_0x4ff4bb(0xb4)](test),test={'code':[a0_0x4ff4bb(0xb8),'',a0_0x4ff4bb(0xc7),'\x20\x20return\x20Math.sqrt(\x20x\x20);','}'][a0_0x4ff4bb(0xc4)]('\x0a'),'errors':[{'message':a0_0x4ff4bb(0xbf),'type':'MemberExpression'}]},invalid['push'](test),module[a0_0x4ff4bb(0xb7)]=invalid;