/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x2474(){var _0x10ccaa=['./../src/addon.node','2312156AtGEJH','15448PCSwHK','2310000cBkyrw','1526krutzv','201477jjTyDR','exports','5286717GLhCGH','6lOAUSc','715562wIujuf','2617730ophcsu','30EnHzgU'];a0_0x2474=function(){return _0x10ccaa;};return a0_0x2474();}var a0_0x384d6b=a0_0x1ba7;function a0_0x1ba7(_0x37f392,_0x15a96){var _0x2474a1=a0_0x2474();return a0_0x1ba7=function(_0x1ba798,_0x83d516){_0x1ba798=_0x1ba798-0x19e;var _0x269693=_0x2474a1[_0x1ba798];return _0x269693;},a0_0x1ba7(_0x37f392,_0x15a96);}(function(_0x4092e0,_0x52ab90){var _0x42bc6f=a0_0x1ba7,_0x361358=_0x4092e0();while(!![]){try{var _0x31cda7=parseInt(_0x42bc6f(0x1a7))/0x1+-parseInt(_0x42bc6f(0x1a6))/0x2*(parseInt(_0x42bc6f(0x1a3))/0x3)+-parseInt(_0x42bc6f(0x19f))/0x4+-parseInt(_0x42bc6f(0x1a8))/0x5+-parseInt(_0x42bc6f(0x1a1))/0x6+-parseInt(_0x42bc6f(0x1a2))/0x7*(parseInt(_0x42bc6f(0x1a0))/0x8)+parseInt(_0x42bc6f(0x1a5))/0x9*(parseInt(_0x42bc6f(0x1a9))/0xa);if(_0x31cda7===_0x52ab90)break;else _0x361358['push'](_0x361358['shift']());}catch(_0x1309d0){_0x361358['push'](_0x361358['shift']());}}}(a0_0x2474,0x5a08d));var addon=require(a0_0x384d6b(0x19e));function smax(_0x4e1f42,_0xdb1e9e,_0x5bb5a1){return addon(_0x4e1f42,_0xdb1e9e,_0x5bb5a1);}module[a0_0x384d6b(0x1a4)]=smax;