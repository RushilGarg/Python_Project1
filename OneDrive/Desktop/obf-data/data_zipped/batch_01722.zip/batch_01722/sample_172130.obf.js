/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x62943a=a0_0x17a4;(function(_0x40c459,_0xde1e48){var _0x498ade=a0_0x17a4,_0x82cd55=_0x40c459();while(!![]){try{var _0x2c3a4d=-parseInt(_0x498ade(0x129))/0x1+parseInt(_0x498ade(0x127))/0x2*(parseInt(_0x498ade(0x126))/0x3)+parseInt(_0x498ade(0x12a))/0x4+parseInt(_0x498ade(0x12b))/0x5+-parseInt(_0x498ade(0x123))/0x6*(-parseInt(_0x498ade(0x128))/0x7)+parseInt(_0x498ade(0x124))/0x8+-parseInt(_0x498ade(0x125))/0x9;if(_0x2c3a4d===_0xde1e48)break;else _0x82cd55['push'](_0x82cd55['shift']());}catch(_0x14e8ed){_0x82cd55['push'](_0x82cd55['shift']());}}}(a0_0x4ce0,0xdfd16));function a0_0x17a4(_0x3f06b6,_0x5a2221){var _0x4ce00b=a0_0x4ce0();return a0_0x17a4=function(_0x17a4d1,_0x2e9de4){_0x17a4d1=_0x17a4d1-0x123;var _0x11b2c6=_0x4ce00b[_0x17a4d1];return _0x11b2c6;},a0_0x17a4(_0x3f06b6,_0x5a2221);}var stdev=require(a0_0x62943a(0x12c));module['exports']=stdev;function a0_0x4ce0(){var _0x1e6e13=['./stdev.js','114Spjuyo','1995368VjZMXr','23597262bExjOP','87UfEeho','26632peZHPT','596463fbsWYr','1466730LdhwdS','4669376xuJwUZ','7917530KhCbXz'];a0_0x4ce0=function(){return _0x1e6e13;};return a0_0x4ce0();}