const a0_0x7929e=a0_0x4bce;(function(_0x1532a7,_0x3bba5d){const _0x56b209=a0_0x4bce,_0xe2722e=_0x1532a7();while(!![]){try{const _0x48ad17=-parseInt(_0x56b209(0xe4))/0x1*(-parseInt(_0x56b209(0xcf))/0x2)+parseInt(_0x56b209(0xda))/0x3+-parseInt(_0x56b209(0xdf))/0x4+parseInt(_0x56b209(0xd6))/0x5+-parseInt(_0x56b209(0xc9))/0x6*(-parseInt(_0x56b209(0xcb))/0x7)+parseInt(_0x56b209(0xe5))/0x8+parseInt(_0x56b209(0xd1))/0x9*(-parseInt(_0x56b209(0xdc))/0xa);if(_0x48ad17===_0x3bba5d)break;else _0xe2722e['push'](_0xe2722e['shift']());}catch(_0x458d5e){_0xe2722e['push'](_0xe2722e['shift']());}}}(a0_0x4fbf,0x7f311));import{PolymerElement,html}from'@polymer/polymer';import'./noflo-card-styles';function a0_0x4bce(_0x354bfb,_0x289bd8){const _0x4fbf42=a0_0x4fbf();return a0_0x4bce=function(_0x4bcec5,_0x414f65){_0x4bcec5=_0x4bcec5-0xc2;let _0x12c54d=_0x4fbf42[_0x4bcec5];return _0x12c54d;},a0_0x4bce(_0x354bfb,_0x289bd8);}import'./noflo-icon';import'./the-graph-thumb';function a0_0x4fbf(){const _0x31c8f1=['gist','caret-down','deleteProject','send','ellipsis-v','button','openGithub','1861146hEjgFL','click','7BPxbqZ','event','_getMainGraph','dispatchEvent','24lKZLCZ','filter','9vzmjYh','function','template','define','menuopen','4554095YKRvQa','repo','https://github.com/','properties','712575uUpBjJ','location','9481530aiavez','project','stopPropagation','2830632oGnmiW','menuicon','preventDefault','_menuOpenChanged','graphs','2452mGgHeI','5510632wjFJcx','openGist'];a0_0x4fbf=function(){return _0x31c8f1;};return a0_0x4fbf();}class NoFloProjectCard extends PolymerElement{static get[a0_0x7929e(0xd3)](){return html`
    <style include="noflo-card-styles">
      the-graph-thumb {
        display: block;
        position: absolute;
        left: 100px;
        top: -20px;
      }
    </style>
    <the-graph-thumb graph="[[_getMainGraph(project.main)]]" width="200" height="120"></the-graph-thumb>
    <button id="menubutton" title="Project menu" on-click="toggleMenu"><noflo-icon icon="[[menuicon]]"></noflo-icon></button>
    <template is="dom-if" if="[[menuopen]]">
    <ul id="menu">
      <template is="dom-if" if="[[project.repo]]">
      <li><button on-click="openGithub">View on GitHub</button></li>
      </template>
      <template is="dom-if" if="[[project.gist]]">
      <li><button on-click="openGithub">View Gist</button></li>
      </template>
      <li><button on-click="deleteProject">Delete project</button></li>
    </ul>
    </template>
    <h2>[[project.name]]</h2>
    <p><span>[[project.graphs.length]]</span>&nbsp;graphs, <span>[[project.components.length]]</span>&nbsp;components</p>
`;}static get['is'](){return'noflo-project-card';}static get[a0_0x7929e(0xd9)](){const _0x59b707=a0_0x7929e;return{'menuopen':{'type':Boolean,'value':![],'observer':'_menuOpenChanged'},'menuicon':{'type':String,'value':_0x59b707(0xc6)},'project':{'type':Object,'value'(){return{};}}};}['toggleMenu'](_0x40b191){const _0x1fe474=a0_0x7929e;_0x40b191[_0x1fe474(0xde)](),_0x40b191['preventDefault']();if(this[_0x1fe474(0xd5)]){this[_0x1fe474(0xd5)]=![];return;}this[_0x1fe474(0xd5)]=!![];}[a0_0x7929e(0xc8)](_0x3ca749){const _0x17699f=a0_0x7929e;_0x3ca749[_0x17699f(0xde)](),_0x3ca749[_0x17699f(0xe1)]();if(!this['project'][_0x17699f(0xd7)]&&!this[_0x17699f(0xdd)][_0x17699f(0xc2)])return;if(this[_0x17699f(0xdd)][_0x17699f(0xd7)]){typeof ga===_0x17699f(0xd2)&&ga(_0x17699f(0xc5),_0x17699f(0xcc),'button',_0x17699f(0xca),_0x17699f(0xc8));window[_0x17699f(0xdb)]=_0x17699f(0xd8)+this[_0x17699f(0xdd)][_0x17699f(0xd7)];return;}this['project'][_0x17699f(0xc2)]&&(typeof ga===_0x17699f(0xd2)&&ga('send',_0x17699f(0xcc),_0x17699f(0xc7),_0x17699f(0xca),_0x17699f(0xe6)),window['location']='https://gist.github.com/'+this[_0x17699f(0xdd)][_0x17699f(0xc2)]);}[a0_0x7929e(0xc4)](_0x1c6208){const _0x414c79=a0_0x7929e;_0x1c6208[_0x414c79(0xde)](),_0x1c6208[_0x414c79(0xe1)](),typeof ga===_0x414c79(0xd2)&&ga(_0x414c79(0xc5),'event','button',_0x414c79(0xca),_0x414c79(0xc4)),this[_0x414c79(0xce)](new CustomEvent(_0x414c79(0xc4),{'detail':this['project'],'composed':!![],'bubbles':!![]})),this['menuopen']=![];}[a0_0x7929e(0xcd)](_0x24a577){const _0x2c491e=a0_0x7929e;if(!_0x24a577)return null;const _0x25582e=this['project'][_0x2c491e(0xe3)][_0x2c491e(0xd0)](_0x42cdf3=>{const _0x12383a=_0x2c491e;if(_0x42cdf3[_0x12383a(0xd9)]['id']!==_0x24a577)return![];return!![];});if(!_0x25582e['length'])return null;return _0x25582e[0x0];}[a0_0x7929e(0xe2)](){const _0x15841e=a0_0x7929e;if(this[_0x15841e(0xd5)]){this[_0x15841e(0xe0)]=_0x15841e(0xc3);return;}this['menuicon']=_0x15841e(0xc6);}}customElements[a0_0x7929e(0xd4)](NoFloProjectCard['is'],NoFloProjectCard);