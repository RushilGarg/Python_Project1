/**
 * @license
 * Copyright 2018 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';const a0_0x4b2708=a0_0xcb40;(function(_0x546209,_0x526c1a){const _0x399f76=a0_0xcb40,_0x5b4d23=_0x546209();while(!![]){try{const _0x3bdec8=-parseInt(_0x399f76(0x202))/0x1*(parseInt(_0x399f76(0x1f1))/0x2)+-parseInt(_0x399f76(0x1fb))/0x3*(-parseInt(_0x399f76(0x1f5))/0x4)+parseInt(_0x399f76(0x200))/0x5*(-parseInt(_0x399f76(0x1f7))/0x6)+parseInt(_0x399f76(0x1f8))/0x7+parseInt(_0x399f76(0x1ef))/0x8+parseInt(_0x399f76(0x1ed))/0x9*(parseInt(_0x399f76(0x1f0))/0xa)+-parseInt(_0x399f76(0x1f2))/0xb*(parseInt(_0x399f76(0x1f3))/0xc);if(_0x3bdec8===_0x526c1a)break;else _0x5b4d23['push'](_0x5b4d23['shift']());}catch(_0x482e4c){_0x5b4d23['push'](_0x5b4d23['shift']());}}}(a0_0x1b0f,0x77e28));function a0_0x1b0f(){const _0x68869c=['19716vWykjP','./on-create-user','3867042ZMzwcx','737919VLjNmO','onCreateUser','status','489dglRFZ','onCreate','cors','send','onRequest','5hDoSWY','auth','528839zCBHGc','9YYvixL','Internal\x20error','37928IfmZoj','8124010WVRJXO','2ISNNkO','88LOGKcb','92388nyKjFw','catch'];a0_0x1b0f=function(){return _0x68869c;};return a0_0x1b0f();}const functions=require('firebase-functions'),onCreateUser=require(a0_0x4b2708(0x1f6)),exportCsv=require('./export-csv'),importCsv=require('./import-csv'),importGeoJson=require('./import-geojson'),cors=require(a0_0x4b2708(0x1fd))({'origin':!![]});function a0_0xcb40(_0x38e8d3,_0x3b0f41){const _0x1b0f79=a0_0x1b0f();return a0_0xcb40=function(_0xcb40ad,_0x373344){_0xcb40ad=_0xcb40ad-0x1ed;let _0x596b1d=_0x1b0f79[_0xcb40ad];return _0x596b1d;},a0_0xcb40(_0x38e8d3,_0x3b0f41);}function onHttpsRequest(_0x58b360){const _0x1ece67=a0_0x4b2708;return functions['https'][_0x1ece67(0x1ff)]((_0x2a8409,_0x284ea8)=>cors(_0x2a8409,_0x284ea8,()=>_0x58b360(_0x2a8409,_0x284ea8)[_0x1ece67(0x1f4)](_0x1d8753=>onError(_0x284ea8,_0x1d8753))));}function onError(_0x2f256e,_0x2a45f5){const _0xa687c7=a0_0x4b2708;console['error'](_0x2a45f5),_0x2f256e[_0xa687c7(0x1fa)](0x1f4)[_0xa687c7(0x1fe)](_0xa687c7(0x1ee));}exports[a0_0x4b2708(0x1f9)]=functions[a0_0x4b2708(0x201)]['user']()[a0_0x4b2708(0x1fc)](onCreateUser),exports['importCsv']=onHttpsRequest(importCsv),exports['importGeoJson']=onHttpsRequest(importGeoJson),exports['exportCsv']=onHttpsRequest(exportCsv);