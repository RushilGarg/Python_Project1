/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x466493=a0_0x3270;function a0_0x3270(_0x519b37,_0x43de8e){var _0x2fbe98=a0_0x2fbe();return a0_0x3270=function(_0x32707e,_0x52dfbe){_0x32707e=_0x32707e-0x156;var _0x210802=_0x2fbe98[_0x32707e];return _0x210802;},a0_0x3270(_0x519b37,_0x43de8e);}(function(_0x2aebc3,_0x960b70){var _0x298b35=a0_0x3270,_0x1bfe3f=_0x2aebc3();while(!![]){try{var _0x15f8b4=-parseInt(_0x298b35(0x16d))/0x1+parseInt(_0x298b35(0x160))/0x2*(-parseInt(_0x298b35(0x169))/0x3)+-parseInt(_0x298b35(0x16a))/0x4+parseInt(_0x298b35(0x166))/0x5*(parseInt(_0x298b35(0x167))/0x6)+parseInt(_0x298b35(0x162))/0x7+parseInt(_0x298b35(0x165))/0x8*(parseInt(_0x298b35(0x15c))/0x9)+parseInt(_0x298b35(0x159))/0xa;if(_0x15f8b4===_0x960b70)break;else _0x1bfe3f['push'](_0x1bfe3f['shift']());}catch(_0x18b3a5){_0x1bfe3f['push'](_0x1bfe3f['shift']());}}}(a0_0x2fbe,0x3c931));var logger=require('debug'),walk=require(a0_0x466493(0x16b)),isNamespaceAssignment=require('./is_namespace_assignment.js'),debug=logger(a0_0x466493(0x161));function a0_0x2fbe(){var _0x405d42=['Namespace\x20property:\x20%s','837BiWgRz','type','Literal','push','280212CMFaPO','lint-namespace-aliases:walk','64365ahMmpd','CallExpression','require','1952nyBFnM','35lhdnFS','370698akiZUU','length','9OuxVOf','1751396wyvkeK','acorn-walk','recursive','198808ZrOBEQ','exports','name','Found\x20a\x20namespace\x20assignment.','8407200ofNRlb','arguments'];a0_0x2fbe=function(){return _0x405d42;};return a0_0x2fbe();}function walker(_0x2cf07e,_0x2be30a){var _0xff5a76=a0_0x466493,_0x13caeb,_0xac61dc;_0xac61dc=[],_0x13caeb={'CallExpression':_0x5373d8},walk[_0xff5a76(0x16c)](_0x2be30a,null,_0x13caeb);return _0xac61dc;function _0x5373d8(_0x39d4a2){var _0x300d33=_0xff5a76,_0x1cce55,_0x9e6230,_0x15a652;if(isNamespaceAssignment(_0x39d4a2)===![])return;_0x39d4a2[_0x300d33(0x15a)][_0x300d33(0x168)]&&(_0x9e6230=_0x39d4a2[_0x300d33(0x15a)][0x1],_0x9e6230&&_0x9e6230[_0x300d33(0x15d)]===_0x300d33(0x15e)&&(_0x1cce55=_0x9e6230['value'],debug(_0x300d33(0x15b),_0x1cce55)),_0x9e6230=_0x39d4a2[_0x300d33(0x15a)][0x2],_0x9e6230&&_0x9e6230[_0x300d33(0x15d)]===_0x300d33(0x163)&&_0x9e6230['callee']['type']==='Identifier'&&_0x9e6230['callee'][_0x300d33(0x157)]===_0x300d33(0x164)&&(_0x15a652=_0x9e6230[_0x300d33(0x15a)][0x0]['value'],debug('Package\x20identifer:\x20%s',_0x15a652)),_0x1cce55&&_0x15a652&&(debug(_0x300d33(0x158)),_0xac61dc[_0x300d33(0x15f)]({'id':_0x15a652,'alias':_0x1cce55})));}}module[a0_0x466493(0x156)]=walker;