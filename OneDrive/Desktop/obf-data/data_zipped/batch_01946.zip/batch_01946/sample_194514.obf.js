/**
 * Copyright (c) 2015 Famous Industries, Inc.
 * 
 * Permission is hereby granted, free of charge, to any person obtaining a 
 * copy of this software and associated documentation files (the "Software"), 
 * to deal in the Software without restriction, including without limitation 
 * the rights to use, copy, modify, merge, publish, distribute, sublicense, 
 * and/or sell copies of the Software, and to permit persons to whom the 
 * Software is furnished to do so, subject to the following conditions:
 * 
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software.
 * 
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE 
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS 
 * IN THE SOFTWARE.
 *
 * @license MIT
 */
function a0_0x2858(){var _0x2b1045=['2400410ixPEMc','546990qLIYFG','8nbGELR','famous/surfaces/ImageSurface','famous/core/Modifier','6nzGQLz','5320mqAsRf','4806492CqRdcs','286041VulAyR','4360860GvtgGC','famous/core/Engine','2216700xMuMqR','createContext','16080rEYExH','add'];a0_0x2858=function(){return _0x2b1045;};return a0_0x2858();}function a0_0x300b(_0x458d41,_0x1a9bf8){var _0x285851=a0_0x2858();return a0_0x300b=function(_0x300bd4,_0x1db83a){_0x300bd4=_0x300bd4-0x104;var _0x18708a=_0x285851[_0x300bd4];return _0x18708a;},a0_0x300b(_0x458d41,_0x1a9bf8);}(function(_0x15b08a,_0x31b671){var _0x17f528=a0_0x300b,_0x48eba8=_0x15b08a();while(!![]){try{var _0x3dc83d=-parseInt(_0x17f528(0x108))/0x1*(parseInt(_0x17f528(0x111))/0x2)+-parseInt(_0x17f528(0x10b))/0x3+parseInt(_0x17f528(0x107))/0x4+-parseInt(_0x17f528(0x10f))/0x5*(-parseInt(_0x17f528(0x105))/0x6)+-parseInt(_0x17f528(0x106))/0x7*(-parseInt(_0x17f528(0x10d))/0x8)+-parseInt(_0x17f528(0x109))/0x9+-parseInt(_0x17f528(0x110))/0xa;if(_0x3dc83d===_0x31b671)break;else _0x48eba8['push'](_0x48eba8['shift']());}catch(_0x4a1e19){_0x48eba8['push'](_0x48eba8['shift']());}}}(a0_0x2858,0xc023a),define(function(_0xf7513d,_0x66f2a9,_0x16943a){var _0x228c83=a0_0x300b,_0x23669d=_0xf7513d(_0x228c83(0x10a)),_0x3e101c=_0xf7513d(_0x228c83(0x104)),_0x50d116=_0xf7513d(_0x228c83(0x112)),_0x3e8224=_0x23669d[_0x228c83(0x10c)](),_0x5b09b7=new _0x50d116({'size':[0xc8,0xc8]});_0x5b09b7['setContent']('http://code.famo.us/assets/famous.jpg'),_0x3e8224[_0x228c83(0x10e)](new _0x3e101c({'align':[0.5,0.5],'origin':[0.5,0.5]}))['add'](_0x5b09b7);}));