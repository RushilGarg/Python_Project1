/**
 * @fileOverview Progressive realtime web framework config-driven or API-driven for building easily serverless files, websites and webapps component-based and service-oriented.
 * @author {@link https://www.lesieur.name/ Bruno Lesieur}
 * @license {@link https://raw.githubusercontent.com/Haeresis/NodeAtlas/master/LICENSE GNU GENERAL PUBLIC LICENSE Version 2}
 * @module node-atlas
 * @requires {@link NA#modules.external:async}
 * @requires {@link NA#modules.external:body-parser}
 * @requires {@link NA#modules.external:clean-css}
 * @requires {@link NA#modules.external:commander}
 * @requires {@link NA#modules.external:compression}
 * @requires {@link NA#modules.external:cookie-parser}
 * @requires {@link NA#modules.external:css-parse}
 * @requires {@link NA#modules.external:ejs}
 * @requires {@link NA#modules.external:express}
 * @requires {@link NA#modules.external:express-session}
 * @requires {@link NA#modules.external:extend}
 * @requires {@link NA#modules.external:jsdom}
 * @requires {@link NA#modules.external:less}
 * @requires {@link NA#modules.external:less-middleware}
 * @requires {@link NA#modules.external:mkpath}
 * @requires {@link NA#modules.external:open}
 * @requires {@link NA#modules.external:pug}
 * @requires {@link NA#modules.external:socketio}
 * @requires {@link NA#modules.external:stylus}
 * @requires {@link NA#modules.external:copy-dir}
 * @requires {@link NA#modules.external:uglify-js}
 */
var a0_0x30f475=a0_0x32ef;function a0_0x5126(){var _0x15361c=['50OdLKvV','main','start','1JAGfJD','1786872QiiESV','10264MvBxGB','518200blfZog','24467172gFMmLg','7973QGpYdm','1579330fryyLC','2358828DZrwqk','1368894jJLvdZ','11MTyobN','9NlkXyp'];a0_0x5126=function(){return _0x15361c;};return a0_0x5126();}(function(_0x41dff4,_0x246d80){var _0x506f78=a0_0x32ef,_0x3b5cfe=_0x41dff4();while(!![]){try{var _0x2c0dfd=parseInt(_0x506f78(0x114))/0x1*(parseInt(_0x506f78(0x115))/0x2)+-parseInt(_0x506f78(0x10d))/0x3+parseInt(_0x506f78(0x109))/0x4*(parseInt(_0x506f78(0x111))/0x5)+-parseInt(_0x506f78(0x10e))/0x6+parseInt(_0x506f78(0x10b))/0x7*(parseInt(_0x506f78(0x116))/0x8)+-parseInt(_0x506f78(0x110))/0x9*(-parseInt(_0x506f78(0x10c))/0xa)+parseInt(_0x506f78(0x10f))/0xb*(-parseInt(_0x506f78(0x10a))/0xc);if(_0x2c0dfd===_0x246d80)break;else _0x3b5cfe['push'](_0x3b5cfe['shift']());}catch(_0x1a0468){_0x3b5cfe['push'](_0x3b5cfe['shift']());}}}(a0_0x5126,0xb84a2));var NA=require('./bin/node-atlas.js');function a0_0x32ef(_0x3713f9,_0x10b70f){var _0x51267b=a0_0x5126();return a0_0x32ef=function(_0x32effb,_0x566fb8){_0x32effb=_0x32effb-0x109;var _0x36cc11=_0x51267b[_0x32effb];return _0x36cc11;},a0_0x32ef(_0x3713f9,_0x10b70f);}require[a0_0x30f475(0x112)]===module&&(global['NA']=new NA(),global['NA'][a0_0x30f475(0x113)]());module['exports']=NA;