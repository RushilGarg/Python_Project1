/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x375b2a=a0_0x4616;(function(_0x45389e,_0x307e47){var _0x3683d2=a0_0x4616,_0x3cf0bd=_0x45389e();while(!![]){try{var _0x4e4b9b=parseInt(_0x3683d2(0x1fd))/0x1*(-parseInt(_0x3683d2(0x1fb))/0x2)+-parseInt(_0x3683d2(0x1f2))/0x3+-parseInt(_0x3683d2(0x1f1))/0x4*(parseInt(_0x3683d2(0x1fa))/0x5)+parseInt(_0x3683d2(0x1ff))/0x6*(-parseInt(_0x3683d2(0x1f9))/0x7)+parseInt(_0x3683d2(0x1ef))/0x8*(-parseInt(_0x3683d2(0x1f6))/0x9)+-parseInt(_0x3683d2(0x1ee))/0xa*(parseInt(_0x3683d2(0x1f0))/0xb)+-parseInt(_0x3683d2(0x1fc))/0xc*(-parseInt(_0x3683d2(0x1f3))/0xd);if(_0x4e4b9b===_0x307e47)break;else _0x3cf0bd['push'](_0x3cf0bd['shift']());}catch(_0x431add){_0x3cf0bd['push'](_0x3cf0bd['shift']());}}}(a0_0x3b94,0x4384e));function a0_0x4616(_0x3b31e9,_0x28fa09){var _0x3b94ad=a0_0x3b94();return a0_0x4616=function(_0x4616b1,_0x3df9d2){_0x4616b1=_0x4616b1-0x1ec;var _0x516dc8=_0x3b94ad[_0x4616b1];return _0x516dc8;},a0_0x4616(_0x3b31e9,_0x28fa09);}var isPositiveInteger=require(a0_0x375b2a(0x1ec)),constantFunction=require(a0_0x375b2a(0x1fe)),isfinite=require(a0_0x375b2a(0x1ed)),round=require(a0_0x375b2a(0x1f7)),isnan=require(a0_0x375b2a(0x1f8)),exp=require('@stdlib/math/base/special/exp'),LN2=require('@stdlib/constants/float64/ln-two'),weights=require(a0_0x375b2a(0x1f4));function a0_0x3b94(){var _0x397ae1=['@stdlib/math/base/assert/is-finite','4670MehyfW','56caGQhS','5159SQVinV','124xjcPYF','603075RSRdQV','26650sJZGXS','./weights.js','exports','709713neKNLb','@stdlib/math/base/special/round','@stdlib/math/base/assert/is-nan','189Ekqjxt','62915mjyEwy','395474UEehDd','12252zOHdou','1OMaPQG','@stdlib/utils/constant-function','57030ggwvBD','@stdlib/math/base/assert/is-positive-integer'];a0_0x3b94=function(){return _0x397ae1;};return a0_0x3b94();}function factory(_0x54d19b){var _0x4f329d,_0x2180ec;if(!isPositiveInteger(_0x54d19b)||!isfinite(_0x54d19b))return constantFunction(NaN);_0x2180ec=exp(-_0x54d19b*LN2),_0x4f329d=_0x54d19b*(_0x54d19b+0x1)/0x2;return _0x23dd5b;function _0x23dd5b(_0x27de1a){var _0x24ce5c,_0x2961c7;if(isnan(_0x27de1a))return NaN;if(_0x27de1a<0x0)return 0x0;_0x27de1a=round(_0x27de1a);if(_0x27de1a>=_0x4f329d)return 0x1;_0x2961c7=0x0;for(_0x24ce5c=0x0;_0x24ce5c<=_0x27de1a;_0x24ce5c++){_0x2961c7+=weights(_0x24ce5c,_0x54d19b)*_0x2180ec;}return _0x2961c7;}}module[a0_0x375b2a(0x1f5)]=factory;