/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x3d5b42=a0_0x489e;function a0_0x489e(_0x31e794,_0x1a82e0){var _0xa37c2f=a0_0xa37c();return a0_0x489e=function(_0x489e14,_0x23b3a0){_0x489e14=_0x489e14-0x7e;var _0x4ae4f0=_0xa37c2f[_0x489e14];return _0x4ae4f0;},a0_0x489e(_0x31e794,_0x1a82e0);}function a0_0xa37c(){var _0x5a3597=['9UITrWJ','3450rhYADw','3918260Cvdkpp','length','buffer','65764iIKvhc','662788AvDwgn','544180gPAAac','./smin.native.js','exports','295874LBcxMq','1986Knaijf','60TlVulw','@stdlib/array/float32','byteOffset','333792GcqlWf'];a0_0xa37c=function(){return _0x5a3597;};return a0_0xa37c();}(function(_0x74b4c0,_0x2e7be2){var _0x750cbd=a0_0x489e,_0xf6add6=_0x74b4c0();while(!![]){try{var _0x2f291a=-parseInt(_0x750cbd(0x8d))/0x1+-parseInt(_0x750cbd(0x89))/0x2+parseInt(_0x750cbd(0x7f))/0x3*(parseInt(_0x750cbd(0x88))/0x4)+-parseInt(_0x750cbd(0x84))/0x5*(-parseInt(_0x750cbd(0x7e))/0x6)+-parseInt(_0x750cbd(0x8a))/0x7+-parseInt(_0x750cbd(0x82))/0x8+parseInt(_0x750cbd(0x83))/0x9*(parseInt(_0x750cbd(0x85))/0xa);if(_0x2f291a===_0x2e7be2)break;else _0xf6add6['push'](_0xf6add6['shift']());}catch(_0x6c9ba3){_0xf6add6['push'](_0xf6add6['shift']());}}}(a0_0xa37c,0x31640));var Float32Array=require(a0_0x3d5b42(0x80)),addon=require(a0_0x3d5b42(0x8b));function smin(_0x3d36e6,_0x4fb104,_0x5732f2,_0x1722ef){var _0x3aec31=a0_0x3d5b42,_0x167c44;return _0x5732f2<0x0&&(_0x1722ef+=(_0x3d36e6-0x1)*_0x5732f2),_0x167c44=new Float32Array(_0x4fb104[_0x3aec31(0x87)],_0x4fb104[_0x3aec31(0x81)]+_0x4fb104['BYTES_PER_ELEMENT']*_0x1722ef,_0x4fb104[_0x3aec31(0x86)]-_0x1722ef),addon(_0x3d36e6,_0x167c44,_0x5732f2);}module[a0_0x3d5b42(0x8c)]=smin;