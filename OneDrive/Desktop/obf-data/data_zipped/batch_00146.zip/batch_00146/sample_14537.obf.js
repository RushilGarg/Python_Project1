/**
 * @license
 * Copyright 2014 Software Freedom Conservancy
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x49b41b=a0_0x5ef1;function a0_0x2605(){var _0xf67ea1=['4492hEYscV','34696wTkhhb','155YVUTQO','2359zVXwWg','STRING','call','prototype','Literal:\x20','4005uJrWJV','provide','text_','wgxpath.Expr','11694bVwBoZ','333504EhEMsW','341HNKsLr','4021263PINGKl','DataType','Expr','toString','Literal','wgxpath.Literal','728930nyKNia','2325573eVxDgP'];a0_0x2605=function(){return _0xf67ea1;};return a0_0x2605();}function a0_0x5ef1(_0x7e8aae,_0x445f17){var _0x260514=a0_0x2605();return a0_0x5ef1=function(_0x5ef167,_0xb1997b){_0x5ef167=_0x5ef167-0x11c;var _0x4e1787=_0x260514[_0x5ef167];return _0x4e1787;},a0_0x5ef1(_0x7e8aae,_0x445f17);}(function(_0x5905ee,_0x14a4ba){var _0x858357=a0_0x5ef1,_0x5c0598=_0x5905ee();while(!![]){try{var _0x51eda8=parseInt(_0x858357(0x12f))/0x1*(-parseInt(_0x858357(0x12d))/0x2)+-parseInt(_0x858357(0x12c))/0x3+parseInt(_0x858357(0x123))/0x4+parseInt(_0x858357(0x11e))/0x5*(parseInt(_0x858357(0x122))/0x6)+parseInt(_0x858357(0x130))/0x7*(-parseInt(_0x858357(0x12e))/0x8)+-parseInt(_0x858357(0x125))/0x9+-parseInt(_0x858357(0x12b))/0xa*(-parseInt(_0x858357(0x124))/0xb);if(_0x51eda8===_0x14a4ba)break;else _0x5c0598['push'](_0x5c0598['shift']());}catch(_0x226e10){_0x5c0598['push'](_0x5c0598['shift']());}}}(a0_0x2605,0xd503f),goog[a0_0x49b41b(0x11f)](a0_0x49b41b(0x12a)),goog['require'](a0_0x49b41b(0x121)),wgxpath[a0_0x49b41b(0x129)]=function(_0x425887){var _0x4d213e=a0_0x49b41b;wgxpath[_0x4d213e(0x127)][_0x4d213e(0x132)](this,wgxpath[_0x4d213e(0x126)][_0x4d213e(0x131)]),this[_0x4d213e(0x120)]=_0x425887['substring'](0x1,_0x425887['length']-0x1);},goog['inherits'](wgxpath[a0_0x49b41b(0x129)],wgxpath[a0_0x49b41b(0x127)]),wgxpath[a0_0x49b41b(0x129)][a0_0x49b41b(0x11c)]['evaluate']=function(_0x529048){var _0x264559=a0_0x49b41b;return this[_0x264559(0x120)];},wgxpath[a0_0x49b41b(0x129)][a0_0x49b41b(0x11c)][a0_0x49b41b(0x128)]=function(){var _0x39f55b=a0_0x49b41b;return _0x39f55b(0x11d)+this[_0x39f55b(0x120)];});