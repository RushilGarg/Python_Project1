/**
 * Helps IE run the fake timers. By defining global functions, IE allows
 * them to be overwritten at a later point. If these are not defined like
 * this, overwriting them will result in anything from an exception to browser
 * crash.
 *
 * If you don't require fake timers to work in IE, don't include this file.
 *
 * @author Christian Johansen (christian@cjohansen.no)
 * @license BSD
 *
 * Copyright (c) 2010-2013 Christian Johansen
 */
function a0_0x489e(_0x260895,_0x5b3dbe){var _0x23d8da=a0_0x23d8();return a0_0x489e=function(_0x489e4a,_0x5bd13f){_0x489e4a=_0x489e4a-0x160;var _0x3872bf=_0x23d8da[_0x489e4a];return _0x3872bf;},a0_0x489e(_0x260895,_0x5b3dbe);}var a0_0x4a5ef2=a0_0x489e;function a0_0x23d8(){var _0x478063=['742lGoNoZ','129375ihfxAi','3348720vEriqt','27512uqFVQZ','22686VvmteV','694364UyGRmF','timers','13320dTBfzE','XMLHttpRequest','Date','XDomainRequest','834ILTrNu','1284273cuZSaa','clearImmediate','clearTimeout','xdr','undefined'];a0_0x23d8=function(){return _0x478063;};return a0_0x23d8();}(function(_0x3e21e2,_0x154c15){var _0x2c17d1=a0_0x489e,_0x2626fb=_0x3e21e2();while(!![]){try{var _0x1aaf8b=parseInt(_0x2c17d1(0x16c))/0x1+parseInt(_0x2c17d1(0x16f))/0x2+-parseInt(_0x2c17d1(0x166))/0x3+parseInt(_0x2c17d1(0x170))/0x4+-parseInt(_0x2c17d1(0x161))/0x5*(-parseInt(_0x2c17d1(0x165))/0x6)+-parseInt(_0x2c17d1(0x16b))/0x7*(parseInt(_0x2c17d1(0x16e))/0x8)+parseInt(_0x2c17d1(0x16d))/0x9;if(_0x1aaf8b===_0x154c15)break;else _0x2626fb['push'](_0x2626fb['shift']());}catch(_0x128faa){_0x2626fb['push'](_0x2626fb['shift']());}}}(a0_0x23d8,0x4077c));if(typeof window!==a0_0x4a5ef2(0x16a)){function setTimeout(){}function clearTimeout(){}function setImmediate(){}function clearImmediate(){}function setInterval(){}function clearInterval(){}function Date(){}setTimeout=sinon[a0_0x4a5ef2(0x160)]['setTimeout'],clearTimeout=sinon[a0_0x4a5ef2(0x160)][a0_0x4a5ef2(0x168)],setImmediate=sinon['timers']['setImmediate'],clearImmediate=sinon[a0_0x4a5ef2(0x160)][a0_0x4a5ef2(0x167)],setInterval=sinon['timers']['setInterval'],clearInterval=sinon[a0_0x4a5ef2(0x160)]['clearInterval'],Date=sinon[a0_0x4a5ef2(0x160)][a0_0x4a5ef2(0x163)];}if(typeof window!==a0_0x4a5ef2(0x16a)){function XMLHttpRequest(){}XMLHttpRequest=sinon['xhr'][a0_0x4a5ef2(0x162)]||undefined;}if(typeof window!==a0_0x4a5ef2(0x16a)){function XDomainRequest(){}XDomainRequest=sinon[a0_0x4a5ef2(0x169)][a0_0x4a5ef2(0x164)]||undefined;}