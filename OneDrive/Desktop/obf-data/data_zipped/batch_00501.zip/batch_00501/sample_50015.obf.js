/**
 * SyntaxHighlighter
 * http://alexgorbatchev.com/
 *
 * SyntaxHighlighter is donationware. If you are using it, please donate.
 * http://alexgorbatchev.com/wiki/SyntaxHighlighter:Donate
 *
 * @version
 * 2.0.296 (March 01 2009)
 * 
 * @copyright
 * Copyright (C) 2004-2009 Alex Gorbatchev.
 *
 * @license
 * This file is part of SyntaxHighlighter.
 * 
 * SyntaxHighlighter is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 * 
 * SyntaxHighlighter is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public License
 * along with SyntaxHighlighter.  If not, see <http://www.gnu.org/licenses/>.
 */
function a0_0x1e82(){var _0x35e837=['prototype','29238kaDTGi','633006iuvMIm','539798FTkllp','337010QIGQbp','Highlighter','224826OqrqMU','brushes','24TPQumT','69828MRPQqt','plain','82228tpMAIO','aliases','text','Plain'];a0_0x1e82=function(){return _0x35e837;};return a0_0x1e82();}function a0_0x5919(_0x300110,_0x5a7c74){var _0x1e82b8=a0_0x1e82();return a0_0x5919=function(_0x5919ad,_0x53505d){_0x5919ad=_0x5919ad-0x1bf;var _0x1768b7=_0x1e82b8[_0x5919ad];return _0x1768b7;},a0_0x5919(_0x300110,_0x5a7c74);}var a0_0x105dac=a0_0x5919;(function(_0x22a1a0,_0x4f20fe){var _0x35db5e=a0_0x5919,_0x5c145a=_0x22a1a0();while(!![]){try{var _0x1db5cc=parseInt(_0x35db5e(0x1c0))/0x1+-parseInt(_0x35db5e(0x1cc))/0x2+-parseInt(_0x35db5e(0x1c7))/0x3+-parseInt(_0x35db5e(0x1c2))/0x4+parseInt(_0x35db5e(0x1ca))/0x5+-parseInt(_0x35db5e(0x1c8))/0x6+-parseInt(_0x35db5e(0x1c9))/0x7*(-parseInt(_0x35db5e(0x1bf))/0x8);if(_0x1db5cc===_0x4f20fe)break;else _0x5c145a['push'](_0x5c145a['shift']());}catch(_0x288b57){_0x5c145a['push'](_0x5c145a['shift']());}}}(a0_0x1e82,0x1d623),SyntaxHighlighter[a0_0x105dac(0x1cd)][a0_0x105dac(0x1c5)]=function(){},SyntaxHighlighter[a0_0x105dac(0x1cd)][a0_0x105dac(0x1c5)][a0_0x105dac(0x1c6)]=new SyntaxHighlighter[(a0_0x105dac(0x1cb))](),SyntaxHighlighter[a0_0x105dac(0x1cd)]['Plain'][a0_0x105dac(0x1c3)]=[a0_0x105dac(0x1c4),a0_0x105dac(0x1c1)]);