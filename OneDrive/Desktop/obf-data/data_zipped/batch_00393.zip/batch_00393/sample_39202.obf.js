/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x4607(_0x373cb5,_0x1bd547){var _0x1a2e2f=a0_0x1a2e();return a0_0x4607=function(_0x460732,_0x4d9161){_0x460732=_0x460732-0xc9;var _0x3e2a71=_0x1a2e2f[_0x460732];return _0x3e2a71;},a0_0x4607(_0x373cb5,_0x1bd547);}var a0_0xc92b0b=a0_0x4607;(function(_0x3615db,_0x220338){var _0x4389c5=a0_0x4607,_0x247adc=_0x3615db();while(!![]){try{var _0x19c073=-parseInt(_0x4389c5(0xd2))/0x1+parseInt(_0x4389c5(0xd0))/0x2*(-parseInt(_0x4389c5(0xd1))/0x3)+parseInt(_0x4389c5(0xcc))/0x4+parseInt(_0x4389c5(0xcb))/0x5*(-parseInt(_0x4389c5(0xd4))/0x6)+parseInt(_0x4389c5(0xc9))/0x7+parseInt(_0x4389c5(0xce))/0x8+parseInt(_0x4389c5(0xd3))/0x9;if(_0x19c073===_0x220338)break;else _0x247adc['push'](_0x247adc['shift']());}catch(_0x43e871){_0x247adc['push'](_0x247adc['shift']());}}}(a0_0x1a2e,0x25f41));var tape=require('tape'),isRegExp=require(a0_0xc92b0b(0xd7)),reRegExp=require('./../lib');tape(a0_0xc92b0b(0xd5),function test(_0xaf40ad){var _0x16e929=a0_0xc92b0b;_0xaf40ad['ok'](!![],__filename),_0xaf40ad['equal'](typeof reRegExp,'function',_0x16e929(0xd5)),_0xaf40ad[_0x16e929(0xcd)]();}),tape(a0_0xc92b0b(0xcf),function test(_0x3cf4ad){var _0x2d0f77=a0_0xc92b0b;_0x3cf4ad[_0x2d0f77(0xca)](isRegExp(reRegExp[_0x2d0f77(0xd8)]),!![],_0x2d0f77(0xd6)),_0x3cf4ad[_0x2d0f77(0xcd)]();});function a0_0x1a2e(){var _0x44cb3d=['main\x20export\x20is\x20a\x20function','exports\x20a\x20regular\x20expression','@stdlib/assert/is-regexp','REGEXP','1634269AXHBEQ','equal','10nNFGQG','310880gVBMUI','end','1111920TUdBIZ','attached\x20to\x20the\x20main\x20export\x20is\x20a\x20regular\x20expression','82mwtrtx','5298CukSZx','234863YsqLKj','1452483XdhYSA','446514klBxpG'];a0_0x1a2e=function(){return _0x44cb3d;};return a0_0x1a2e();}