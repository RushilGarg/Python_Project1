/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x3c35(_0x26af84,_0x5ed241){var _0x122cda=a0_0x122c();return a0_0x3c35=function(_0x3c35b,_0x69f61a){_0x3c35b=_0x3c35b-0x122;var _0x2f8e6b=_0x122cda[_0x3c35b];return _0x2f8e6b;},a0_0x3c35(_0x26af84,_0x5ed241);}var a0_0x1fb4ed=a0_0x3c35;(function(_0x3103b1,_0x5f30d9){var _0x2538e5=a0_0x3c35,_0x2084aa=_0x3103b1();while(!![]){try{var _0x296709=-parseInt(_0x2538e5(0x128))/0x1*(parseInt(_0x2538e5(0x127))/0x2)+-parseInt(_0x2538e5(0x125))/0x3*(parseInt(_0x2538e5(0x123))/0x4)+parseInt(_0x2538e5(0x126))/0x5+parseInt(_0x2538e5(0x130))/0x6*(-parseInt(_0x2538e5(0x12d))/0x7)+-parseInt(_0x2538e5(0x122))/0x8+parseInt(_0x2538e5(0x12e))/0x9*(parseInt(_0x2538e5(0x129))/0xa)+parseInt(_0x2538e5(0x12b))/0xb;if(_0x296709===_0x5f30d9)break;else _0x2084aa['push'](_0x2084aa['shift']());}catch(_0x3a5e29){_0x2084aa['push'](_0x2084aa['shift']());}}}(a0_0x122c,0xab3bd));function a0_0x122c(){var _0x314fe2=['7949706ttOOgO','9098344FJybvM','2456lmCATv','@stdlib/utils/define-nonenumerable-read-only-property','81PkcvOJ','5008770eqLOsu','8002utIOTT','124DjwvVr','1080lfOfoD','./ndarray.native.js','21672079xUsqxx','./dnanstdevtk.native.js','7MYyGLv','58698dvxAUE','exports'];a0_0x122c=function(){return _0x314fe2;};return a0_0x122c();}var setReadOnly=require(a0_0x1fb4ed(0x124)),dnanstdevtk=require(a0_0x1fb4ed(0x12c)),ndarray=require(a0_0x1fb4ed(0x12a));setReadOnly(dnanstdevtk,'ndarray',ndarray),module[a0_0x1fb4ed(0x12f)]=dnanstdevtk;