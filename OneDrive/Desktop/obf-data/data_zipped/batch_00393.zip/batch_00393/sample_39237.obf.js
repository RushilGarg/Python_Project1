/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2d05cb=a0_0x2a78;(function(_0x57df49,_0xd56df3){var _0x4da4c0=a0_0x2a78,_0x2e5033=_0x57df49();while(!![]){try{var _0x269bb4=-parseInt(_0x4da4c0(0x17c))/0x1*(-parseInt(_0x4da4c0(0x17d))/0x2)+-parseInt(_0x4da4c0(0x17e))/0x3+parseInt(_0x4da4c0(0x17f))/0x4*(parseInt(_0x4da4c0(0x17a))/0x5)+parseInt(_0x4da4c0(0x179))/0x6*(-parseInt(_0x4da4c0(0x181))/0x7)+parseInt(_0x4da4c0(0x183))/0x8+parseInt(_0x4da4c0(0x180))/0x9+-parseInt(_0x4da4c0(0x17b))/0xa;if(_0x269bb4===_0xd56df3)break;else _0x2e5033['push'](_0x2e5033['shift']());}catch(_0x28a587){_0x2e5033['push'](_0x2e5033['shift']());}}}(a0_0x2c27,0x9822d));function a0_0x2c27(){var _0x26ebde=['5349304HafDHT','19182emVGmg','15jXyiVx','7741120AlJNhp','518239jLnYoc','2JYvGAq','3607920bgUzud','966732zIIKbQ','8781120JZmflY','630DEfbRh','exports'];a0_0x2c27=function(){return _0x26ebde;};return a0_0x2c27();}function a0_0x2a78(_0x1e3b36,_0x416c67){var _0x2c2766=a0_0x2c27();return a0_0x2a78=function(_0x2a7839,_0x52b8ab){_0x2a7839=_0x2a7839-0x179;var _0xb255d0=_0x2c2766[_0x2a7839];return _0xb255d0;},a0_0x2a78(_0x1e3b36,_0x416c67);}var kurtosis=require('./kurtosis.js');module[a0_0x2d05cb(0x182)]=kurtosis;