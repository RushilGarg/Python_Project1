/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x45eb8c=a0_0xe468;function a0_0x1a1f(){var _0x8ee0ca=['stdin','276hCRiYn','518784pBgsmT','object','is\x20an\x20alias','592273OHkGtS','1060938VdjgyS','the\x20export\x20is\x20an\x20alias\x20for\x20`process.stdin`','112844dMKnOF','915835vdcvbA','12VrguXR','1118256TnWuqb','30qLcvyO','./../lib','process','tape','233005XHCyhz','12JDsJCv','equal','63yTelLd','main\x20export\x20is\x20an\x20object','end'];a0_0x1a1f=function(){return _0x8ee0ca;};return a0_0x1a1f();}(function(_0x5e9d5f,_0x2f4e03){var _0x44d919=a0_0xe468,_0x4dfd31=_0x5e9d5f();while(!![]){try{var _0x424b34=parseInt(_0x44d919(0xb2))/0x1*(parseInt(_0x44d919(0xac))/0x2)+-parseInt(_0x44d919(0xb5))/0x3*(-parseInt(_0x44d919(0xc0))/0x4)+parseInt(_0x44d919(0xc1))/0x5*(-parseInt(_0x44d919(0xb3))/0x6)+-parseInt(_0x44d919(0xba))/0x7+parseInt(_0x44d919(0xad))/0x8+-parseInt(_0x44d919(0xbe))/0x9*(-parseInt(_0x44d919(0xae))/0xa)+parseInt(_0x44d919(0xbd))/0xb*(-parseInt(_0x44d919(0xb9))/0xc);if(_0x424b34===_0x2f4e03)break;else _0x4dfd31['push'](_0x4dfd31['shift']());}catch(_0x318555){_0x4dfd31['push'](_0x4dfd31['shift']());}}}(a0_0x1a1f,0xc48be));var proc=require(a0_0x45eb8c(0xb0)),tape=require(a0_0x45eb8c(0xb1)),stdin=require(a0_0x45eb8c(0xaf));function a0_0xe468(_0x2facc4,_0x2964a3){var _0x1a1fb=a0_0x1a1f();return a0_0xe468=function(_0xe468ac,_0x5b1714){_0xe468ac=_0xe468ac-0xac;var _0x5148dc=_0x1a1fb[_0xe468ac];return _0x5148dc;},a0_0xe468(_0x2facc4,_0x2964a3);}tape(a0_0x45eb8c(0xb6),function test(_0x3e5b15){var _0x4351b8=a0_0x45eb8c;_0x3e5b15['ok'](!![],__filename),_0x3e5b15[_0x4351b8(0xb4)](typeof stdin,_0x4351b8(0xbb),'main\x20export\x20is\x20an\x20object'),_0x3e5b15['end']();}),tape(a0_0x45eb8c(0xbf),function test(_0x4db62d){var _0x624dbd=a0_0x45eb8c;_0x4db62d[_0x624dbd(0xb4)](stdin,proc[_0x624dbd(0xb8)],_0x624dbd(0xbc)),_0x4db62d[_0x624dbd(0xb7)]();});