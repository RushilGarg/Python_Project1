/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x4f3c64=a0_0x532d;(function(_0x4a7567,_0x12b64a){var _0x5843ec=a0_0x532d,_0x3e61e3=_0x4a7567();while(!![]){try{var _0x37505f=parseInt(_0x5843ec(0x186))/0x1+parseInt(_0x5843ec(0x176))/0x2*(-parseInt(_0x5843ec(0x17e))/0x3)+parseInt(_0x5843ec(0x174))/0x4*(parseInt(_0x5843ec(0x17c))/0x5)+parseInt(_0x5843ec(0x177))/0x6*(-parseInt(_0x5843ec(0x179))/0x7)+-parseInt(_0x5843ec(0x17d))/0x8*(-parseInt(_0x5843ec(0x17f))/0x9)+parseInt(_0x5843ec(0x180))/0xa*(-parseInt(_0x5843ec(0x175))/0xb)+parseInt(_0x5843ec(0x185))/0xc;if(_0x37505f===_0x12b64a)break;else _0x3e61e3['push'](_0x3e61e3['shift']());}catch(_0x5cb17b){_0x3e61e3['push'](_0x3e61e3['shift']());}}}(a0_0x545b,0xafd63),CLASS({'package':a0_0x4f3c64(0x17b),'name':a0_0x4f3c64(0x178),'requires':['foam.ui.TableView'],'properties':[{'type':a0_0x4f3c64(0x173),'name':a0_0x4f3c64(0x187)},{'type':a0_0x4f3c64(0x173),'name':a0_0x4f3c64(0x184)},{'name':a0_0x4f3c64(0x17a),'view':a0_0x4f3c64(0x188)}],'actions':[{'name':a0_0x4f3c64(0x183),'code':function(){var _0x3f96c3=a0_0x4f3c64;this['X'][_0x3f96c3(0x181)]['find'](this[_0x3f96c3(0x187)],{'put':function(_0x1c00bb){var _0x37dd66=_0x3f96c3;this[_0x37dd66(0x17a)]=_0x1c00bb;}['bind'](this),'error':function(_0x13103c){this['errorMessage']=''+_0x13103c;}[_0x3f96c3(0x182)](this)});}}]}));function a0_0x532d(_0x1475c4,_0x56bbb0){var _0x545b97=a0_0x545b();return a0_0x532d=function(_0x532d73,_0x629015){_0x532d73=_0x532d73-0x173;var _0x3106d5=_0x545b97[_0x532d73];return _0x3106d5;},a0_0x532d(_0x1475c4,_0x56bbb0);}function a0_0x545b(){var _0x57b40f=['bind','test','errorMessage','2383176KjrZJL','698068Fokvxq','objId','foam.ui.DetailView','String','44wZuLst','268587QVLhCP','222kHvQBP','38274YbEdMZ','BrowserFileDAO','385tUCjLq','value','foam.demos','501865NOGBJG','296MtTPaC','22224xwyEKp','270837LUvoVZ','500affRXe','ModelDAO'];a0_0x545b=function(){return _0x57b40f;};return a0_0x545b();}