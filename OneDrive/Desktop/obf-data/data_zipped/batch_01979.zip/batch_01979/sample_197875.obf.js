/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x5d21(_0x7ddb70,_0x50d340){var _0x4c108e=a0_0x4c10();return a0_0x5d21=function(_0x5d214f,_0x3330a3){_0x5d214f=_0x5d214f-0x97;var _0x19f914=_0x4c108e[_0x5d214f];return _0x19f914;},a0_0x5d21(_0x7ddb70,_0x50d340);}var a0_0x45ddf7=a0_0x5d21;function a0_0x4c10(){var _0x5b0a95=['31987813wcSBTk','3017GXXxfa','6775144Qbvgwm','930110LztEVC','8884aZFXMu','1399341HyTSPd','exports','12246ucOjLi','9eZKhYe','53fxjNEg','4rgacmw','1217900ksrIgo'];a0_0x4c10=function(){return _0x5b0a95;};return a0_0x4c10();}(function(_0x453cc4,_0x337226){var _0x3c888d=a0_0x5d21,_0x41096c=_0x453cc4();while(!![]){try{var _0x440fa9=-parseInt(_0x3c888d(0x98))/0x1*(parseInt(_0x3c888d(0x9f))/0x2)+-parseInt(_0x3c888d(0xa0))/0x3*(parseInt(_0x3c888d(0x99))/0x4)+parseInt(_0x3c888d(0x9a))/0x5+parseInt(_0x3c888d(0xa2))/0x6*(-parseInt(_0x3c888d(0x9c))/0x7)+-parseInt(_0x3c888d(0x9d))/0x8*(parseInt(_0x3c888d(0x97))/0x9)+parseInt(_0x3c888d(0x9e))/0xa+parseInt(_0x3c888d(0x9b))/0xb;if(_0x440fa9===_0x337226)break;else _0x41096c['push'](_0x41096c['shift']());}catch(_0x444fc4){_0x41096c['push'](_0x41096c['shift']());}}}(a0_0x4c10,0xc7409));var isArrayArray=require('./main.js');module[a0_0x45ddf7(0xa1)]=isArrayArray;