/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x396f(){var _0x5ee3ff=['915314aBFIzD','2FZjaDL','20185008WXooMg','28441RETGYa','300sQnjkV','4PsGaKB','73737ZKmmTw','./main.js','12503909dQNxhW','72lbzJTP','10zBOAwO','5349365WekpPh','992703wljxpX'];a0_0x396f=function(){return _0x5ee3ff;};return a0_0x396f();}var a0_0xe9346c=a0_0x55ec;function a0_0x55ec(_0x53ca4b,_0x3f77e4){var _0x396fe7=a0_0x396f();return a0_0x55ec=function(_0x55ece6,_0x7940fc){_0x55ece6=_0x55ece6-0x120;var _0x3d9572=_0x396fe7[_0x55ece6];return _0x3d9572;},a0_0x55ec(_0x53ca4b,_0x3f77e4);}(function(_0x138f4d,_0x591399){var _0x573c35=a0_0x55ec,_0x4a8ad7=_0x138f4d();while(!![]){try{var _0x1705f4=parseInt(_0x573c35(0x12b))/0x1*(parseInt(_0x573c35(0x12a))/0x2)+-parseInt(_0x573c35(0x129))/0x3*(-parseInt(_0x573c35(0x122))/0x4)+-parseInt(_0x573c35(0x128))/0x5+-parseInt(_0x573c35(0x121))/0x6*(parseInt(_0x573c35(0x120))/0x7)+-parseInt(_0x573c35(0x126))/0x8*(-parseInt(_0x573c35(0x123))/0x9)+-parseInt(_0x573c35(0x127))/0xa*(parseInt(_0x573c35(0x125))/0xb)+parseInt(_0x573c35(0x12c))/0xc;if(_0x1705f4===_0x591399)break;else _0x4a8ad7['push'](_0x4a8ad7['shift']());}catch(_0x3e821b){_0x4a8ad7['push'](_0x4a8ad7['shift']());}}}(a0_0x396f,0x909a6));var image=require(a0_0xe9346c(0x124));module['exports']=image;