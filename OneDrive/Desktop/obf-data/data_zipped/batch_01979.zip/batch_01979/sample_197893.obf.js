/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x5a0b34=a0_0x57bd;(function(_0x3e7a51,_0x548432){var _0x274c8d=a0_0x57bd,_0xaf7e60=_0x3e7a51();while(!![]){try{var _0x136ece=parseInt(_0x274c8d(0x18c))/0x1*(parseInt(_0x274c8d(0x191))/0x2)+parseInt(_0x274c8d(0x194))/0x3*(parseInt(_0x274c8d(0x197))/0x4)+-parseInt(_0x274c8d(0x18e))/0x5*(parseInt(_0x274c8d(0x192))/0x6)+-parseInt(_0x274c8d(0x198))/0x7*(parseInt(_0x274c8d(0x199))/0x8)+parseInt(_0x274c8d(0x18d))/0x9+-parseInt(_0x274c8d(0x190))/0xa*(parseInt(_0x274c8d(0x195))/0xb)+parseInt(_0x274c8d(0x193))/0xc;if(_0x136ece===_0x548432)break;else _0xaf7e60['push'](_0xaf7e60['shift']());}catch(_0x22abce){_0xaf7e60['push'](_0xaf7e60['shift']());}}}(a0_0x475a,0x51458));function a0_0x475a(){var _0x4c25fc=['272ghKdKk','17268Oyzmxs','16504188JEDGyX','1365uzKAtX','66RLpiyr','./../lib','1724ieBpNB','7zyxESV','2754312ZBhsFL','log','757SwSsEa','1133109Oroyie','955pPVhbt','%d\x20+\x20%d\x20=\x20%d','955720hXZIVa'];a0_0x475a=function(){return _0x4c25fc;};return a0_0x475a();}function a0_0x57bd(_0x5ec82c,_0x639007){var _0x475abd=a0_0x475a();return a0_0x57bd=function(_0x57bdd8,_0x430b41){_0x57bdd8=_0x57bdd8-0x18c;var _0xeaa280=_0x475abd[_0x57bdd8];return _0xeaa280;},a0_0x57bd(_0x5ec82c,_0x639007);}var rand=require('@stdlib/random/base/discrete-uniform'),addf=require(a0_0x5a0b34(0x196)),x,y,i;for(i=0x0;i<0x64;i++){x=rand(-0x32,0x32),y=rand(-0x32,0x32),console[a0_0x5a0b34(0x19a)](a0_0x5a0b34(0x18f),x,y,addf(x,y));}