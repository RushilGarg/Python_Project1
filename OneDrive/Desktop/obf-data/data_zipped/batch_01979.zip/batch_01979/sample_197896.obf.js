/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x463d(_0x41c2b6,_0x14ee99){var _0x2254f5=a0_0x2254();return a0_0x463d=function(_0x463d88,_0x1caa2f){_0x463d88=_0x463d88-0x9e;var _0x8c4d5d=_0x2254f5[_0x463d88];return _0x8c4d5d;},a0_0x463d(_0x41c2b6,_0x14ee99);}var a0_0x41a9b0=a0_0x463d;function a0_0x2254(){var _0x1672ac=['2338372rojffI','599562iRukny','4501JwkEwg','15320bLNFgl','3gOdVQe','6vcfjly','882082hxtkWd','11VGTcpM','2393950WBcXjz','1909945GOFtJt','@stdlib/math/base/special/exp','exports','@stdlib/math/base/assert/is-nan','30941610EAdfPR'];a0_0x2254=function(){return _0x1672ac;};return a0_0x2254();}(function(_0x2279b3,_0x4b28cf){var _0x172454=a0_0x463d,_0x190dfb=_0x2279b3();while(!![]){try{var _0x841218=-parseInt(_0x172454(0xab))/0x1+-parseInt(_0x172454(0x9f))/0x2+parseInt(_0x172454(0xa9))/0x3*(parseInt(_0x172454(0xa5))/0x4)+-parseInt(_0x172454(0xa0))/0x5*(-parseInt(_0x172454(0xaa))/0x6)+-parseInt(_0x172454(0xa7))/0x7*(parseInt(_0x172454(0xa8))/0x8)+-parseInt(_0x172454(0xa6))/0x9+parseInt(_0x172454(0xa4))/0xa*(parseInt(_0x172454(0x9e))/0xb);if(_0x841218===_0x4b28cf)break;else _0x190dfb['push'](_0x190dfb['shift']());}catch(_0x320c51){_0x190dfb['push'](_0x190dfb['shift']());}}}(a0_0x2254,0xa6ecb));var isnan=require(a0_0x41a9b0(0xa3)),exp=require(a0_0x41a9b0(0xa1));function cdf(_0x5f1b08,_0x115b0c,_0x4f613d){var _0x440776;if(isnan(_0x5f1b08)||isnan(_0x115b0c)||isnan(_0x4f613d)||_0x4f613d<=0x0)return NaN;return _0x440776=(_0x5f1b08-_0x115b0c)/_0x4f613d,exp(-exp(-_0x440776));}module[a0_0x41a9b0(0xa2)]=cdf;