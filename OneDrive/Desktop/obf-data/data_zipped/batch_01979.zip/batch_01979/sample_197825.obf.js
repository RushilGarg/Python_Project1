/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x32b8(){var _0xc76a22=['6zOjQkZ','exports','747733SokAGO','boop','38xzHNOt','12umwmDY','36XnByMM','3769792snuWYz','15345770xEfFHf','https','989647SOvGOz','8929512jsADwn','133023VfuYeG','10fXIecK','api.github.com','beep','387215AwxaBl','public_repo'];a0_0x32b8=function(){return _0xc76a22;};return a0_0x32b8();}var a0_0xdf9bb2=a0_0x4f5a;(function(_0x26f851,_0x528ff9){var _0x113659=a0_0x4f5a,_0x99408d=_0x26f851();while(!![]){try{var _0x5cde06=-parseInt(_0x113659(0x7d))/0x1+parseInt(_0x113659(0x89))/0x2*(parseInt(_0x113659(0x7f))/0x3)+-parseInt(_0x113659(0x8b))/0x4*(-parseInt(_0x113659(0x83))/0x5)+-parseInt(_0x113659(0x85))/0x6*(parseInt(_0x113659(0x87))/0x7)+parseInt(_0x113659(0x7a))/0x8+parseInt(_0x113659(0x7e))/0x9*(parseInt(_0x113659(0x80))/0xa)+parseInt(_0x113659(0x7b))/0xb*(-parseInt(_0x113659(0x8a))/0xc);if(_0x5cde06===_0x528ff9)break;else _0x99408d['push'](_0x99408d['shift']());}catch(_0x1a508e){_0x99408d['push'](_0x99408d['shift']());}}}(a0_0x32b8,0x7cd5a));function a0_0x4f5a(_0x155361,_0xa41314){var _0x32b899=a0_0x32b8();return a0_0x4f5a=function(_0x4f5a51,_0x483092){_0x4f5a51=_0x4f5a51-0x7a;var _0x5543be=_0x32b899[_0x4f5a51];return _0x5543be;},a0_0x4f5a(_0x155361,_0xa41314);}function getOpts(){var _0x416d28=a0_0x4f5a,_0x3b56cb={'username':_0x416d28(0x82),'password':_0x416d28(0x88),'hostname':_0x416d28(0x81),'port':0x1bb,'protocol':_0x416d28(0x7c),'scopes':[_0x416d28(0x84)],'note':'beep'};return _0x3b56cb;}module[a0_0xdf9bb2(0x86)]=getOpts;