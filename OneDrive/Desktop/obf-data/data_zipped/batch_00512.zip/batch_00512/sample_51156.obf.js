function a0_0x5bb9(_0x59a9f4,_0x10ea9e){var _0x5b45e0=a0_0x5b45();return a0_0x5bb9=function(_0x5bb902,_0x42bafc){_0x5bb902=_0x5bb902-0x135;var _0x578d23=_0x5b45e0[_0x5bb902];return _0x578d23;},a0_0x5bb9(_0x59a9f4,_0x10ea9e);}var a0_0x5ba29e=a0_0x5bb9;(function(_0x5323bb,_0x462b5c){var _0x315ebf=a0_0x5bb9,_0x4ac07c=_0x5323bb();while(!![]){try{var _0x5899dd=parseInt(_0x315ebf(0x13b))/0x1+-parseInt(_0x315ebf(0x139))/0x2+-parseInt(_0x315ebf(0x142))/0x3*(parseInt(_0x315ebf(0x141))/0x4)+-parseInt(_0x315ebf(0x136))/0x5+parseInt(_0x315ebf(0x13c))/0x6+parseInt(_0x315ebf(0x135))/0x7*(parseInt(_0x315ebf(0x13f))/0x8)+parseInt(_0x315ebf(0x140))/0x9;if(_0x5899dd===_0x462b5c)break;else _0x4ac07c['push'](_0x4ac07c['shift']());}catch(_0x1dd8eb){_0x4ac07c['push'](_0x4ac07c['shift']());}}}(a0_0x5b45,0xefc63));var html=require(a0_0x5ba29e(0x13e)),css=require(a0_0x5ba29e(0x138)),styles=css`
  .loading {
    height: 100%;
    width: 100%;
    display: flex;
    justify-content: center;
    align-items: center;
  }

  .loader,
  .loader:before,
  .loader:after {
    background: var(--dark);
    -webkit-animation: load1 1s infinite ease-in-out;
    animation: load1 1s infinite ease-in-out;
    width: 1em;
    height: 4em;
  }
  .loader:before,
  .loader:after {
    position: absolute;
    top: 0;
    content: '';
  }
  .loader:before {
    left: -1.5em;
    -webkit-animation-delay: -0.32s;
    animation-delay: -0.32s;
  }
  .loader {
    color: var(--dark);
    text-indent: -9999em;
    margin: 88px auto;
    position: relative;
    font-size: 11px;
    -webkit-transform: translateZ(0);
    -ms-transform: translateZ(0);
    transform: translateZ(0);
    -webkit-animation-delay: -0.16s;
    animation-delay: -0.16s;
  }
  .loader:after {
    left: 1.5em;
  }
  @-webkit-keyframes load1 {
    0%,
    80%,
    100% {
      box-shadow: 0 0;
      height: 4em;
    }
    40% {
      box-shadow: 0 -2em;
      height: 5em;
    }
  }
  @keyframes load1 {
    0%,
    80%,
    100% {
      box-shadow: 0 0;
      height: 4em;
    }
    40% {
      box-shadow: 0 -2em;
      height: 5em;
    }
  }
`;function a0_0x5b45(){var _0x1fe04f=['4ExfpxE','1332789RcWUSw','14462nXYCHa','7850395DMDaLU','loader','csjs-inject','1599768SyeVCk','exports','1528240XiBowg','160128TsmWtA','loading','choo/html','712YXSPsd','18517851kUrHvT'];a0_0x5b45=function(){return _0x1fe04f;};return a0_0x5b45();}module[a0_0x5ba29e(0x13a)]=function loader(){var _0x7c0a83=a0_0x5ba29e;return html`
    <div class="${styles[_0x7c0a83(0x13d)]}">
      <div class="${styles[_0x7c0a83(0x137)]}"></div>
    </div>
  `;};