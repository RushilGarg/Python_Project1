/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x5ebf2a=a0_0x8d8e;(function(_0x18d3c3,_0x21982c){var _0x98eb07=a0_0x8d8e,_0x500699=_0x18d3c3();while(!![]){try{var _0x191df2=-parseInt(_0x98eb07(0xde))/0x1*(parseInt(_0x98eb07(0xef))/0x2)+parseInt(_0x98eb07(0xe1))/0x3*(parseInt(_0x98eb07(0xdf))/0x4)+-parseInt(_0x98eb07(0xf1))/0x5*(parseInt(_0x98eb07(0xdc))/0x6)+parseInt(_0x98eb07(0xe2))/0x7+parseInt(_0x98eb07(0xec))/0x8*(parseInt(_0x98eb07(0xe5))/0x9)+-parseInt(_0x98eb07(0xed))/0xa*(parseInt(_0x98eb07(0xdb))/0xb)+-parseInt(_0x98eb07(0xe0))/0xc*(-parseInt(_0x98eb07(0xd9))/0xd);if(_0x191df2===_0x21982c)break;else _0x500699['push'](_0x500699['shift']());}catch(_0x15a00f){_0x500699['push'](_0x500699['shift']());}}}(a0_0x516c,0x5488b));function a0_0x8d8e(_0x518d1e,_0x465b05){var _0x516c1b=a0_0x516c();return a0_0x8d8e=function(_0x8d8e38,_0x273c2b){_0x8d8e38=_0x8d8e38-0xd8;var _0x395c5f=_0x516c1b[_0x8d8e38];return _0x395c5f;},a0_0x8d8e(_0x518d1e,_0x465b05);}var resolve=require('path')[a0_0x5ebf2a(0xe6)],writeFileSync=require(a0_0x5ebf2a(0xe8))[a0_0x5ebf2a(0xd8)],replace=require('@stdlib/string/replace'),FILE_LIST=require(a0_0x5ebf2a(0xe7)),RE_EXT=/\.txt$/;function main(){var _0x5605b6=a0_0x5ebf2a,_0x37cc96,_0x21933c,_0xa47afd,_0x185257,_0x53a63a,_0x173b98;_0xa47afd=FILE_LIST['length'],_0x185257='',_0x185257+='//\x20This\x20file\x20is\x20generated\x20using\x20`scripts/build.js`.\x0a',_0x185257+='\x27use\x20strict\x27;\x0a\x0a',_0x185257+=_0x5605b6(0xdd)+_0xa47afd+_0x5605b6(0xe4);for(_0x173b98=0x0;_0x173b98<_0xa47afd;_0x173b98++){_0x53a63a=replace(FILE_LIST[_0x173b98],RE_EXT,_0x5605b6(0xe3)),_0x185257+=_0x5605b6(0xf0)+_0x173b98+_0x5605b6(0xea)+_0x53a63a+_0x5605b6(0xe9);}_0x185257+='\x0a\x0a//\x20EXPORTS\x20//\x0a\x0a',_0x185257+=_0x5605b6(0xee),_0x21933c={'encoding':_0x5605b6(0xf2)},_0x37cc96=resolve(__dirname,'..',_0x5605b6(0xda),_0x5605b6(0xeb)),writeFileSync(_0x37cc96,_0x185257,_0x21933c);}function a0_0x516c(){var _0x1cf2c2=['1266205pfDWXu','utf8','sync','715AIWBrf','data','1914Gvftiz','6asyYLq','var\x20data\x20=\x20new\x20Array(\x20','6yachNK','8JFaQnv','27144qcawcr','453972KDgNWZ','4772026RGvsly','.json','\x20);\x0a','9fWrZdB','resolve','./../data/file_list.json','@stdlib/fs/write-file','\x27\x20);\x0a','\x20]\x20=\x20require(\x20\x27./','data.js','304288OzPlZN','10070YsLptU','module.exports\x20=\x20data;\x0a','124034SlvTnz','data[\x20'];a0_0x516c=function(){return _0x1cf2c2;};return a0_0x516c();}main();