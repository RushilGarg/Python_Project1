/**
 * @license
 * Copyright (C) 2020 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const a0_0x423d9f=a0_0x21b5;function a0_0x21b5(_0x274c0d,_0x5c009f){const _0x4f7758=a0_0x4f77();return a0_0x21b5=function(_0x21b599,_0x26c126){_0x21b599=_0x21b599-0x108;let _0x5d070e=_0x4f7758[_0x21b599];return _0x5d070e;},a0_0x21b5(_0x274c0d,_0x5c009f);}(function(_0x2b7352,_0x35c1a8){const _0x364627=a0_0x21b5,_0x4410f1=_0x2b7352();while(!![]){try{const _0x2b761f=-parseInt(_0x364627(0x10f))/0x1*(parseInt(_0x364627(0x10e))/0x2)+parseInt(_0x364627(0x116))/0x3+-parseInt(_0x364627(0x10a))/0x4*(parseInt(_0x364627(0x109))/0x5)+parseInt(_0x364627(0x114))/0x6+parseInt(_0x364627(0x112))/0x7+-parseInt(_0x364627(0x11a))/0x8*(-parseInt(_0x364627(0x10b))/0x9)+parseInt(_0x364627(0x10d))/0xa*(parseInt(_0x364627(0x110))/0xb);if(_0x2b761f===_0x35c1a8)break;else _0x4410f1['push'](_0x4410f1['shift']());}catch(_0x5b8255){_0x4410f1['push'](_0x4410f1['shift']());}}}(a0_0x4f77,0xd0896));const {spawnSync}=require(a0_0x423d9f(0x118)),path=require(a0_0x423d9f(0x10c)),nodePath=process[a0_0x423d9f(0x119)][0x0],scriptArgs=process[a0_0x423d9f(0x119)][a0_0x423d9f(0x117)](0x2),nodeArgs=process[a0_0x423d9f(0x11c)],pathToBin=require[a0_0x423d9f(0x108)](a0_0x423d9f(0x115)),options={'stdio':'inherit'},spawnResult=spawnSync(nodePath,[...nodeArgs,pathToBin,...scriptArgs],options);spawnResult['status']!==null&&process[a0_0x423d9f(0x111)](spawnResult[a0_0x423d9f(0x11b)]);spawnResult[a0_0x423d9f(0x113)]&&(console[a0_0x423d9f(0x113)](spawnResult[a0_0x423d9f(0x113)]),process[a0_0x423d9f(0x111)](0x1));function a0_0x4f77(){const _0x120cd8=['error','4009464hToXaE','rollup/dist/bin/rollup','2802114XyRrUr','slice','child_process','argv','24680ewBVkY','status','execArgv','resolve','5Lmoeyz','5611548mPDSfr','3213mOprUI','path','30QIaFeU','24784jpkZbl','80UiqbTG','1731697BfODpY','exit','507535wHcUVs'];a0_0x4f77=function(){return _0x120cd8;};return a0_0x4f77();}