/**
@license
Copyright (c) 2015 The Polymer Project Authors. All rights reserved.
This code may only be used under the BSD style license found at
http://polymer.github.io/LICENSE.txt The complete set of authors may be found at
http://polymer.github.io/AUTHORS.txt The complete set of contributors may be
found at http://polymer.github.io/CONTRIBUTORS.txt Code distributed by Google as
part of the polymer project is also subject to an additional IP rights grant
found at http://polymer.github.io/PATENTS.txt
*/
var a0_0x41d6d6=a0_0x48f8;(function(_0x5e4c22,_0x3ca8bb){var _0x1f5274=a0_0x48f8,_0x58053c=_0x5e4c22();while(!![]){try{var _0x2ecc46=parseInt(_0x1f5274(0x183))/0x1+-parseInt(_0x1f5274(0x16f))/0x2*(-parseInt(_0x1f5274(0x181))/0x3)+-parseInt(_0x1f5274(0x169))/0x4*(-parseInt(_0x1f5274(0x188))/0x5)+-parseInt(_0x1f5274(0x17b))/0x6+-parseInt(_0x1f5274(0x172))/0x7*(parseInt(_0x1f5274(0x165))/0x8)+-parseInt(_0x1f5274(0x18c))/0x9*(-parseInt(_0x1f5274(0x17e))/0xa)+-parseInt(_0x1f5274(0x180))/0xb*(-parseInt(_0x1f5274(0x178))/0xc);if(_0x2ecc46===_0x3ca8bb)break;else _0x58053c['push'](_0x58053c['shift']());}catch(_0xcf352){_0x58053c['push'](_0x58053c['shift']());}}}(a0_0x1e9f,0xab9d4));import{IronA11yAnnouncer}from'@polymer/iron-a11y-announcer/iron-a11y-announcer.js';import{IronOverlayBehavior,IronOverlayBehaviorImpl}from'@polymer/iron-overlay-behavior/iron-overlay-behavior.js';import{Polymer}from'@polymer/polymer/lib/legacy/polymer-fn.js';function a0_0x1e9f(){var _0x3b0ce3=['requestAvailability','add','146902SQwwZW','_finishRenderClosed','_canAutoClose','\x22\x20is\x20not\x20valid.','classList','propertyName','120AElbjU','_openedChanged','opacity','7762998kKkVUt','apply','string','3762650PpNAQo','async','718729DVaXas','3hIIWMu','positionTarget','439137udZJjd','indexOf','paper-toast','The\x20property\x20\x22','close','16525CWcede','opened','open','_onFitIntoChanged','9hAwzXb','left','328eYGJAQ','duration','__onTransitionEnd','remove','760YWWQqw','text','target','_warn','paper-toast-open','_autoClose','1520898PvxgAa'];a0_0x1e9f=function(){return _0x3b0ce3;};return a0_0x1e9f();}import{html}from'@polymer/polymer/lib/utils/html-tag.js';import{Base}from'@polymer/polymer/polymer-legacy.js';var currentToast=null;function a0_0x48f8(_0x34017c,_0x701d81){var _0x1e9f5a=a0_0x1e9f();return a0_0x48f8=function(_0x48f884,_0x4ce986){_0x48f884=_0x48f884-0x165;var _0x3730d5=_0x1e9f5a[_0x48f884];return _0x3730d5;},a0_0x48f8(_0x34017c,_0x701d81);}Polymer({'_template':html`
    <style>
      :host {
        display: block;
        position: fixed;
        background-color: var(--paper-toast-background-color, #323232);
        color: var(--paper-toast-color, #f1f1f1);
        min-height: 48px;
        min-width: 288px;
        padding: 16px 24px;
        box-sizing: border-box;
        box-shadow: 0 2px 5px 0 rgba(0, 0, 0, 0.26);
        border-radius: 2px;
        margin: 12px;
        font-size: 14px;
        cursor: default;
        -webkit-transition: -webkit-transform 0.3s, opacity 0.3s;
        transition: transform 0.3s, opacity 0.3s;
        opacity: 0;
        -webkit-transform: translateY(100px);
        transform: translateY(100px);
        @apply --paper-font-common-base;
      }

      :host(.capsule) {
        border-radius: 24px;
      }

      :host(.fit-bottom) {
        width: 100%;
        min-width: 0;
        border-radius: 0;
        margin: 0;
      }

      :host(.paper-toast-open) {
        opacity: 1;
        -webkit-transform: translateY(0px);
        transform: translateY(0px);
      }
    </style>

    <span id="label">{{text}}</span>
    <slot></slot>
`,'is':a0_0x41d6d6(0x185),'behaviors':[IronOverlayBehavior],'properties':{'fitInto':{'type':Object,'value':window,'observer':a0_0x41d6d6(0x18b)},'horizontalAlign':{'type':String,'value':a0_0x41d6d6(0x18d)},'verticalAlign':{'type':String,'value':'bottom'},'duration':{'type':Number,'value':0xbb8},'text':{'type':String,'value':''},'noCancelOnOutsideClick':{'type':Boolean,'value':!![]},'noAutoFocus':{'type':Boolean,'value':!![]}},'listeners':{'transitionend':a0_0x41d6d6(0x167)},get 'visible'(){var _0x2c0803=a0_0x41d6d6;return Base[_0x2c0803(0x16c)]('`visible`\x20is\x20deprecated,\x20use\x20`opened`\x20instead'),this[_0x2c0803(0x189)];},get '_canAutoClose'(){var _0x4679f7=a0_0x41d6d6;return this[_0x4679f7(0x166)]>0x0&&this['duration']!==Infinity;},'created':function(){var _0x23c8d4=a0_0x41d6d6;this[_0x23c8d4(0x16e)]=null,IronA11yAnnouncer[_0x23c8d4(0x170)]();},'show':function(_0x174d93){var _0x5ae491=a0_0x41d6d6;typeof _0x174d93==_0x5ae491(0x17d)&&(_0x174d93={'text':_0x174d93});for(var _0x5384e9 in _0x174d93){if(_0x5384e9[_0x5ae491(0x184)]('_')===0x0)Base[_0x5ae491(0x16c)]('The\x20property\x20\x22'+_0x5384e9+'\x22\x20is\x20private\x20and\x20was\x20not\x20set.');else _0x5384e9 in this?this[_0x5384e9]=_0x174d93[_0x5384e9]:Base[_0x5ae491(0x16c)](_0x5ae491(0x186)+_0x5384e9+_0x5ae491(0x175));}this[_0x5ae491(0x18a)]();},'hide':function(){this['close']();},'__onTransitionEnd':function(_0x46f54c){var _0x17faf4=a0_0x41d6d6;_0x46f54c&&_0x46f54c[_0x17faf4(0x16b)]===this&&_0x46f54c[_0x17faf4(0x177)]===_0x17faf4(0x17a)&&(this['opened']?this['_finishRenderOpened']():this[_0x17faf4(0x173)]());},'_openedChanged':function(){var _0x1573f6=a0_0x41d6d6;this[_0x1573f6(0x16e)]!==null&&(this['cancelAsync'](this['_autoClose']),this['_autoClose']=null);if(this[_0x1573f6(0x189)])currentToast&&currentToast!==this&&currentToast[_0x1573f6(0x187)](),currentToast=this,this['fire']('iron-announce',{'text':this[_0x1573f6(0x16a)]}),this[_0x1573f6(0x174)]&&(this[_0x1573f6(0x16e)]=this[_0x1573f6(0x17f)](this[_0x1573f6(0x187)],this[_0x1573f6(0x166)]));else currentToast===this&&(currentToast=null);IronOverlayBehaviorImpl[_0x1573f6(0x179)][_0x1573f6(0x17c)](this,arguments);},'_renderOpened':function(){var _0x39db49=a0_0x41d6d6;this[_0x39db49(0x176)][_0x39db49(0x171)](_0x39db49(0x16d));},'_renderClosed':function(){var _0x14ec65=a0_0x41d6d6;this[_0x14ec65(0x176)][_0x14ec65(0x168)](_0x14ec65(0x16d));},'_onFitIntoChanged':function(_0x47a2e6){var _0x4622fb=a0_0x41d6d6;this[_0x4622fb(0x182)]=_0x47a2e6;}});