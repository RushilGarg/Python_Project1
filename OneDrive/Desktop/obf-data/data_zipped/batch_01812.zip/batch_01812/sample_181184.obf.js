/**
 * @license
 * Copyright 2019 Google Inc.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */
(function(_0x547ae1,_0x24af6b){var _0x3bccfc=a0_0x507c,_0x2e6340=_0x547ae1();while(!![]){try{var _0x513481=parseInt(_0x3bccfc(0xd5))/0x1+-parseInt(_0x3bccfc(0xe1))/0x2*(parseInt(_0x3bccfc(0xd4))/0x3)+-parseInt(_0x3bccfc(0xd2))/0x4+parseInt(_0x3bccfc(0xd7))/0x5+parseInt(_0x3bccfc(0xde))/0x6*(parseInt(_0x3bccfc(0xd9))/0x7)+-parseInt(_0x3bccfc(0xdc))/0x8+-parseInt(_0x3bccfc(0xdb))/0x9*(-parseInt(_0x3bccfc(0xd6))/0xa);if(_0x513481===_0x24af6b)break;else _0x2e6340['push'](_0x2e6340['shift']());}catch(_0x53209d){_0x2e6340['push'](_0x2e6340['shift']());}}}(a0_0x326d,0xec3a8));function a0_0x507c(_0x113758,_0x950ca8){var _0x326da9=a0_0x326d();return a0_0x507c=function(_0x507ced,_0xf6c9ae){_0x507ced=_0x507ced-0xd1;var _0x3f72cd=_0x326da9[_0x507ced];return _0x3f72cd;},a0_0x507c(_0x113758,_0x950ca8);}import*as a0_0x193c0c from'tslib';function a0_0x326d(){var _0x3bf168=['defineProperty','642uDimXp','__extends','strings','2XwgVQC','__assign','4668608BhrzIG','setContent','482598xhwcWv','1417131SuNhzF','80890abMZrU','4605830FXugIf','\x20/\x20','756gBNaNI','defaultAdapter','1251UkarxK','9428912QfwwGw'];a0_0x326d=function(){return _0x3bf168;};return a0_0x326d();}import{MDCFoundation}from'@material/base/foundation';import{cssClasses,strings}from'./constants';var MDCTextFieldCharacterCounterFoundation=function(_0x230bc0){var _0x381c72=a0_0x507c;a0_0x193c0c[_0x381c72(0xdf)](_0xb3b343,_0x230bc0);function _0xb3b343(_0x1c9eff){var _0x1a5cfa=_0x381c72;return _0x230bc0['call'](this,a0_0x193c0c[_0x1a5cfa(0xd1)]({},_0xb3b343['defaultAdapter'],_0x1c9eff))||this;}return Object[_0x381c72(0xdd)](_0xb3b343,'cssClasses',{'get':function(){return cssClasses;},'enumerable':!![],'configurable':!![]}),Object['defineProperty'](_0xb3b343,_0x381c72(0xe0),{'get':function(){return strings;},'enumerable':!![],'configurable':!![]}),Object['defineProperty'](_0xb3b343,_0x381c72(0xda),{'get':function(){return{'setContent':function(){return undefined;}};},'enumerable':!![],'configurable':!![]}),_0xb3b343['prototype']['setCounterValue']=function(_0x165eef,_0x53a06f){var _0x293fc5=_0x381c72;_0x165eef=Math['min'](_0x165eef,_0x53a06f),this['adapter_'][_0x293fc5(0xd3)](_0x165eef+_0x293fc5(0xd8)+_0x53a06f);},_0xb3b343;}(MDCFoundation);export{MDCTextFieldCharacterCounterFoundation};export default MDCTextFieldCharacterCounterFoundation;