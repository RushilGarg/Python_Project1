/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xb68d45=a0_0x89e1;(function(_0x3ca21c,_0x10065f){var _0x14a843=a0_0x89e1,_0x16f513=_0x3ca21c();while(!![]){try{var _0x50c1d7=parseInt(_0x14a843(0x1a6))/0x1+-parseInt(_0x14a843(0x1a1))/0x2+parseInt(_0x14a843(0x19d))/0x3+-parseInt(_0x14a843(0x19e))/0x4+parseInt(_0x14a843(0x1a3))/0x5+parseInt(_0x14a843(0x1a0))/0x6*(-parseInt(_0x14a843(0x1a5))/0x7)+-parseInt(_0x14a843(0x19f))/0x8*(-parseInt(_0x14a843(0x1a4))/0x9);if(_0x50c1d7===_0x10065f)break;else _0x16f513['push'](_0x16f513['shift']());}catch(_0x223499){_0x16f513['push'](_0x16f513['shift']());}}}(a0_0xc6ec,0x8b17f));function a0_0x89e1(_0x8f8376,_0x3d41c4){var _0xc6ec4e=a0_0xc6ec();return a0_0x89e1=function(_0x89e188,_0xc24cd1){_0x89e188=_0x89e188-0x19d;var _0x33d97f=_0xc6ec4e[_0x89e188];return _0x33d97f;},a0_0x89e1(_0x8f8376,_0x3d41c4);}function a0_0xc6ec(){var _0x130d6d=['329836NLoFSI','8wNuqLJ','206346fCttGW','1338056XLFswH','exports','3586630jRGYou','2281185GNjMKb','7gpUOPF','292110GQzywt','278112LaoTzq'];a0_0xc6ec=function(){return _0x130d6d;};return a0_0xc6ec();}var floorn=require('./cfloorn.js');function cfloorn(_0x1c1af3,_0x31f851,_0x42f7f5,_0x185b32){if(arguments['length']===0x3)return floorn([0x0,0x0],_0x1c1af3,_0x31f851,_0x42f7f5);return floorn(_0x1c1af3,_0x31f851,_0x42f7f5,_0x185b32);}module[a0_0xb68d45(0x1a2)]=cfloorn;