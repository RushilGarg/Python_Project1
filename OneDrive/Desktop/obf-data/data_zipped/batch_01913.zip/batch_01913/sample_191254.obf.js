const a0_0x535ea1=a0_0x203c;(function(_0x399e03,_0x5aa24f){const _0x2b5c96=a0_0x203c,_0x1dc493=_0x399e03();while(!![]){try{const _0x256316=parseInt(_0x2b5c96(0x16d))/0x1*(parseInt(_0x2b5c96(0x16c))/0x2)+-parseInt(_0x2b5c96(0x177))/0x3+parseInt(_0x2b5c96(0x178))/0x4+parseInt(_0x2b5c96(0x16f))/0x5*(-parseInt(_0x2b5c96(0x170))/0x6)+parseInt(_0x2b5c96(0x174))/0x7+-parseInt(_0x2b5c96(0x16a))/0x8*(-parseInt(_0x2b5c96(0x171))/0x9)+-parseInt(_0x2b5c96(0x16e))/0xa*(parseInt(_0x2b5c96(0x176))/0xb);if(_0x256316===_0x5aa24f)break;else _0x1dc493['push'](_0x1dc493['shift']());}catch(_0xe8262f){_0x1dc493['push'](_0x1dc493['shift']());}}}(a0_0x5821,0xdf744));import a0_0x297ec1 from'styled-components';import a0_0xf2ba6d from'../../../TeamLogo';export const TotalScoreWrapper=a0_0x297ec1['div']`
  width: 100%;
  display: flex;
  flex-direction: row;
  align-items: center;
  justify-content: center;
  font-family: 'Bungee';
  margin-bottom: 44px;

  @media (max-width: 600px), (min-width: 950px) and (max-width: 1120px) {
    display: grid;
    grid-gap: 12px 8px;
    grid-template-areas:
      'awayTeamDetails awayTeamLogo awayTeamScore'
      'homeTeamDetails homeTeamLogo homeTeamScore';
    }
  }
`;export const TeamWrapper=a0_0x297ec1[a0_0x535ea1(0x172)]`
  flex: 1;
  display: flex;
  align-items: center;

  &.away {
    justify-content: flex-end;
  }

  &.home {
    justify-content: flex-start;
  }
`;export const TeamImage=a0_0x297ec1(a0_0xf2ba6d)`
  width: 52px;
  height: 52px;

  &.away {
    order: 1;
    margin-left: 8px;
    margin-right: 8px;
  }

  &.home {
    margin-left: 8px;
    margin-right: 8px;
  }

  @media (max-width: 600px), (min-width: 950px) and (max-width: 1120px) {
    &.away,
    &.home {
      margin: 0 16px 0 0;
      align-self: center;
      justify-self: center;
    }

    &.away {
      grid-area: awayTeamLogo;
    }

    &.home {
      grid-area: homeTeamLogo;
    }
  }
`;export const TeamDetailsWrapper=a0_0x297ec1[a0_0x535ea1(0x172)]`
  display: flex;
  text-align: left;
  flex-direction: column;
  font-family: 'Inter UI', serif;

  &.away {
    text-align: right;
  }

  @media (max-width: 600px), (min-width: 950px) and (max-width: 1120px) {
    &.away,
    &.home {
      text-align: right;
      align-self: center;
      justify-self: right;
    }

    &.away {
      grid-area: awayTeamDetails;
    }

    &.home {
      text-align: right;
      grid-area: homeTeamDetails;
    }
  }
`;export const TeamName=a0_0x297ec1['p']`
  font-size: 14px;
  text-transform: uppercase;
`;export const TeamNickname=a0_0x297ec1['p']`
  font-size: 22px;
`;export const TeamRanking=a0_0x297ec1[a0_0x535ea1(0x173)]`
  font-size: 14px;
  color: ${_0x3e5c0d=>_0x3e5c0d['theme'][a0_0x535ea1(0x16b)]['gray']};
  margin-right: 4px;
`;export const TeamRecord=a0_0x297ec1['p']`
  font-size: 14px;
  color: ${_0x13bb47=>_0x13bb47[a0_0x535ea1(0x175)][a0_0x535ea1(0x16b)]['gray']};
`;function a0_0x203c(_0x2cccbc,_0x51c65d){const _0x5821f6=a0_0x5821();return a0_0x203c=function(_0x203cd0,_0x3276dd){_0x203cd0=_0x203cd0-0x16a;let _0x1b0d52=_0x5821f6[_0x203cd0];return _0x1b0d52;},a0_0x203c(_0x2cccbc,_0x51c65d);}function a0_0x5821(){const _0x10096b=['12thMatY','113823READqb','div','span','7924028famffy','theme','30168380cKyudc','131160JMUnyU','1106888yrkFvV','1056aOzBvn','colors','1265734szXaxN','2jlMwQp','10WTRdRi','1605740bsjBnn'];a0_0x5821=function(){return _0x10096b;};return a0_0x5821();}export const Score=a0_0x297ec1['p']`
  font-size: 36px;
  text-align: center;
  white-space: nowrap;

  @media (max-width: 600px), (min-width: 950px) and (max-width: 1120px) {
    &.away,
    &.home {
      align-self: center;
      justify-self: center;
    }

    &.away {
      grid-area: awayTeamScore;
    }

    &.home {
      grid-area: homeTeamScore;
    }
  }
`;