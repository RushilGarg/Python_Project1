/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x327a71=a0_0x9b0a;function a0_0x4532(){var _0x19fff8=['20MpiXcc','805939yipCNY','1969803qdGAWH','415206cRfjpW','998949FsDWCl','192408QdJhAI','2118200XGzhUW','506945OnARBu','exports','10kSWRtj','24kGCtOW'];a0_0x4532=function(){return _0x19fff8;};return a0_0x4532();}(function(_0x5b1227,_0x53efde){var _0x3f3f85=a0_0x9b0a,_0x27b204=_0x5b1227();while(!![]){try{var _0x4eb764=-parseInt(_0x3f3f85(0x86))/0x1+-parseInt(_0x3f3f85(0x83))/0x2*(parseInt(_0x3f3f85(0x8a))/0x3)+-parseInt(_0x3f3f85(0x85))/0x4*(-parseInt(_0x3f3f85(0x8c))/0x5)+parseInt(_0x3f3f85(0x88))/0x6+parseInt(_0x3f3f85(0x89))/0x7+-parseInt(_0x3f3f85(0x84))/0x8*(-parseInt(_0x3f3f85(0x87))/0x9)+parseInt(_0x3f3f85(0x8b))/0xa;if(_0x4eb764===_0x53efde)break;else _0x27b204['push'](_0x27b204['shift']());}catch(_0x3d08e8){_0x27b204['push'](_0x27b204['shift']());}}}(a0_0x4532,0x7076f));function a0_0x9b0a(_0x454ac4,_0x2a727b){var _0x4532dd=a0_0x4532();return a0_0x9b0a=function(_0x9b0af6,_0x3783fa){_0x9b0af6=_0x9b0af6-0x82;var _0x49997f=_0x4532dd[_0x9b0af6];return _0x49997f;},a0_0x9b0a(_0x454ac4,_0x2a727b);}var median=require('./median.js');module[a0_0x327a71(0x82)]=median;