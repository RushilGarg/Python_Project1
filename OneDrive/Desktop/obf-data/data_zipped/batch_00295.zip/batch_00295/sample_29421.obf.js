/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x1eb8fb=a0_0x3de5;(function(_0x23d101,_0x3f2030){var _0x280eec=a0_0x3de5,_0x1b95c3=_0x23d101();while(!![]){try{var _0x3240a5=parseInt(_0x280eec(0xd5))/0x1*(-parseInt(_0x280eec(0xcf))/0x2)+parseInt(_0x280eec(0xd7))/0x3*(-parseInt(_0x280eec(0xdd))/0x4)+-parseInt(_0x280eec(0xd8))/0x5*(parseInt(_0x280eec(0xd4))/0x6)+-parseInt(_0x280eec(0xce))/0x7+-parseInt(_0x280eec(0xd0))/0x8*(parseInt(_0x280eec(0xd6))/0x9)+parseInt(_0x280eec(0xd3))/0xa+parseInt(_0x280eec(0xda))/0xb;if(_0x3240a5===_0x3f2030)break;else _0x1b95c3['push'](_0x1b95c3['shift']());}catch(_0x91a528){_0x1b95c3['push'](_0x1b95c3['shift']());}}}(a0_0x3e3c,0xbd8cc));function a0_0x3e3c(){var _0x41de80=['end','2108Grsfau','4115608QsEueY','326478Rycyxo','8863592QMMNuL','function','./../lib','3715500fmjKVq','4526562ZQEWFU','9IAhsfv','9HOprhv','8481KYHbxJ','10BgAbHS','strictEqual','72254303HVURgA','main\x20export\x20is\x20a\x20function'];a0_0x3e3c=function(){return _0x41de80;};return a0_0x3e3c();}var tape=require('tape'),runner=require(a0_0x1eb8fb(0xd2));function a0_0x3de5(_0x544b43,_0xabbb4){var _0x3e3c65=a0_0x3e3c();return a0_0x3de5=function(_0x3de5e0,_0x50e92b){_0x3de5e0=_0x3de5e0-0xce;var _0x45fc0c=_0x3e3c65[_0x3de5e0];return _0x45fc0c;},a0_0x3de5(_0x544b43,_0xabbb4);}tape(a0_0x1eb8fb(0xdb),function test(_0x25458f){var _0x5bc93b=a0_0x1eb8fb;_0x25458f['ok'](!![],__filename),_0x25458f[_0x5bc93b(0xd9)](typeof runner,_0x5bc93b(0xd1),_0x5bc93b(0xdb)),_0x25458f[_0x5bc93b(0xdc)]();});