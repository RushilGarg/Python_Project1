const a0_0x5571f6=a0_0x4c55;(function(_0x13c2b8,_0x2da2a7){const _0x3d72a9=a0_0x4c55,_0x356575=_0x13c2b8();while(!![]){try{const _0x4e816d=parseInt(_0x3d72a9(0x1a2))/0x1+parseInt(_0x3d72a9(0x19e))/0x2*(-parseInt(_0x3d72a9(0x1a3))/0x3)+-parseInt(_0x3d72a9(0x199))/0x4+parseInt(_0x3d72a9(0x19a))/0x5*(parseInt(_0x3d72a9(0x19c))/0x6)+parseInt(_0x3d72a9(0x1a5))/0x7*(-parseInt(_0x3d72a9(0x19b))/0x8)+-parseInt(_0x3d72a9(0x19d))/0x9+parseInt(_0x3d72a9(0x1a4))/0xa;if(_0x4e816d===_0x2da2a7)break;else _0x356575['push'](_0x356575['shift']());}catch(_0x4153dc){_0x356575['push'](_0x356575['shift']());}}}(a0_0x3665,0x4d253));import a0_0x3bac04 from'styled-components';import a0_0xda76b4 from'styled-media-query';import a0_0x24ba6b from'gatsby-plugin-transition-link/AniLink';function a0_0x3665(){const _0x67bb87=['102TEdldN','lessThan','nav','large','237759eOcJTO','10029cZbKnc','6665210mngUrw','7qGgLra','567284HUGyuP','142355jsApUC','2515568aJLNoa','66xbOHDt','2472426VriVtx'];a0_0x3665=function(){return _0x67bb87;};return a0_0x3665();}export const MenuLinksWrapper=a0_0x3bac04[a0_0x5571f6(0x1a0)]`
  ${a0_0xda76b4[a0_0x5571f6(0x19f)](a0_0x5571f6(0x1a1))`
    display: none;
  `}
`;function a0_0x4c55(_0x48fa75,_0x4b5594){const _0x366575=a0_0x3665();return a0_0x4c55=function(_0x4c5570,_0x10a764){_0x4c5570=_0x4c5570-0x199;let _0x81884a=_0x366575[_0x4c5570];return _0x81884a;},a0_0x4c55(_0x48fa75,_0x4b5594);}export const MenuLinksList=a0_0x3bac04['ul']`
  font-size: 1.2rem;
  font-weight: 300;
`;export const MenuLinksItem=a0_0x3bac04['li']`
  padding: 0.5rem 0;

  .active {
    color: var(--highlight);
  }
`;export const MenuLinksLink=a0_0x3bac04(a0_0x24ba6b)`
  color: var(--texts);
  text-decoration: none;
  transition: color 0.5s;

  &:hover {
    color: var(--highlight);
  }
`;