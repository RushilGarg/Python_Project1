/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x42c6(){var _0x413a3b=['108972ETXQWg','1872iYoyad','@stdlib/random/base/randu','@stdlib/math/base/special/round','85cQouLf','3MzSlWw','6029840wDPVqu','./../lib','1212633ePdJcN','k:\x20%d,\x20λ:\x20%d,\x20mode(X;k,λ):\x20%d','432267ZlEqHc','40VLoguH','86408ZhUUEm','log','toFixed','132eykSJT','177804ixxJfj','12159RrMDhh'];a0_0x42c6=function(){return _0x413a3b;};return a0_0x42c6();}function a0_0x59e3(_0x3b57e5,_0x2730a1){var _0x42c699=a0_0x42c6();return a0_0x59e3=function(_0x59e37b,_0x18ce82){_0x59e37b=_0x59e37b-0xe6;var _0x247d80=_0x42c699[_0x59e37b];return _0x247d80;},a0_0x59e3(_0x3b57e5,_0x2730a1);}var a0_0x4f9035=a0_0x59e3;(function(_0x4f8843,_0x283dc3){var _0x2889d4=a0_0x59e3,_0x7d0692=_0x4f8843();while(!![]){try{var _0x3e67f4=-parseInt(_0x2889d4(0xe9))/0x1+-parseInt(_0x2889d4(0xeb))/0x2*(-parseInt(_0x2889d4(0xf6))/0x3)+parseInt(_0x2889d4(0xf1))/0x4*(parseInt(_0x2889d4(0xf5))/0x5)+parseInt(_0x2889d4(0xf2))/0x6*(parseInt(_0x2889d4(0xf0))/0x7)+parseInt(_0x2889d4(0xea))/0x8*(-parseInt(_0x2889d4(0xe7))/0x9)+parseInt(_0x2889d4(0xf7))/0xa+-parseInt(_0x2889d4(0xef))/0xb*(parseInt(_0x2889d4(0xee))/0xc);if(_0x3e67f4===_0x283dc3)break;else _0x7d0692['push'](_0x7d0692['shift']());}catch(_0x1510bf){_0x7d0692['push'](_0x7d0692['shift']());}}}(a0_0x42c6,0x59b93));var randu=require(a0_0x4f9035(0xf3)),round=require(a0_0x4f9035(0xf4)),EPS=require('@stdlib/constants/float64/eps'),mode=require(a0_0x4f9035(0xe6)),lambda,k,v,i;for(i=0x0;i<0xa;i++){k=round(randu()*0xa),lambda=randu()*0xa+EPS,v=mode(k,lambda),console[a0_0x4f9035(0xec)](a0_0x4f9035(0xe8),k[a0_0x4f9035(0xed)](0x4),lambda[a0_0x4f9035(0xed)](0x4),v[a0_0x4f9035(0xed)](0x4));}