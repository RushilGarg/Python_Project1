/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x7dbc(_0x387700,_0x21dd48){var _0x4245a5=a0_0x4245();return a0_0x7dbc=function(_0x7dbca7,_0x3f7de2){_0x7dbca7=_0x7dbca7-0x8e;var _0x216259=_0x4245a5[_0x7dbca7];return _0x216259;},a0_0x7dbc(_0x387700,_0x21dd48);}var a0_0x5b3d15=a0_0x7dbc;(function(_0x9a6c73,_0xd15360){var _0x300164=a0_0x7dbc,_0x5337a8=_0x9a6c73();while(!![]){try{var _0x39a4a4=parseInt(_0x300164(0x95))/0x1+parseInt(_0x300164(0x98))/0x2*(parseInt(_0x300164(0x90))/0x3)+parseInt(_0x300164(0x99))/0x4*(parseInt(_0x300164(0x97))/0x5)+-parseInt(_0x300164(0x92))/0x6*(parseInt(_0x300164(0x9f))/0x7)+-parseInt(_0x300164(0x93))/0x8+parseInt(_0x300164(0x91))/0x9+parseInt(_0x300164(0xa0))/0xa*(parseInt(_0x300164(0xa1))/0xb);if(_0x39a4a4===_0xd15360)break;else _0x5337a8['push'](_0x5337a8['shift']());}catch(_0xdea00b){_0x5337a8['push'](_0x5337a8['shift']());}}}(a0_0x4245,0x5dd4a));var bench=require(a0_0x5b3d15(0x9b)),randu=require(a0_0x5b3d15(0x96)),isnan=require('@stdlib/math/base/assert/is-nan'),pkg=require(a0_0x5b3d15(0xa2))[a0_0x5b3d15(0x9d)],exp2=require(a0_0x5b3d15(0x9c));bench(pkg,function benchmark(_0x534225){var _0x315af0=a0_0x5b3d15,_0x27672f,_0x83b48b,_0x15b385;_0x534225[_0x315af0(0x8f)]();for(_0x15b385=0x0;_0x15b385<_0x534225['iterations'];_0x15b385++){_0x27672f=randu()*0x7fc-0x3fe,_0x83b48b=exp2(_0x27672f),isnan(_0x83b48b)&&_0x534225[_0x315af0(0x8e)](_0x315af0(0xa3));}_0x534225[_0x315af0(0x9e)](),isnan(_0x83b48b)&&_0x534225[_0x315af0(0x8e)](_0x315af0(0xa3)),_0x534225[_0x315af0(0x9a)](_0x315af0(0x94)),_0x534225[_0x315af0(0xa4)]();});function a0_0x4245(){var _0x3a9f20=['name','toc','77vzVGcJ','20fNRsFy','1463836lBZqyt','./../package.json','should\x20not\x20return\x20NaN','end','fail','tic','3bQYNCV','832131ZzVjmb','195996afKFlD','4568608BInUTe','benchmark\x20finished','433358aTNWSv','@stdlib/random/base/randu','17465Puyjho','947722YCpDFg','56JrMmlU','pass','@stdlib/bench','./../lib'];a0_0x4245=function(){return _0x3a9f20;};return a0_0x4245();}