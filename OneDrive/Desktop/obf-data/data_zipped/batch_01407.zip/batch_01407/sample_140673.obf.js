/**
* @license Apache-2.0
*
* Copyright (c) 2019 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x42e9(){var _0x1c0933=['1177GaMnMA','1XvOzTb','2460030efKgqr','12OJyJVL','./../data/data.json','exports','4485600XAdrJI','910445vDaJWv','1778902toCpgF','650DxpgZq','379020GcAXyf','5971626mwSSlI','7SGwacv','@stdlib/assert/has-own-property','isPrimitive','@stdlib/assert/is-string'];a0_0x42e9=function(){return _0x1c0933;};return a0_0x42e9();}function a0_0x14c9(_0x4f9aa9,_0x2d8957){var _0x42e934=a0_0x42e9();return a0_0x14c9=function(_0x14c9b3,_0x531116){_0x14c9b3=_0x14c9b3-0x138;var _0x2b8bdb=_0x42e934[_0x14c9b3];return _0x2b8bdb;},a0_0x14c9(_0x4f9aa9,_0x2d8957);}var a0_0xacce44=a0_0x14c9;(function(_0x54468a,_0x1d0a3e){var _0x7fc76e=a0_0x14c9,_0x37c7ab=_0x54468a();while(!![]){try{var _0x37b30e=parseInt(_0x7fc76e(0x13b))/0x1*(-parseInt(_0x7fc76e(0x142))/0x2)+parseInt(_0x7fc76e(0x13c))/0x3+parseInt(_0x7fc76e(0x13d))/0x4*(parseInt(_0x7fc76e(0x141))/0x5)+parseInt(_0x7fc76e(0x144))/0x6*(-parseInt(_0x7fc76e(0x146))/0x7)+-parseInt(_0x7fc76e(0x140))/0x8+parseInt(_0x7fc76e(0x145))/0x9+parseInt(_0x7fc76e(0x143))/0xa*(parseInt(_0x7fc76e(0x13a))/0xb);if(_0x37b30e===_0x1d0a3e)break;else _0x37c7ab['push'](_0x37c7ab['shift']());}catch(_0x9795b2){_0x37c7ab['push'](_0x37c7ab['shift']());}}}(a0_0x42e9,0x7fca1));var isString=require(a0_0xacce44(0x139))[a0_0xacce44(0x138)],hasOwnProp=require(a0_0xacce44(0x147)),ALIAS_TO_HELP=require(a0_0xacce44(0x13e));function help(_0x17340e){if(!isString(_0x17340e))throw new TypeError('invalid\x20argument.\x20Must\x20provide\x20a\x20string.\x20Value:\x20`'+_0x17340e+'`.');if(hasOwnProp(ALIAS_TO_HELP,_0x17340e))return ALIAS_TO_HELP[_0x17340e];return null;}module[a0_0xacce44(0x13f)]=help;