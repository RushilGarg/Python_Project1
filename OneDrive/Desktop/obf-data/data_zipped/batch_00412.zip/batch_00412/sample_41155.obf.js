function a0_0x443b(){const _0x427acf=['parameters','name','_queries','_parameters','meta','161583cstagm','2244fOcGiX','QueryObjectClass','_neo4jQueryObjectClass','partials','push','_shelvedObjs','execute','243683NzBNdl','672lLVVeV','52aQQPVa','_partials','update','object','9160DphNqf','11502UEVKeb','processQueries','concat','1939JaveFY','isArray','4729ostWUZ','splice','shelvedObjs','shelfQuery','exports','length','unshelfQuery','4698880ASozts','string','queries','31596jyYGUb','2703625kzaBpB'];a0_0x443b=function(){return _0x427acf;};return a0_0x443b();}const a0_0x21732f=a0_0x2dbf;function a0_0x2dbf(_0x317cfc,_0x190ba6){const _0x443b2f=a0_0x443b();return a0_0x2dbf=function(_0x2dbf71,_0x9ed8f2){_0x2dbf71=_0x2dbf71-0x79;let _0x30e510=_0x443b2f[_0x2dbf71];return _0x30e510;},a0_0x2dbf(_0x317cfc,_0x190ba6);}(function(_0x3f3a0c,_0x4f8acf){const _0x2de97a=a0_0x2dbf,_0x3315f0=_0x3f3a0c();while(!![]){try{const _0x6e85c=parseInt(_0x2de97a(0x7a))/0x1*(parseInt(_0x2de97a(0x94))/0x2)+parseInt(_0x2de97a(0x8b))/0x3*(parseInt(_0x2de97a(0x95))/0x4)+-parseInt(_0x2de97a(0x85))/0x5+parseInt(_0x2de97a(0x84))/0x6*(parseInt(_0x2de97a(0x9d))/0x7)+parseInt(_0x2de97a(0x81))/0x8+parseInt(_0x2de97a(0x9a))/0x9*(parseInt(_0x2de97a(0x99))/0xa)+parseInt(_0x2de97a(0x93))/0xb*(-parseInt(_0x2de97a(0x8c))/0xc);if(_0x6e85c===_0x4f8acf)break;else _0x3315f0['push'](_0x3315f0['shift']());}catch(_0x824e11){_0x3315f0['push'](_0x3315f0['shift']());}}}(a0_0x443b,0xc8cdb));import a0_0x4c98c7 from'simple-neo4j';import a0_0x2845da from'template-query-object';/**
 * Creates an instance of this class in preperation for use. One instance is
 * all thats needed for all communication.
 *
 * @class module:isomorphic-cypher
 * @classdesc
 * SimpleNeo4J class makes it easy to stack up queries, send them over in one transaction,
 * and readily make use of the response. This class builds on top of that by
 * embracing the cypher query language and provides a powerful toolset
 * for building modular re-usable query strings easily, comapctly, and
 * integrating a full-fleged template language to make use of query compilation
 * both here and/or on Neo4J.
 *
 * All variables are used both by here and the database as their transmitted along
 * with the transaction. Its always best to offload all possible content and
 * query building to the database where possible for dozens of reasons. But
 * for more granular query building, the database may not be able to do it
 * and thus you can just let this class build it for you. Either way, the choice is yours
 * how much you want built by this class, if any, and how much you want built by the
 * database, if any.
 *
 * In each query
 *
 *     {variable_name}      Will be offloaded to the database to build for you
 *                          Neo4J cant handle every build-case but its highly
 *                          recommended to use it whenever possible.
 *
 *     {{variable_name}}    this class will build it for you before sending it to the
 *                          database. this class can handle any kind of building
 *                          even down to the more complex and fine-grained building
 *
 *     {{{variable_name}}}  this class will handle it, same as above, but the variable
 *                           will be escaped beforehand.
 *
 *     {(js expression)}    this class will evaluate the Javascript expression
 *
 *                          Two varibales are available for using in an expression,
 *
 *                          _       - Lodash
 *                          self    - An instance of template-query-object
 *                          _inst   - Also an instance of template-query-object
 *                          _class  - template-query-object class, useful for static methods
 *
 * @summary
 * Creates an instance of this class
 * @param  {module:simple-neo4j~propertyConfigObj} [opts] -
 * Configuration object
 * @author {@link http://codepen.io/wiseguy12851|John Mothershed}
 * @copyright 2015 John Mothershed
 * @license {@link http://www.apache.org/licenses/LICENSE-2.0|Apache-2.0}
 * @version 2.0.0
 * @extends module:simple-neo4j
 * @example
 * // Create a new instance
 * new IsomorphicCypher()
 */
module[a0_0x21732f(0x7e)]=class IsomorphicCypher extends a0_0x4c98c7{constructor(_0x4e3490={}){const _0x5ec310=a0_0x21732f;let _0x586fde=_0x4e3490;if(typeof _0x586fde!=='object'||_0x586fde===null)_0x586fde={};super(_0x586fde),this[_0x5ec310(0x97)](_0x586fde,!![]);}['update'](_0x4415fc,_0xf4ce32=![]){const _0x6aae94=a0_0x21732f;super[_0x6aae94(0x97)](_0x4415fc,_0xf4ce32);const _0x125186=_0x4415fc;if(typeof _0x125186!==_0x6aae94(0x98)||_0x125186===null)return;if(_0x125186[_0x6aae94(0x7c)]||_0xf4ce32)this[_0x6aae94(0x7c)]=_0x125186['shelvedObjs'];if(_0x125186[_0x6aae94(0x86)]||_0xf4ce32)this[_0x6aae94(0x86)]=_0x125186[_0x6aae94(0x86)];if(_0x125186['partials']||_0xf4ce32)this['partials']=_0x125186['partials'];if(_0x125186[_0x6aae94(0x83)]||_0xf4ce32)this[_0x6aae94(0x83)]=_0x125186[_0x6aae94(0x83)];}get[a0_0x21732f(0x8d)](){const _0x29ec64=a0_0x21732f;return this[_0x29ec64(0x8e)];}set[a0_0x21732f(0x8d)](_0x56cc29){const _0xd9baa5=a0_0x21732f;if(_0x56cc29 instanceof a0_0x2845da)this['_neo4jQueryObjectClass']=_0x56cc29;else this[_0xd9baa5(0x8e)]=a0_0x2845da;}get[a0_0x21732f(0x7c)](){const _0x51a062=a0_0x21732f;return this[_0x51a062(0x91)];}set['shelvedObjs'](_0x49fe62){const _0x1a4711=a0_0x21732f;if(typeof _0x49fe62===_0x1a4711(0x98)&&_0x49fe62!==null)this['_shelvedObjs']=_0x49fe62;else this[_0x1a4711(0x91)]={};}get['parameters'](){const _0x5b1b00=a0_0x21732f;return this[_0x5b1b00(0x89)];}set[a0_0x21732f(0x86)](_0x3405ad){const _0x1a3364=a0_0x21732f;if(typeof _0x3405ad===_0x1a3364(0x98)&&_0x3405ad!==null)this[_0x1a3364(0x89)]=_0x3405ad;else this[_0x1a3364(0x89)]={};}get[a0_0x21732f(0x8f)](){return this['_partials'];}set['partials'](_0xfbff53){const _0x4e14ef=a0_0x21732f;if(typeof _0xfbff53===_0x4e14ef(0x98)&&_0xfbff53!==null)this[_0x4e14ef(0x96)]=_0xfbff53;else this[_0x4e14ef(0x96)]={};}get[a0_0x21732f(0x83)](){return this['_queries'];}set[a0_0x21732f(0x83)](_0x41c8ec){const _0x13404b=a0_0x21732f;if(typeof _0x41c8ec===_0x13404b(0x98)&&_0x41c8ec!==null)this[_0x13404b(0x88)]=_0x41c8ec;else this['_queries']={};}[a0_0x21732f(0x9b)](_0x29e559){const _0x293244=a0_0x21732f,_0x149c37=super[_0x293244(0x9b)](_0x29e559);for(let _0x1599fa=0x0;_0x1599fa<_0x149c37[_0x293244(0x7f)];_0x1599fa++){const _0xf38939=_0x149c37[_0x1599fa];_0xf38939['globalParams']=this[_0x293244(0x86)],_0xf38939['partials']=this[_0x293244(0x8f)];}return _0x149c37;}[a0_0x21732f(0x7d)](_0x3e5b3f){const _0x24966c=a0_0x21732f;if(!Array[_0x24966c(0x79)](_0x3e5b3f)&&typeof _0x3e5b3f!==_0x24966c(0x98))return;let _0x577a77=[];if(!Array['isArray'](_0x3e5b3f))_0x577a77[_0x24966c(0x90)](_0x3e5b3f);else _0x577a77=_0x577a77[_0x24966c(0x9c)](_0x3e5b3f);for(let _0x4df96e=0x0;_0x4df96e<_0x577a77[_0x24966c(0x7f)];_0x4df96e++){const _0x3f4efb=_0x577a77[_0x4df96e];if(typeof _0x3f4efb!==_0x24966c(0x98)||typeof _0x3f4efb[_0x24966c(0x87)]!==_0x24966c(0x82)||_0x3f4efb[_0x24966c(0x87)][_0x24966c(0x7f)]<0x1){_0x577a77[_0x24966c(0x7b)](_0x4df96e,0x1);continue;}if(typeof _0x3f4efb['meta']!==_0x24966c(0x98))_0x3f4efb[_0x24966c(0x8a)]={};_0x3f4efb[_0x24966c(0x8a)]['name']=_0x3f4efb['name'];}const _0x46de7b=this[_0x24966c(0x9b)](_0x577a77);if(_0x46de7b[_0x24966c(0x7f)]<0x1)return;for(let _0x1508f1=0x0;_0x1508f1<_0x46de7b[_0x24966c(0x7f)];_0x1508f1++){const _0x4444e2=_0x46de7b[_0x1508f1];this['shelvedObjs'][_0x4444e2[_0x24966c(0x8a)][_0x24966c(0x87)]]=_0x4444e2;}}[a0_0x21732f(0x80)](_0x6e27c8,_0x3d5f93=![]){const _0x53befc=a0_0x21732f;if(!Array[_0x53befc(0x79)](_0x6e27c8)||_0x6e27c8['length']<0x1)return;const _0x965ccd=[];for(let _0x2ddeb3=0x0;_0x2ddeb3<_0x6e27c8['length'];_0x2ddeb3++){const _0x916620=_0x6e27c8[_0x2ddeb3];if(typeof _0x916620!==_0x53befc(0x82)||_0x916620[_0x53befc(0x7f)]<0x1)continue;const _0x3032b4=this[_0x53befc(0x7c)][_0x916620];if(!(_0x3032b4 instanceof a0_0x2845da))continue;_0x965ccd[_0x53befc(0x90)](_0x3032b4);}return this[_0x53befc(0x92)](_0x965ccd,_0x3d5f93);}};