const a0_0x3ee73a=a0_0xc19d;(function(_0x42ad56,_0x5e9982){const _0x1d066c=a0_0xc19d,_0x1852f7=_0x42ad56();while(!![]){try{const _0x51c87b=parseInt(_0x1d066c(0x191))/0x1*(-parseInt(_0x1d066c(0x190))/0x2)+-parseInt(_0x1d066c(0x185))/0x3+-parseInt(_0x1d066c(0x188))/0x4*(-parseInt(_0x1d066c(0x18a))/0x5)+parseInt(_0x1d066c(0x18b))/0x6*(parseInt(_0x1d066c(0x186))/0x7)+parseInt(_0x1d066c(0x187))/0x8*(parseInt(_0x1d066c(0x18c))/0x9)+-parseInt(_0x1d066c(0x183))/0xa*(parseInt(_0x1d066c(0x189))/0xb)+parseInt(_0x1d066c(0x18e))/0xc*(parseInt(_0x1d066c(0x18d))/0xd);if(_0x51c87b===_0x5e9982)break;else _0x1852f7['push'](_0x1852f7['shift']());}catch(_0x3998fc){_0x1852f7['push'](_0x1852f7['shift']());}}}(a0_0x4239,0xecd39));import a0_0x4d0a41 from'styled-components';import a0_0xa020e0 from'../../utils/colors';function a0_0x4239(){const _0x30604b=['6200cWSkDH','4632mpmNja','7991412zSvVSk','1245sRvLTJ','78ppOsoV','12618yPDAbU','13aJiTYe','7709124RmahtL','div','2TaWtJh','1271024vgeqmf','10cxapPL','base','171123FOHtuV','542381eDJYPy'];a0_0x4239=function(){return _0x30604b;};return a0_0x4239();}export const Wrap=a0_0x4d0a41[a0_0x3ee73a(0x18f)]`
  height: 100vh;
  width: 100vw;
  display: flex;
  padding: 16px;
  flex-direction: column;
`;export const Row=a0_0x4d0a41[a0_0x3ee73a(0x18f)]`
  width: 100%;
  height: 100%;
  display: flex;
  flex-direction: row;
`;function a0_0xc19d(_0x4b97ef,_0x17b83a){const _0x4239c9=a0_0x4239();return a0_0xc19d=function(_0xc19d45,_0x75e3fe){_0xc19d45=_0xc19d45-0x183;let _0x110f40=_0x4239c9[_0xc19d45];return _0x110f40;},a0_0xc19d(_0x4b97ef,_0x17b83a);}export const Cell=a0_0x4d0a41[a0_0x3ee73a(0x18f)]`
  width: 50%;
  height: 100%;
  margin: 8px;
  padding: 16px;
  border-radius: 32px;
  display: flex;
  border: 1px solid ${a0_0xa020e0[a0_0x3ee73a(0x184)]['accent']};
  flex-direction: column;
`;export const Title=a0_0x4d0a41['h2']`
  margin: 0 0 16px 0;
  font-weight: 300;
  color: ${a0_0xa020e0[a0_0x3ee73a(0x184)]['accent']};
  font-size: 12px;
  height: 16px;
  text-transform: uppercase;
`;export const ViewrWrap=a0_0x4d0a41[a0_0x3ee73a(0x18f)]`
  position: relative;
  width: 100%;
  height: calc(100% - 32px);
`;