/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x216bde=a0_0x4628;function a0_0x4628(_0x5111ac,_0x5f3c23){var _0x4953c5=a0_0x4953();return a0_0x4628=function(_0x4628cd,_0x332413){_0x4628cd=_0x4628cd-0x1a5;var _0x23b66a=_0x4953c5[_0x4628cd];return _0x23b66a;},a0_0x4628(_0x5111ac,_0x5f3c23);}(function(_0xa24d0d,_0x4d7817){var _0x1a14f5=a0_0x4628,_0x9c33ec=_0xa24d0d();while(!![]){try{var _0x4cb52c=-parseInt(_0x1a14f5(0x1ad))/0x1*(-parseInt(_0x1a14f5(0x1af))/0x2)+parseInt(_0x1a14f5(0x1ae))/0x3+-parseInt(_0x1a14f5(0x1a5))/0x4*(parseInt(_0x1a14f5(0x1aa))/0x5)+parseInt(_0x1a14f5(0x1a7))/0x6+parseInt(_0x1a14f5(0x1a8))/0x7+parseInt(_0x1a14f5(0x1ab))/0x8+-parseInt(_0x1a14f5(0x1b0))/0x9;if(_0x4cb52c===_0x4d7817)break;else _0x9c33ec['push'](_0x9c33ec['shift']());}catch(_0x13ae96){_0x9c33ec['push'](_0x9c33ec['shift']());}}}(a0_0x4953,0x3d813));var setReadOnly=require('@stdlib/utils/define-nonenumerable-read-only-property'),dmeanli=require(a0_0x216bde(0x1a9)),ndarray=require(a0_0x216bde(0x1ac));setReadOnly(dmeanli,'ndarray',ndarray),module[a0_0x216bde(0x1a6)]=dmeanli;function a0_0x4953(){var _0x39ea3b=['4692447IsZqsL','14256juIGXL','exports','1875852KuOVrv','3440150jOkKPI','./dmeanli.js','565kuIMFd','1398368ENuYdK','./ndarray.js','83557WGmwja','340779IUnMCf','2jBOEUZ'];a0_0x4953=function(){return _0x39ea3b;};return a0_0x4953();}