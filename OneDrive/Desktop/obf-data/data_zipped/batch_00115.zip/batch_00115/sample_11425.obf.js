const a0_0x3902fa=a0_0x38cf;(function(_0xda179c,_0xed8183){const _0x5e829a=a0_0x38cf,_0xec7291=_0xda179c();while(!![]){try{const _0xe83def=-parseInt(_0x5e829a(0x1de))/0x1*(-parseInt(_0x5e829a(0x1e4))/0x2)+parseInt(_0x5e829a(0x1db))/0x3*(-parseInt(_0x5e829a(0x1e3))/0x4)+parseInt(_0x5e829a(0x1d6))/0x5*(-parseInt(_0x5e829a(0x1e0))/0x6)+-parseInt(_0x5e829a(0x1d7))/0x7*(parseInt(_0x5e829a(0x1dc))/0x8)+parseInt(_0x5e829a(0x1e2))/0x9*(-parseInt(_0x5e829a(0x1df))/0xa)+parseInt(_0x5e829a(0x1e1))/0xb*(-parseInt(_0x5e829a(0x1da))/0xc)+parseInt(_0x5e829a(0x1d9))/0xd*(parseInt(_0x5e829a(0x1dd))/0xe);if(_0xe83def===_0xed8183)break;else _0xec7291['push'](_0xec7291['shift']());}catch(_0x5aca60){_0xec7291['push'](_0xec7291['shift']());}}}(a0_0x5065,0xa03f6));import a0_0x5c345f from'styled-components';export const Wrapper=a0_0x5c345f[a0_0x3902fa(0x1e5)]`
  margin: 0 auto;
  width: 100%;
  max-width: 1170px;
`;export const VerticalListView=a0_0x5c345f['ul']`
  margin: var(--topbar-height) 0;
  padding: 0;
  list-style-type: none;
`;export const VerticalListSection=a0_0x5c345f['li']`
  margin-bottom: var(--padding);

  &:last-child {
    position: relative;
    padding-bottom: calc(var(--topbar-height) * 1.5);
  }

  h4, ul:not(.slider-list) {
    padding-left: var(--padding);
  }
`;export const HorizontalListView=a0_0x5c345f['ul']`
  margin: 0;
  padding: var(--padding);
  padding-left: 0;
  display: flex;
  flex-flow: row no-wrap;
  list-style-type: none;
  overflow-x: auto;
  align-items: center;
`;function a0_0x38cf(_0x34221b,_0x5a1290){const _0x506514=a0_0x5065();return a0_0x38cf=function(_0x38cf05,_0x37ed23){_0x38cf05=_0x38cf05-0x1d6;let _0x45c720=_0x506514[_0x38cf05];return _0x45c720;},a0_0x38cf(_0x34221b,_0x5a1290);}export const HorizontalListItem=a0_0x5c345f['li']`
  margin-right: var(--padding);
  
  &:last-child {
    position: relative;
    padding-right: calc(var(--topbar-height) * 0.5);
  }
`;export const TagButton=a0_0x5c345f['button']`
  padding: calc(var(--padding) * 0.5) calc(var(--padding) * 2);
  background: var(--primary-accent-color);
  color: var(--background-color);
  border-radius: 50px;
  white-space: nowrap;
`;export const FacilityButton=a0_0x5c345f[a0_0x3902fa(0x1d8)]`
  background: var(--foreground-color);
  color: var(--background-color);
  padding: var(--padding);
  border-radius: 4px;
    white-space: nowrap;
`;export const FacilityIcon=a0_0x5c345f['img']`
  display: block;
  margin: 0 auto;
  height: 24px;
  margin-bottom: calc(var(--padding) / 2);
`;export const SearchContainer=a0_0x5c345f['section']`
  position: relative;
  margin: auto;
  width: 100%;
  max-width: 1170px;
  display: flex;
  align-items: center;
`;export const SearchLabel=a0_0x5c345f['label']`
  // padding: calc(var(--padding) / 1);
  padding-left: calc(var(--padding) / 2);
  border-radius: 4px 0 0 4px;
`;export const SearchBox=a0_0x5c345f['input']`
  display: block;
  flex: 2;
  // padding: calc(var(--padding) / 1);
  font-size: 16px;

  &:focus {
    outline: 0;
  }
`;function a0_0x5065(){const _0x29b022=['21030mCgfcd','836CzbsMm','4574709DZHunN','44624WeKlsf','3046wPiUYd','section','1735xxdXcM','2395834rrVUZM','button','15846922DPRsgB','29412nHLTqu','204jhuIAa','16ZSCofy','42eExohs','232UKYVgI','10URhKQN'];a0_0x5065=function(){return _0x29b022;};return a0_0x5065();}export const List=a0_0x5c345f['ul']`
  margin: var(--topbar-height) 0 calc(var(--topbar-height) * 1.5) 0;
  padding: 0;
  list-style-type: 0;
`;export const Item=a0_0x5c345f['li']`
  border-bottom: 1px solid var(--light-gray);
`;export const SlideList=a0_0x5c345f['section']`
  padding: var(--padding);
`;