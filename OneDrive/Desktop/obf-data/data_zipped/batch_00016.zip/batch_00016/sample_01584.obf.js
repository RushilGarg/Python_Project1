/**
 * @license
 * Copyright 2015 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 */
var a0_0x1f7967=a0_0x134a;function a0_0x134a(_0x12ef7d,_0x74284f){var _0x2c4442=a0_0x2c44();return a0_0x134a=function(_0x134ac2,_0x2da6e8){_0x134ac2=_0x134ac2-0xf2;var _0x355f26=_0x2c4442[_0x134ac2];return _0x355f26;},a0_0x134a(_0x12ef7d,_0x74284f);}(function(_0x510f4a,_0x1f6d7b){var _0x5116d1=a0_0x134a,_0x3882d8=_0x510f4a();while(!![]){try{var _0x3478a3=parseInt(_0x5116d1(0xf5))/0x1*(-parseInt(_0x5116d1(0xf3))/0x2)+parseInt(_0x5116d1(0xf6))/0x3*(parseInt(_0x5116d1(0xfc))/0x4)+-parseInt(_0x5116d1(0xf9))/0x5*(-parseInt(_0x5116d1(0xfe))/0x6)+-parseInt(_0x5116d1(0x100))/0x7*(parseInt(_0x5116d1(0xfb))/0x8)+-parseInt(_0x5116d1(0xf2))/0x9*(parseInt(_0x5116d1(0x101))/0xa)+parseInt(_0x5116d1(0xfa))/0xb*(parseInt(_0x5116d1(0xff))/0xc)+parseInt(_0x5116d1(0xfd))/0xd;if(_0x3478a3===_0x1f6d7b)break;else _0x3882d8['push'](_0x3882d8['shift']());}catch(_0x35a7cd){_0x3882d8['push'](_0x3882d8['shift']());}}}(a0_0x2c44,0x22b15),CLASS({'name':a0_0x1f7967(0xf7),'package':'foam.flow','extends':a0_0x1f7967(0xf8),'constants':{'ELEMENT_NAME':'log-entry'},'properties':[{'name':a0_0x1f7967(0xf4)}],'templates':[function toInnerHTML(){},function CSS(){}]}));function a0_0x2c44(){var _0x407d77=['164225BAGYXq','11UgFYUW','632BroZBA','1420XhExcR','1504217CQeyQF','30WWgLnr','727836zPyjjt','10059cmRixA','40cYyyCx','475596WGHzWo','12OTjjLK','data','2302WypCYz','1185lrAMdy','LogEntryView','foam.flow.Element'];a0_0x2c44=function(){return _0x407d77;};return a0_0x2c44();}