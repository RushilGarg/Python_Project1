/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x3e600e=a0_0x368a;(function(_0x160d92,_0x4c0ebf){var _0x1abc7c=a0_0x368a,_0x2798b0=_0x160d92();while(!![]){try{var _0x485a6f=-parseInt(_0x1abc7c(0xa8))/0x1+parseInt(_0x1abc7c(0xb3))/0x2*(parseInt(_0x1abc7c(0xab))/0x3)+parseInt(_0x1abc7c(0xaf))/0x4*(parseInt(_0x1abc7c(0xa3))/0x5)+parseInt(_0x1abc7c(0xb5))/0x6*(parseInt(_0x1abc7c(0xb6))/0x7)+-parseInt(_0x1abc7c(0xa6))/0x8*(parseInt(_0x1abc7c(0xba))/0x9)+-parseInt(_0x1abc7c(0xa0))/0xa*(parseInt(_0x1abc7c(0xb4))/0xb)+parseInt(_0x1abc7c(0xb2))/0xc;if(_0x485a6f===_0x4c0ebf)break;else _0x2798b0['push'](_0x2798b0['shift']());}catch(_0x2746e5){_0x2798b0['push'](_0x2798b0['shift']());}}}(a0_0x296a,0xa6eab));var join=require(a0_0x3e600e(0xa1))['join'],lunr=require(a0_0x3e600e(0xa7)),rootDir=require(a0_0x3e600e(0xb7)),pkgIndex=require('./../lib'),dir=join(rootDir(),a0_0x3e600e(0xaa),a0_0x3e600e(0xad),a0_0x3e600e(0xb9),a0_0x3e600e(0xb1),a0_0x3e600e(0xac),a0_0x3e600e(0xb0)),opts={'dir':dir};function a0_0x296a(){var _0x57b445=['lunr','602292cSDvoS','load','lib','31362FndfWH','base','node_modules','search','4zlbXEX','special','math','6262548GVvsMi','226jiUKfU','3916077ckrlOY','1108068KUZSPS','7nLaeJt','@stdlib/_tools/utils/root-dir','log','@stdlib','9uvnOCq','stringify','20nIYkqz','path','Unable\x20to\x20create\x20search\x20index.\x20Try\x20modifying\x20package\x20search\x20criteria\x20and\x20trying\x20again.','5935870BKtMec','Index','sine','8616288Urogky'];a0_0x296a=function(){return _0x57b445;};return a0_0x296a();}function a0_0x368a(_0xb153a0,_0x315ea0){var _0x296aec=a0_0x296a();return a0_0x368a=function(_0x368a8c,_0x5c157c){_0x368a8c=_0x368a8c-0xa0;var _0x20b906=_0x296aec[_0x368a8c];return _0x20b906;},a0_0x368a(_0xb153a0,_0x315ea0);}pkgIndex(opts,onIndex);function onIndex(_0x41e6b3,_0x1891e7){var _0x21186d=a0_0x3e600e,_0x2ef182,_0x189b76;if(_0x41e6b3)throw _0x41e6b3;if(_0x1891e7===null){console['error'](_0x21186d(0xa2));return;}_0x2ef182=lunr[_0x21186d(0xa4)][_0x21186d(0xa9)](_0x1891e7),_0x189b76=_0x2ef182[_0x21186d(0xae)](_0x21186d(0xa5)),console[_0x21186d(0xb8)](JSON[_0x21186d(0xbb)](_0x189b76,null,'\x20\x20'));}