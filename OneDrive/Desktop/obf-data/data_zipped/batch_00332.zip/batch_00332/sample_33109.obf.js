/**
 * @license
 * Copyright 2018 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x5863ef=a0_0x2d68;(function(_0xec253a,_0x435431){var _0x2dc3e1=a0_0x2d68,_0x2b7489=_0xec253a();while(!![]){try{var _0x19a174=parseInt(_0x2dc3e1(0x15e))/0x1+parseInt(_0x2dc3e1(0x162))/0x2*(-parseInt(_0x2dc3e1(0x156))/0x3)+parseInt(_0x2dc3e1(0x160))/0x4*(parseInt(_0x2dc3e1(0x159))/0x5)+-parseInt(_0x2dc3e1(0x158))/0x6+parseInt(_0x2dc3e1(0x161))/0x7*(-parseInt(_0x2dc3e1(0x15f))/0x8)+-parseInt(_0x2dc3e1(0x15d))/0x9+parseInt(_0x2dc3e1(0x157))/0xa*(parseInt(_0x2dc3e1(0x15a))/0xb);if(_0x19a174===_0x435431)break;else _0x2b7489['push'](_0x2b7489['shift']());}catch(_0x35a523){_0x2b7489['push'](_0x2b7489['shift']());}}}(a0_0x1d10,0x3267b));class MDCTopAppBarAdapter{['addClass'](_0x4de614){}['removeClass'](_0x21ed5c){}['hasClass'](_0x3ed806){}[a0_0x5863ef(0x15c)](_0x52d0a4,_0x212fa9){}['getTopAppBarHeight'](){}[a0_0x5863ef(0x15b)](_0x2dd1f7,_0x112319){}['deregisterNavigationIconInteractionHandler'](_0x4667be,_0x33b4df){}[a0_0x5863ef(0x153)](){}[a0_0x5863ef(0x155)](_0x285f9d){}['deregisterScrollHandler'](_0xe6f7fb){}[a0_0x5863ef(0x154)](_0x43e63c){}['deregisterResizeHandler'](_0x349509){}['getViewportScrollY'](){}['getTotalActionItems'](){}}export default MDCTopAppBarAdapter;function a0_0x2d68(_0x50ddb9,_0x210296){var _0x1d102b=a0_0x1d10();return a0_0x2d68=function(_0x2d687e,_0x102e15){_0x2d687e=_0x2d687e-0x153;var _0x22133e=_0x1d102b[_0x2d687e];return _0x22133e;},a0_0x2d68(_0x50ddb9,_0x210296);}function a0_0x1d10(){var _0x15df90=['4225177rmDhzJ','registerNavigationIconInteractionHandler','setStyle','3280131lIjYnu','79281pIfuwN','56pvuZJL','25548yQsQgW','298907wvcBKO','10arGpOi','notifyNavigationIconClicked','registerResizeHandler','registerScrollHandler','37158cZOyjS','30oWoQrD','2258946EdtnoV','60GryRXS'];a0_0x1d10=function(){return _0x15df90;};return a0_0x1d10();}