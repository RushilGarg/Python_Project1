/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x2f48ea=a0_0x47ee;(function(_0x507f06,_0x50b08d){var _0x5475f6=a0_0x47ee,_0x34b466=_0x507f06();while(!![]){try{var _0x1d3840=parseInt(_0x5475f6(0x17b))/0x1+parseInt(_0x5475f6(0x17f))/0x2+-parseInt(_0x5475f6(0x180))/0x3+parseInt(_0x5475f6(0x182))/0x4+-parseInt(_0x5475f6(0x184))/0x5*(-parseInt(_0x5475f6(0x179))/0x6)+parseInt(_0x5475f6(0x17c))/0x7+-parseInt(_0x5475f6(0x185))/0x8*(parseInt(_0x5475f6(0x183))/0x9);if(_0x1d3840===_0x50b08d)break;else _0x34b466['push'](_0x34b466['shift']());}catch(_0x4b7f3a){_0x34b466['push'](_0x34b466['shift']());}}}(a0_0x2229,0x3e24c));function a0_0x47ee(_0x232b44,_0x1eaa47){var _0x222942=a0_0x2229();return a0_0x47ee=function(_0x47ee64,_0xdc5b2a){_0x47ee64=_0x47ee64-0x177;var _0x322f66=_0x222942[_0x47ee64];return _0x322f66;},a0_0x47ee(_0x232b44,_0x1eaa47);}var tape=require(a0_0x2f48ea(0x186)),gapx=require('./../lib');tape(a0_0x2f48ea(0x177),function test(_0x200f79){var _0x49be08=a0_0x2f48ea;_0x200f79['ok'](!![],__filename),_0x200f79[_0x49be08(0x17a)](typeof gapx,_0x49be08(0x17d),_0x49be08(0x177)),_0x200f79[_0x49be08(0x181)]();}),tape(a0_0x2f48ea(0x17e),function test(_0x3a23c3){var _0x344a05=a0_0x2f48ea;_0x3a23c3[_0x344a05(0x17a)](typeof gapx[_0x344a05(0x178)],_0x344a05(0x17d),'method\x20is\x20a\x20function'),_0x3a23c3['end']();});function a0_0x2229(){var _0x549b1=['18qWfRka','strictEqual','171135cLlcqb','2754752BPCrlu','function','attached\x20to\x20the\x20main\x20export\x20is\x20a\x20method\x20providing\x20an\x20ndarray\x20interface','851312yEuEWF','844395nYBJqb','end','1122732zLWAUw','12294sGHUZD','712435STYvFa','6808cxYNjd','tape','main\x20export\x20is\x20a\x20function','ndarray'];a0_0x2229=function(){return _0x549b1;};return a0_0x2229();}