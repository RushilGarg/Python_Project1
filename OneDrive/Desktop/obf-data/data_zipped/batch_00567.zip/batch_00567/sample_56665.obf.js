const a0_0x5efe92=a0_0x72b0;(function(_0x271075,_0x1ad28a){const _0x9094ad=a0_0x72b0,_0x10a6c5=_0x271075();while(!![]){try{const _0x5136af=-parseInt(_0x9094ad(0x6b))/0x1*(-parseInt(_0x9094ad(0x71))/0x2)+parseInt(_0x9094ad(0x6d))/0x3*(parseInt(_0x9094ad(0x74))/0x4)+-parseInt(_0x9094ad(0x6a))/0x5*(-parseInt(_0x9094ad(0x6e))/0x6)+parseInt(_0x9094ad(0x6c))/0x7*(parseInt(_0x9094ad(0x70))/0x8)+-parseInt(_0x9094ad(0x75))/0x9+-parseInt(_0x9094ad(0x69))/0xa+-parseInt(_0x9094ad(0x6f))/0xb;if(_0x5136af===_0x1ad28a)break;else _0x10a6c5['push'](_0x10a6c5['shift']());}catch(_0x36dbc4){_0x10a6c5['push'](_0x10a6c5['shift']());}}}(a0_0x1b1c,0x1fb10));import{css}from'emotion';import{Color,mobileMaxWidth}from'constants/css';function a0_0x72b0(_0x406b37,_0x7d4f48){const _0x1b1c44=a0_0x1b1c();return a0_0x72b0=function(_0x72b08b,_0x4b41f3){_0x72b08b=_0x72b08b-0x68;let _0x1b3fb6=_0x1b1c44[_0x72b08b];return _0x1b3fb6;},a0_0x72b0(_0x406b37,_0x7d4f48);}export const commentContainer=css`
  display: flex;
  width: 100%;
  flex-direction: column;
  margin-top: 1.5rem;
  position: relative;
  font-size: 1.6rem;
  .dropdown-wrapper {
    right: 0;
    position: absolute;
  }
  .content-wrapper {
    display: flex;
    width: 100%;
    position: relative;
    aside {
      width: 7rem;
      justify-content: center;
      display: flex;
    }
    section {
      width: 100%;
      margin-left: 1rem;
    }
  }
  .timestamp {
    color: ${Color['gray']()};
    > a {
      color: ${Color[a0_0x5efe92(0x72)]()};
    }
  }
  .to {
    color: ${Color[a0_0x5efe92(0x68)]()};
    font-size: 1.3rem;
    line-height: 2.3rem;
    font-weight: bold;
  }
  .username {
    font-size: 1.8rem;
  }
  .comment__content {
    white-space: pre-wrap;
    overflow-wrap: break-word;
    word-break: break-word;
    line-height: 1.5;
    padding: 1.5rem 0 2rem 0;
  }
  .reply-button {
    margin-left: 0.5rem;
  }
  .comment__likes {
    margin-top: 0.5rem;
    font-size: 1.2rem;
    line-height: 1.5;
    font-weight: bold;
    color: ${Color['darkerGray']()};
  }
  .comment__buttons {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    width: 100%;
  }
  @media (max-width: ${mobileMaxWidth}) {
    .likes {
      font-size: 1.8rem;
      margin-top: 0.5rem;
      font-weight: bold;
      color: ${Color[a0_0x5efe92(0x73)]()};
    }
  }
`;function a0_0x1b1c(){const _0xff7fbe=['darkerGray','100tbVgDr','526599MGKdAI','blue','1164930EAoyzO','15aSUtzg','1iTcMIi','168fjcfGr','7143oKuuax','431166STHZjK','2374427KhZRau','33928nRxRIm','287554SNwIQA','gray'];a0_0x1b1c=function(){return _0xff7fbe;};return a0_0x1b1c();}