/**
 * @license
 * Copyright 2019 The Google Earth Engine Community Authors
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x5cab(){var _0x25611c=['970trJOaH','evaluate','tasseledCap','12836XFpbid','../helpers/test-image.js','toBeCloseTo','21UkuFHF','create','45djBwvM','../../api.js','toBeUndefined','1630002DsHRfc','Landsat5','getImageCollection','12077304haMzqR','collection_','6989472cigoNZ','657342knDnwl','ImageCollection','4379160YTKirr','73778BsBQtJ'];a0_0x5cab=function(){return _0x25611c;};return a0_0x5cab();}var a0_0x3ed468=a0_0x2003;(function(_0x203fe6,_0x125f2b){var _0x5d8a67=a0_0x2003,_0xdf72b9=_0x203fe6();while(!![]){try{var _0x37f12e=-parseInt(_0x5d8a67(0x126))/0x1+parseInt(_0x5d8a67(0x114))/0x2*(-parseInt(_0x5d8a67(0x11b))/0x3)+parseInt(_0x5d8a67(0x118))/0x4*(-parseInt(_0x5d8a67(0x115))/0x5)+-parseInt(_0x5d8a67(0x120))/0x6+-parseInt(_0x5d8a67(0x125))/0x7+parseInt(_0x5d8a67(0x123))/0x8+parseInt(_0x5d8a67(0x11d))/0x9*(parseInt(_0x5d8a67(0x128))/0xa);if(_0x37f12e===_0x125f2b)break;else _0xdf72b9['push'](_0xdf72b9['shift']());}catch(_0x3c677c){_0xdf72b9['push'](_0xdf72b9['shift']());}}}(a0_0x5cab,0xd9859));function a0_0x2003(_0x7b7f87,_0x45a642){var _0x5cab84=a0_0x5cab();return a0_0x2003=function(_0x2003f4,_0x24cce0){_0x2003f4=_0x2003f4-0x114;var _0x2eea98=_0x5cab84[_0x2003f4];return _0x2eea98;},a0_0x2003(_0x7b7f87,_0x45a642);}var lct=require(a0_0x3ed468(0x11e)),TestImage=require(a0_0x3ed468(0x119));function TestLandsat5(_0x23d99d){var _0x392771=a0_0x3ed468,_0x5a6ba2=lct[_0x392771(0x121)]();return _0x5a6ba2[_0x392771(0x124)]=_0x23d99d,_0x5a6ba2;}withEarthEngine(a0_0x3ed468(0x121),function(){var _0x2026a7=a0_0x3ed468;it(_0x2026a7(0x117),function(_0x46332f){var _0x1a7faf=_0x2026a7,_0x3fe404={'B1':0x7d0,'B2':0xbb8,'B3':0xfa0,'B4':0x1388,'B5':0x1770,'B7':0x1b58},_0x535248=Object['assign']({},_0x3fe404,{'TC1':10222.6,'TC2':-180.9,'TC3':2514.4,'TC4':-1528.5,'TC5':1731.7,'TC6':242.8}),_0x407b8e=TestLandsat5(ee[_0x1a7faf(0x127)]([TestImage[_0x1a7faf(0x11c)](_0x3fe404)])),_0x49b092=_0x407b8e['addTasseledCap'](),_0x445fb0=_0x49b092[_0x1a7faf(0x122)]()['mosaic'](),_0xc3a578=TestImage['reduceConstant'](_0x445fb0);_0xc3a578[_0x1a7faf(0x116)](function(_0xd1f292,_0x4c5a12){var _0x21e271=_0x1a7faf;expect(_0x4c5a12)[_0x21e271(0x11f)]();for(key in _0xd1f292){expect(_0xd1f292[key])[_0x21e271(0x11a)](_0x535248[key],0x1);}_0x46332f();});});});