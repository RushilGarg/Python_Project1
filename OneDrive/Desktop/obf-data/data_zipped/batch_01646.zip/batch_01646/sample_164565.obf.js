/**
 * @license
 * Copyright 2014 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
var a0_0x249042=a0_0x1d50;function a0_0x1d50(_0x5c3034,_0x57ccd7){var _0x38a5f0=a0_0x38a5();return a0_0x1d50=function(_0x1d5081,_0x1ce706){_0x1d5081=_0x1d5081-0x9f;var _0x3dfde5=_0x38a5f0[_0x1d5081];return _0x3dfde5;},a0_0x1d50(_0x5c3034,_0x57ccd7);}function a0_0x38a5(){var _0x504ae2=['polymerProperties','654BnMnAo','getOwnPropertyNames','8601390geZfbo','28897XHSfyB','8VLwkXh','content','updateHTML','postSet','12730RAgziQ','413577VQOJbR','View','initHTML','264924fyJADH','bindData','foam.ui.polymer.gen','2164311usNoeo','bind','47365eUIBph','SUPER','forEach','633230SehGkD','1SKCXIC','textContent'];a0_0x38a5=function(){return _0x504ae2;};return a0_0x38a5();}(function(_0x46fc6d,_0x4561a5){var _0x11aa14=a0_0x1d50,_0x4b3127=_0x46fc6d();while(!![]){try{var _0x1d97d1=-parseInt(_0x11aa14(0xb0))/0x1*(-parseInt(_0x11aa14(0xaf))/0x2)+-parseInt(_0x11aa14(0xaa))/0x3+-parseInt(_0x11aa14(0xa7))/0x4+-parseInt(_0x11aa14(0xac))/0x5*(parseInt(_0x11aa14(0xb3))/0x6)+-parseInt(_0x11aa14(0xb5))/0x7+parseInt(_0x11aa14(0x9f))/0x8*(parseInt(_0x11aa14(0xa4))/0x9)+-parseInt(_0x11aa14(0xa3))/0xa*(-parseInt(_0x11aa14(0xb6))/0xb);if(_0x1d97d1===_0x4561a5)break;else _0x4b3127['push'](_0x4b3127['shift']());}catch(_0x3e73fb){_0x4b3127['push'](_0x4b3127['shift']());}}}(a0_0x38a5,0xa0950),CLASS({'name':a0_0x249042(0xa5),'package':a0_0x249042(0xa9),'extends':'foam.ui.polymer.View','properties':[{'type':'String','name':a0_0x249042(0xa0),'defaultValue':'','postSet':function(){var _0x5eaf90=a0_0x249042;if(this['$'])this['$'][_0x5eaf90(0xb1)]=this[_0x5eaf90(0xa0)];}},{'name':a0_0x249042(0xb2),'factory':function(){return{};}}],'methods':[{'name':a0_0x249042(0xa2),'code':function(_0x14e740,_0x36ae8e,_0x2cf39c){var _0x10500a=a0_0x249042;this[_0x10500a(0xb2)][_0x14e740]=_0x2cf39c,this['bindData']();}},{'name':a0_0x249042(0xa8),'code':function(){var _0x188732=a0_0x249042;if(!this['$'])return;Object[_0x188732(0xb4)](this[_0x188732(0xb2)])[_0x188732(0xae)](function(_0x46512d){this['$'][_0x46512d]=this[_0x46512d];}[_0x188732(0xab)](this));}},{'name':a0_0x249042(0xa6),'code':function(){var _0x393986=a0_0x249042,_0x3082e0=this[_0x393986(0xad)]();return this['bindData'](),_0x3082e0;}},{'name':a0_0x249042(0xa1),'code':function(){var _0x2730b6=a0_0x249042,_0x59f48e=this[_0x2730b6(0xad)]();return this[_0x2730b6(0xa8)](),_0x59f48e;}}],'templates':[function toHTML(){},function toInnerHTML(){}]}));