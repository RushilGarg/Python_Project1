/**
 * @license Highstock JS v8.1.2 (2020-06-16)
 * @module highcharts/indicators/accumulation-distribution
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Indicator series type for Highstock
 *
 * (c) 2010-2019 Sebastian Bochan
 *
 * License: www.highcharts.com/license
 */
'use strict';function a0_0x215d(_0xad3b9a,_0x3d9fa4){var _0x4aec4c=a0_0x4aec();return a0_0x215d=function(_0x215d5f,_0x106ca3){_0x215d5f=_0x215d5f-0x150;var _0x1d6ea7=_0x4aec4c[_0x215d5f];return _0x1d6ea7;},a0_0x215d(_0xad3b9a,_0x3d9fa4);}function a0_0x4aec(){var _0x4ab7bb=['6wAVsOp','72ZsQwAV','1340124uhqAvo','370945MepFPZ','634248pEjoZP','63008JzPEcj','6720756IPZhRQ','13043944snGEEL','12811640StJCbp','9aMLsWs'];a0_0x4aec=function(){return _0x4ab7bb;};return a0_0x4aec();}(function(_0x3cfa1c,_0x677c31){var _0x3e9d8f=a0_0x215d,_0x3f6a63=_0x3cfa1c();while(!![]){try{var _0x67f287=parseInt(_0x3e9d8f(0x154))/0x1+-parseInt(_0x3e9d8f(0x156))/0x2+-parseInt(_0x3e9d8f(0x153))/0x3*(-parseInt(_0x3e9d8f(0x157))/0x4)+parseInt(_0x3e9d8f(0x155))/0x5*(parseInt(_0x3e9d8f(0x152))/0x6)+-parseInt(_0x3e9d8f(0x158))/0x7+parseInt(_0x3e9d8f(0x159))/0x8*(parseInt(_0x3e9d8f(0x151))/0x9)+-parseInt(_0x3e9d8f(0x150))/0xa;if(_0x67f287===_0x677c31)break;else _0x3f6a63['push'](_0x3f6a63['shift']());}catch(_0x4cb393){_0x3f6a63['push'](_0x3f6a63['shift']());}}}(a0_0x4aec,0xd30ca));import'../../indicators/accumulation-distribution.src.js';