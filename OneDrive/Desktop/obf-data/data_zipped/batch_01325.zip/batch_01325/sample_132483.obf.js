/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x266d(_0x273db1,_0x4d76e){var _0x2e9de3=a0_0x2e9d();return a0_0x266d=function(_0x266d3b,_0xc57fb){_0x266d3b=_0x266d3b-0x113;var _0x5ea487=_0x2e9de3[_0x266d3b];return _0x5ea487;},a0_0x266d(_0x273db1,_0x4d76e);}var a0_0xf53a20=a0_0x266d;(function(_0x1478c7,_0x58d426){var _0x4d09e6=a0_0x266d,_0x39ebee=_0x1478c7();while(!![]){try{var _0x5aab90=-parseInt(_0x4d09e6(0x119))/0x1*(parseInt(_0x4d09e6(0x118))/0x2)+-parseInt(_0x4d09e6(0x11a))/0x3*(parseInt(_0x4d09e6(0x116))/0x4)+parseInt(_0x4d09e6(0x11f))/0x5*(-parseInt(_0x4d09e6(0x11d))/0x6)+parseInt(_0x4d09e6(0x114))/0x7+parseInt(_0x4d09e6(0x11c))/0x8*(parseInt(_0x4d09e6(0x11e))/0x9)+parseInt(_0x4d09e6(0x117))/0xa+-parseInt(_0x4d09e6(0x115))/0xb*(-parseInt(_0x4d09e6(0x113))/0xc);if(_0x5aab90===_0x58d426)break;else _0x39ebee['push'](_0x39ebee['shift']());}catch(_0x4240b6){_0x39ebee['push'](_0x39ebee['shift']());}}}(a0_0x2e9d,0xd68ee));function a0_0x2e9d(){var _0xb20983=['18999aoRoeb','20vjoMFB','exports','12PvLpzO','10821223gXfMsA','2488706wjolNr','20vtZGDl','16811840vAUMgD','116682mVhdVO','10RZZjzi','648027GtKxLI','./main.js','2576rggRga','2386164MNCFhH'];a0_0x2e9d=function(){return _0xb20983;};return a0_0x2e9d();}var meanpn=require(a0_0xf53a20(0x11b));module[a0_0xf53a20(0x120)]=meanpn;