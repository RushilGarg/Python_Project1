/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xe67b7d=a0_0x4a8d;(function(_0x25aee9,_0x433762){var _0x496cae=a0_0x4a8d,_0x535ed8=_0x25aee9();while(!![]){try{var _0x21dc16=-parseInt(_0x496cae(0x1dc))/0x1*(parseInt(_0x496cae(0x1d8))/0x2)+parseInt(_0x496cae(0x1e2))/0x3+-parseInt(_0x496cae(0x1de))/0x4+parseInt(_0x496cae(0x1e0))/0x5*(parseInt(_0x496cae(0x1da))/0x6)+parseInt(_0x496cae(0x1d6))/0x7+parseInt(_0x496cae(0x1dd))/0x8+parseInt(_0x496cae(0x1db))/0x9*(-parseInt(_0x496cae(0x1d5))/0xa);if(_0x21dc16===_0x433762)break;else _0x535ed8['push'](_0x535ed8['shift']());}catch(_0xb0e497){_0x535ed8['push'](_0x535ed8['shift']());}}}(a0_0x1eb4,0xe97e3));function a0_0x4a8d(_0x17b4f9,_0x27d651){var _0x1eb49b=a0_0x1eb4();return a0_0x4a8d=function(_0x4a8d47,_0x4e3b47){_0x4a8d47=_0x4a8d47-0x1d4;var _0x33fc39=_0x1eb49b[_0x4a8d47];return _0x33fc39;},a0_0x4a8d(_0x17b4f9,_0x27d651);}function a0_0x1eb4(){var _0x520c0d=['log','11580XmScMi','9PXsENv','12HuwHSe','15052624DxNCxz','4171684IVxKya','./../lib','1070mknfxB','@stdlib/math/base/special/round','4548591XjXTbR','@stdlib/random/base/randu','length','10574770juaaXX','4397554UhFDIQ','@stdlib/array/float64','230372TRNhUP'];a0_0x1eb4=function(){return _0x520c0d;};return a0_0x1eb4();}var randu=require(a0_0xe67b7d(0x1e3)),round=require(a0_0xe67b7d(0x1e1)),Float64Array=require(a0_0xe67b7d(0x1d7)),dcusumpw=require(a0_0xe67b7d(0x1df)),y,x,i;x=new Float64Array(0xa),y=new Float64Array(x['length']);for(i=0x0;i<x[a0_0xe67b7d(0x1d4)];i++){x[i]=round(randu()*0x64);}console['log'](x),console[a0_0xe67b7d(0x1d9)](y),dcusumpw(x['length'],0x0,x,0x1,y,-0x1),console[a0_0xe67b7d(0x1d9)](y);