/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xf80bb0=a0_0x5c1b;function a0_0x1feb(){var _0x68d3cf=['895278sneIlL','534315sCbAZf','911222CByJjb','fail','24269ubRjyy','./../lib','3360534WNRiSf','187pHQGjN','967130bmwRAg','pass','tic','6403050BsSQhp','should\x20not\x20return\x20NaN','@stdlib/math/base/assert/is-nan','2sCRLuZ','@stdlib/random/base/randu','name','@stdlib/bench','16TAeAXB','1552mvKDuY','toc'];a0_0x1feb=function(){return _0x68d3cf;};return a0_0x1feb();}(function(_0x18ace5,_0xecbd92){var _0x2361ac=a0_0x5c1b,_0x274858=_0x18ace5();while(!![]){try{var _0x559cf7=parseInt(_0x2361ac(0x1fb))/0x1*(-parseInt(_0x2361ac(0x1f2))/0x2)+-parseInt(_0x2361ac(0x1f9))/0x3+-parseInt(_0x2361ac(0x1f6))/0x4*(parseInt(_0x2361ac(0x1fa))/0x5)+parseInt(_0x2361ac(0x1ea))/0x6+-parseInt(_0x2361ac(0x1e8))/0x7*(-parseInt(_0x2361ac(0x1f7))/0x8)+-parseInt(_0x2361ac(0x1ef))/0x9+parseInt(_0x2361ac(0x1ec))/0xa*(parseInt(_0x2361ac(0x1eb))/0xb);if(_0x559cf7===_0xecbd92)break;else _0x274858['push'](_0x274858['shift']());}catch(_0x54aa90){_0x274858['push'](_0x274858['shift']());}}}(a0_0x1feb,0x80f82));function a0_0x5c1b(_0x569853,_0x31cef7){var _0x1feb9c=a0_0x1feb();return a0_0x5c1b=function(_0x5c1b33,_0x10f7c2){_0x5c1b33=_0x5c1b33-0x1e7;var _0x3edb4b=_0x1feb9c[_0x5c1b33];return _0x3edb4b;},a0_0x5c1b(_0x569853,_0x31cef7);}var bench=require(a0_0xf80bb0(0x1f5)),randu=require(a0_0xf80bb0(0x1f3)),isnan=require(a0_0xf80bb0(0x1f1)),pkg=require('./../package.json')[a0_0xf80bb0(0x1f4)],wrap=require(a0_0xf80bb0(0x1e9));bench(pkg,function benchmark(_0x389a7c){var _0x126849=a0_0xf80bb0,_0x4d8bf0,_0x4a9b0d,_0x4d3511;_0x389a7c[_0x126849(0x1ee)]();for(_0x4d3511=0x0;_0x4d3511<_0x389a7c['iterations'];_0x4d3511++){_0x4d8bf0=randu()*0x14-0xa,_0x4a9b0d=wrap(_0x4d8bf0,-0x5,0x5),isnan(_0x4a9b0d)&&_0x389a7c[_0x126849(0x1e7)]('should\x20not\x20return\x20NaN');}_0x389a7c[_0x126849(0x1f8)](),isnan(_0x4a9b0d)&&_0x389a7c[_0x126849(0x1e7)](_0x126849(0x1f0)),_0x389a7c[_0x126849(0x1ed)]('benchmark\x20finished'),_0x389a7c['end']();});