/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xdadf3=a0_0x40d0;function a0_0x40d0(_0x19f01b,_0x55070a){var _0x5772bf=a0_0x5772();return a0_0x40d0=function(_0x40d020,_0x5c9097){_0x40d020=_0x40d020-0x1ae;var _0x3bab7f=_0x5772bf[_0x40d020];return _0x3bab7f;},a0_0x40d0(_0x19f01b,_0x55070a);}(function(_0x49cb4e,_0x1cc432){var _0x24767b=a0_0x40d0,_0x26b182=_0x49cb4e();while(!![]){try{var _0x59800d=-parseInt(_0x24767b(0x1bf))/0x1*(-parseInt(_0x24767b(0x1be))/0x2)+-parseInt(_0x24767b(0x1ae))/0x3*(parseInt(_0x24767b(0x1ba))/0x4)+parseInt(_0x24767b(0x1c4))/0x5*(-parseInt(_0x24767b(0x1b4))/0x6)+-parseInt(_0x24767b(0x1af))/0x7+-parseInt(_0x24767b(0x1b0))/0x8+-parseInt(_0x24767b(0x1b6))/0x9*(parseInt(_0x24767b(0x1b2))/0xa)+parseInt(_0x24767b(0x1b9))/0xb;if(_0x59800d===_0x1cc432)break;else _0x26b182['push'](_0x26b182['shift']());}catch(_0x254d2a){_0x26b182['push'](_0x26b182['shift']());}}}(a0_0x5772,0x260da));var bench=require(a0_0xdadf3(0x1bd)),randu=require(a0_0xdadf3(0x1b1)),ceil=require('@stdlib/math/base/special/ceil'),isnan=require(a0_0xdadf3(0x1c1)),pkg=require(a0_0xdadf3(0x1b7))['name'],kurtosis=require(a0_0xdadf3(0x1c2));bench(pkg,function benchmark(_0x256672){var _0x5cda6e=a0_0xdadf3,_0x1bb692,_0x2e51ac,_0x4d2483,_0x3fe051,_0xe049df;_0x256672[_0x5cda6e(0x1bc)]();for(_0xe049df=0x0;_0xe049df<_0x256672[_0x5cda6e(0x1b5)];_0xe049df++){_0x1bb692=ceil(randu()*0x64)+0x14,_0x2e51ac=ceil(randu()*(_0x1bb692-0x1)),_0x4d2483=ceil(randu()*(_0x1bb692-0x1)),_0x3fe051=kurtosis(_0x1bb692,_0x2e51ac,_0x4d2483),isnan(_0x3fe051)&&_0x256672['fail'](_0x5cda6e(0x1b8));}_0x256672[_0x5cda6e(0x1b3)](),isnan(_0x3fe051)&&_0x256672[_0x5cda6e(0x1c3)](_0x5cda6e(0x1b8)),_0x256672['pass'](_0x5cda6e(0x1bb)),_0x256672[_0x5cda6e(0x1c0)]();});function a0_0x5772(){var _0x46bbb8=['@stdlib/random/base/randu','4000MySjaT','toc','24IWLaWq','iterations','4302giYkAF','./../package.json','should\x20not\x20return\x20NaN','10750168opBflQ','32DyruMz','benchmark\x20finished','tic','@stdlib/bench','2tHgron','264466TsUtoo','end','@stdlib/math/base/assert/is-nan','./../lib','fail','363040OiMcNB','53955vXcxqs','1972957nHuKDB','1428200yrzOuu'];a0_0x5772=function(){return _0x46bbb8;};return a0_0x5772();}