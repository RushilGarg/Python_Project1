/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x5ea2(_0x41eada,_0x420f37){var _0x1a2da8=a0_0x1a2d();return a0_0x5ea2=function(_0x5ea27f,_0x2a9674){_0x5ea27f=_0x5ea27f-0x11c;var _0x268978=_0x1a2da8[_0x5ea27f];return _0x268978;},a0_0x5ea2(_0x41eada,_0x420f37);}var a0_0xad70eb=a0_0x5ea2;function a0_0x1a2d(){var _0x59a125=['11OcvoEa','./factory.js','40pwRtZn','111kqvIFg','121434jRxZWP','2232085avNRsz','exports','5967372jmZruD','790504Crffcq','13042OBChBC','2583910AwBOBR','1733067OaxQrk','factory','7eFbLMY'];a0_0x1a2d=function(){return _0x59a125;};return a0_0x1a2d();}(function(_0x17fa45,_0x550f1d){var _0x1729b8=a0_0x5ea2,_0x3b4d02=_0x17fa45();while(!![]){try{var _0xa2643f=-parseInt(_0x1729b8(0x121))/0x1*(parseInt(_0x1729b8(0x127))/0x2)+-parseInt(_0x1729b8(0x122))/0x3*(-parseInt(_0x1729b8(0x120))/0x4)+-parseInt(_0x1729b8(0x123))/0x5+-parseInt(_0x1729b8(0x125))/0x6*(-parseInt(_0x1729b8(0x11d))/0x7)+-parseInt(_0x1729b8(0x126))/0x8+parseInt(_0x1729b8(0x129))/0x9+parseInt(_0x1729b8(0x128))/0xa*(parseInt(_0x1729b8(0x11e))/0xb);if(_0xa2643f===_0x550f1d)break;else _0x3b4d02['push'](_0x3b4d02['shift']());}catch(_0x305250){_0x3b4d02['push'](_0x3b4d02['shift']());}}}(a0_0x1a2d,0x8de73));var setReadOnly=require('@stdlib/utils/define-nonenumerable-read-only-property'),quantile=require('./quantile.js'),factory=require(a0_0xad70eb(0x11f));setReadOnly(quantile,a0_0xad70eb(0x11c),factory),module[a0_0xad70eb(0x124)]=quantile;