/**
 * @license
 * 
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
const a0_0x3b7e59=a0_0x3aca;(function(_0x53f1b0,_0xb6a833){const _0xa9a1be=a0_0x3aca,_0x394c19=_0x53f1b0();while(!![]){try{const _0x4494ee=-parseInt(_0xa9a1be(0xd2))/0x1+parseInt(_0xa9a1be(0xd3))/0x2*(-parseInt(_0xa9a1be(0xce))/0x3)+parseInt(_0xa9a1be(0xd9))/0x4*(-parseInt(_0xa9a1be(0xc8))/0x5)+parseInt(_0xa9a1be(0xc5))/0x6*(-parseInt(_0xa9a1be(0xda))/0x7)+parseInt(_0xa9a1be(0xd8))/0x8*(parseInt(_0xa9a1be(0xd1))/0x9)+-parseInt(_0xa9a1be(0xca))/0xa+parseInt(_0xa9a1be(0xcf))/0xb;if(_0x4494ee===_0xb6a833)break;else _0x394c19['push'](_0x394c19['shift']());}catch(_0x23d9bf){_0x394c19['push'](_0x394c19['shift']());}}}(a0_0x138b,0x7584b));import*as a0_0x235872 from'blockly/core';import'blockly/blocks';function a0_0x138b(){const _0x2454d7=['click','Check\x20the\x20console\x20for\x20the\x20generated\x20output.','inject','media/','385048uTkZWj','834052mntAYu','14DCngXT','blocklyDiv','JavaScript','537066HbKZRY','addEventListener','DOMContentLoaded','5hZNqeO','workspaceToCode','8853420VvsOeh','log','toolbox','getElementById','6eOtpxP','30627355WJzTpp','blocklyButton','63wliKkP','897512zrdCud','469478flrCmQ'];a0_0x138b=function(){return _0x2454d7;};return a0_0x138b();}import'blockly/javascript';function a0_0x3aca(_0x327f88,_0x1292a9){const _0x138be8=a0_0x138b();return a0_0x3aca=function(_0x3acae4,_0x10bd30){_0x3acae4=_0x3acae4-0xc5;let _0x56a7f5=_0x138be8[_0x3acae4];return _0x56a7f5;},a0_0x3aca(_0x327f88,_0x1292a9);}import*as a0_0xafb341 from'blockly/msg/fr';a0_0x235872['setLocale'](a0_0xafb341),document[a0_0x3b7e59(0xc6)](a0_0x3b7e59(0xc7),function(){const _0x2915f6=a0_0x3b7e59,_0x17b525=a0_0x235872[_0x2915f6(0xd6)](_0x2915f6(0xdb),{'toolbox':document[_0x2915f6(0xcd)](_0x2915f6(0xcc)),'media':_0x2915f6(0xd7)}),_0x5c1bc7=_0x2915f6(0xdc),_0x94dad0=document[_0x2915f6(0xcd)](_0x2915f6(0xd0));_0x94dad0['addEventListener'](_0x2915f6(0xd4),function(){const _0x26d582=_0x2915f6;alert(_0x26d582(0xd5));const _0x469e26=a0_0x235872[_0x5c1bc7][_0x26d582(0xc9)](_0x17b525);console[_0x26d582(0xcb)](_0x469e26);});});