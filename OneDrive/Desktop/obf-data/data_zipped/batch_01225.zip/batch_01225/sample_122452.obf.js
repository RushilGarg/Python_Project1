/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x11ce(){var _0x46937c=['187FDOkUy','2008768ASukrH','throws\x20an\x20error','549114hBtYkV','throws','684SwETFR','10CmnBSB','main\x20export\x20is\x20a\x20function','function','tape','167272PmHTTP','end','./../lib/main.js','proxyquire','112uzmoqv','1398149xoxYyv','strictEqual','10ETPRJR','160479mgWZGU','17466680vuNYfW','4112652jtPrTw'];a0_0x11ce=function(){return _0x46937c;};return a0_0x11ce();}var a0_0x4ca838=a0_0x22f0;(function(_0x5f39f5,_0x3aa243){var _0x50f88e=a0_0x22f0,_0x54b12f=_0x5f39f5();while(!![]){try{var _0x5d05bd=-parseInt(_0x50f88e(0x11c))/0x1+-parseInt(_0x50f88e(0x113))/0x2*(-parseInt(_0x50f88e(0x10a))/0x3)+parseInt(_0x50f88e(0x10e))/0x4*(parseInt(_0x50f88e(0x11e))/0x5)+-parseInt(_0x50f88e(0x110))/0x6*(parseInt(_0x50f88e(0x11b))/0x7)+-parseInt(_0x50f88e(0x117))/0x8*(parseInt(_0x50f88e(0x112))/0x9)+-parseInt(_0x50f88e(0x10b))/0xa+-parseInt(_0x50f88e(0x10d))/0xb*(-parseInt(_0x50f88e(0x10c))/0xc);if(_0x5d05bd===_0x3aa243)break;else _0x54b12f['push'](_0x54b12f['shift']());}catch(_0x14f1ca){_0x54b12f['push'](_0x54b12f['shift']());}}}(a0_0x11ce,0xdbb3d));function a0_0x22f0(_0x52616e,_0x20ed0b){var _0x11cea0=a0_0x11ce();return a0_0x22f0=function(_0x22f00d,_0x31206c){_0x22f00d=_0x22f00d-0x10a;var _0x322289=_0x11cea0[_0x22f00d];return _0x322289;},a0_0x22f0(_0x52616e,_0x20ed0b);}var tape=require(a0_0x4ca838(0x116)),proxyquire=require(a0_0x4ca838(0x11a)),afinn96=require(a0_0x4ca838(0x119));tape(a0_0x4ca838(0x114),function test(_0x36ed1b){var _0x2d94e0=a0_0x4ca838;_0x36ed1b['ok'](!![],__filename),_0x36ed1b[_0x2d94e0(0x11d)](typeof afinn96,_0x2d94e0(0x115),_0x2d94e0(0x114)),_0x36ed1b[_0x2d94e0(0x118)]();}),tape('the\x20function\x20throws\x20an\x20error\x20if\x20unable\x20to\x20load\x20data',function test(_0x2eec4e){var _0x206fdc=a0_0x4ca838,_0x4eb2e1=proxyquire(_0x206fdc(0x119),{'@stdlib/fs/read-json':{'sync':_0x1afca0}});_0x2eec4e[_0x206fdc(0x111)](_0x4eb2e1,Error,_0x206fdc(0x10f)),_0x2eec4e[_0x206fdc(0x118)]();function _0x1afca0(){return new Error('unable\x20to\x20read\x20data');}});