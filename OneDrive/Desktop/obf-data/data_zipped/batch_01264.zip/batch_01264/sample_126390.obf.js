/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0xb7c7(){var _0x4795ea=['51021wOjoyH','458332OTQFfz','length','8168710rPzepW','543373qhPckB','187295RwwxDf','Same\x20reference:\x20%s','./../lib','Same\x20length:\x20%s','408LodzHN','114LojBlC','176WgzpRI','@stdlib/buffer/alloc-unsafe','log','4136WEekYb','486186LsxbLB'];a0_0xb7c7=function(){return _0x4795ea;};return a0_0xb7c7();}var a0_0x2ac460=a0_0xc334;(function(_0x4bbbbf,_0x166dba){var _0x17cbcf=a0_0xc334,_0x201da4=_0x4bbbbf();while(!![]){try{var _0x242c53=parseInt(_0x17cbcf(0x79))/0x1+-parseInt(_0x17cbcf(0x74))/0x2+parseInt(_0x17cbcf(0x7e))/0x3*(parseInt(_0x17cbcf(0x73))/0x4)+parseInt(_0x17cbcf(0x7a))/0x5+-parseInt(_0x17cbcf(0x6f))/0x6*(-parseInt(_0x17cbcf(0x76))/0x7)+parseInt(_0x17cbcf(0x70))/0x8*(-parseInt(_0x17cbcf(0x75))/0x9)+-parseInt(_0x17cbcf(0x78))/0xa;if(_0x242c53===_0x166dba)break;else _0x201da4['push'](_0x201da4['shift']());}catch(_0x4a7b57){_0x201da4['push'](_0x201da4['shift']());}}}(a0_0xb7c7,0xbea12));function a0_0xc334(_0x4c85ce,_0x19305e){var _0xb7c70e=a0_0xb7c7();return a0_0xc334=function(_0xc33498,_0x289294){_0xc33498=_0xc33498-0x6f;var _0x48fdde=_0xb7c70e[_0xc33498];return _0x48fdde;},a0_0xc334(_0x4c85ce,_0x19305e);}var allocUnsafe=require(a0_0x2ac460(0x71)),copyBuffer=require(a0_0x2ac460(0x7c)),bool,b1,b2,i;b1=allocUnsafe(0xa),b2=copyBuffer(b1),bool=b2===b1,console[a0_0x2ac460(0x72)](a0_0x2ac460(0x7b),bool),bool=b2['length']===b1[a0_0x2ac460(0x77)],console['log'](a0_0x2ac460(0x7d),bool);for(i=0x0;i<b2[a0_0x2ac460(0x77)];i++){console[a0_0x2ac460(0x72)](b2[i]===b1[i]);}