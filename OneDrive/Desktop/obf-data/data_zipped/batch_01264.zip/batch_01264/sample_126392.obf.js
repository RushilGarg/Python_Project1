/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x7a5420=a0_0x1230;(function(_0x25005e,_0x3a3e25){var _0xbcee40=a0_0x1230,_0x46b38f=_0x25005e();while(!![]){try{var _0x3db249=parseInt(_0xbcee40(0x1e6))/0x1*(-parseInt(_0xbcee40(0x1eb))/0x2)+-parseInt(_0xbcee40(0x1e3))/0x3*(parseInt(_0xbcee40(0x1f1))/0x4)+parseInt(_0xbcee40(0x1ea))/0x5*(-parseInt(_0xbcee40(0x1ee))/0x6)+-parseInt(_0xbcee40(0x1f2))/0x7*(-parseInt(_0xbcee40(0x1e9))/0x8)+parseInt(_0xbcee40(0x1e8))/0x9+-parseInt(_0xbcee40(0x1ef))/0xa+-parseInt(_0xbcee40(0x1ec))/0xb*(-parseInt(_0xbcee40(0x1f4))/0xc);if(_0x3db249===_0x3a3e25)break;else _0x46b38f['push'](_0x46b38f['shift']());}catch(_0x15a53b){_0x46b38f['push'](_0x46b38f['shift']());}}}(a0_0x595b,0xd5d31));var logger=require(a0_0x7a5420(0x1e4)),isFunction=require('@stdlib/assert/is-function'),debug=logger(a0_0x7a5420(0x1e5));function set(_0x8ecd97){var _0x28f493=a0_0x7a5420;if(!isFunction(_0x8ecd97))throw new TypeError(_0x28f493(0x1f0)+_0x8ecd97+'.`');debug('Current\x20value:\x20%s.',this['_isDefined']),this[_0x28f493(0x1e7)]=_0x8ecd97,debug(_0x28f493(0x1f5),this['_isDefined']),this[_0x28f493(0x1ed)](_0x28f493(0x1f3));}function a0_0x1230(_0x2ab998,_0x2a455f){var _0x595bd9=a0_0x595b();return a0_0x1230=function(_0x123004,_0xb6ae53){_0x123004=_0x123004-0x1e3;var _0x407178=_0x595bd9[_0x123004];return _0x407178;},a0_0x1230(_0x2ab998,_0x2a455f);}module['exports']=set;function a0_0x595b(){var _0x103992=['New\x20Value:\x20%s.','225yJmUnH','debug','symbols:set:is-defined','10FDjwiH','_isDefined','13415220VZvEfG','8QUQqmt','60wMmBdW','8312NimgWI','539wzQydu','emit','58008iUrZPE','8726040tOqNFu','invalid\x20value.\x20`isDefined`\x20must\x20be\x20a\x20function.\x20Value:\x20`','23812CLkhZS','5676923xgDCFj','change','12468JIHooP'];a0_0x595b=function(){return _0x103992;};return a0_0x595b();}