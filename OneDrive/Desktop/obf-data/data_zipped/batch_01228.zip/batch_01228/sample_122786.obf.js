/**
 * Pimcore
 *
 * LICENSE
 *
 * This source file is subject to the new BSD license that is bundled
 * with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.pimcore.org/license
 *
 * @copyright  Copyright (c) 2009-2010 elements.at New Media Solutions GmbH (http://www.elements.at)
 * @license    http://www.pimcore.org/license     New BSD License
 */
var a0_0x44948f=a0_0x1cc3;(function(_0x5ca639,_0x5cf218){var _0x4bc376=a0_0x1cc3,_0x258269=_0x5ca639();while(!![]){try{var _0x1d845d=parseInt(_0x4bc376(0xaa))/0x1+-parseInt(_0x4bc376(0xa2))/0x2+-parseInt(_0x4bc376(0xa4))/0x3*(parseInt(_0x4bc376(0xa5))/0x4)+parseInt(_0x4bc376(0xa8))/0x5+-parseInt(_0x4bc376(0xa6))/0x6+-parseInt(_0x4bc376(0xae))/0x7+parseInt(_0x4bc376(0xac))/0x8*(parseInt(_0x4bc376(0xa1))/0x9);if(_0x1d845d===_0x5cf218)break;else _0x258269['push'](_0x258269['shift']());}catch(_0x30ed6c){_0x258269['push'](_0x258269['shift']());}}}(a0_0x1e36,0x752b9),pimcore[a0_0x44948f(0xa3)]('pimcore.user'),pimcore['user']=Class[a0_0x44948f(0xa7)]({'initialize':function(_0x1e06b8){var _0x734b74=a0_0x44948f;Object[_0x734b74(0xab)](this,_0x1e06b8);},'isAllowed':function(_0x1fe6c8){var _0x15a068=a0_0x44948f;if(this[_0x15a068(0xa9)])return!![];if(typeof this[_0x15a068(0xad)]=='object'){if(in_array(_0x1fe6c8,this[_0x15a068(0xad)]))return!![];}return![];}}));function a0_0x1cc3(_0x48d358,_0x471697){var _0x1e36ff=a0_0x1e36();return a0_0x1cc3=function(_0x1cc339,_0x148a36){_0x1cc339=_0x1cc339-0xa1;var _0x764a08=_0x1e36ff[_0x1cc339];return _0x764a08;},a0_0x1cc3(_0x48d358,_0x471697);}function a0_0x1e36(){var _0x4129d5=['extend','2502048ZPuNee','permissions','1118194MFhuAs','36hIFCYg','707338eMgxQE','registerNS','6948Gwnwwr','660MENFVJ','731532cwlOFS','create','1148525eDVurC','admin','16673OgCyIS'];a0_0x1e36=function(){return _0x4129d5;};return a0_0x1e36();}