/** PROMISIFY CALLBACK-STYLE FUNCTIONS TO ES6 PROMISES
*
* EXAMPLE:
* const fn = promisify( (callback) => callback(null, "Hello world!") );
* fn((err, str) => console.log(str));
* fn().then((str) => console.log(str));
* //Both functions, will log 'Hello world!'
*
* Note: The function you pass, may have any arguments you want, but the latest
* have to be the callback, which you will call with: next(err, value)
*
* @param method: Function/Array/Map = The function(s) to promisify
* @param options: Map =
*  "context" (default is function): The context which to apply the called function
*  "replace" (default is falsy): When passed an array/map, if to replace the original object
*
* @return: A promise if passed a function, otherwise the object with the promises
*
* @license: MIT
* @version: 1.0.3
* @author: Manuel Di Iorio
**/
var a0_0x5ab08b=a0_0x47f9;function a0_0x47f9(_0x413b11,_0x34b792){var _0x32a6dd=a0_0x32a6();return a0_0x47f9=function(_0x47f9e7,_0x3aaa3d){_0x47f9e7=_0x47f9e7-0x176;var _0x4fe432=_0x32a6dd[_0x47f9e7];return _0x4fe432;},a0_0x47f9(_0x413b11,_0x34b792);}(function(_0x1299e9,_0xa8a041){var _0x1d5afa=a0_0x47f9,_0x51e4e4=_0x1299e9();while(!![]){try{var _0x1e85ba=parseInt(_0x1d5afa(0x176))/0x1+parseInt(_0x1d5afa(0x178))/0x2*(parseInt(_0x1d5afa(0x188))/0x3)+parseInt(_0x1d5afa(0x184))/0x4*(parseInt(_0x1d5afa(0x177))/0x5)+parseInt(_0x1d5afa(0x18d))/0x6+-parseInt(_0x1d5afa(0x17e))/0x7*(parseInt(_0x1d5afa(0x18a))/0x8)+-parseInt(_0x1d5afa(0x186))/0x9+-parseInt(_0x1d5afa(0x17d))/0xa*(parseInt(_0x1d5afa(0x183))/0xb);if(_0x1e85ba===_0xa8a041)break;else _0x51e4e4['push'](_0x51e4e4['shift']());}catch(_0x1571d7){_0x51e4e4['push'](_0x51e4e4['shift']());}}}(a0_0x32a6,0xee582));var createCallback=function(_0x39c457,_0x4ee768){return function(){var _0x3ec5ba=a0_0x47f9,_0x1201a4=Array['prototype'][_0x3ec5ba(0x190)][_0x3ec5ba(0x18b)](arguments),_0x31f2e2=_0x1201a4['length']-0x1,_0x66bce4=_0x1201a4&&_0x1201a4[_0x3ec5ba(0x17f)]>0x0?_0x1201a4[_0x31f2e2]:null,_0x3eb7d1=typeof _0x66bce4===_0x3ec5ba(0x180)?_0x66bce4:null;if(_0x3eb7d1)return _0x39c457[_0x3ec5ba(0x182)](_0x4ee768,_0x1201a4);return new Promise(function(_0x3b0b15,_0x3552f7){var _0xb366e0=_0x3ec5ba;_0x1201a4[_0xb366e0(0x17c)](function(_0xe1635a,_0xad89ab){if(_0xe1635a)return _0x3552f7(_0xe1635a);_0x3b0b15(_0xad89ab);}),_0x39c457['apply'](_0x4ee768,_0x1201a4);});};};if(typeof module===a0_0x5ab08b(0x18f))module={};function a0_0x32a6(){var _0x565b1f=['1852lmjzvs','promisify','[object\x20Array]','replace','push','10gEEHof','5824AGiZPj','length','function','exports','apply','39850415koPlDR','1888864XWKHZx','toString','4721148BSoeIm','[object\x20Object]','4449WzttHT','prototype','3248JRLNoZ','call','context','9647286eBbrsj','hasOwnProperty','undefined','slice','1063600uUOzlb','15LETRmj'];a0_0x32a6=function(){return _0x565b1f;};return a0_0x32a6();}module[a0_0x5ab08b(0x181)]=function(_0x14bee0,_0x14d0a2){var _0x4cd474=a0_0x5ab08b;_0x14d0a2=_0x14d0a2||{};var _0x3ef367=Object[_0x4cd474(0x189)][_0x4cd474(0x185)][_0x4cd474(0x18b)](_0x14bee0);if(_0x3ef367===_0x4cd474(0x187)||_0x3ef367===_0x4cd474(0x17a)){var _0x5d9e47=_0x14d0a2[_0x4cd474(0x17b)]?_0x14bee0:{};for(var _0x37d3e2 in _0x14bee0){if(_0x14bee0[_0x4cd474(0x18e)](_0x37d3e2))_0x5d9e47[_0x37d3e2]=createCallback(_0x14bee0[_0x37d3e2]);}return _0x5d9e47;}return createCallback(_0x14bee0,_0x14d0a2[_0x4cd474(0x18c)]||_0x14bee0);};typeof exports===a0_0x5ab08b(0x18f)&&(this[a0_0x5ab08b(0x179)]=module[a0_0x5ab08b(0x181)]);