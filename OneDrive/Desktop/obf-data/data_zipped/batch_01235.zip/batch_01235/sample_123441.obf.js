function a0_0x2bbb(_0x45cb9f,_0x40f282){var _0x5ed85b=a0_0x5ed8();return a0_0x2bbb=function(_0x2bbbf3,_0x546c41){_0x2bbbf3=_0x2bbbf3-0x150;var _0x15eaca=_0x5ed85b[_0x2bbbf3];return _0x15eaca;},a0_0x2bbb(_0x45cb9f,_0x40f282);}var a0_0x34267f=a0_0x2bbb;function a0_0x5ed8(){var _0x534bb5=['rad-classnamed','1060848rJLDHn','2CSQwXZ','brandClass','1773IptPVz','card-default','rad-card','3954IqHFVv','1795LCPxNA','card','2460036Rdxvld','1644979RMuwzN','brand','84690ukXyyU','404531vaqlUe','994017bROzFM'];a0_0x5ed8=function(){return _0x534bb5;};return a0_0x5ed8();}(function(_0x38558e,_0x320ecc){var _0x48d477=a0_0x2bbb,_0x38145b=_0x38558e();while(!![]){try{var _0x413b57=-parseInt(_0x48d477(0x152))/0x1+-parseInt(_0x48d477(0x156))/0x2*(-parseInt(_0x48d477(0x153))/0x3)+-parseInt(_0x48d477(0x15e))/0x4+-parseInt(_0x48d477(0x15c))/0x5*(parseInt(_0x48d477(0x15b))/0x6)+-parseInt(_0x48d477(0x15f))/0x7+-parseInt(_0x48d477(0x155))/0x8+-parseInt(_0x48d477(0x158))/0x9*(-parseInt(_0x48d477(0x151))/0xa);if(_0x413b57===_0x320ecc)break;else _0x38145b['push'](_0x38145b['shift']());}catch(_0x1b7ddb){_0x38145b['push'](_0x38145b['shift']());}}}(a0_0x5ed8,0x5bcc8));import a0_0x2f50e6 from'@ember/component';import{computed}from'@ember/object';import a0_0x3f0195 from'htmlbars-inline-precompile';export default a0_0x2f50e6['extend']({'brand':'','blockComponent':a0_0x34267f(0x154),'bodyComponent':'rad-classnamed','footerComponent':a0_0x34267f(0x154),'headerComponent':a0_0x34267f(0x154),'titleComponent':a0_0x34267f(0x154),'attributeBindings':['data-test'],'brandClass':computed(function(){var _0x54aba8=a0_0x34267f;return this[_0x54aba8(0x150)]?'card-'+this[_0x54aba8(0x150)]:_0x54aba8(0x159);}),'classNames':[a0_0x34267f(0x15d),a0_0x34267f(0x15a)],'classNameBindings':[a0_0x34267f(0x157)],'layout':a0_0x3f0195`
    {{! TODO: make title an h4 by default in v2, old titles should actually be
        headers in v2 }}
    {{yield (hash
      block=(component blockComponent
        _classNames='card-block'
        data-test=(if data-test (concat data-test '-block')))
      body=(component bodyComponent
        _classNames='card-block card-body'
        data-test=(if data-test (concat data-test '-body')))
      footer=(component footerComponent
        _classNames='card-footer'
        data-test=(if data-test (concat data-test '-footer')))
      header=(component headerComponent
        _classNames='card-header'
        data-test=(if data-test (concat data-test '-header')))
      title=(component titleComponent
        _classNames='card-title'
        tagName='div'
        data-test=(if data-test (concat data-test '-title')))
    )}}
  `});