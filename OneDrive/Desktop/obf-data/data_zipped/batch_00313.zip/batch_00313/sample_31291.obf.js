/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4d45a1=a0_0x4826;(function(_0x49b744,_0x5779e5){var _0x436aec=a0_0x4826,_0x4a310a=_0x49b744();while(!![]){try{var _0x3a4d9f=-parseInt(_0x436aec(0x1ba))/0x1*(-parseInt(_0x436aec(0x1bc))/0x2)+parseInt(_0x436aec(0x1b4))/0x3+-parseInt(_0x436aec(0x1be))/0x4+parseInt(_0x436aec(0x1c1))/0x5+parseInt(_0x436aec(0x1c3))/0x6*(parseInt(_0x436aec(0x1b9))/0x7)+parseInt(_0x436aec(0x1b8))/0x8+parseInt(_0x436aec(0x1b7))/0x9;if(_0x3a4d9f===_0x5779e5)break;else _0x4a310a['push'](_0x4a310a['shift']());}catch(_0x34d80a){_0x4a310a['push'](_0x4a310a['shift']());}}}(a0_0x130c,0xecbdc));var tape=require(a0_0x4d45a1(0x1c2)),nanvariancech=require(a0_0x4d45a1(0x1b6));function a0_0x130c(){var _0x58ec1f=['function','./../lib','703422IGOjnZ','3730792HOUSRy','7DLSioP','2589OabyyV','main\x20export\x20is\x20a\x20function','610fcthNn','end','7397912Dcmhxt','strictEqual','attached\x20to\x20the\x20main\x20export\x20is\x20a\x20method\x20providing\x20an\x20ndarray\x20interface','1438765NXiaHO','tape','5004294uvVGQo','method\x20is\x20a\x20function','1089648cLVATm'];a0_0x130c=function(){return _0x58ec1f;};return a0_0x130c();}function a0_0x4826(_0x465dcf,_0x45ae8a){var _0x130ce6=a0_0x130c();return a0_0x4826=function(_0x4826bb,_0x4cfe11){_0x4826bb=_0x4826bb-0x1b4;var _0x14564a=_0x130ce6[_0x4826bb];return _0x14564a;},a0_0x4826(_0x465dcf,_0x45ae8a);}tape(a0_0x4d45a1(0x1bb),function test(_0x50932a){var _0x34cd60=a0_0x4d45a1;_0x50932a['ok'](!![],__filename),_0x50932a[_0x34cd60(0x1bf)](typeof nanvariancech,_0x34cd60(0x1b5),_0x34cd60(0x1bb)),_0x50932a['end']();}),tape(a0_0x4d45a1(0x1c0),function test(_0x5b6aa4){var _0x92aef3=a0_0x4d45a1;_0x5b6aa4[_0x92aef3(0x1bf)](typeof nanvariancech['ndarray'],_0x92aef3(0x1b5),_0x92aef3(0x1c4)),_0x5b6aa4[_0x92aef3(0x1bd)]();});