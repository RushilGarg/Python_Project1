/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x3238e1=a0_0x2cfd;(function(_0x39e64d,_0x1d457f){var _0x17c44c=a0_0x2cfd,_0x4ea665=_0x39e64d();while(!![]){try{var _0x129c4e=-parseInt(_0x17c44c(0x133))/0x1*(-parseInt(_0x17c44c(0x13b))/0x2)+parseInt(_0x17c44c(0x12f))/0x3+parseInt(_0x17c44c(0x137))/0x4+parseInt(_0x17c44c(0x13e))/0x5*(-parseInt(_0x17c44c(0x13d))/0x6)+-parseInt(_0x17c44c(0x12e))/0x7+-parseInt(_0x17c44c(0x132))/0x8*(parseInt(_0x17c44c(0x131))/0x9)+parseInt(_0x17c44c(0x138))/0xa*(parseInt(_0x17c44c(0x135))/0xb);if(_0x129c4e===_0x1d457f)break;else _0x4ea665['push'](_0x4ea665['shift']());}catch(_0x16b837){_0x4ea665['push'](_0x4ea665['shift']());}}}(a0_0x5507,0xa97d9));function a0_0x2cfd(_0x2286ba,_0x5ca5d1){var _0x55072d=a0_0x5507();return a0_0x2cfd=function(_0x2cfdcb,_0x332434){_0x2cfdcb=_0x2cfdcb-0x12e;var _0x202cfc=_0x55072d[_0x2cfdcb];return _0x202cfc;},a0_0x2cfd(_0x2286ba,_0x5ca5d1);}function a0_0x5507(){var _0x5ed3b7=['70244SfOgkk','end','952716OVavsH','40HMuoyr','pass','benchmark\x20finished','7516460tgXzzw','295203oHifRA','should\x20not\x20return\x20NaN','13329plXbyL','2168kOTyRd','31iPIUxc','tic','14366517MvKflN','./../package.json','3785688ZOXpqs','10mwDGon','toc','./../lib'];a0_0x5507=function(){return _0x5ed3b7;};return a0_0x5507();}var bench=require('@stdlib/bench'),randu=require('@stdlib/random/base/randu'),isnan=require('@stdlib/math/base/assert/is-nan'),EPS=require('@stdlib/constants/float64/eps'),pkg=require(a0_0x3238e1(0x136))['name'],mode=require(a0_0x3238e1(0x13a));bench(pkg,function benchmark(_0x306dea){var _0x2992ce=a0_0x3238e1,_0x1810ce,_0x65ee0e,_0xd2a3d1,_0x3f7631;_0x306dea[_0x2992ce(0x134)]();for(_0x3f7631=0x0;_0x3f7631<_0x306dea['iterations'];_0x3f7631++){_0x1810ce=randu()*0xa+0x2+EPS,_0x65ee0e=randu()*0xa+EPS,_0xd2a3d1=mode(_0x1810ce,_0x65ee0e),isnan(_0xd2a3d1)&&_0x306dea['fail'](_0x2992ce(0x130));}_0x306dea[_0x2992ce(0x139)](),isnan(_0xd2a3d1)&&_0x306dea['fail'](_0x2992ce(0x130)),_0x306dea[_0x2992ce(0x13f)](_0x2992ce(0x140)),_0x306dea[_0x2992ce(0x13c)]();});