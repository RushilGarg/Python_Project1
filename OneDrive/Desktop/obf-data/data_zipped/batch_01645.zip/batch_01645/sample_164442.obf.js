const a0_0x353b3d=a0_0x7789;(function(_0xb751bc,_0x20ec95){const _0x429c43=a0_0x7789,_0x29c0fc=_0xb751bc();while(!![]){try{const _0x4554dd=-parseInt(_0x429c43(0x1f6))/0x1*(-parseInt(_0x429c43(0x203))/0x2)+-parseInt(_0x429c43(0x200))/0x3+parseInt(_0x429c43(0x1fd))/0x4+parseInt(_0x429c43(0x204))/0x5+-parseInt(_0x429c43(0x202))/0x6*(-parseInt(_0x429c43(0x1f5))/0x7)+parseInt(_0x429c43(0x1f9))/0x8*(-parseInt(_0x429c43(0x1f2))/0x9)+-parseInt(_0x429c43(0x1f7))/0xa;if(_0x4554dd===_0x20ec95)break;else _0x29c0fc['push'](_0x29c0fc['shift']());}catch(_0x51e4dd){_0x29c0fc['push'](_0x29c0fc['shift']());}}}(a0_0x14cc,0x726bc));import a0_0x1a02c6 from'../../src/base/AriaListMixin.js';import a0_0x5aa252 from'../../src/base/ContentItemsMixin.js';import a0_0x5b177b from'../../src/base/CursorAPIMixin.js';import a0_0x59e6c1 from'../../src/base/CursorInViewMixin.js';import a0_0x424861 from'../../src/base/CursorSelectMixin.js';import a0_0x47e2ae from'../../src/base/DirectionCursorMixin.js';import{defaultState,firstRender,ids,render,rendered,scrollTarget,setState,state,template}from'../../src/base/internal.js';import a0_0x2d5d8a from'../../src/base/ItemsAPIMixin.js';import a0_0x29e7d1 from'../../src/base/ItemsCursorMixin.js';function a0_0x14cc(){const _0x274ac1=['orientation','16EkyOZW','country-list-box','vertical','assign','3561468XOzVel','currentIndex','forEach','1243500AfkQky','content','36domnKf','53870tdNGjG','2223300SQLlWS','define','3051459dDORAm','selected','items','173019qoImok','34OeWeKA','8378490rIOSWe'];a0_0x14cc=function(){return _0x274ac1;};return a0_0x14cc();}import a0_0x190c3b from'../../src/base/ItemsTextMixin.js';import a0_0x33087b from'../../src/base/KeyboardDirectionMixin.js';import a0_0x250920 from'../../src/base/KeyboardMixin.js';import a0_0x5ef477 from'../../src/base/KeyboardPagedCursorMixin.js';import a0_0x10f49b from'../../src/base/KeyboardPrefixCursorMixin.js';import a0_0x5bd24f from'../../src/base/LanguageDirectionMixin.js';import a0_0x1efa5c from'../../src/base/SelectedTextAPIMixin.js';function a0_0x7789(_0x160f18,_0x5680d9){const _0x14cc68=a0_0x14cc();return a0_0x7789=function(_0x77895,_0x4db1d4){_0x77895=_0x77895-0x1f2;let _0x2fa235=_0x14cc68[_0x77895];return _0x2fa235;},a0_0x7789(_0x160f18,_0x5680d9);}import a0_0x431052 from'../../src/base/SingleSelectAPIMixin.js';import a0_0x42204b from'../../src/base/TapCursorMixin.js';import{templateFrom}from'../../src/core/htmlLiterals.js';import a0_0x366bf4 from'../../src/core/ReactiveElement.js';const Base=a0_0x1a02c6(a0_0x5aa252(a0_0x5b177b(a0_0x59e6c1(a0_0x424861(a0_0x47e2ae(a0_0x2d5d8a(a0_0x29e7d1(a0_0x190c3b(a0_0x33087b(a0_0x250920(a0_0x5ef477(a0_0x10f49b(a0_0x5bd24f(a0_0x1efa5c(a0_0x431052(a0_0x42204b(a0_0x366bf4)))))))))))))))));class CountryListBox extends Base{get[defaultState](){const _0x1763ef=a0_0x7789;return Object[_0x1763ef(0x1fc)](super[defaultState],{'orientation':_0x1763ef(0x1fb)});}get[a0_0x353b3d(0x1f8)](){const _0xbb30cc=a0_0x353b3d;return this[state][_0xbb30cc(0x1f8)];}[render](_0x3e8c8c){const _0x432b2f=a0_0x353b3d;super[render](_0x3e8c8c);if(_0x3e8c8c[_0x432b2f(0x1f4)]||_0x3e8c8c[_0x432b2f(0x1fe)]){const {currentIndex:_0x2436ed,items:_0x351704}=this[state];_0x351704&&_0x351704[_0x432b2f(0x1ff)]((_0xb5f89b,_0x1bfb7f)=>{const _0x451bdc=_0x432b2f;_0xb5f89b['toggleAttribute'](_0x451bdc(0x1f3),_0x1bfb7f===_0x2436ed);});}}[rendered](_0x4bdd8a){const _0x1d9ec6=a0_0x353b3d;super[rendered](_0x4bdd8a);if(this[firstRender]){const _0xfd2234=this[ids][_0x1d9ec6(0x201)]['children'];this[setState]({'content':_0xfd2234});}}get[scrollTarget](){const _0x3746ed=a0_0x353b3d;return this[ids][_0x3746ed(0x201)];}get[template](){return templateFrom['html']`
      <style>
        :host {
          border: 1px solid gray;
          box-sizing: border-box;
          cursor: default;
          display: flex;
          -webkit-tap-highlight-color: transparent;
        }

        #content {
          display: flex;
          flex-direction: column;
          flex: 1;
          -webkit-overflow-scrolling: touch; /* for momentum scrolling */
          overflow-x: hidden;
          overflow-y: scroll;
        }

        #content > * {
          padding: 0.25em;
        }

        #content > [selected] {
          background: highlight;
          color: highlighttext;
        }
      </style>
      <div id="content" role="none">
        <div>Afghanistan</div>
        <div>Albania</div>
        <div>Algeria</div>
        <div>Andorra</div>
        <div>Angola</div>
        <div>Antigua and Barbuda</div>
        <div>Argentina</div>
        <div>Armenia</div>
        <div>Australia</div>
        <div>Austria</div>
        <div>Azerbaijan</div>
        <div>Bahamas</div>
        <div>Bahrain</div>
        <div>Bangladesh</div>
        <div>Barbados</div>
        <div>Belarus</div>
        <div>Belgium</div>
        <div>Belize</div>
        <div>Benin</div>
        <div>Bhutan</div>
        <div>Bolivia</div>
        <div>Bosnia and Herzegovina</div>
        <div>Botswana</div>
        <div>Brazil</div>
        <div>Brunei</div>
        <div>Bulgaria</div>
        <div>Burkina Faso</div>
        <div>Burundi</div>
        <div>Cambodia</div>
        <div>Cameroon</div>
        <div>Canada</div>
        <div>Cape Verde</div>
        <div>Central African Republic</div>
        <div>Chad</div>
        <div>Chile</div>
        <div>China</div>
        <div>Colombia</div>
        <div>Comoros</div>
        <div>Costa Rica</div>
        <div>Croatia</div>
        <div>Cuba</div>
        <div>Cyprus</div>
        <div>Czech Republic</div>
        <div>Democratic Republic of the Congo</div>
        <div>Denmark</div>
        <div>Djibouti</div>
        <div>Dominica</div>
        <div>Dominican Republic</div>
        <div>East Timor</div>
        <div>Ecuador</div>
        <div>Egypt</div>
        <div>El Salvador</div>
        <div>Equatorial Guinea</div>
        <div>Eritrea</div>
        <div>Estonia</div>
        <div>Ethiopia</div>
        <div>Fiji</div>
        <div>Finland</div>
        <div>France</div>
        <div>Gabon</div>
        <div>Gambia</div>
        <div>Georgia</div>
        <div>Germany</div>
        <div>Ghana</div>
        <div>Greece</div>
        <div>Grenada</div>
        <div>Guatemala</div>
        <div>Guinea</div>
        <div>Guinea-Bissau</div>
        <div>Guyana</div>
        <div>Haiti</div>
        <div>Honduras</div>
        <div>Hungary</div>
        <div>Iceland</div>
        <div>India</div>
        <div>Indonesia</div>
        <div>Iran</div>
        <div>Iraq</div>
        <div>Ireland</div>
        <div>Israel</div>
        <div>Italy</div>
        <div>Ivory Coast</div>
        <div>Jamaica</div>
        <div>Japan</div>
        <div>Jordan</div>
        <div>Kazakhstan</div>
        <div>Kenya</div>
        <div>Kiribati</div>
        <div>Kuwait</div>
        <div>Kyrgyzstan</div>
        <div>Laos</div>
        <div>Latvia</div>
        <div>Lebanon</div>
        <div>Lesotho</div>
        <div>Liberia</div>
        <div>Libya</div>
        <div>Liechtenstein</div>
        <div>Lithuania</div>
        <div>Luxembourg</div>
        <div>Macedonia</div>
        <div>Madagascar</div>
        <div>Malawi</div>
        <div>Malaysia</div>
        <div>Maldives</div>
        <div>Mali</div>
        <div>Malta</div>
        <div>Marshall Islands</div>
        <div>Mauritania</div>
        <div>Mauritius</div>
        <div>Mexico</div>
        <div>Micronesia</div>
        <div>Moldova</div>
        <div>Monaco</div>
        <div>Mongolia</div>
        <div>Montenegro</div>
        <div>Morocco</div>
        <div>Mozambique</div>
        <div>Myanmar</div>
        <div>Namibia</div>
        <div>Nauru</div>
        <div>Nepal</div>
        <div>Netherlands</div>
        <div>New Zealand</div>
        <div>Nicaragua</div>
        <div>Niger</div>
        <div>Nigeria</div>
        <div>North Korea</div>
        <div>Norway</div>
        <div>Oman</div>
        <div>Pakistan</div>
        <div>Palau</div>
        <div>Palestine</div>
        <div>Panama</div>
        <div>Papua New Guinea</div>
        <div>Paraguay</div>
        <div>Peru</div>
        <div>Philippines</div>
        <div>Poland</div>
        <div>Portugal</div>
        <div>Qatar</div>
        <div>Republic of the Congo</div>
        <div>Romania</div>
        <div>Russia</div>
        <div>Rwanda</div>
        <div>Saint Kitts and Nevis</div>
        <div>Saint Lucia</div>
        <div>Saint Vincent and the Grenadines</div>
        <div>Samoa</div>
        <div>San Marino</div>
        <div>São Tomé and Príncipe</div>
        <div>Saudi Arabia</div>
        <div>Senegal</div>
        <div>Serbia</div>
        <div>Seychelles</div>
        <div>Sierra Leone</div>
        <div>Singapore</div>
        <div>Slovakia</div>
        <div>Slovenia</div>
        <div>Solomon Islands</div>
        <div>Somalia</div>
        <div>South Africa</div>
        <div>South Korea</div>
        <div>South Sudan</div>
        <div>Spain</div>
        <div>Sri Lanka</div>
        <div>Sudan</div>
        <div>Suriname</div>
        <div>Swaziland</div>
        <div>Sweden</div>
        <div>Switzerland</div>
        <div>Syria</div>
        <div>Taiwan</div>
        <div>Tajikistan</div>
        <div>Tanzania</div>
        <div>Thailand</div>
        <div>Togo</div>
        <div>Tonga</div>
        <div>Trinidad and Tobago</div>
        <div>Tunisia</div>
        <div>Turkey</div>
        <div>Turkmenistan</div>
        <div>Tuvalu</div>
        <div>Uganda</div>
        <div>Ukraine</div>
        <div>United Arab Emirates</div>
        <div>United Kingdom</div>
        <div>United States</div>
        <div>Uruguay</div>
        <div>Uzbekistan</div>
        <div>Vanuatu</div>
        <div>Vatican City</div>
        <div>Venezuela</div>
        <div>Vietnam</div>
        <div>Yemen</div>
        <div>Zambia</div>
        <div>Zimbabwe</div>
      </div>
    `;}}customElements[a0_0x353b3d(0x205)](a0_0x353b3d(0x1fa),CountryListBox);export default CountryListBox;