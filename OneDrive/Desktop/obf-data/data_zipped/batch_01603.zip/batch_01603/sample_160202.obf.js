/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x1977(_0xd20f53,_0x5debd8){var _0x6712c2=a0_0x6712();return a0_0x1977=function(_0x197776,_0x56aca5){_0x197776=_0x197776-0x10a;var _0x1b8f35=_0x6712c2[_0x197776];return _0x1b8f35;},a0_0x1977(_0xd20f53,_0x5debd8);}var a0_0x62a072=a0_0x1977;function a0_0x6712(){var _0x5d12fa=['buffer','141879lueVFe','20009964gBhaQZ','45TEbasa','length','@stdlib/array/float32','392bUamvQ','byteOffset','exports','231592ccIhWU','819105kkPcra','539160PSispj','2IktOqK','176yLNzgr','108786dagvcY','49525SeslrX','385ABDgWM'];a0_0x6712=function(){return _0x5d12fa;};return a0_0x6712();}(function(_0x2974b4,_0x2982f8){var _0x14bd49=a0_0x1977,_0xf85bb3=_0x2974b4();while(!![]){try{var _0x555c24=-parseInt(_0x14bd49(0x10b))/0x1+-parseInt(_0x14bd49(0x116))/0x2*(parseInt(_0x14bd49(0x114))/0x3)+parseInt(_0x14bd49(0x110))/0x4*(parseInt(_0x14bd49(0x119))/0x5)+parseInt(_0x14bd49(0x118))/0x6*(-parseInt(_0x14bd49(0x11a))/0x7)+-parseInt(_0x14bd49(0x113))/0x8*(-parseInt(_0x14bd49(0x10d))/0x9)+-parseInt(_0x14bd49(0x115))/0xa*(parseInt(_0x14bd49(0x117))/0xb)+parseInt(_0x14bd49(0x10c))/0xc;if(_0x555c24===_0x2982f8)break;else _0xf85bb3['push'](_0xf85bb3['shift']());}catch(_0x254dd6){_0xf85bb3['push'](_0xf85bb3['shift']());}}}(a0_0x6712,0x7c0fd));var Float32Array=require(a0_0x62a072(0x10f)),addon=require('./sminsorted.native.js');function sminsorted(_0x296cb9,_0x3a4646,_0x28b127,_0x56da4a){var _0x404941=a0_0x62a072,_0x4b81c2;return _0x28b127<0x0&&(_0x56da4a+=(_0x296cb9-0x1)*_0x28b127),_0x4b81c2=new Float32Array(_0x3a4646[_0x404941(0x10a)],_0x3a4646[_0x404941(0x111)]+_0x3a4646['BYTES_PER_ELEMENT']*_0x56da4a,_0x3a4646[_0x404941(0x10e)]-_0x56da4a),addon(_0x296cb9,_0x4b81c2,_0x28b127);}module[a0_0x62a072(0x112)]=sminsorted;