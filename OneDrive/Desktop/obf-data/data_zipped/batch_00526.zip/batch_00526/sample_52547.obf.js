/**
 * @author Markus Näsman
 * @copyright 2012 (c) Markus Näsman <markus at botten dot org >
 * @license Copyright (c) 2012, Markus Näsman
 * All rights reserved.
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *    * Redistributions of source code must retain the above copyright
 *      notice, this list of conditions and the following disclaimer.
 *    * Redistributions in binary form must reproduce the above copyright
 *      notice, this list of conditions and the following disclaimer in the
 *      documentation and/or other materials provided with the distribution.
 *    * Neither the name of the <organization> nor the
 *      names of its contributors may be used to endorse or promote products
 *      derived from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
 * WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
 * DISCLAIMED. IN NO EVENT SHALL MARKUS NÄSMAN BE LIABLE FOR ANY
 * DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
 * (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */
function a0_0x15e5(){var _0x3968f2=['9zQKLtI','1NoeByY','rgb_to_lab','should\x20convert\x20to\x20expected\x20lab\x20color\x20#2','751888qvxlbl','4182176kbkHkT','1708242hJyqcl','5wONSYz','4999330Mvrepc','should\x20convert\x20to\x20expected\x20lab\x20color\x20#3','#rgb_to_lab()','3rMqdyl','../lib/convert','1548534TMSDgC','deepEqual','assert','7575381YAxlGz','3286955rypTnW','round'];a0_0x15e5=function(){return _0x3968f2;};return a0_0x15e5();}var a0_0x269cfd=a0_0x2639;(function(_0x271734,_0x204781){var _0x491d76=a0_0x2639,_0x1c1307=_0x271734();while(!![]){try{var _0x45f36c=-parseInt(_0x491d76(0x141))/0x1*(-parseInt(_0x491d76(0x146))/0x2)+parseInt(_0x491d76(0x138))/0x3*(-parseInt(_0x491d76(0x144))/0x4)+-parseInt(_0x491d76(0x147))/0x5*(-parseInt(_0x491d76(0x13a))/0x6)+parseInt(_0x491d76(0x13e))/0x7+parseInt(_0x491d76(0x145))/0x8+parseInt(_0x491d76(0x140))/0x9*(-parseInt(_0x491d76(0x148))/0xa)+-parseInt(_0x491d76(0x13d))/0xb;if(_0x45f36c===_0x204781)break;else _0x1c1307['push'](_0x1c1307['shift']());}catch(_0x310135){_0x1c1307['push'](_0x1c1307['shift']());}}}(a0_0x15e5,0xb1ba3));var assert=require(a0_0x269cfd(0x13c)),color_convert=require(a0_0x269cfd(0x139));function a0_0x2639(_0x527d21,_0x9cb284){var _0x15e551=a0_0x15e5();return a0_0x2639=function(_0x2639b4,_0x50820c){_0x2639b4=_0x2639b4-0x136;var _0x294330=_0x15e551[_0x2639b4];return _0x294330;},a0_0x2639(_0x527d21,_0x9cb284);}describe('convert',function(){var _0x5514cd=a0_0x269cfd;describe(_0x5514cd(0x137),function(){var _0x34ac84=_0x5514cd;it('should\x20convert\x20to\x20expected\x20lab\x20color\x20#1',function(){var _0x17f865=a0_0x2639;assert[_0x17f865(0x13b)]({'L':40.473,'a':-6.106,'b':-21.417},round_all(color_convert[_0x17f865(0x142)]({'R':0x37,'G':0x64,'B':0x82})));}),it(_0x34ac84(0x143),function(){var _0x47db3a=_0x34ac84;assert[_0x47db3a(0x13b)]({'L':0x0,'a':0x0,'b':0x0},round_all(color_convert['rgb_to_lab']({'R':0x0,'G':0x0,'B':0x0})));}),it(_0x34ac84(0x136),function(){var _0x4b65c3=_0x34ac84;assert['deepEqual']({'L':0x64,'a':0.005,'b':-0.01},round_all(color_convert[_0x4b65c3(0x142)]({'R':0xff,'G':0xff,'B':0xff})));});});});function round_all(_0x7a3837){return{'L':round(_0x7a3837['L']),'a':round(_0x7a3837['a']),'b':round(_0x7a3837['b'])};}function round(_0x6e48eb){var _0x31879b=a0_0x269cfd;return Math[_0x31879b(0x13f)](_0x6e48eb*0x3e8)/0x3e8;}