/**
 * @license Highstock JS v9.1.0 (2021-05-04)
 * @module highcharts/modules/stock-tools
 * @requires highcharts
 * @requires highcharts/modules/stock
 *
 * Advanced Highcharts Stock tools
 *
 * (c) 2010-2021 Highsoft AS
 * Author: Torstein Honsi
 *
 * License: www.highcharts.com/license
 */
'use strict';(function(_0x418340,_0x139530){var _0x17c36b=a0_0x555c,_0x35997c=_0x418340();while(!![]){try{var _0x7df6d=-parseInt(_0x17c36b(0x1b1))/0x1*(parseInt(_0x17c36b(0x1b4))/0x2)+-parseInt(_0x17c36b(0x1b6))/0x3+parseInt(_0x17c36b(0x1ad))/0x4+-parseInt(_0x17c36b(0x1af))/0x5*(parseInt(_0x17c36b(0x1b5))/0x6)+parseInt(_0x17c36b(0x1b3))/0x7*(-parseInt(_0x17c36b(0x1b0))/0x8)+-parseInt(_0x17c36b(0x1ac))/0x9*(parseInt(_0x17c36b(0x1b2))/0xa)+parseInt(_0x17c36b(0x1ae))/0xb;if(_0x7df6d===_0x139530)break;else _0x35997c['push'](_0x35997c['shift']());}catch(_0x5ed4c0){_0x35997c['push'](_0x35997c['shift']());}}}(a0_0x2b79,0xb4777));import'../../Stock/StockToolsBindings.js';function a0_0x555c(_0x4b7cbb,_0x55dcf0){var _0x2b7926=a0_0x2b79();return a0_0x555c=function(_0x555c74,_0x1bdf07){_0x555c74=_0x555c74-0x1ac;var _0x2e8a1e=_0x2b7926[_0x555c74];return _0x2e8a1e;},a0_0x555c(_0x4b7cbb,_0x55dcf0);}import'../../Stock/StockToolsGui.js';function a0_0x2b79(){var _0x2adaaf=['1wNHnke','2358520XWccGk','7TvvDte','1111626RSsaum','2847138OBhjDs','3943671gBXfXk','36GRpCOE','1407016ohLQLr','50064696TjsWjA','5bbqiEY','7004784uZudoJ'];a0_0x2b79=function(){return _0x2adaaf;};return a0_0x2b79();}