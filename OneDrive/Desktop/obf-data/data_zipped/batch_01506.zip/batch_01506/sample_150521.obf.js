/**
 * @license
 * Copyright 2016 Google Inc. All Rights Reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x533b(_0xc39257,_0x198220){var _0x3f2c15=a0_0x3f2c();return a0_0x533b=function(_0x533bac,_0x378caa){_0x533bac=_0x533bac-0x80;var _0x5474b8=_0x3f2c15[_0x533bac];return _0x5474b8;},a0_0x533b(_0xc39257,_0x198220);}var a0_0x16d163=a0_0x533b;function a0_0x3f2c(){var _0x28d577=['5cnNlav','602844ZSApXv','9598HaVysM','foam.core.property','3721910wQczlv','6MWKkrA','value','String','9fKXfgk','3859208gkyqyp','13335252WXBpIX','adapt','2008072dqfhJu','11ibIuCe','1220471YfJwxV','375UxgoCv','Property'];a0_0x3f2c=function(){return _0x28d577;};return a0_0x3f2c();}(function(_0x54e6a4,_0x4ce47e){var _0x42a75b=a0_0x533b,_0x275c6c=_0x54e6a4();while(!![]){try{var _0x40bc0f=parseInt(_0x42a75b(0x89))/0x1+parseInt(_0x42a75b(0x8a))/0x2*(parseInt(_0x42a75b(0x86))/0x3)+parseInt(_0x42a75b(0x83))/0x4*(parseInt(_0x42a75b(0x88))/0x5)+parseInt(_0x42a75b(0x8d))/0x6*(-parseInt(_0x42a75b(0x85))/0x7)+parseInt(_0x42a75b(0x80))/0x8*(-parseInt(_0x42a75b(0x90))/0x9)+parseInt(_0x42a75b(0x8c))/0xa*(parseInt(_0x42a75b(0x84))/0xb)+-parseInt(_0x42a75b(0x81))/0xc;if(_0x40bc0f===_0x4ce47e)break;else _0x275c6c['push'](_0x275c6c['shift']());}catch(_0x1e3428){_0x275c6c['push'](_0x275c6c['shift']());}}}(a0_0x3f2c,0x4b6a7),foam['CLASS']({'package':a0_0x16d163(0x8b),'name':a0_0x16d163(0x8f),'extends':a0_0x16d163(0x87),'properties':[{'name':a0_0x16d163(0x82),'value':function(_0x464810,_0x50014c){var _0x2ba974=a0_0x16d163;return foam[_0x2ba974(0x8f)]['coerce'](_0x50014c);}},{'name':a0_0x16d163(0x8e),'value':''}]}));