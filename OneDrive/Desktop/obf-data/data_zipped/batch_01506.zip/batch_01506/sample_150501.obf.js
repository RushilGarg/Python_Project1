/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x2d6a(_0x73fdd7,_0x3d007a){var _0x4f4f3b=a0_0x4f4f();return a0_0x2d6a=function(_0x2d6a91,_0x410e3b){_0x2d6a91=_0x2d6a91-0xd8;var _0x4287a8=_0x4f4f3b[_0x2d6a91];return _0x4287a8;},a0_0x2d6a(_0x73fdd7,_0x3d007a);}var a0_0x4e3814=a0_0x2d6a;function a0_0x4f4f(){var _0x391f46=['./../lib','4587345qKIuUK','4TvtGhb','227390uJEQdl','43119RrNKSy','@stdlib/math/base/ops/add','8179105VxTCDV','data','2984177vxzLZV','112XwMfXI','@stdlib/random/base/discrete-uniform','1021552VlPyfc','6173000GUSnAC','6AfCpei','@stdlib/utils/nary-function','27VXFFxa','log','generic'];a0_0x4f4f=function(){return _0x391f46;};return a0_0x4f4f();}(function(_0x26779e,_0x5a9339){var _0x47476c=a0_0x2d6a,_0x34fc70=_0x26779e();while(!![]){try{var _0x473aa4=parseInt(_0x47476c(0xe5))/0x1*(parseInt(_0x47476c(0xe6))/0x2)+-parseInt(_0x47476c(0xe7))/0x3*(-parseInt(_0x47476c(0xda))/0x4)+-parseInt(_0x47476c(0xe4))/0x5+parseInt(_0x47476c(0xde))/0x6*(-parseInt(_0x47476c(0xd9))/0x7)+-parseInt(_0x47476c(0xdc))/0x8*(parseInt(_0x47476c(0xe0))/0x9)+parseInt(_0x47476c(0xdd))/0xa+parseInt(_0x47476c(0xe9))/0xb;if(_0x473aa4===_0x5a9339)break;else _0x34fc70['push'](_0x34fc70['shift']());}catch(_0x159f0f){_0x34fc70['push'](_0x34fc70['shift']());}}}(a0_0x4f4f,0x77ed1));var filledarrayBy=require('@stdlib/array/filled-by'),discreteUniform=require(a0_0x4e3814(0xdb))['factory'],naryFunction=require(a0_0x4e3814(0xdf)),add=require(a0_0x4e3814(0xe8)),array=require('@stdlib/ndarray/array'),reduce=require(a0_0x4e3814(0xe3));function fill(_0x2225d0){var _0x2ea499=a0_0x4e3814,_0x12ff10=discreteUniform(-0xa*(_0x2225d0+0x1),0xa*(_0x2225d0+0x1));return filledarrayBy(0xa,_0x2ea499(0xe2),_0x12ff10);}var x=array(filledarrayBy(0xa,a0_0x4e3814(0xe2),fill),{'dtype':a0_0x4e3814(0xe2),'flatten':!![]}),f=naryFunction(add,0x2),out=reduce(x,0x0,f);console[a0_0x4e3814(0xe1)]('x:'),console[a0_0x4e3814(0xe1)](x[a0_0x4e3814(0xd8)]),console[a0_0x4e3814(0xe1)]('sum:\x20%d',out);