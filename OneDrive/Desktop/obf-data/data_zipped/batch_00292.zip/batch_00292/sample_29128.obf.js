/**
 *
 * pHKondo : pHKondo software for condominium property managers (http://phalkaline.net)
 * Copyright (c) pHAlkaline . (http://phalkaline.net)
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License along
 * with this program; if not, write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.
 *
 * @copyright     Copyright (c) pHAlkaline . (http://phalkaline.net)
 * @link          https://phkondo.net pHKondo Project
 * @package       app.View.Themed.webroot.js
 * @since         pHKondo v 0.0.1
 * @license       http://opensource.org/licenses/GPL-2.0 GNU General Public License, version 2 (GPL-2.0)
 * 
 */
function a0_0x5074(_0x3462ae,_0x285e7a){var _0x7661c1=a0_0x7661();return a0_0x5074=function(_0x50748f,_0x38cf4b){_0x50748f=_0x50748f-0xf9;var _0x89d943=_0x7661c1[_0x50748f];return _0x89d943;},a0_0x5074(_0x3462ae,_0x285e7a);}(function(_0x30d24d,_0x386220){var _0x157ff8=a0_0x5074,_0x20a1b0=_0x30d24d();while(!![]){try{var _0x18d317=parseInt(_0x157ff8(0xff))/0x1+-parseInt(_0x157ff8(0x106))/0x2*(-parseInt(_0x157ff8(0xfe))/0x3)+parseInt(_0x157ff8(0x104))/0x4+-parseInt(_0x157ff8(0x10a))/0x5*(parseInt(_0x157ff8(0xfd))/0x6)+-parseInt(_0x157ff8(0x103))/0x7*(parseInt(_0x157ff8(0xf9))/0x8)+parseInt(_0x157ff8(0x105))/0x9*(parseInt(_0x157ff8(0x102))/0xa)+-parseInt(_0x157ff8(0x10b))/0xb;if(_0x18d317===_0x386220)break;else _0x20a1b0['push'](_0x20a1b0['shift']());}catch(_0x4afe06){_0x20a1b0['push'](_0x20a1b0['shift']());}}}(a0_0x7661,0x8e3b3),$(function(){var _0x821a4e=a0_0x5074;$(_0x821a4e(0x10c))['change'](function(){var _0x546522=_0x821a4e;$('#addNotesTotalAmount')[_0x546522(0x101)]('\x20'+totalAmount());}),$('#addNotesTotalAmount')[_0x821a4e(0x101)]('\x20'+totalAmount());}));function a0_0x7661(){var _0x1d6400=['820266FGdvsO','2391IdhgEu','901897ZUqOqF',':checkbox:checked','html','307070pAbiiA','154jsdHuu','3810868BLsWAH','153saIlWN','718IzwDQl','each','replace','Amount','10EDQToP','8403747mleKJZ','input[type=\x27checkbox\x27]','val','attr','379192twQDwl','toFixed','#Note','#ReceiptAmount'];a0_0x7661=function(){return _0x1d6400;};return a0_0x7661();}function totalAmount(){var _0x5b49aa=a0_0x5074,_0x166c0a=0x0,_0x187c44=$(_0x5b49aa(0x100));return _0x187c44[_0x5b49aa(0x107)](function(){var _0x46aa68=_0x5b49aa,_0xee41f1=$(this)[_0x46aa68(0x10e)]('id')[_0x46aa68(0x108)](/[^0-9]/g,''),_0x5325be=$('#Note'+_0xee41f1+'Type')['val']();switch(_0x5325be){case'1':_0x166c0a=parseFloat(_0x166c0a)-parseFloat($('#Note'+_0xee41f1+_0x46aa68(0x109))[_0x46aa68(0x10d)]());break;case'2':_0x166c0a=parseFloat(_0x166c0a)+parseFloat($(_0x46aa68(0xfb)+_0xee41f1+_0x46aa68(0x109))[_0x46aa68(0x10d)]());break;default:break;}_0x166c0a=_0x166c0a[_0x46aa68(0xfa)](0x2);}),(parseFloat($(_0x5b49aa(0xfc))[_0x5b49aa(0x10d)]())+parseFloat(_0x166c0a))[_0x5b49aa(0xfa)](0x2);}