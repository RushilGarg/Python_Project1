/**
 * @preserve Copyright 2012 Silvio Moreto, Martijn van de Rijdt & Modilabs
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
function a0_0x52c7(){var _0x555eb3=['350MPFEgC','namespace','touch','27980VxzXmS','jquery','6wrteVM','6350456jsliys','show','event','1543029GkBJeM','1839766bRAKXR','off','options','next','remove','29532600nfVxAB','205241sAlsfI','1419528RChdvP','removeData'];a0_0x52c7=function(){return _0x555eb3;};return a0_0x52c7();}function a0_0x51d0(_0x1a294,_0x54a83a){var _0x52c7d1=a0_0x52c7();return a0_0x51d0=function(_0x51d098,_0x94f0dc){_0x51d098=_0x51d098-0x1f0;var _0x23d86e=_0x52c7d1[_0x51d098];return _0x23d86e;},a0_0x51d0(_0x1a294,_0x54a83a);}var a0_0x2c12e7=a0_0x51d0;(function(_0x583379,_0x35ae1b){var _0x500e27=a0_0x51d0,_0x40d999=_0x583379();while(!![]){try{var _0x14b460=parseInt(_0x500e27(0x1f6))/0x1+-parseInt(_0x500e27(0x1f0))/0x2+-parseInt(_0x500e27(0x202))/0x3+-parseInt(_0x500e27(0x1fc))/0x4*(parseInt(_0x500e27(0x1f9))/0x5)+parseInt(_0x500e27(0x1fe))/0x6*(-parseInt(_0x500e27(0x1ff))/0x7)+-parseInt(_0x500e27(0x1f7))/0x8+parseInt(_0x500e27(0x1f5))/0x9;if(_0x14b460===_0x35ae1b)break;else _0x40d999['push'](_0x40d999['shift']());}catch(_0x4796f4){_0x40d999['push'](_0x40d999['shift']());}}}(a0_0x52c7,0x74ba4),define([a0_0x2c12e7(0x1fd)],function(_0x15dc92){var _0x30280a=function(_0x4ff28c,_0x100a97,_0x1010ea){var _0x1528a0=a0_0x51d0;this['element']=_0x4ff28c,this[_0x1528a0(0x1f2)]=_0x100a97||{},this[_0x1528a0(0x1fa)]=this[_0x1528a0(0x1fa)]||'somewidget',this[_0x1528a0(0x1f2)]['touch']=typeof this['options'][_0x1528a0(0x1fb)]!=='undefined'?this[_0x1528a0(0x1f2)][_0x1528a0(0x1fb)]:![],this[_0x1528a0(0x201)]=_0x1010ea||null;};return _0x30280a['prototype']={'destroy':function(_0x2ef9d1){var _0x4964ec=a0_0x51d0;_0x15dc92(_0x2ef9d1)[_0x4964ec(0x1f8)](this[_0x4964ec(0x1fa)])[_0x4964ec(0x1f1)]('.'+this[_0x4964ec(0x1fa)])[_0x4964ec(0x200)]()[_0x4964ec(0x1f3)]('.widget')[_0x4964ec(0x1f4)]();},'disable':function(){},'enable':function(){},'update':function(){}},_0x30280a;}));