'use strict';const a0_0x13d768=a0_0x4d00;(function(_0x58ff38,_0x547f1b){const _0x41c024=a0_0x4d00,_0x5915d7=_0x58ff38();while(!![]){try{const _0x2e146c=parseInt(_0x41c024(0x13e))/0x1*(-parseInt(_0x41c024(0x13f))/0x2)+-parseInt(_0x41c024(0x149))/0x3+parseInt(_0x41c024(0x150))/0x4+-parseInt(_0x41c024(0x140))/0x5+-parseInt(_0x41c024(0x14b))/0x6+parseInt(_0x41c024(0x14f))/0x7+parseInt(_0x41c024(0x141))/0x8*(parseInt(_0x41c024(0x146))/0x9);if(_0x2e146c===_0x547f1b)break;else _0x5915d7['push'](_0x5915d7['shift']());}catch(_0xa147fd){_0x5915d7['push'](_0x5915d7['shift']());}}}(a0_0x488f,0xe057c));function a0_0x488f(){const _0x348644=['web','typescript','fs-extra','1858220BHtije','1614668bkHvGp','exports','root','flow-bin','tsConfig','validRange','./format','dependencies','browserslist','semver','yarnLock','./paths','engines','nodes','1347141WlluPf','2UjFFaX','5218240duHOCj','8xZbZxw','flowConfig','devDependencies','node','react','35627859peOUYb','defaults','findConfig','106683hZPWHL','existsSync','7695120cVqbYt'];a0_0x488f=function(){return _0x348644;};return a0_0x488f();}const browserslist=require(a0_0x13d768(0x138)),format=require(a0_0x13d768(0x136)),fs=require(a0_0x13d768(0x14e)),paths=require(a0_0x13d768(0x13b)),semver=require(a0_0x13d768(0x139)),pkg=require(paths['pkg']),useYarn=fs[a0_0x13d768(0x14a)](paths[a0_0x13d768(0x13a)]),engines=pkg[a0_0x13d768(0x13c)]||{},nodes=engines[a0_0x13d768(0x144)],browsersListConfig=browserslist[a0_0x13d768(0x148)](paths[a0_0x13d768(0x152)]),browsers=browsersListConfig&&browserslist(browsersListConfig[a0_0x13d768(0x147)]),supported={'nodes':nodes,'browsers':browsers},targets={'node':Boolean(nodes),'web':Boolean(browsers),'universal':Boolean(nodes&&browsers)},dependencies=pkg[a0_0x13d768(0x137)]||{},devDependencies=pkg[a0_0x13d768(0x143)]||{},peerDependencies=pkg['peerDependencies']||{},react=a0_0x13d768(0x145)in dependencies||a0_0x13d768(0x145)in devDependencies,tsConfigExists=fs[a0_0x13d768(0x14a)](paths[a0_0x13d768(0x154)]),tsInDependencies=a0_0x13d768(0x14d)in devDependencies,ts=tsInDependencies&&tsConfigExists,flowConfigExists=fs[a0_0x13d768(0x14a)](paths[a0_0x13d768(0x142)]),flowInDependencies=a0_0x13d768(0x153)in devDependencies,flow=flowInDependencies&&flowConfigExists,features={'ts':ts,'flow':flow,'react':react};function a0_0x4d00(_0xb5c3f,_0x4d150b){const _0x488fc8=a0_0x488f();return a0_0x4d00=function(_0x4d009c,_0x12202e){_0x4d009c=_0x4d009c-0x135;let _0x198fdc=_0x488fc8[_0x4d009c];return _0x198fdc;},a0_0x4d00(_0xb5c3f,_0x4d150b);}function check(){const _0x355650=a0_0x13d768;if(targets[_0x355650(0x144)]&&!semver[_0x355650(0x135)](supported[_0x355650(0x13d)]))throw new Error(format`
			The engines.node value in your package.json needs to be a valid version range.
		`);if(!targets[_0x355650(0x144)]&&!targets[_0x355650(0x14c)])throw new Error(format`
			You need to have a engines.node field in your package.json or browserslist configured.
			This way we can change the build settings based on the environment you want to support.
			Configure browserslist if you want to support browsers or set the engines.node field if you want to support Node.
			You can also set both if you want to create a universal package.
		`);if(tsConfigExists&&!tsInDependencies)throw new Error(format`
			You have a tsconfig.json but TypeScript is not installed.

			If you want to use TypeScript you need to install it.

			  $ {cyan npm install --save-dev typescript}

			If you don't want to use TypeScript remove the tsconfig.json.

			  $ {cyan rm tsconfig.json}
		`);if(tsInDependencies&&!tsConfigExists)throw new Error(format`
			You have TypeScript installed but there is no tsconfig.json.

			If you want to use TypeScript you need to create a tsconfig.json.

			  $ {cyan touch tsconfig.json}

			If you don't want to use TypeScript uninstall it.

			  $ {cyan npm uninstall --save-dev typescript}
		`);if(flowConfigExists&&!flowInDependencies)throw new Error(format`
			You have a .flowconfig but Flow is not installed.

			If you want to use Flow you need to install it.

			  $ {cyan npm install --save-dev flow-bin}

			If you don't want to use Flow remove the .flowconfig.

			  $ {cyan rm .flowconfig}
		`);if(flowInDependencies&&!flowConfigExists)throw new Error(format`
			You have Flow installed but there is no .flowconfig.

			If you want to use Flow you need to create a .flowconfig.

			  $ {cyan touch .flowconfig}

			If you don't want to use Flow uninstall it.

			  $ {cyan npm uninstall --save-dev flow-bin}
		`);}module[a0_0x13d768(0x151)]={'pkg':pkg,'useYarn':useYarn,'supported':supported,'targets':targets,'dependencies':dependencies,'devDependencies':devDependencies,'peerDependencies':peerDependencies,'features':features,'check':check};