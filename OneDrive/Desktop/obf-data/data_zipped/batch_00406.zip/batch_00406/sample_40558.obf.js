function a0_0x5e83(_0x9e6ac5,_0x1b05f4){const _0x939463=a0_0x9394();return a0_0x5e83=function(_0x5e839d,_0x83b9fd){_0x5e839d=_0x5e839d-0x156;let _0x4a9785=_0x939463[_0x5e839d];return _0x4a9785;},a0_0x5e83(_0x9e6ac5,_0x1b05f4);}const a0_0x260907=a0_0x5e83;(function(_0x20811b,_0x525194){const _0x5ca385=a0_0x5e83,_0x53e180=_0x20811b();while(!![]){try{const _0x67541d=parseInt(_0x5ca385(0x16b))/0x1*(parseInt(_0x5ca385(0x162))/0x2)+-parseInt(_0x5ca385(0x163))/0x3+-parseInt(_0x5ca385(0x167))/0x4+parseInt(_0x5ca385(0x168))/0x5*(parseInt(_0x5ca385(0x15a))/0x6)+parseInt(_0x5ca385(0x159))/0x7*(parseInt(_0x5ca385(0x166))/0x8)+parseInt(_0x5ca385(0x15c))/0x9*(parseInt(_0x5ca385(0x170))/0xa)+-parseInt(_0x5ca385(0x15e))/0xb*(parseInt(_0x5ca385(0x164))/0xc);if(_0x67541d===_0x525194)break;else _0x53e180['push'](_0x53e180['shift']());}catch(_0x225896){_0x53e180['push'](_0x53e180['shift']());}}}(a0_0x9394,0x9bc48));function a0_0x9394(){const _0x2f19b9=['256nsnYko','1922440vuoIol','910720lSiigm','styles',';\x20--l:\x20','1VipsPt','--h:\x20','round','saturation','push','40070mMRagn','hue','define','user-id','substr','102361IuAebQ','30gQsmkb','userId','1611hjavsw','render','11tAlYAE',';\x20--s:\x20','charAt','lightness','272990HAoqVu','3124731jZOQVl','866316IHUALP','sc-identicon'];a0_0x9394=function(){return _0x2f19b9;};return a0_0x9394();}import{LitElement,html,css}from'lit';import a0_0x431514 from'sha1';import{RESET}from'./styles';class IdenticonElement extends LitElement{static get[a0_0x260907(0x169)](){return css`
      /* Stop prettier from doing dumb things with this */
      ${RESET} /* */

      :host {
        display: block;
        width: 100%;
        height: 100%;
      }

      .identicon {
        width: 100%;
        height: 100%;
        contain: layout;
        border: 1px solid var(--colorBorder);
        border-radius: 2px;
        padding: 3px;

        background-color: hsl(
          calc(var(--h) + 180),
          calc(var(--identiconBgSaturation) * 1%),
          calc(var(--identiconBgLightness) * 1%)
        );
        color: hsl(
          var(--h),
          calc(
            1% *
              (
                var(--s) * (var(--identiconFgSaturationHigh) - var(--identiconFgSaturationLow)) +
                  var(--identiconFgSaturationLow)
              )
          ),
          calc(
            1% *
              (
                var(--l) * (var(--identiconFgLightnessHigh) - var(--identiconFgLightnessLow)) +
                  var(--identiconFgLightnessLow)
              )
          )
        );
      }

      .block {
        float: left;
        width: 20%;
        height: 20%;
      }

      .on {
        background-color: currentColor;
      }
    `;}static get['properties'](){const _0x291005=a0_0x260907;return{'userId':{'type':String,'attribute':_0x291005(0x157)}};}[a0_0x260907(0x15b)]='';[a0_0x260907(0x15d)](){const _0x9374a4=a0_0x260907,_0x1251c9=a0_0x431514(this[_0x9374a4(0x15b)]),_0x4542aa={'hue':Math[_0x9374a4(0x16d)](parseInt(_0x1251c9[_0x9374a4(0x158)](-0xa),0x10)/0xffffffffff*0x168),'saturation':parseInt(_0x1251c9['substr'](-0xd,0x3),0x10)/0xfff,'lightness':parseInt(_0x1251c9['substr'](-0x10,0x3),0x10)/0xfff},_0x14cdb1=[];for(let _0x198deb=0x0;_0x198deb<0x3;_0x198deb++){_0x14cdb1[_0x9374a4(0x16f)]([![],![],![],![],![]]);}for(let _0x19056c=0x0,_0x5b71dc=0x0;_0x19056c<0xf;_0x19056c++,_0x5b71dc++){const _0x15aa90=0x2-(_0x19056c/0x5|0x0),_0x31b981=!(parseInt(_0x1251c9[_0x9374a4(0x160)](_0x19056c),0x10)%0x2);_0x5b71dc=_0x5b71dc%0x5,_0x14cdb1[_0x15aa90][_0x5b71dc]=_0x31b981;}const _0x502f1b=[];for(let _0x494d84=0x0;_0x494d84<0x5;_0x494d84++){for(let _0x5ee03c=0x0;_0x5ee03c<0x5;_0x5ee03c++){const _0x3f9426=_0x5ee03c>=0x3?0x4-_0x5ee03c:_0x5ee03c;_0x502f1b[_0x9374a4(0x16f)](_0x14cdb1[_0x3f9426][_0x494d84]?html` <div class="block on"></div> `:html` <div class="block"></div> `);}}const _0x4fbdba=_0x9374a4(0x16c)+_0x4542aa[_0x9374a4(0x171)]+_0x9374a4(0x15f)+_0x4542aa[_0x9374a4(0x16e)]+_0x9374a4(0x16a)+_0x4542aa[_0x9374a4(0x161)]+';';return html` <div class="identicon" style="${_0x4fbdba}">${_0x502f1b}</div> `;}}customElements[a0_0x260907(0x156)](a0_0x260907(0x165),IdenticonElement);