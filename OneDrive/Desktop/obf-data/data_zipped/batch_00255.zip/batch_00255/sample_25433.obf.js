const a0_0x26640f=a0_0x5be8;(function(_0x4add02,_0x1770fc){const _0x203d24=a0_0x5be8,_0x51dee=_0x4add02();while(!![]){try{const _0x22f169=parseInt(_0x203d24(0x19f))/0x1+parseInt(_0x203d24(0x194))/0x2*(parseInt(_0x203d24(0x19b))/0x3)+-parseInt(_0x203d24(0x19d))/0x4+parseInt(_0x203d24(0x195))/0x5+-parseInt(_0x203d24(0x1a0))/0x6+parseInt(_0x203d24(0x1a1))/0x7+-parseInt(_0x203d24(0x196))/0x8;if(_0x22f169===_0x1770fc)break;else _0x51dee['push'](_0x51dee['shift']());}catch(_0x701df4){_0x51dee['push'](_0x51dee['shift']());}}}(a0_0x2907,0xb1d71));import{PropTypes}from'react';function a0_0x2907(){const _0x11dd3d=['11367jGUpXD','propTypes','22204KnuZGK','error','663486uLwvIA','3978876SqTZVZ','3258766NeUpqA','theme','blue','info','warning','464AiAznD','5967615FmyNvj','14435720kyGSoq','yellow','div','success','red'];a0_0x2907=function(){return _0x11dd3d;};return a0_0x2907();}import a0_0x4d3f46,{css}from'styled-components';const Alert=a0_0x4d3f46[a0_0x26640f(0x198)]`
  color: #fff;
  padding: 10px 20px;
  margin: 0 0 20px;
  background-color: ${_0x28dc04=>_0x28dc04['theme']['gray3']};
  border-radius: 4px;

  ${_0x57970e=>{const _0x8dd9a2=a0_0x26640f;switch(_0x57970e['type']){case _0x8dd9a2(0x19e):return css`
          background-color: ${_0x57970e[_0x8dd9a2(0x1a2)][_0x8dd9a2(0x19a)]};
        `;case _0x8dd9a2(0x1a4):return css`
          background-color: ${_0x57970e['theme'][_0x8dd9a2(0x1a3)]};
        `;case'success':return css`
          background-color: ${_0x57970e[_0x8dd9a2(0x1a2)]['green']};
        `;case'warning':return css`
          background-color: ${_0x57970e['theme'][_0x8dd9a2(0x197)]};
        `;}}}

  & a {
    color: #fff;
    border-bottom: 1px solid #fff;

    &:hover {
      border: 0;
    }
  }
`;function a0_0x5be8(_0x5065bf,_0x33105b){const _0x290757=a0_0x2907();return a0_0x5be8=function(_0x5be8b9,_0x4652fe){_0x5be8b9=_0x5be8b9-0x193;let _0x2b7af8=_0x290757[_0x5be8b9];return _0x2b7af8;},a0_0x5be8(_0x5065bf,_0x33105b);}Alert[a0_0x26640f(0x19c)]={'type':PropTypes['oneOf']([a0_0x26640f(0x19e),a0_0x26640f(0x1a4),a0_0x26640f(0x193),a0_0x26640f(0x199)])};export default Alert;