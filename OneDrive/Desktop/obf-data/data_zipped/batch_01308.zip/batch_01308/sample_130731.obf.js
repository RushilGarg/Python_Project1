/**
 * @license
 * Copyright 2017 The Bazel Authors. All rights reserved.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 *
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';const a0_0x4fd444=a0_0x30e4;(function(_0x470e3a,_0x1780a9){const _0x55968=a0_0x30e4,_0x19d1f5=_0x470e3a();while(!![]){try{const _0x5fb8ea=-parseInt(_0x55968(0x1a4))/0x1*(parseInt(_0x55968(0x196))/0x2)+-parseInt(_0x55968(0x19a))/0x3*(parseInt(_0x55968(0x19d))/0x4)+parseInt(_0x55968(0x195))/0x5*(parseInt(_0x55968(0x1a9))/0x6)+parseInt(_0x55968(0x193))/0x7*(-parseInt(_0x55968(0x19c))/0x8)+-parseInt(_0x55968(0x1a7))/0x9*(-parseInt(_0x55968(0x1a0))/0xa)+parseInt(_0x55968(0x1ab))/0xb*(parseInt(_0x55968(0x1a8))/0xc)+parseInt(_0x55968(0x198))/0xd*(parseInt(_0x55968(0x19f))/0xe);if(_0x5fb8ea===_0x1780a9)break;else _0x19d1f5['push'](_0x19d1f5['shift']());}catch(_0x4d940d){_0x19d1f5['push'](_0x19d1f5['shift']());}}}(a0_0x2d65,0x8dbd5));function a0_0x30e4(_0x734c14,_0xa0fd24){const _0x2d6504=a0_0x2d65();return a0_0x30e4=function(_0x30e4a0,_0x3146e8){_0x30e4a0=_0x30e4a0-0x193;let _0x455ca3=_0x2d6504[_0x30e4a0];return _0x455ca3;},a0_0x30e4(_0x734c14,_0xa0fd24);}function a0_0x2d65(){const _0x5f3dcf=['utf-8','7634GkHSJD','readFileSync','3605UwBayU','trim','83705EqRCkY','240878maxuEg','\x27\x0a\x20\x20\x20\x20\x20\x20//:.bazelversion\x20\x27','26JAtSTV','env','9hkcNXI','bazel:','2936dtpsFi','378148wFFHBH','build_bazel_rules_nodejs/.bazelci/presubmit.yml','7797202TnHkCN','10LgObCd','Bazel\x20versions\x20do\x20not\x20match.\x0a\x20\x20\x20\x20\x20\x20//:index.bzl\x20BAZEL_VERSION=\x27','resolve','split','5WRViAB','\x27\x0a\x20\x20\x20\x20\x20\x20//:.bazelci/presubmit.yml\x20\x27','argv','4302729NKLcBf','228mekmAG','18fZZmEz'];a0_0x2d65=function(){return _0x5f3dcf;};return a0_0x2d65();}const runfiles=require(process[a0_0x4fd444(0x199)]['BAZEL_NODE_RUNFILES_HELPER']),fs=require('fs'),args=process[a0_0x4fd444(0x1a6)]['slice'](0x2),BAZEL_VERSION=args[0x0],version=fs[a0_0x4fd444(0x1ac)](runfiles[a0_0x4fd444(0x1a2)]('build_bazel_rules_nodejs/.bazelversion'),'utf-8')[a0_0x4fd444(0x194)](),bazelci_version=fs[a0_0x4fd444(0x1ac)](runfiles['resolve'](a0_0x4fd444(0x19e)),a0_0x4fd444(0x1aa))['split']('\x0a')['find'](_0x1fd363=>_0x1fd363['startsWith'](a0_0x4fd444(0x19b)));(version!==BAZEL_VERSION||bazelci_version[a0_0x4fd444(0x1a3)](':')[0x1]['trim']()!==BAZEL_VERSION)&&(console['error'](a0_0x4fd444(0x1a1)+BAZEL_VERSION+a0_0x4fd444(0x197)+version+a0_0x4fd444(0x1a5)+bazelci_version+'\x27'),process['exitCode']=0x1);