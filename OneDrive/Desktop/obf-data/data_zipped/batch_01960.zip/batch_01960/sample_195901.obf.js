/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x5780(_0x5c5ead,_0x743f9f){var _0x3d2987=a0_0x3d29();return a0_0x5780=function(_0x57800e,_0x552fdf){_0x57800e=_0x57800e-0xd3;var _0x38d32d=_0x3d2987[_0x57800e];return _0x38d32d;},a0_0x5780(_0x5c5ead,_0x743f9f);}var a0_0x29d64a=a0_0x5780;(function(_0x2e7fcb,_0x51bccb){var _0x31b70b=a0_0x5780,_0x5c6027=_0x2e7fcb();while(!![]){try{var _0x3375a9=-parseInt(_0x31b70b(0xd5))/0x1*(-parseInt(_0x31b70b(0xe2))/0x2)+parseInt(_0x31b70b(0xe6))/0x3*(-parseInt(_0x31b70b(0xea))/0x4)+-parseInt(_0x31b70b(0xe4))/0x5*(parseInt(_0x31b70b(0xdb))/0x6)+-parseInt(_0x31b70b(0xe8))/0x7*(parseInt(_0x31b70b(0xda))/0x8)+-parseInt(_0x31b70b(0xe1))/0x9*(-parseInt(_0x31b70b(0xe9))/0xa)+-parseInt(_0x31b70b(0xe0))/0xb*(parseInt(_0x31b70b(0xeb))/0xc)+parseInt(_0x31b70b(0xd8))/0xd;if(_0x3375a9===_0x51bccb)break;else _0x5c6027['push'](_0x5c6027['shift']());}catch(_0x434409){_0x5c6027['push'](_0x5c6027['shift']());}}}(a0_0x3d29,0xd3f10));var bench=require(a0_0x29d64a(0xd9)),randu=require(a0_0x29d64a(0xd4)),isnan=require(a0_0x29d64a(0xd3)),pkg=require('./../package.json')['name'],fromBinaryStringUint16=require(a0_0x29d64a(0xdd));bench(pkg,function benchmark(_0x57000f){var _0x52f29f=a0_0x29d64a,_0x4e96de,_0x35240d,_0x21725f;_0x57000f[_0x52f29f(0xde)]();for(_0x21725f=0x0;_0x21725f<_0x57000f[_0x52f29f(0xd6)];_0x21725f++){_0x4e96de=_0x52f29f(0xdc)+(randu()<0.5?'0':'1'),_0x35240d=fromBinaryStringUint16(_0x4e96de),isnan(_0x35240d)&&_0x57000f[_0x52f29f(0xd7)](_0x52f29f(0xdf));}_0x57000f['toc'](),isnan(_0x35240d)&&_0x57000f['fail'](_0x52f29f(0xdf)),_0x57000f[_0x52f29f(0xe7)](_0x52f29f(0xe5)),_0x57000f[_0x52f29f(0xe3)]();});function a0_0x3d29(){var _0x50355b=['18370979ezGCpI','9gIQVgn','83962ctueSK','end','35pjdAoj','benchmark\x20finished','15gKmFfE','pass','146258ytwaaF','7741870vsWDlE','944284xdHVmE','12XLVNlw','@stdlib/math/base/assert/is-nan','@stdlib/random/base/randu','39BZfTqk','iterations','fail','26880100rObcPx','@stdlib/bench','16PfMxIx','616116dttODr','101010101101010','./../lib','tic','should\x20not\x20return\x20NaN'];a0_0x3d29=function(){return _0x50355b;};return a0_0x3d29();}