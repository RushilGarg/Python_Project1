/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0xd90d(){var _0x24c4ff=['ndarray','545264mEgoAo','604850LGeTap','114414mcnPSY','1769340CGqXMl','@stdlib/utils/define-nonenumerable-read-only-property','130natpeU','./ndarray.native.js','3989Ehuxtu','993902NhtvCD','1611760cVAZsy'];a0_0xd90d=function(){return _0x24c4ff;};return a0_0xd90d();}function a0_0x2996(_0x20c7f0,_0x267e52){var _0xd90d02=a0_0xd90d();return a0_0x2996=function(_0x299669,_0x2ba1b7){_0x299669=_0x299669-0xb6;var _0x573ec7=_0xd90d02[_0x299669];return _0x573ec7;},a0_0x2996(_0x20c7f0,_0x267e52);}var a0_0x67b842=a0_0x2996;(function(_0x35b3c7,_0x577277){var _0x34afb4=a0_0x2996,_0x5bb9ef=_0x35b3c7();while(!![]){try{var _0x2a023f=-parseInt(_0x34afb4(0xb7))/0x1*(-parseInt(_0x34afb4(0xc0))/0x2)+-parseInt(_0x34afb4(0xbd))/0x3+-parseInt(_0x34afb4(0xbb))/0x4+parseInt(_0x34afb4(0xbc))/0x5+-parseInt(_0x34afb4(0xbe))/0x6+parseInt(_0x34afb4(0xb8))/0x7+parseInt(_0x34afb4(0xb9))/0x8;if(_0x2a023f===_0x577277)break;else _0x5bb9ef['push'](_0x5bb9ef['shift']());}catch(_0x393ad6){_0x5bb9ef['push'](_0x5bb9ef['shift']());}}}(a0_0xd90d,0x3e19f));var setReadOnly=require(a0_0x67b842(0xbf)),snansumors=require('./snansumors.native.js'),ndarray=require(a0_0x67b842(0xb6));setReadOnly(snansumors,a0_0x67b842(0xba),ndarray),module['exports']=snansumors;