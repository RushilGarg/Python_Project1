/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x4b2f(_0x35d14e,_0x210a50){var _0x2e479f=a0_0x2e47();return a0_0x4b2f=function(_0x4b2f57,_0x1b3f0b){_0x4b2f57=_0x4b2f57-0x110;var _0xa6b338=_0x2e479f[_0x4b2f57];return _0xa6b338;},a0_0x4b2f(_0x35d14e,_0x210a50);}var a0_0x5463dc=a0_0x4b2f;(function(_0x2d49ba,_0x19f8a0){var _0x2a290f=a0_0x4b2f,_0x3bc8aa=_0x2d49ba();while(!![]){try{var _0x573252=parseInt(_0x2a290f(0x116))/0x1*(-parseInt(_0x2a290f(0x11a))/0x2)+parseInt(_0x2a290f(0x11e))/0x3+-parseInt(_0x2a290f(0x11f))/0x4*(-parseInt(_0x2a290f(0x114))/0x5)+parseInt(_0x2a290f(0x11b))/0x6+-parseInt(_0x2a290f(0x115))/0x7*(-parseInt(_0x2a290f(0x111))/0x8)+-parseInt(_0x2a290f(0x110))/0x9*(-parseInt(_0x2a290f(0x119))/0xa)+-parseInt(_0x2a290f(0x120))/0xb;if(_0x573252===_0x19f8a0)break;else _0x3bc8aa['push'](_0x3bc8aa['shift']());}catch(_0x27a60b){_0x3bc8aa['push'](_0x3bc8aa['shift']());}}}(a0_0x2e47,0x520c4));var numel=require(a0_0x5463dc(0x118)),ind2sub=require(a0_0x5463dc(0x121)),shape=[0x3,0x3,0x3],len=numel(shape),arr=[],i;function a0_0x2e47(){var _0xe0e857=['column-major','View\x20(subscripts):','1240674eUyQsW','4KMXWbT','8352223eNeNdv','./../lib','389664LINERU','584nrjdnI','log','Dimensions:\x20%s.','1342910lEhiij','42609JDDOrr','650609SnmmvS','join','@stdlib/ndarray/base/numel','60OuAPos','2dJMWBU','2158218KVviqK'];a0_0x2e47=function(){return _0xe0e857;};return a0_0x2e47();}for(i=0x0;i<len;i++){arr['push'](i);}var opts={'order':a0_0x5463dc(0x11c)};console['log'](''),console[a0_0x5463dc(0x112)](a0_0x5463dc(0x113),shape[a0_0x5463dc(0x117)]('x')),console['log'](a0_0x5463dc(0x11d)),console[a0_0x5463dc(0x112)]('');var row,s;row='\x20\x20';for(i=0x0;i<len;i++){s=ind2sub(shape,i,opts),row+='('+s[a0_0x5463dc(0x117)](',')+')',(i+0x1)%shape[0x0]===0x0?(console[a0_0x5463dc(0x112)](row),row='\x20\x20'):row+=',\x20',(i+0x1)%(shape[0x0]*shape[0x1])===0x0&&console[a0_0x5463dc(0x112)]('');}