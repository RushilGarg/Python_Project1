/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x43ed(_0x4e5d0a,_0x3f74bf){var _0x16ceb1=a0_0x16ce();return a0_0x43ed=function(_0x43ed26,_0x285959){_0x43ed26=_0x43ed26-0xf2;var _0x2fbac8=_0x16ceb1[_0x43ed26];return _0x2fbac8;},a0_0x43ed(_0x4e5d0a,_0x3f74bf);}function a0_0x16ce(){var _0x42789c=['8pDweKn','1826CGSMMq','18860UQUpci','843798HnzFEN','4809933MhUzME','foo','92AIfaMO','432717GxADHU','120mYfOic','bar','./../lib','179615arObPE','1517lmwWtk','boop','226324iWHqmI'];a0_0x16ce=function(){return _0x42789c;};return a0_0x16ce();}var a0_0x17d055=a0_0x43ed;(function(_0x587f60,_0x180fef){var _0x363e94=a0_0x43ed,_0xf253c0=_0x587f60();while(!![]){try{var _0x1d7d94=-parseInt(_0x363e94(0xf6))/0x1*(parseInt(_0x363e94(0xff))/0x2)+-parseInt(_0x363e94(0x100))/0x3+parseInt(_0x363e94(0xf9))/0x4*(parseInt(_0x363e94(0xf5))/0x5)+parseInt(_0x363e94(0xfc))/0x6+parseInt(_0x363e94(0xf8))/0x7*(-parseInt(_0x363e94(0xf2))/0x8)+parseInt(_0x363e94(0xfd))/0x9+parseInt(_0x363e94(0xfb))/0xa*(parseInt(_0x363e94(0xfa))/0xb);if(_0x1d7d94===_0x180fef)break;else _0xf253c0['push'](_0xf253c0['shift']());}catch(_0x42707a){_0xf253c0['push'](_0xf253c0['shift']());}}}(a0_0x16ce,0x5821f));var bench=require(a0_0x17d055(0xf4));bench('beep'),bench(a0_0x17d055(0xf7)),bench(a0_0x17d055(0xfe),{}),bench(a0_0x17d055(0xf3),{'skip':![]});