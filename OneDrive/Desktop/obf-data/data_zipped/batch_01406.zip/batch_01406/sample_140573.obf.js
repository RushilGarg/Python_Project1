/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4b3e3a=a0_0x43b4;(function(_0x42117a,_0x30b691){var _0x58a8f8=a0_0x43b4,_0x2d4a38=_0x42117a();while(!![]){try{var _0x4aee6a=parseInt(_0x58a8f8(0xf2))/0x1*(parseInt(_0x58a8f8(0xda))/0x2)+parseInt(_0x58a8f8(0xef))/0x3*(parseInt(_0x58a8f8(0xe9))/0x4)+-parseInt(_0x58a8f8(0xe3))/0x5+parseInt(_0x58a8f8(0xdf))/0x6+parseInt(_0x58a8f8(0xf1))/0x7*(parseInt(_0x58a8f8(0xea))/0x8)+-parseInt(_0x58a8f8(0xee))/0x9+-parseInt(_0x58a8f8(0xe1))/0xa;if(_0x4aee6a===_0x30b691)break;else _0x2d4a38['push'](_0x2d4a38['shift']());}catch(_0x42f7dd){_0x2d4a38['push'](_0x2d4a38['shift']());}}}(a0_0x5177,0xdd79d));var resolve=require('path')[a0_0x4b3e3a(0xe7)],bench=require(a0_0x4b3e3a(0xe6)),randu=require(a0_0x4b3e3a(0xdd)),isnan=require(a0_0x4b3e3a(0xe2)),pow=require('@stdlib/math/base/special/pow'),Float32Array=require(a0_0x4b3e3a(0xec)),tryRequire=require(a0_0x4b3e3a(0xd9)),pkg=require(a0_0x4b3e3a(0xe0))['name'],sdsmeanors=tryRequire(resolve(__dirname,a0_0x4b3e3a(0xdc))),opts={'skip':sdsmeanors instanceof Error};function createBenchmark(_0x1273cc){var _0x5c330e,_0x2a26c5;_0x5c330e=new Float32Array(_0x1273cc);for(_0x2a26c5=0x0;_0x2a26c5<_0x5c330e['length'];_0x2a26c5++){_0x5c330e[_0x2a26c5]=randu()*0x14-0xa;}return _0x2ee675;function _0x2ee675(_0x244b09){var _0x6b67d7=a0_0x43b4,_0x1a3aa0,_0x189914;_0x244b09[_0x6b67d7(0xe4)]();for(_0x189914=0x0;_0x189914<_0x244b09[_0x6b67d7(0xeb)];_0x189914++){_0x1a3aa0=sdsmeanors(_0x5c330e[_0x6b67d7(0xde)],_0x5c330e,0x1,0x0),isnan(_0x1a3aa0)&&_0x244b09[_0x6b67d7(0xe5)](_0x6b67d7(0xdb));}_0x244b09['toc'](),isnan(_0x1a3aa0)&&_0x244b09[_0x6b67d7(0xe5)](_0x6b67d7(0xdb)),_0x244b09[_0x6b67d7(0xed)](_0x6b67d7(0xf0)),_0x244b09[_0x6b67d7(0xe8)]();}}function main(){var _0x101ca2,_0x81a139,_0x10b579,_0x31c969,_0x20674e;_0x81a139=0x1,_0x10b579=0x6;for(_0x20674e=_0x81a139;_0x20674e<=_0x10b579;_0x20674e++){_0x101ca2=pow(0xa,_0x20674e),_0x31c969=createBenchmark(_0x101ca2),bench(pkg+'::native:ndarray:len='+_0x101ca2,opts,_0x31c969);}}function a0_0x43b4(_0x461c42,_0x534195){var _0x51774d=a0_0x5177();return a0_0x43b4=function(_0x43b414,_0x382a3c){_0x43b414=_0x43b414-0xd9;var _0x2ee81a=_0x51774d[_0x43b414];return _0x2ee81a;},a0_0x43b4(_0x461c42,_0x534195);}main();function a0_0x5177(){var _0x157399=['8883635zlIeGx','tic','fail','@stdlib/bench','resolve','end','2051792oEaKqW','16HwjiSw','iterations','@stdlib/array/float32','pass','16278741ILjqpW','6qVPgPq','benchmark\x20finished','4351704GVjJBj','473873qUTVde','@stdlib/utils/try-require','6NpNgRq','should\x20not\x20return\x20NaN','./../lib/ndarray.native.js','@stdlib/random/base/randu','length','8431608DcdFnS','./../package.json','6034860RBXoZT','@stdlib/math/base/assert/is-nan'];a0_0x5177=function(){return _0x157399;};return a0_0x5177();}