/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x318eed=a0_0x362d;(function(_0x3fcc6,_0x2f041e){var _0x2dd258=a0_0x362d,_0x2aaff3=_0x3fcc6();while(!![]){try{var _0x189541=parseInt(_0x2dd258(0xaa))/0x1+parseInt(_0x2dd258(0xa0))/0x2*(parseInt(_0x2dd258(0xa3))/0x3)+-parseInt(_0x2dd258(0xa2))/0x4+parseInt(_0x2dd258(0x9e))/0x5*(parseInt(_0x2dd258(0x9d))/0x6)+-parseInt(_0x2dd258(0xa1))/0x7+-parseInt(_0x2dd258(0xac))/0x8+-parseInt(_0x2dd258(0xa4))/0x9*(parseInt(_0x2dd258(0xa7))/0xa);if(_0x189541===_0x2f041e)break;else _0x2aaff3['push'](_0x2aaff3['shift']());}catch(_0xc0b3c4){_0x2aaff3['push'](_0x2aaff3['shift']());}}}(a0_0x1d82,0x7ff98));var isPositive=require('@stdlib/assert/is-positive-number')[a0_0x318eed(0xab)],isNumber=require('@stdlib/assert/is-number')['isPrimitive'],isnan=require(a0_0x318eed(0xa8));function validate(_0x527c92,_0x4a5d14){var _0x6d970e=a0_0x318eed;if(!isPositive(_0x527c92))return new TypeError(_0x6d970e(0xa5)+_0x527c92+'`.');if(!isNumber(_0x4a5d14)||isnan(_0x4a5d14))return new TypeError(_0x6d970e(0xa6)+_0x4a5d14+'`.');if(_0x4a5d14<=0x0||_0x4a5d14>=0x1)return new RangeError(_0x6d970e(0x9f)+_0x4a5d14+'`.');return null;}module[a0_0x318eed(0xa9)]=validate;function a0_0x362d(_0x4354ed,_0x325a90){var _0x1d82d5=a0_0x1d82();return a0_0x362d=function(_0x362da6,_0x27a874){_0x362da6=_0x362da6-0x9d;var _0xea0288=_0x1d82d5[_0x362da6];return _0xea0288;},a0_0x362d(_0x4354ed,_0x325a90);}function a0_0x1d82(){var _0x46c35c=['3550UDbSsg','@stdlib/assert/is-nan','exports','139252Zgpoxl','isPrimitive','4574440QgmZNd','12nhJWrw','2549815rPpTuA','invalid\x20argument.\x20Second\x20argument\x20must\x20be\x20on\x20the\x20interval\x20`(0,1)`.\x20Value:\x20`','55524tEjcpm','1292137HsWGGt','3253392CkMxOa','105jCBTIQ','936sWIqvZ','invalid\x20argument.\x20First\x20argument\x20must\x20be\x20a\x20positive\x20number.\x20Value:\x20`','invalid\x20argument.\x20Second\x20argument\x20must\x20be\x20a\x20number\x20primitive\x20and\x20not\x20`NaN`.\x20Value:\x20`'];a0_0x1d82=function(){return _0x46c35c;};return a0_0x1d82();}