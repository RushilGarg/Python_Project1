/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x233f(_0x1369c1,_0x346a3b){var _0x2714cd=a0_0x2714();return a0_0x233f=function(_0x233f57,_0x422d7e){_0x233f57=_0x233f57-0x163;var _0x157a5c=_0x2714cd[_0x233f57];return _0x157a5c;},a0_0x233f(_0x1369c1,_0x346a3b);}var a0_0x1f3b6d=a0_0x233f;(function(_0x3d6936,_0xc0b215){var _0x1dc4a8=a0_0x233f,_0x532346=_0x3d6936();while(!![]){try{var _0x21971d=parseInt(_0x1dc4a8(0x166))/0x1+parseInt(_0x1dc4a8(0x163))/0x2+-parseInt(_0x1dc4a8(0x16d))/0x3*(parseInt(_0x1dc4a8(0x16e))/0x4)+-parseInt(_0x1dc4a8(0x169))/0x5+-parseInt(_0x1dc4a8(0x16a))/0x6*(parseInt(_0x1dc4a8(0x167))/0x7)+parseInt(_0x1dc4a8(0x165))/0x8+parseInt(_0x1dc4a8(0x168))/0x9*(parseInt(_0x1dc4a8(0x16c))/0xa);if(_0x21971d===_0xc0b215)break;else _0x532346['push'](_0x532346['shift']());}catch(_0x3ebe8e){_0x532346['push'](_0x532346['shift']());}}}(a0_0x2714,0x878a5));function a0_0x2714(){var _0x5ff61=['7924aVzDWa','892932MgiQBW','exports','6094424LFevku','800370piqJBR','116011zdWeda','4014CInmkg','3545875BdjROc','366EdrmWx','@stdlib/strided/base/smap','9710xlcvfI','252PZomEb'];a0_0x2714=function(){return _0x5ff61;};return a0_0x2714();}var smap=require(a0_0x1f3b6d(0x16b))['ndarray'],truncf=require('@stdlib/math/base/special/truncf');function strunc(_0x52a7f2,_0x1562cf,_0x5e2987,_0x1374d6,_0x4666ca,_0x18964f,_0x169470){return smap(_0x52a7f2,_0x1562cf,_0x5e2987,_0x1374d6,_0x4666ca,_0x18964f,_0x169470,truncf);}module[a0_0x1f3b6d(0x164)]=strunc;