(function(_0x405f31,_0x4f2d64){const _0x10570f=a0_0xcffa,_0x1bc989=_0x405f31();while(!![]){try{const _0x14f586=-parseInt(_0x10570f(0x9f))/0x1*(parseInt(_0x10570f(0xa0))/0x2)+-parseInt(_0x10570f(0xa5))/0x3*(-parseInt(_0x10570f(0x9c))/0x4)+parseInt(_0x10570f(0xa3))/0x5+parseInt(_0x10570f(0x9d))/0x6*(parseInt(_0x10570f(0xa2))/0x7)+parseInt(_0x10570f(0xa1))/0x8*(-parseInt(_0x10570f(0x9b))/0x9)+-parseInt(_0x10570f(0x9e))/0xa+-parseInt(_0x10570f(0xa4))/0xb*(-parseInt(_0x10570f(0xa6))/0xc);if(_0x14f586===_0x4f2d64)break;else _0x1bc989['push'](_0x1bc989['shift']());}catch(_0x56144f){_0x1bc989['push'](_0x1bc989['shift']());}}}(a0_0x4943,0x42632));import{gql}from'@apollo/client';export const MOVIES=gql`
  query Movies($offset: Int, $limit: Int) {
    movies(offset: $offset, limit: $limit) {
      id
      title
      direction
      releaseDate
      poster
      formats {
        id
        name
        logo
      }
    }
  }
`;function a0_0xcffa(_0x5c06e1,_0x31df26){const _0x494303=a0_0x4943();return a0_0xcffa=function(_0xcffaaa,_0x5a0fba){_0xcffaaa=_0xcffaaa-0x9b;let _0x581583=_0x494303[_0xcffaaa];return _0x581583;},a0_0xcffa(_0x5c06e1,_0x31df26);}function a0_0x4943(){const _0x3124cb=['1516641VWtPGH','2604UqnoVC','2367BkGahe','4NLbTfZ','18792djmiQF','3391740kRvPNG','5700DGdgef','122ErsaUR','16384KRrOaA','406DEwZKC','2509300fKUMYa','15631BkMSgj'];a0_0x4943=function(){return _0x3124cb;};return a0_0x4943();}export const MOVIE=gql`
  query Movie($id: Int) {
    movie(id: $id) {
      id
      title
      direction
      releaseDate
      poster
      formats {
        id
        name
        logo
      }
    }
  }
`;export const SEARCH=gql`
  query Explore($terms: String) {
    explore(terms: $terms) {
      title
      direction
      releaseDate
      poster
    }
  }
`;