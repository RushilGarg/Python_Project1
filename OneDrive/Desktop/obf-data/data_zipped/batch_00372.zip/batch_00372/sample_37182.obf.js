/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x411a02=a0_0xb2ef;(function(_0x451682,_0x1c9632){var _0x3c8337=a0_0xb2ef,_0x4a6db7=_0x451682();while(!![]){try{var _0x1e6268=parseInt(_0x3c8337(0xc1))/0x1*(-parseInt(_0x3c8337(0xb8))/0x2)+-parseInt(_0x3c8337(0xb9))/0x3+-parseInt(_0x3c8337(0xc0))/0x4+parseInt(_0x3c8337(0xb6))/0x5*(-parseInt(_0x3c8337(0xb7))/0x6)+-parseInt(_0x3c8337(0xb5))/0x7+parseInt(_0x3c8337(0xbc))/0x8+parseInt(_0x3c8337(0xbb))/0x9*(parseInt(_0x3c8337(0xbd))/0xa);if(_0x1e6268===_0x1c9632)break;else _0x4a6db7['push'](_0x4a6db7['shift']());}catch(_0x3909f5){_0x4a6db7['push'](_0x4a6db7['shift']());}}}(a0_0x2d11,0x6be67));var randu=require(a0_0x411a02(0xb4)),round=require(a0_0x411a02(0xbe)),Float32Array=require(a0_0x411a02(0xc2)),Uint8Array=require('@stdlib/array/uint8'),smskrange=require(a0_0x411a02(0xbf)),mask,x,i;x=new Float32Array(0xa),mask=new Uint8Array(x[a0_0x411a02(0xba)]);function a0_0xb2ef(_0x3784df,_0x20e665){var _0x2d11ef=a0_0x2d11();return a0_0xb2ef=function(_0xb2efb1,_0xee3daf){_0xb2efb1=_0xb2efb1-0xb3;var _0x54addb=_0x2d11ef[_0xb2efb1];return _0x54addb;},a0_0xb2ef(_0x3784df,_0x20e665);}for(i=0x0;i<x[a0_0x411a02(0xba)];i++){randu()<0.2?mask[i]=0x1:mask[i]=0x0,x[i]=round(randu()*0x64-0x32);}console[a0_0x411a02(0xb3)](x),console[a0_0x411a02(0xb3)](mask);var v=smskrange(x[a0_0x411a02(0xba)],x,0x1,mask,0x1);function a0_0x2d11(){var _0x453790=['5155871riOGWm','9175PxmMro','30ULdTwL','103310lSHRxy','603339dHPrRF','length','13161879UqktGM','4764824vDSqri','10FsNags','@stdlib/math/base/special/round','./../lib','2470316pUgjnt','1QoYkfY','@stdlib/array/float32','log','@stdlib/random/base/randu'];a0_0x2d11=function(){return _0x453790;};return a0_0x2d11();}console['log'](v);