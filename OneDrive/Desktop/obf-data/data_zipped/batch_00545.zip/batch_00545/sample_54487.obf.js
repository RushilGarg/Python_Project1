(function(_0x3dbc60,_0x1e7887){const _0x1b3ff2=a0_0x1e19,_0x182fcf=_0x3dbc60();while(!![]){try{const _0x23a1bb=parseInt(_0x1b3ff2(0x208))/0x1*(parseInt(_0x1b3ff2(0x204))/0x2)+-parseInt(_0x1b3ff2(0x1f1))/0x3+parseInt(_0x1b3ff2(0x1c7))/0x4*(-parseInt(_0x1b3ff2(0x1e0))/0x5)+-parseInt(_0x1b3ff2(0x202))/0x6*(-parseInt(_0x1b3ff2(0x1db))/0x7)+parseInt(_0x1b3ff2(0x20c))/0x8+-parseInt(_0x1b3ff2(0x1d7))/0x9+parseInt(_0x1b3ff2(0x1fd))/0xa*(parseInt(_0x1b3ff2(0x1f9))/0xb);if(_0x23a1bb===_0x1e7887)break;else _0x182fcf['push'](_0x182fcf['shift']());}catch(_0x3650e6){_0x182fcf['push'](_0x182fcf['shift']());}}}(a0_0xaae1,0x6c98c),suite('rb/views/ReviewView',function(){const _0x3134d8=a0_0x1e19,_0x392366=_['template'](dedent`
        <div class="review review-request-page-entry">
         <div class="review-request-page-entry-contents">
          <div class="collapse-button"></div>
          <div class="banners">
           <input type="button" value="Publish" />
           <input type="button" value="Discard" />
          </div>
          <div class="body">
           <ol class="review-comments">
            <li>
             <div class="review-comment-thread">
              <div class="review-comment">
               <pre class="reviewtext body_top"></pre>
              </div>
              <div class="comment-section" data-context-type="body_top">
               <a class="add_comment_link"></a>
               <ul class="reply-comments">
                <li class="draft" data-comment-id="456">
                 <pre class="reviewtext"></pre>
                </li>
               </ul>
              </div>
             </div>
            </li>
            <li>
             <div class="review-comment-thread">
              <div class="comment-section" data-context-id="123"
                   data-context-type="diff_comments">
               <a class="add_comment_link"></a>
               <ul class="reply-comments"></ul>
              </div>
             </div>
            </li>
            <li>
             <div class="review-comment-thread">
              <div class="review-comment">
               <pre class="reviewtext body_bottom"></pre>
              </div>
              <div class="comment-section" data-context-type="body_bottom">
               <a class="add_comment_link"></a>
               <ul class="reply-comments"></ul>
              </div>
             </div>
            </div>
           </li>
          </ol>
         </div>
        </div>
    `);let _0x306957,_0x2108c7,_0x5a49d7;beforeEach(function(){const _0x368bc3=a0_0x1e19,_0x33200c=new RB['ReviewRequest'](),_0x451cd1=new RB['ReviewRequestEditor']({'reviewRequest':_0x33200c});_0x2108c7=_0x33200c[_0x368bc3(0x20d)]({'loaded':!![],'links':{'replies':{'href':'/api/review/123/replies/'}}});const _0x27b300=$(_0x392366())[_0x368bc3(0x1f5)]($testsScratch);_0x5a49d7=_0x2108c7[_0x368bc3(0x1d5)](),_0x306957=new RB['ReviewRequestPage'][(_0x368bc3(0x1cc))]({'el':_0x27b300,'model':_0x2108c7,'entryModel':new RB['ReviewRequestPage'][(_0x368bc3(0x1fc))]({'review':_0x2108c7,'reviewRequest':_0x33200c,'reviewRequestEditor':_0x451cd1})}),_0x306957[_0x368bc3(0x1cf)](_0x5a49d7),spyOn(_0x306957,_0x368bc3(0x1e9))[_0x368bc3(0x1ff)][_0x368bc3(0x20a)](),_0x306957['render']();}),describe(_0x3134d8(0x20b),()=>{const _0x3d28ae=_0x3134d8;it('bodyTop\x20changed',()=>{const _0x2c1b62=a0_0x1e19;_0x2108c7[_0x2c1b62(0x1ed)]({'bodyTop':_0x2c1b62(0x1cb),'htmlTextFields':{'bodyTop':_0x2c1b62(0x1f2)}}),expect(_0x306957[_0x2c1b62(0x1d0)][_0x2c1b62(0x1f4)]())[_0x2c1b62(0x1e1)](_0x2c1b62(0x1f2));}),it(_0x3d28ae(0x1d8),()=>{const _0x2c49a1=_0x3d28ae;_0x2108c7[_0x2c49a1(0x1ed)]({'bodyBottom':_0x2c49a1(0x1d2),'htmlTextFields':{'bodyBottom':_0x2c49a1(0x1ec)}}),expect(_0x306957[_0x2c49a1(0x1dd)][_0x2c49a1(0x1f4)]())['toBe'](_0x2c49a1(0x1ec));}),describe(_0x3d28ae(0x1f6),()=>{const _0x166745=_0x3d28ae;it(_0x166745(0x1d3),()=>{const _0xd461ea=_0x166745;expect(_0x306957[_0xd461ea(0x1d0)][_0xd461ea(0x1e7)](_0xd461ea(0x1de)))[_0xd461ea(0x1e1)](![]),_0x2108c7['set'](_0xd461ea(0x1ce),!![]),expect(_0x306957[_0xd461ea(0x1d0)][_0xd461ea(0x1e7)](_0xd461ea(0x1de)))[_0xd461ea(0x1e1)](!![]);}),it(_0x166745(0x206),()=>{const _0x3b2a05=_0x166745;_0x2108c7[_0x3b2a05(0x203)][_0x3b2a05(0x1ce)]=!![],_0x306957[_0x3b2a05(0x1d0)][_0x3b2a05(0x207)](_0x3b2a05(0x1de)),_0x2108c7[_0x3b2a05(0x1ed)]('bodyTopRichText',![]),expect(_0x306957[_0x3b2a05(0x1d0)][_0x3b2a05(0x1e7)](_0x3b2a05(0x1de)))['toBe'](![]);});}),describe(_0x3d28ae(0x1e4),()=>{it('To\x20true',()=>{const _0x1a34d6=a0_0x1e19;expect(_0x306957[_0x1a34d6(0x1dd)][_0x1a34d6(0x1e7)](_0x1a34d6(0x1de)))[_0x1a34d6(0x1e1)](![]),_0x2108c7['set']('bodyBottomRichText',!![]),expect(_0x306957[_0x1a34d6(0x1dd)][_0x1a34d6(0x1e7)](_0x1a34d6(0x1de)))[_0x1a34d6(0x1e1)](!![]);}),it('To\x20false',()=>{const _0x19c042=a0_0x1e19;_0x2108c7[_0x19c042(0x203)][_0x19c042(0x1ea)]=!![],_0x306957[_0x19c042(0x1dd)]['addClass'](_0x19c042(0x1de)),_0x2108c7[_0x19c042(0x1ed)]('bodyBottomRichText',![]),expect(_0x306957[_0x19c042(0x1dd)][_0x19c042(0x1e7)]('rich-text'))['toBe'](![]);});});}),describe(_0x3134d8(0x210),function(){const _0x46027f=_0x3134d8;it(_0x46027f(0x1df),function(){const _0x289dce=_0x46027f;expect(_0x306957[_0x289dce(0x1e6)][_0x289dce(0x209)])[_0x289dce(0x1e1)](0x3);}),it('Initial\x20state\x20populated',function(){const _0x51f52a=_0x46027f;let _0x34e72c=_0x306957[_0x51f52a(0x1e6)][0x0][_0x51f52a(0x1fb)];expect(_0x34e72c[_0x51f52a(0x1f8)](_0x51f52a(0x1da)))[_0x51f52a(0x1e1)](null),expect(_0x34e72c[_0x51f52a(0x1f8)](_0x51f52a(0x1e2)))[_0x51f52a(0x1e1)](_0x51f52a(0x1ca)),_0x34e72c=_0x306957['_replyEditorViews'][0x1][_0x51f52a(0x1fb)],expect(_0x34e72c['get'](_0x51f52a(0x1da)))[_0x51f52a(0x1e1)](0x7b),expect(_0x34e72c[_0x51f52a(0x1f8)](_0x51f52a(0x1e2)))[_0x51f52a(0x1e1)]('diff_comments'),_0x34e72c=_0x306957['_replyEditorViews'][0x2][_0x51f52a(0x1fb)],expect(_0x34e72c['get'](_0x51f52a(0x1da)))[_0x51f52a(0x1e1)](null),expect(_0x34e72c[_0x51f52a(0x1f8)]('contextType'))[_0x51f52a(0x1e1)](_0x51f52a(0x1ee));}),it('Draft\x20banner\x20when\x20draft\x20comment\x20exists',function(){const _0x708113=_0x46027f;expect(_0x306957[_0x708113(0x1e9)])['toHaveBeenCalledWith']('hasDraftChanged',!![]);}),describe(_0x46027f(0x20e),function(){const _0x1453bc=_0x46027f;it(_0x1453bc(0x1e3),function(){const _0x5cdb98=_0x1453bc;spyOn(_0x306957,_0x5cdb98(0x1cf)),spyOn(_0x5a49d7,_0x5cdb98(0x201))[_0x5cdb98(0x1ff)][_0x5cdb98(0x1c9)]((_0x1d483f,_0x164ebe)=>_0x1d483f[_0x5cdb98(0x200)][_0x5cdb98(0x205)](_0x164ebe)),_0x5a49d7[_0x5cdb98(0x1e9)](_0x5cdb98(0x1c8)),expect(_0x306957[_0x5cdb98(0x1cf)])[_0x5cdb98(0x1d9)]();}),it('Publish',function(){const _0x54ebac=_0x1453bc;spyOn(_0x306957,_0x54ebac(0x1cf)),_0x306957[_0x54ebac(0x1f0)][_0x54ebac(0x1f7)](_0xc4cd5f=>spyOn(_0xc4cd5f,_0x54ebac(0x1f3))),_0x5a49d7['trigger'](_0x54ebac(0x1cd)),expect(_0x306957[_0x54ebac(0x1cf)])[_0x54ebac(0x1d9)]();});}),describe(_0x46027f(0x1e8),function(){const _0x12ef5a=_0x46027f;it(_0x12ef5a(0x1eb),function(){const _0xbfc4a4=_0x12ef5a;spyOn(_0x306957,_0xbfc4a4(0x1fe))[_0xbfc4a4(0x1ff)][_0xbfc4a4(0x20a)](),_0x306957[_0xbfc4a4(0x1cf)](new RB[(_0xbfc4a4(0x1fa))]()),expect(_0x306957[_0xbfc4a4(0x1fe)]['calls'][_0xbfc4a4(0x1d4)](0x0)[0x1])['toBe'](_0xbfc4a4(0x20f));}),it('Signals\x20disconnected\x20from\x20old\x20reviewReply',function(){const _0x4709e9=_0x12ef5a;spyOn(_0x306957,_0x4709e9(0x1dc))[_0x4709e9(0x1ff)][_0x4709e9(0x20a)](),_0x306957[_0x4709e9(0x1cf)](),expect(_0x306957['stopListening'])[_0x4709e9(0x1d6)](_0x5a49d7);}),it(_0x12ef5a(0x1ef),function(){const _0x2b7e91=_0x12ef5a;_0x306957[_0x2b7e91(0x1cf)](),expect(_0x306957['trigger'])[_0x2b7e91(0x1d6)](_0x2b7e91(0x1e5),![]);}),it('Editors\x20updated',function(){const _0x331bc5=_0x12ef5a;_0x306957[_0x331bc5(0x1cf)](),_0x306957[_0x331bc5(0x1f0)]['forEach'](_0x5d6844=>expect(_0x5d6844['get'](_0x331bc5(0x1d1)))['toBe'](_0x306957['_reviewReply']));});});});}));function a0_0x1e19(_0x492e56,_0x34d556){const _0xaae1e=a0_0xaae1();return a0_0x1e19=function(_0x1e19bb,_0x1ebd79){_0x1e19bb=_0x1e19bb-0x1c7;let _0x448986=_0xaae1e[_0x1e19bb];return _0x448986;},a0_0x1e19(_0x492e56,_0x34d556);}function a0_0xaae1(){const _0x5098e0=['15064zifWbx','stopListening','_$bodyBottom','rich-text','Views\x20created','4396630tjceFV','toBe','contextType','Discard','bodyBottomRichText\x20changed','hasDraftChanged','_replyEditorViews','hasClass','When\x20reviewReply\x20changes','trigger','bodyBottomRichText','Signals\x20connected','<p>new\x20<strong>body</strong>\x20bottom</p>','set','body_bottom','Hide\x20draft\x20banner\x20signal\x20emitted','_replyEditors','2639112TrOtpt','<p>new\x20<strong>body</strong>\x20top</p>','_resetState','html','appendTo','bodyTopRichText\x20changed','forEach','get','55QisOBY','ReviewReply','model','ReviewEntry','2831880vxqBpr','listenTo','and','success','discardIfEmpty','1608XUsaOK','attributes','3328jGPuGZ','call','To\x20false','addClass','277XNxZsO','length','callThrough','Model\x20events','4181024zIQWpJ','createReview','reviewReply\x20changes\x20on','destroyed\x20published','Reply\x20editors','4XfvWbF','destroyed','callFake','body_top','new\x20**body**\x20top','ReviewView','published','bodyTopRichText','_setupNewReply','_$bodyTop','reviewReply','new\x20**body**\x20bottom','To\x20true','argsFor','createReply','toHaveBeenCalledWith','6951510pFQlSv','bodyBottom\x20changed','toHaveBeenCalled','contextID'];a0_0xaae1=function(){return _0x5098e0;};return a0_0xaae1();}