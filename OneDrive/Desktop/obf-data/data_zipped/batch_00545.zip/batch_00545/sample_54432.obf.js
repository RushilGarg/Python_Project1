const a0_0x46872e=a0_0x3fdc;(function(_0x31f52b,_0x20656d){const _0x3be553=a0_0x3fdc,_0x1c6913=_0x31f52b();while(!![]){try{const _0x5cb76b=-parseInt(_0x3be553(0x104))/0x1+-parseInt(_0x3be553(0x10a))/0x2+-parseInt(_0x3be553(0x101))/0x3*(parseInt(_0x3be553(0x107))/0x4)+-parseInt(_0x3be553(0x102))/0x5+parseInt(_0x3be553(0x100))/0x6*(-parseInt(_0x3be553(0x109))/0x7)+-parseInt(_0x3be553(0x108))/0x8*(-parseInt(_0x3be553(0x106))/0x9)+-parseInt(_0x3be553(0x105))/0xa*(-parseInt(_0x3be553(0x103))/0xb);if(_0x5cb76b===_0x20656d)break;else _0x1c6913['push'](_0x1c6913['shift']());}catch(_0xf0255f){_0x1c6913['push'](_0x1c6913['shift']());}}}(a0_0x1135,0x81cd7));function a0_0x3fdc(_0x1f9952,_0x16756e){const _0x1135d6=a0_0x1135();return a0_0x3fdc=function(_0x3fdc46,_0x39848c){_0x3fdc46=_0x3fdc46-0x100;let _0x4a5a4e=_0x1135d6[_0x3fdc46];return _0x4a5a4e;},a0_0x3fdc(_0x1f9952,_0x16756e);}import a0_0x300115 from'styled-components';function a0_0x1135(){const _0x38fa2d=['413796xNSdNC','808260PJuRjT','55VsWdTj','109074mUneVR','3728960UQXorQ','189IpAkNQ','28boovPb','314296agYKhC','100121gTGUKD','613114bZotUJ','div','258ZaPRnm'];a0_0x1135=function(){return _0x38fa2d;};return a0_0x1135();}const MenuHeader=a0_0x300115[a0_0x46872e(0x10b)]`
    display: -webkit-box;
    display: -moz-box;
    display: -ms-flexbox;
    display: -webkit-flex;
    display: flex;  

    list-style: none;
    margin: 0;
    padding: 0;

    
    -webkit-flex-flow: row wrap;
    flex-flow: row wrap;

    background: #152032;
    color: #777;

    /* On mouse-over, add a deeper shadow */
    &:hover, &:focus {
        color: #DDD;
    }

    & :first-child {
        flex-grow: 1;
    }
`;export default MenuHeader;