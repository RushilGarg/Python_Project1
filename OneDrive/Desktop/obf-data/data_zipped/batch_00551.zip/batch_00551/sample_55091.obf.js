/* @license
 * This file is part of the Game Closure SDK.
 *
 * The Game Closure SDK is free software: you can redistribute it and/or modify
 * it under the terms of the Mozilla Public License v. 2.0 as published by Mozilla.

 * The Game Closure SDK is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * Mozilla Public License v. 2.0 for more details.

 * You should have received a copy of the Mozilla Public License v. 2.0
 * along with the Game Closure SDK.  If not, see <http://mozilla.org/MPL/2.0/>.
 */
function a0_0x4fa4(_0x5e5f26,_0x5d8b51){var _0x72e80d=a0_0x72e8();return a0_0x4fa4=function(_0x4fa451,_0x133cc4){_0x4fa451=_0x4fa451-0x153;var _0x416a9a=_0x72e80d[_0x4fa451];return _0x416a9a;},a0_0x4fa4(_0x5e5f26,_0x5d8b51);}var a0_0xc9d3fc=a0_0x4fa4;(function(_0x1f4ffb,_0x18b671){var _0x52329a=a0_0x4fa4,_0x4c5ece=_0x1f4ffb();while(!![]){try{var _0x33f559=parseInt(_0x52329a(0x157))/0x1*(parseInt(_0x52329a(0x15c))/0x2)+-parseInt(_0x52329a(0x15d))/0x3*(-parseInt(_0x52329a(0x154))/0x4)+parseInt(_0x52329a(0x160))/0x5+parseInt(_0x52329a(0x15f))/0x6+-parseInt(_0x52329a(0x155))/0x7+parseInt(_0x52329a(0x15e))/0x8*(-parseInt(_0x52329a(0x158))/0x9)+-parseInt(_0x52329a(0x161))/0xa*(parseInt(_0x52329a(0x15b))/0xb);if(_0x33f559===_0x18b671)break;else _0x4c5ece['push'](_0x4c5ece['shift']());}catch(_0x4e733e){_0x4c5ece['push'](_0x4c5ece['shift']());}}}(a0_0x72e8,0x7b598),require('./mockJSIO')['setup'](),require(a0_0xc9d3fc(0x153))[a0_0xc9d3fc(0x162)](),exports[a0_0xc9d3fc(0x162)]=function(){var _0x4ae533=a0_0xc9d3fc;jsio('import\x20device\x20as\x20device'),device['width']=0x280,device[_0x4ae533(0x15a)]=0x1e0,device[_0x4ae533(0x156)]=![],device[_0x4ae533(0x159)]=![];});function a0_0x72e8(){var _0x527df4=['65244OzBuBU','4424252RwwPcT','canResize','504533WdNBKD','2268873FjQpuL','isMobile','height','6233887RkHxEo','2JIsvsM','9RovwHz','8ZXYuTL','4379982xQIIKb','3363135fKrbpk','10FcgpNh','setup','./mockDOM'];a0_0x72e8=function(){return _0x527df4;};return a0_0x72e8();}