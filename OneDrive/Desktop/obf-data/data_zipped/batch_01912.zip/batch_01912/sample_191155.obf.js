function a0_0x50c7(_0x4bd688,_0x41e532){const _0x4e78a5=a0_0x4e78();return a0_0x50c7=function(_0x50c7f0,_0x1ae01d){_0x50c7f0=_0x50c7f0-0x104;let _0x40f041=_0x4e78a5[_0x50c7f0];return _0x40f041;},a0_0x50c7(_0x4bd688,_0x41e532);}const a0_0x445977=a0_0x50c7;(function(_0x24a7c9,_0x512705){const _0x3dd90e=a0_0x50c7,_0x28bf5f=_0x24a7c9();while(!![]){try{const _0xc193a7=parseInt(_0x3dd90e(0x105))/0x1*(-parseInt(_0x3dd90e(0x10c))/0x2)+parseInt(_0x3dd90e(0x10a))/0x3+parseInt(_0x3dd90e(0x10e))/0x4+-parseInt(_0x3dd90e(0x10b))/0x5+parseInt(_0x3dd90e(0x107))/0x6*(parseInt(_0x3dd90e(0x106))/0x7)+parseInt(_0x3dd90e(0x10f))/0x8+-parseInt(_0x3dd90e(0x104))/0x9*(parseInt(_0x3dd90e(0x108))/0xa);if(_0xc193a7===_0x512705)break;else _0x28bf5f['push'](_0x28bf5f['shift']());}catch(_0x30a1f3){_0x28bf5f['push'](_0x28bf5f['shift']());}}}(a0_0x4e78,0xaa7e1));import{css}from'@emotion/core';import a0_0x5acecd from'../../config/theme';const prism=css`
  p > code,
  li > code {
    color: #f8f8f2;
    background: #131316;
    font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
    text-align: left;
    word-spacing: normal;
    word-break: normal;
    word-wrap: normal;
    line-height: 1.5;
    padding: 0.4em 0.5em;
    margin: 0.5em 0;
    overflow: auto;
    border-radius: 0.3em;
    tab-size: 4;
    hyphens: none;
  }
  code[class*='language-'],
  pre[class*='language-'] {
    color: #f8f8f2;
    background: none;
    font-family: Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace;
    text-align: left;
    word-spacing: normal;
    word-break: normal;
    word-wrap: normal;
    line-height: 1.5;
    tab-size: 4;
    hyphens: none;
  }
  pre[class*='language-'] {
    padding: 1em;
    margin: 1.5rem 0;
    overflow: auto;
    border-radius: 0.3em;
    &::-webkit-scrollbar-thumb {
      background: ${a0_0x5acecd[a0_0x445977(0x10d)][a0_0x445977(0x111)][a0_0x445977(0x109)]};
    }
    &::-webkit-scrollbar-track {
      background: ${a0_0x5acecd[a0_0x445977(0x10d)][a0_0x445977(0x110)]['light']};
    }
    &::-webkit-scrollbar {
      width: 12px;
      height: 12px;
    }
  }
  pre[class*='language-'] {
    background: #131316;
  }
  p > code[class*='language-'],
  li > code[class*='language-'] {
    border-radius: 0.3em;
    background: rgba(52, 152, 219, 0.2);
    color: #2e3246;
    bottom: 2px;
    position: relative;
  }
  .token.operator {
    color: #bc78d7;
  }
  .token.comment,
  .token.prolog,
  .token.doctype,
  .token.cdata {
    color: slategray;
  }
  .token.punctuation {
    color: #7ad7e2;
  }
  .namespace {
    opacity: 0.7;
  }
  .token.property,
  .token.tag,
  .token.constant,
  .token.symbol,
  .token.deleted {
    color: #ef514f;
  }
  .token.boolean,
  .token.number {
    color: #ae81ff;
  }
  .token.selector,
  .token.attr-name,
  .token.string,
  .token.char,
  .token.builtin,
  .token.inserted {
    color: #e5db89;
  }
  .token.entity,
  .token.url,
  .language-css .token.string,
  .style .token.string,
  .token.variable {
    color: #f8f8f2;
  }
  .token.atrule,
  .token.attr-value,
  .token.class-name {
    color: #e6db74;
  }
  .token.function {
    color: #84c16a;
  }

  .token.keyword {
    color: #6095ea;
  }
  .token.regex,
  .token.important {
    color: #fd971f;
  }
  .token.important,
  .token.bold {
    font-weight: bold;
  }
  .token.italic {
    font-style: italic;
  }
  .token.entity {
    cursor: help;
  }
`;export default prism;function a0_0x4e78(){const _0x8154cc=['colors','2015832jYhENr','8053680XRDXlR','black','primary','3258WPWOvi','1148311wqMVIO','14xEKIBw','2357898eqSjPg','42820andBtJ','base','3558495tZQsVC','430335Qomzxf','2eaueYG'];a0_0x4e78=function(){return _0x8154cc;};return a0_0x4e78();}