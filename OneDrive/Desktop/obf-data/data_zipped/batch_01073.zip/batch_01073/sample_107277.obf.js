/**
 * @license Angular v4.3.6
 * (c) 2010-2017 Google, Inc. https://angular.io/
 * License: MIT
 */
function a0_0x2da1(){const _0x40827e=['$templateCache','278OPalBO','Failed\x20to\x20load\x20','31056nPGjEJ','send','status','674330lkFDRI','_cache','reject','GET','onload','responseText','77440VhOQWL','get','resolve','4.3.6','responseType','6NhfNbx','884IDGBWo','633870fCaezn','onerror','text','response','1526338HQqFkR','1068904EiRFur','CachedResourceLoader:\x20Did\x20not\x20find\x20cached\x20template\x20for\x20','7FLMbxs','ctorParameters','10iEXTlF','hasOwnProperty'];a0_0x2da1=function(){return _0x40827e;};return a0_0x2da1();}const a0_0x2cd671=a0_0x2b71;(function(_0x194af0,_0x49248d){const _0x346312=a0_0x2b71,_0x33840e=_0x194af0();while(!![]){try{const _0x9d91f8=-parseInt(_0x346312(0x166))/0x1*(parseInt(_0x346312(0x159))/0x2)+parseInt(_0x346312(0x168))/0x3+parseInt(_0x346312(0x153))/0x4+parseInt(_0x346312(0x16b))/0x5*(parseInt(_0x346312(0x158))/0x6)+parseInt(_0x346312(0x161))/0x7*(-parseInt(_0x346312(0x15f))/0x8)+parseInt(_0x346312(0x15a))/0x9+-parseInt(_0x346312(0x163))/0xa*(-parseInt(_0x346312(0x15e))/0xb);if(_0x9d91f8===_0x49248d)break;else _0x33840e['push'](_0x33840e['shift']());}catch(_0xae5243){_0x33840e['push'](_0x33840e['shift']());}}}(a0_0x2da1,0x1ca1d));import{ResourceLoader,platformCoreDynamic}from'@angular/compiler';import{COMPILER_OPTIONS,Injectable,PLATFORM_ID,Version,createPlatformFactory,ɵglobal}from'@angular/core';import{ɵPLATFORM_BROWSER_ID}from'@angular/common';import{ɵINTERNAL_BROWSER_PLATFORM_PROVIDERS}from'@angular/platform-browser';/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
class ResourceLoaderImpl extends ResourceLoader{['get'](_0x298028){const _0x22d47c=a0_0x2b71;let _0x35c3b6,_0x4d0e8d;const _0x1376f2=new Promise((_0x1bc358,_0x33ae12)=>{_0x35c3b6=_0x1bc358,_0x4d0e8d=_0x33ae12;}),_0x5e0ac7=new XMLHttpRequest();return _0x5e0ac7['open'](_0x22d47c(0x16e),_0x298028,!![]),_0x5e0ac7[_0x22d47c(0x157)]=_0x22d47c(0x15c),_0x5e0ac7[_0x22d47c(0x151)]=function(){const _0x50cefd=_0x22d47c,_0x2dee2f=_0x5e0ac7[_0x50cefd(0x15d)]||_0x5e0ac7[_0x50cefd(0x152)];let _0x1e533e=_0x5e0ac7['status']===0x4c7?0xcc:_0x5e0ac7[_0x50cefd(0x16a)];_0x1e533e===0x0&&(_0x1e533e=_0x2dee2f?0xc8:0x0),0xc8<=_0x1e533e&&_0x1e533e<=0x12c?_0x35c3b6(_0x2dee2f):_0x4d0e8d(_0x50cefd(0x167)+_0x298028);},_0x5e0ac7[_0x22d47c(0x15b)]=function(){const _0x2ccbfd=_0x22d47c;_0x4d0e8d(_0x2ccbfd(0x167)+_0x298028);},_0x5e0ac7[_0x22d47c(0x169)](),_0x1376f2;}}ResourceLoaderImpl['decorators']=[{'type':Injectable}],ResourceLoaderImpl[a0_0x2cd671(0x162)]=()=>[];/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const INTERNAL_BROWSER_DYNAMIC_PLATFORM_PROVIDERS=[ɵINTERNAL_BROWSER_PLATFORM_PROVIDERS,{'provide':COMPILER_OPTIONS,'useValue':{'providers':[{'provide':ResourceLoader,'useClass':ResourceLoaderImpl}]},'multi':!![]},{'provide':PLATFORM_ID,'useValue':ɵPLATFORM_BROWSER_ID}];function a0_0x2b71(_0x4d5f96,_0x57ebe5){const _0x2da1c5=a0_0x2da1();return a0_0x2b71=function(_0x2b71b8,_0x42ff5d){_0x2b71b8=_0x2b71b8-0x151;let _0x112947=_0x2da1c5[_0x2b71b8];return _0x112947;},a0_0x2b71(_0x4d5f96,_0x57ebe5);}/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
class CachedResourceLoader extends ResourceLoader{constructor(){const _0x1d2943=a0_0x2cd671;super(),this[_0x1d2943(0x16c)]=ɵglobal[_0x1d2943(0x165)];if(this[_0x1d2943(0x16c)]==null)throw new Error('CachedResourceLoader:\x20Template\x20cache\x20was\x20not\x20found\x20in\x20$templateCache.');}[a0_0x2cd671(0x154)](_0x2f896f){const _0x4571a0=a0_0x2cd671;return this[_0x4571a0(0x16c)][_0x4571a0(0x164)](_0x2f896f)?Promise[_0x4571a0(0x155)](this['_cache'][_0x2f896f]):Promise[_0x4571a0(0x16d)](_0x4571a0(0x160)+_0x2f896f);}}/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
const VERSION=new Version(a0_0x2cd671(0x156)),RESOURCE_CACHE_PROVIDER=[{'provide':ResourceLoader,'useClass':CachedResourceLoader}],platformBrowserDynamic=createPlatformFactory(platformCoreDynamic,'browserDynamic',INTERNAL_BROWSER_DYNAMIC_PLATFORM_PROVIDERS);/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export{RESOURCE_CACHE_PROVIDER,platformBrowserDynamic,VERSION,INTERNAL_BROWSER_DYNAMIC_PLATFORM_PROVIDERS as ɵINTERNAL_BROWSER_DYNAMIC_PLATFORM_PROVIDERS,ResourceLoaderImpl as ɵResourceLoaderImpl};