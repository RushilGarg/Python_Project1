/**
 *
 * jQuery.ajaxMock - https://github.com/martinkr/jQuery.ajaxMock
 *
 * jQuery.ajaxMock is a tiny but yet powerful mocking plugin for jQuery 1.5+.
 *
 * @Version: 1.2.0
 *
 * @example:
 *
 *   Register your mock object:
 *   // jQuery.ajaxMock.register( URL ,  {reponseText: "{String} Mocked responseText", statusCode: "{Number} Mocked status code", status: "{String} Mocked status description", type: "{String} http request method"}
 *   jQuery.ajaxMock.register('http://example.com', {
 *         responseText:'responseFoo',
 *         statusCode:200,
 *         status:'OK',
 *         type: 'POST', // optional, takes a String as http request method default: 'GET'
 *         delay: 1000 // optional
 *       }
 *  );
 *
 *  And all $.ajax-calls to 'http://example.com' will return the mocked response.
 *
 * Copyright (c) 2012 Martin Krause (jquery.public.mkrause.info)
 * Dual licensed under the MIT and GPL licenses.
 *
 * @author Martin Krause public@mkrause.info
 * @copyright Martin Krause (jquery.public.mkrause.info)
 * @license MIT http://www.opensource.org/licenses/mit-license.php
 * @license GNU http://www.gnu.org/licenses/gpl-3.0.html
 *
 * @requires
 *  jQuery JavaScript Library - http://jquery.com/, v1.5+
 *    Copyright 2010, John Resig
 *    Dual licensed under the MIT or GPL Version 2 licenses - http://jquery.org/license
 *
 */
var a0_0x342ceb=a0_0x525b;function a0_0x525b(_0x3b7138,_0x4c6af7){var _0x483c3d=a0_0x483c();return a0_0x525b=function(_0x525b4a,_0x9f883d){_0x525b4a=_0x525b4a-0x8a;var _0x959ddf=_0x483c3d[_0x525b4a];return _0x959ddf;},a0_0x525b(_0x3b7138,_0x4c6af7);}function a0_0x483c(){var _0x51050b=['delay','type','3786408tnJqlg','32402277MQGSOV','10171BKRlaa','ajaxTransport','initialize','url','9719658AsSgtJ','3992964SUSvdK','statusCode','setTimeout','status','join','ajaxMock','397xqRqTa','4511360IEyHRn','getObject','7634cgWprJ','1432SzCNRO'];a0_0x483c=function(){return _0x51050b;};return a0_0x483c();}(function(_0x33abb6,_0x73ea08){var _0x14440a=a0_0x525b,_0x22a933=_0x33abb6();while(!![]){try{var _0x295723=-parseInt(_0x14440a(0x8f))/0x1*(-parseInt(_0x14440a(0x92))/0x2)+parseInt(_0x14440a(0x96))/0x3+-parseInt(_0x14440a(0x9d))/0x4+parseInt(_0x14440a(0x90))/0x5+parseInt(_0x14440a(0x9c))/0x6+parseInt(_0x14440a(0x98))/0x7*(parseInt(_0x14440a(0x93))/0x8)+-parseInt(_0x14440a(0x97))/0x9;if(_0x295723===_0x73ea08)break;else _0x22a933['push'](_0x22a933['shift']());}catch(_0x1c3d94){_0x22a933['push'](_0x22a933['shift']());}}}(a0_0x483c,0xeab0d),function(_0x4e1fb2){_0x4e1fb2['ajaxMock']=(function(){var _0xb60df8={},_0x14bf48={'url':undefined,'type':undefined},_0x2bb449='GET',_0x4056e0=function(_0x205e38,_0x3c1e46){var _0x47e637=a0_0x525b;return encodeURIComponent([_0x3c1e46||_0x2bb449,'++',_0x205e38][_0x47e637(0x8d)](''));},_0x293e8f=function(_0x440bad,_0x26ee91){var _0x3169d5=a0_0x525b;_0xb60df8[_0x4056e0(_0x440bad,_0x26ee91[_0x3169d5(0x95)])]=_0x26ee91;},_0x50093a=function(_0x4091d5,_0x2203ec){return _0xb60df8[_0x4056e0(_0x4091d5,_0x2203ec)];},_0x1aa87b=function(_0x406e5e,_0xe4141d){return!!_0xb60df8[_0x4056e0(_0x406e5e,_0xe4141d)];},_0x78eefe=function(){_0xb60df8={},_0x14bf48={'url':undefined,'type':undefined};},_0x1d5129=function(_0x10b235,_0x7dc3f9){var _0x4c09c8=a0_0x525b;if(_0x10b235){var _0x23534b=_0x7dc3f9||_0x2bb449;_0x14bf48=_0x50093a(_0x10b235,_0x23534b),_0x14bf48[_0x4c09c8(0x9b)]=_0x10b235,_0x14bf48[_0x4c09c8(0x95)]=_0x23534b;}return _0x14bf48;},_0x2cbe76=function(){var _0x446d9c=a0_0x525b;_0x4e1fb2[_0x446d9c(0x99)]('+*',function(_0xeefbdb){var _0x220f9e=_0x446d9c,_0x32efb0=_0xeefbdb['url'],_0x1685ff=_0xeefbdb[_0x220f9e(0x95)]||_0x2bb449;if(_0x4e1fb2[_0x220f9e(0x8e)]['isRegistered'](_0x32efb0,_0x1685ff))return{'send':function(_0x1ce471,_0x152d87){var _0x12bed1=_0x220f9e,_0x5c778e=_0x4e1fb2[_0x12bed1(0x8e)][_0x12bed1(0x91)](_0x32efb0,_0x1685ff);function _0x11c8b6(){var _0x3294c7=_0x12bed1;_0x4e1fb2['ajaxMock']['last'](_0x32efb0,_0x1685ff),_0x152d87(_0x5c778e[_0x3294c7(0x8a)]||0xc8,_0x5c778e[_0x3294c7(0x8c)]||'OK',{'text':_0x5c778e['responseText']||'','type':_0x1685ff});}_0x5c778e[_0x12bed1(0x94)]?window[_0x12bed1(0x8b)](_0x11c8b6,_0x5c778e[_0x12bed1(0x94)]):_0x11c8b6();}};});};return{'getObject':_0x50093a,'register':_0x293e8f,'isRegistered':_0x1aa87b,'flush':_0x78eefe,'last':_0x1d5129,'initialize':_0x2cbe76};}());}(jQuery),$[a0_0x342ceb(0x8e)][a0_0x342ceb(0x9a)]());