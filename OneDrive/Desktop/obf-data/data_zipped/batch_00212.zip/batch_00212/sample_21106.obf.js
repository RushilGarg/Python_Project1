(function(_0x5dbf2c,_0x33b343){var _0x47bca0=a0_0x2739,_0x40a2c3=_0x5dbf2c();while(!![]){try{var _0x74ea13=-parseInt(_0x47bca0(0x106))/0x1*(parseInt(_0x47bca0(0x10b))/0x2)+-parseInt(_0x47bca0(0x105))/0x3*(parseInt(_0x47bca0(0x104))/0x4)+parseInt(_0x47bca0(0x103))/0x5*(parseInt(_0x47bca0(0x108))/0x6)+parseInt(_0x47bca0(0x107))/0x7+-parseInt(_0x47bca0(0x102))/0x8+parseInt(_0x47bca0(0x109))/0x9+parseInt(_0x47bca0(0x10a))/0xa;if(_0x74ea13===_0x33b343)break;else _0x40a2c3['push'](_0x40a2c3['shift']());}catch(_0x4a5a13){_0x40a2c3['push'](_0x40a2c3['shift']());}}}(a0_0x1064,0xb718c));function a0_0x1064(){var _0x2e53ae=['6984aNMpmo','5491125XtvfJu','10184990JCTOTL','14ZfvsKV','2259072Ihmazo','2150mNbiZw','12KqJBkM','1259667xrbDta','19541IWbjVq','2097606Flatve'];a0_0x1064=function(){return _0x2e53ae;};return a0_0x1064();}function a0_0x2739(_0x97f3c9,_0x163d35){var _0x1064e6=a0_0x1064();return a0_0x2739=function(_0x2739e5,_0x1f7699){_0x2739e5=_0x2739e5-0x102;var _0x3ca305=_0x1064e6[_0x2739e5];return _0x3ca305;},a0_0x2739(_0x97f3c9,_0x163d35);}import{css}from'styled-components';export default css`
  .italic, .oblique, em, i { font-style: italic; }
  .bold, strong, b { font-weight: bold; }
  .regular, .normal, address { font-weight: normal; }
  .thin, .light { font-weight: lighter; }

  h3, h4, h5, h6 {
    line-height: 1.2;
    margin: 0;
    font-weight: bold;
    > sub {
      display: block;
      font-size: .65em;
      opacity: .5;
    }
  }

  h1 {
    font-size: 2.5em;
    letter-spacing: -.025em;
    font-weight: 100;
  }

  h2 {
    font-size: 2em;
    letter-spacing: -.025em;
    font-weight: 300;
  }

  h3 {
    font-size: 1.6em;
    text-transform: uppercase;
    font-weight: 400;
  }

  h4 { font-size: 1.35em; font-weight: 700; }

  h5 { font-size: 1.2em; }

  h6 {
    font-size: 1em;
    font-weight: 800;
  }
`;