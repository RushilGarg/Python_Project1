/**
 * Copyright 2020 The Pennsylvania State University
 * @license Apache-2.0, see License.md for full text.
 */
function a0_0xf154(){var _0x46d80f=['elmsln-studio-dashboard','\x20/\x20','image','footer','firstName','amber','unknown','avatar','join','submissions','assignment','styles','assignmentDate','412008graKHl','render','?student=','map','3204726EqQFbj','assignment-turned-in','long','getActivityTitle','9jjZPaW','feedback','lastName','997885BgHckT','properties','due','accentColor','red','report-problem','firstUpdated','Overdue','3312040RPXiYu','feedbackPercentile','Not\x20Submitted','keys','474384aUTecr','loading','completed','pink','define','94OSSVps','assignment-late','tag','length','orange','given','portfolioId','getActivityLink','profile','14WHRUFH','fetchData','body','profileName','3522tnLVNl','features','date','1896620NChaat','isLate','slice','dateFormat','purple','Submitted\x20Late'];a0_0xf154=function(){return _0x46d80f;};return a0_0xf154();}var a0_0x52a4a8=a0_0x26f0;(function(_0x59d91a,_0xc3739f){var _0x58a4bb=a0_0x26f0,_0x20d3c1=_0x59d91a();while(!![]){try{var _0x5c9076=parseInt(_0x58a4bb(0x1cd))/0x1*(-parseInt(_0x58a4bb(0x1c0))/0x2)+parseInt(_0x58a4bb(0x1a4))/0x3+-parseInt(_0x58a4bb(0x1d0))/0x4+-parseInt(_0x58a4bb(0x1af))/0x5+parseInt(_0x58a4bb(0x1a8))/0x6+parseInt(_0x58a4bb(0x1c9))/0x7*(parseInt(_0x58a4bb(0x1bb))/0x8)+parseInt(_0x58a4bb(0x1ac))/0x9*(parseInt(_0x58a4bb(0x1b7))/0xa);if(_0x5c9076===_0xc3739f)break;else _0x20d3c1['push'](_0x20d3c1['shift']());}catch(_0x36e358){_0x20d3c1['push'](_0x20d3c1['shift']());}}}(a0_0xf154,0x44d87));import{LitElement as a0_0xe71182,html as a0_0x14b746,css as a0_0x558f9e}from'../../../lit/index.js';import{ElmslnStudioUtilities as a0_0x452fb5}from'./elmsln-studio-utilities.js';function a0_0x26f0(_0x410acd,_0x501055){var _0xf154bf=a0_0xf154();return a0_0x26f0=function(_0x26f0e2,_0x383ff3){_0x26f0e2=_0x26f0e2-0x19f;var _0x4feb96=_0xf154bf[_0x26f0e2];return _0x4feb96;},a0_0x26f0(_0x410acd,_0x501055);}import{ElmslnStudioStyles as a0_0x3c6236}from'./elmsln-studio-styles.js';import'./elmsln-studio-link.js';import'./elmsln-studio-button.js';class ElmslnStudioDashboard extends a0_0x452fb5(a0_0x3c6236(a0_0xe71182)){static get[a0_0x52a4a8(0x1c2)](){var _0x3ccb65=a0_0x52a4a8;return _0x3ccb65(0x1d6);}static get[a0_0x52a4a8(0x1a2)](){var _0x37d572=a0_0x52a4a8;return[...super[_0x37d572(0x1a2)],a0_0x558f9e`
        h1,
        h2,
        h3,
        .card [slot="heading"] {
          margin: 0;
          color: #9d9d9d;
          font-weight: normal;
          font-size: calc(1.5 * var(--elmsln-studio-FontSize, 16px));
          font-family: var(--elmsln-studio-FontFamily, "Roboto", sans-serif);
        }
        h2 {
          font-weight: bold;
          color: #989898;
        }
        #primary > div {
          margin: 0;
        }
        .card {
          font-size: var(--elmsln-studio-FontSize, 16px);
          font-family: var(--elmsln-studio-FontFamily, "Roboto", sans-serif);
          margin: calc(0.5 * var(--elmsln-studio-margin, 20px)) 0
            calc(2 * var(--elmsln-studio-margin, 20px));
          flex: 1 0 50%;
          color: #95989a;
          --accent-card-footer-border-color: transparent;
        }
        .card [slot="subheading"] {
          font-weight: bold;
          border: none;
          font-size: calc(0.75 * var(--elmsln-studio-FontSize, 16px));
        }
        .card.primary [slot="heading"],
        .card [slot="subheading"] {
          text-align: center;
          display: block;
          margin: 0 auto;
        }
        .card.primary [slot="label"] {
          color: #5c5c5c;
        }
        .card.primary [slot="description"] {
          color: #818181;
          font-size: calc(0.75 * var(--elmsln-studio-FontSize, 16px));
        }
        .card.feed {
          font-size: calc(0.75 * var(--elmsln-studio-FontSize, 16px));
          --lrndesign-avatar-width: var(--nav-card-linklist-left-size, 36px);
          --nav-card-item-avatar-width: var(
            --nav-card-linklist-left-size,
            36px
          );
          --nav-card-item-avatar-height: var(
            --nav-card-linklist-left-size,
            36px
          );
        }
        .card.due,
        .card.recent {
          --nav-card-linklist-left-size: 36px;
          --nav-card-item-avatar-size: 40px;
        }
        .card.secondary nav-card {
          border: none !important;
        }
        #profile {
          --lrndesign-avatar-width: 100px;
        }
        #profile lrndesign-avatar {
          margin: 0 auto;
          text-align: center;
        }
        accent-card {
          --accent-card-heading-padding-top: 0;
        }
        accent-card table {
          width: 100%;
          border-collapse: collapse;
          font-family: var(
            --elmsln-studio-secondary-FontFamily,
            "Helvetica Neue",
            sans-serif
          );
        }
        accent-card th,
        accent-card td {
          font-weight: normal;
          padding: 5px 0;
          text-align: left;
          min-height: 25px;
          border-bottom: 1px solid
            var(--simple-colors-default-theme-grey-4, #666);
        }
        accent-card td {
          text-align: right;
        }
        accent-card th simple-icon-lite {
          width: 20px;
          height: 20px;
        }
        accent-card.card th elmsln-studio-link {
          --elmsln-studio-link-TextDecoration: underline !important;
        }
        accent-card.card th elmsln-studio-link:focus,
        accent-card.card th elmsln-studio-link:focus-within,
        accent-card.card th elmsln-studio-link:hover {
          --elmsln-studio-link-TextDecoration: none !important;
        }
        @media screen and (min-width: 600px) {
          #profile {
            --lrndesign-avatar-width: 150px;
          }
          #profile lrndesign-avatar {
            margin: 0 auto;
          }
          h1,
          h2 {
            flex: 0 0 100%;
          }
          #primary > div {
            display: flex;
            align-items: stretch;
            justify-content: space-between;
            flex-wrap: wrap;
          }
          .card.primary {
            flex: 0 0 calc(50% - var(--elmsln-studio-margin, 20px));
          }
        }
        @media screen and (min-width: 900px) {
          :host {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
          }
          #profile {
            --lrndesign-avatar-width: 200px;
          }
          #profile lrndesign-avatar {
            margin: 0 auto;
          }
        }
      `];}[a0_0x52a4a8(0x1a5)](){var _0x55f79f=a0_0x52a4a8;return a0_0x14b746`
      <h1 class="sr-only">Overview</h1>
      <div id="primary">
        <div id="profile">
          <h2>${this[_0x55f79f(0x1cc)]||'Loading\x20Your\x20Profile...'}</h2>
          <accent-card accent-color="purple" class="card primary">
            <span slot="heading" class="sr-only">My Progress</span>
            ${!this['profile']||Object[_0x55f79f(0x1ba)](this[_0x55f79f(0x1c8)])[_0x55f79f(0x1c3)]<0x1?this[_0x55f79f(0x1bc)](_0x55f79f(0x1d4),_0x55f79f(0x1d9)):a0_0x14b746`
                  <lrndesign-avatar
                    accent-color="${this[_0x55f79f(0x1b2)](this[_0x55f79f(0x1cc)])}"
                    slot="content"
                    src="${this[_0x55f79f(0x1c8)]?this[_0x55f79f(0x1c8)][_0x55f79f(0x1d8)]:'unknown'}"
                    label="${this[_0x55f79f(0x1cc)]}"
                    two-chars
                    size="200px"
                  ></lrndesign-avatar>
                  <table slot="content">
                    <tbody>
                      <tr>
                        <th scope="row">
                          <simple-icon-lite
                            icon="assignment-turned-in"
                          ></simple-icon-lite>
                          Assignments Completed
                        </th>
                        <td>
                          ${this['profile']&&this[_0x55f79f(0x1c8)][_0x55f79f(0x1bd)]&&this[_0x55f79f(0x1c8)]['due']?this[_0x55f79f(0x1c8)][_0x55f79f(0x1bd)][_0x55f79f(0x1c3)]+_0x55f79f(0x1d7)+(this[_0x55f79f(0x1c8)][_0x55f79f(0x1bd)][_0x55f79f(0x1c3)]+this[_0x55f79f(0x1c8)][_0x55f79f(0x1b1)][_0x55f79f(0x1c3)]):_0x55f79f(0x1dc)}
                        </td>
                      </tr>
                      ${!this[_0x55f79f(0x1c8)]||(this['profile'][_0x55f79f(0x1ce)]||[])[_0x55f79f(0x1c3)]<0x1?'':a0_0x14b746`
                            <tr>
                              <th scope="row">
                                <simple-icon-lite
                                  icon="icons:favorite"
                                ></simple-icon-lite>
                                Submissions Featured
                              </th>
                              <td>
                                ${this[_0x55f79f(0x1c8)]&&this[_0x55f79f(0x1c8)][_0x55f79f(0x1ce)]?this['profile'][_0x55f79f(0x1ce)][_0x55f79f(0x1c3)]:_0x55f79f(0x1dc)}
                              </td>
                            </tr>
                          `}
                      <tr>
                        <th scope="row">
                          <simple-icon-lite
                            icon="communication:forum"
                          ></simple-icon-lite>
                          Peer Reviews Written
                          ${this[_0x55f79f(0x1c8)]&&this[_0x55f79f(0x1c8)][_0x55f79f(0x1c5)]?'\x20('+this[_0x55f79f(0x1c8)][_0x55f79f(0x1c5)][_0x55f79f(0x1c3)]+')':'\x20(0)'}
                        </th>
                        <td>
                          <div id="rating">
                            ${this[_0x55f79f(0x1c8)]['feedbackPercentile']<0x19?'':a0_0x14b746`<simple-icon
                                  icon="star"
                                  accent-color="purple"
                                ></simple-icon>`}
                            ${this[_0x55f79f(0x1c8)]['feedbackPercentile']<0x32?'':a0_0x14b746`<simple-icon
                                  icon="star"
                                  accent-color="purple"
                                ></simple-icon>`}
                            ${this[_0x55f79f(0x1c8)][_0x55f79f(0x1b8)]<0x4b?'':a0_0x14b746`<simple-icon
                                  icon="star"
                                  accent-color="purple"
                                ></simple-icon>`}
                            ${this[_0x55f79f(0x1c8)][_0x55f79f(0x1b8)]<0x5a?'':a0_0x14b746`<simple-icon
                                  icon="star"
                                  accent-color="purple"
                                ></simple-icon>`}
                            ${this[_0x55f79f(0x1c8)]['feedbackPercentile']<0x5f?'':a0_0x14b746`<simple-icon
                                  icon="star"
                                  accent-color="purple"
                                ></simple-icon>`}
                          </div>
                          <simple-tooltip
                            for="rating"
                            ?hidden="${!this[_0x55f79f(0x1c8)][_0x55f79f(0x1b8)]}"
                            >Given peer reviews than
                            ${this[_0x55f79f(0x1c8)][_0x55f79f(0x1b8)]}% of
                            classmates.</simple-tooltip
                          >
                        </td>
                      </tr>
                    </tbody>
                  </table>
                `}
          </accent-card>
          <nav-card accent-color="green" class="card primary due">
            <span slot="heading">Upcoming Assignments</span>
            <elmsln-studio-link slot="subheading" href="assignments"
              >All assignments</elmsln-studio-link
            >
            ${!this[_0x55f79f(0x1c8)]||Object['keys'](this[_0x55f79f(0x1c8)])[_0x55f79f(0x1c3)]<0x1?this[_0x55f79f(0x1bc)]('green',_0x55f79f(0x1d9)):a0_0x14b746`
                  <div slot="linklist">
                    ${(this[_0x55f79f(0x1c8)]['due']||[])['slice'](0x0,0x5)[_0x55f79f(0x1a7)](_0x1cfdbd=>a0_0x14b746`
                        <nav-card-item
                          id="due-${_0x1cfdbd['id']}-item"
                          accent-color="${this[_0x55f79f(0x1d1)](_0x1cfdbd[_0x55f79f(0x1cf)])?_0x55f79f(0x1b3):'grey'}"
                          allow-grey
                          avatar="${this[_0x55f79f(0x1d1)](_0x1cfdbd[_0x55f79f(0x1cf)])?_0x55f79f(0x1b4):'assignment'}"
                          invert
                        >
                          <elmsln-studio-link
                            id="due-${_0x1cfdbd['id']}"
                            aria-describedby="due-${_0x1cfdbd['id']}-desc"
                            slot="label"
                            href="assignments/${_0x1cfdbd['id']}"
                          >
                            ${_0x1cfdbd[_0x55f79f(0x1a1)]}
                          </elmsln-studio-link>
                          <relative-time
                            id="due-${_0x1cfdbd['id']}-desc"
                            slot="description"
                            datetime="${_0x1cfdbd[_0x55f79f(0x1cf)]}"
                          >
                            ${this[_0x55f79f(0x1d3)](_0x1cfdbd['date'],_0x55f79f(0x1aa))}
                          </relative-time>
                        </nav-card-item>
                        <simple-tooltip for="due-${_0x1cfdbd['id']}-item" position="left">
                          ${this[_0x55f79f(0x1d1)](_0x1cfdbd[_0x55f79f(0x1cf)])?_0x55f79f(0x1b6):_0x55f79f(0x1b9)}
                        </simple-tooltip>
                      `)}
                  </div>
                `}
          </nav-card>
        </div>
        <div id="work">
          <h2>Recent Work</h2>
          <nav-card
            accent-color="amber"
            class="card primary recent"
            link-icon="chevron-right"
          >
            <span slot="heading">My Submissions</span>
            <elmsln-studio-link
              slot="subheading"
              href="submissions${this[_0x55f79f(0x1c8)]?_0x55f79f(0x1a6)+this[_0x55f79f(0x1c8)]['id']:''}"
              >All my submissions</elmsln-studio-link
            >
            ${!this[_0x55f79f(0x1c8)]||Object['keys'](this[_0x55f79f(0x1c8)])[_0x55f79f(0x1c3)]<0x1?this['loading'](_0x55f79f(0x1c4),_0x55f79f(0x1d9)):a0_0x14b746` <div slot="linklist">
                  ${(this[_0x55f79f(0x1c8)][_0x55f79f(0x1a0)]||[])[_0x55f79f(0x1d2)](0x0,0x5)[_0x55f79f(0x1a7)](_0x57a0eb=>a0_0x14b746`
                      <nav-card-item
                        id="due-${_0x57a0eb['id']}-item"
                        accent-color="${this[_0x55f79f(0x1d1)](_0x57a0eb[_0x55f79f(0x1a3)],_0x57a0eb['date'])?_0x55f79f(0x1db):'green'}"
                        allow-grey
                        avatar="${this['isLate'](_0x57a0eb[_0x55f79f(0x1a3)],_0x57a0eb['date'])?_0x55f79f(0x1c1):_0x55f79f(0x1a9)}"
                        invert
                      >
                        <elmsln-studio-link
                          id="sub-${_0x57a0eb['id']}"
                          aria-describedby="sub-${_0x57a0eb['id']}-desc"
                          slot="label"
                          href="project/${_0x57a0eb[_0x55f79f(0x1c6)]}?submission=${_0x57a0eb['id']}"
                        >
                          ${_0x57a0eb[_0x55f79f(0x1a1)]}
                        </elmsln-studio-link>
                        <relative-time
                          id="sub-${_0x57a0eb['id']}-desc"
                          slot="description"
                          datetime="${_0x57a0eb[_0x55f79f(0x1cf)]}"
                        >
                          ${this[_0x55f79f(0x1d3)](_0x57a0eb[_0x55f79f(0x1cf)])}
                        </relative-time>
                      </nav-card-item>
                      <simple-tooltip for="due-${_0x57a0eb['id']}-item" position="left">
                        ${this[_0x55f79f(0x1d1)](_0x57a0eb['assignmentDate'],_0x57a0eb[_0x55f79f(0x1cf)])?_0x55f79f(0x1d5):'Submitted'}
                      </simple-tooltip>
                    `)}
                </div>`}
          </nav-card>
          <nav-card
            accent-color="cyan"
            class="card feed primary"
            link-icon="chevron-right"
          >
            <span slot="heading">Feedback for Me</span>
            ${!this[_0x55f79f(0x1c8)]||Object[_0x55f79f(0x1ba)](this[_0x55f79f(0x1c8)])['length']<0x1?this[_0x55f79f(0x1bc)]('cyan',_0x55f79f(0x1d9)):a0_0x14b746` <div slot="linklist">
                  ${(this['profile'][_0x55f79f(0x1ad)]||[])['slice'](0x0,0x5)[_0x55f79f(0x1a7)](_0x6ed575=>a0_0x14b746`
                      <nav-card-item
                        accent-color="${this['accentColor']([_0x6ed575[_0x55f79f(0x1da)],_0x6ed575[_0x55f79f(0x1ae)]]['join']('\x20'))}"
                        .avatar="${_0x6ed575[_0x55f79f(0x1dd)]}"
                        .initials="${[_0x6ed575['firstName'],_0x6ed575['lastName']][_0x55f79f(0x19f)]('\x20')}"
                      >
                        <elmsln-studio-link
                          id="feed-${_0x6ed575['id']}"
                          aria-describedby="feed-${_0x6ed575['id']}-desc"
                          slot="label"
                          href="project/${_0x6ed575[_0x55f79f(0x1c6)]}?submission=${_0x6ed575['submissionId']}&comment=${_0x6ed575['id']}"
                        >
                          ${[_0x6ed575[_0x55f79f(0x1da)],_0x6ed575[_0x55f79f(0x1ae)]][_0x55f79f(0x19f)]('\x20')}'s feedback on
                          ${_0x6ed575[_0x55f79f(0x1a1)]}
                        </elmsln-studio-link>
                        <relative-time
                          id="feed-${_0x6ed575['id']}-desc"
                          slot="description"
                          datetime="${_0x6ed575[_0x55f79f(0x1cf)]}"
                        >
                          ${this[_0x55f79f(0x1d3)](_0x6ed575[_0x55f79f(0x1cf)])}
                        </relative-time>
                      </nav-card-item>
                    `)}
                </div>`}
          </nav-card>
        </div>
      </div>
      <div id="secondary">
        <h2 slot="heading">Class Activity</h2>
        <accent-card accent-color="pink" class="card feed secondary">
          <nav-card flat no-border slot="content">
            <span slot="heading">Recent Submissions</span>
            <elmsln-studio-link slot="subheading" href="submissions"
              >All submissions</elmsln-studio-link
            >
            ${this['submissions']?a0_0x14b746` <div slot="linklist">
                  ${(this['submissions']||[])[_0x55f79f(0x1a7)](_0x268593=>a0_0x14b746`
                      <nav-card-item
                        accent-color="${this['accentColor']([_0x268593['firstName'],_0x268593[_0x55f79f(0x1ae)]][_0x55f79f(0x19f)]('\x20'))}"
                        .avatar="${_0x268593['avatar']}"
                        .initials="${[_0x268593[_0x55f79f(0x1da)],_0x268593[_0x55f79f(0x1ae)]]['join']('\x20')}"
                      >
                        <elmsln-studio-link
                          id="act-${_0x268593['id']}"
                          aria-describedby="act-${_0x268593['id']}-desc"
                          slot="label"
                          href="${this['getActivityLink'](_0x268593)}"
                        >
                          ${this['getActivityTitle'](_0x268593)}
                        </elmsln-studio-link>
                        <relative-time
                          id="act-${_0x268593['id']}-desc"
                          slot="description"
                          datetime="${_0x268593[_0x55f79f(0x1cf)]}"
                        >
                          ${this[_0x55f79f(0x1d3)](_0x268593[_0x55f79f(0x1cf)])}
                        </relative-time>
                      </nav-card-item>
                    `)}
                </div>`:this[_0x55f79f(0x1bc)](_0x55f79f(0x1be),_0x55f79f(0x1cb))}
          </nav-card>
          <nav-card flat no-border slot="content">
            <span slot="heading">Recent Comments</span>
            ${this['discussion']?a0_0x14b746`
                  <div slot="linklist">
                    ${(this['discussion']||[])['map'](_0x2727bd=>a0_0x14b746`
                        <nav-card-item
                          accent-color="${this[_0x55f79f(0x1b2)]([_0x2727bd['firstName'],_0x2727bd['lastName']][_0x55f79f(0x19f)]('\x20'))}"
                          .avatar="${_0x2727bd[_0x55f79f(0x1dd)]}"
                          .initials="${[_0x2727bd[_0x55f79f(0x1da)],_0x2727bd[_0x55f79f(0x1ae)]][_0x55f79f(0x19f)]('\x20')}"
                        >
                          <elmsln-studio-link
                            id="act-${_0x2727bd['id']}"
                            aria-describedby="act-${_0x2727bd['id']}-desc"
                            slot="label"
                            href="${this[_0x55f79f(0x1c7)](_0x2727bd)}"
                          >
                            ${this[_0x55f79f(0x1ab)](_0x2727bd)}
                          </elmsln-studio-link>
                          <relative-time
                            id="act-${_0x2727bd['id']}-desc"
                            slot="description"
                            datetime="${_0x2727bd[_0x55f79f(0x1cf)]}"
                          >
                            ${this['dateFormat'](_0x2727bd[_0x55f79f(0x1cf)])}
                          </relative-time>
                        </nav-card-item>
                      `)}
                  </div>
                `:this['loading'](_0x55f79f(0x1be),_0x55f79f(0x1cb))}
          </nav-card>
        </accent-card>
      </div>
    `;}static get[a0_0x52a4a8(0x1b0)](){var _0xbd914c=a0_0x52a4a8;return{...super[_0xbd914c(0x1b0)],'discussion':{'type':Array},'profile':{'type':Object},'submissions':{'type':Array}};}constructor(){var _0x41aa71=a0_0x52a4a8;super(),this[_0x41aa71(0x1c8)]={};}[a0_0x52a4a8(0x1b5)](_0x5085ee){var _0x371db7=a0_0x52a4a8;super['firstUpdated']&&super[_0x371db7(0x1b5)](_0x5085ee),this[_0x371db7(0x1ca)](_0x371db7(0x1c8)),this[_0x371db7(0x1ca)](_0x371db7(0x1a0));}get[a0_0x52a4a8(0x1cc)](){var _0x59e2dd=a0_0x52a4a8;return this[_0x59e2dd(0x1c8)]&&this['profile'][_0x59e2dd(0x1da)]&&this[_0x59e2dd(0x1c8)][_0x59e2dd(0x1ae)]?this[_0x59e2dd(0x1c8)]['firstName']+'\x20'+this[_0x59e2dd(0x1c8)][_0x59e2dd(0x1ae)]:'';}}customElements[a0_0x52a4a8(0x1bf)](ElmslnStudioDashboard[a0_0x52a4a8(0x1c2)],ElmslnStudioDashboard);export{ElmslnStudioDashboard};