/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x5681(_0x1da38c,_0x40581e){var _0x21cfc1=a0_0x21cf();return a0_0x5681=function(_0x568182,_0x4c1348){_0x568182=_0x568182-0xa4;var _0x178af4=_0x21cfc1[_0x568182];return _0x178af4;},a0_0x5681(_0x1da38c,_0x40581e);}var a0_0x29dddb=a0_0x5681;(function(_0x34dbd8,_0x470ac5){var _0x32aabf=a0_0x5681,_0x4cc713=_0x34dbd8();while(!![]){try{var _0x279004=-parseInt(_0x32aabf(0xaf))/0x1*(parseInt(_0x32aabf(0xb0))/0x2)+parseInt(_0x32aabf(0xab))/0x3+-parseInt(_0x32aabf(0xa4))/0x4+-parseInt(_0x32aabf(0xa8))/0x5*(parseInt(_0x32aabf(0xaa))/0x6)+parseInt(_0x32aabf(0xa5))/0x7*(parseInt(_0x32aabf(0xa9))/0x8)+-parseInt(_0x32aabf(0xb2))/0x9+parseInt(_0x32aabf(0xad))/0xa;if(_0x279004===_0x470ac5)break;else _0x4cc713['push'](_0x4cc713['shift']());}catch(_0x3f654c){_0x4cc713['push'](_0x4cc713['shift']());}}}(a0_0x21cf,0x2abe6));function a0_0x21cf(){var _0x4d375d=['2222937xjxGGR','1080508HKpVBn','14EhTLCp','Character\x20Count:\x20%d','log','126695LJShPU','664304hirzTE','42AnLaCx','487482rmBQkn','./../','5579200mgynie','length','1wrKqIO','33838AnpBAW','SPAM_ASSASSIN'];a0_0x21cf=function(){return _0x4d375d;};return a0_0x21cf();}var corpus=require(a0_0x29dddb(0xac))[a0_0x29dddb(0xb1)],data,i;data=corpus();for(i=0x0;i<data[a0_0x29dddb(0xae)];i++){console[a0_0x29dddb(0xa7)](a0_0x29dddb(0xa6),data[i]['text']['length']);}