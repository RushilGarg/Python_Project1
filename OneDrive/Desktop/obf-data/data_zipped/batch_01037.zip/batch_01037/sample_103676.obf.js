'use strict';const a0_0x3d74c6=a0_0x1cd0;function a0_0x2ffe(){const _0x514950=['returns\x20null\x20when\x20cloning\x20without\x20children','toEqual','clone','toBe','is\x20not\x20a\x20ref\x20query\x20dependency','returns\x20metadata','1267992RpHmWf','RelayQueryFragment','returns\x20directives','clones\x20with\x20updated\x20children','14AdbzGo','39391uobQmC','configureForRelayOSS','returns\x20the\x20source\x20composite\x20hash\x20for\x20cloned\x20fragments','getDebugName','2835GQiGcy','does\x20not\x20equal\x20equivalent\x20fragments\x20with\x20a\x20different\x20structure','canHaveSubselections()','variables\x20argument\x20of\x20@relay\x20directive','getVariables','maps\x20listed\x20variables','getDirectives','equals\x20fragments\x20with\x20the\x20same\x20structure','returns\x20children','createNode','canHaveSubselections','9840280ctZiQF','174919UYJEKd','returns\x20true','equals','getCompositeHash','RelayQueryFragmentRelayQL','include','2247364yhlwbv','city','3YkmbFq','RelayTestUtils','getSchemaName','country','3138UHCfMB','length','RelayClassic_DEPRECATED','is\x20not\x20generated','equals\x20fragments\x20with\x20different\x20names','filters\x20non-listed\x20variables','getSourceCompositeHash','Fragment','isGenerated','matchers','5617915mtRNeR','getType','does\x20not\x20equal\x20different\x20fragment','getChildren','getRoute','../RelayQuery','isRefQueryDependency','330FmWAAB'];a0_0x2ffe=function(){return _0x514950;};return a0_0x2ffe();}(function(_0x132414,_0x37ea52){const _0x504676=a0_0x1cd0,_0x557d2c=_0x132414();while(!![]){try{const _0x2ef55e=parseInt(_0x504676(0x133))/0x1*(parseInt(_0x504676(0x122))/0x2)+-parseInt(_0x504676(0x13b))/0x3*(parseInt(_0x504676(0x139))/0x4)+-parseInt(_0x504676(0x110))/0x5+-parseInt(_0x504676(0x13f))/0x6*(-parseInt(_0x504676(0x127))/0x7)+parseInt(_0x504676(0x132))/0x8+-parseInt(_0x504676(0x11e))/0x9+parseInt(_0x504676(0x117))/0xa*(-parseInt(_0x504676(0x123))/0xb);if(_0x2ef55e===_0x37ea52)break;else _0x557d2c['push'](_0x557d2c['shift']());}catch(_0x27598b){_0x557d2c['push'](_0x557d2c['shift']());}}}(a0_0x2ffe,0xb0386));function a0_0x1cd0(_0x35b379,_0x3dfd31){const _0x2ffe29=a0_0x2ffe();return a0_0x1cd0=function(_0x1cd013,_0x124bf4){_0x1cd013=_0x1cd013-0x10f;let _0x53fdf3=_0x2ffe29[_0x1cd013];return _0x53fdf3;},a0_0x1cd0(_0x35b379,_0x3dfd31);}require(a0_0x3d74c6(0x124));const RelayClassic_DEPRECATED=require(a0_0x3d74c6(0x141)),RelayQuery=require(a0_0x3d74c6(0x115)),RelayTestUtils=require(a0_0x3d74c6(0x13c));describe(a0_0x3d74c6(0x11f),()=>{const _0x4fee72=a0_0x3d74c6,{getNode:_0x50538a}=RelayTestUtils;let _0x1656a0;beforeEach(()=>{const _0x4ab2d7=a0_0x1cd0;jest['resetModules'](),expect['extend'](RelayTestUtils[_0x4ab2d7(0x10f)]);const _0x48b233=RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        city
      }
    `,_0x1edf38=RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
        ${_0x48b233}
      }
    `;_0x1656a0=_0x50538a(_0x1edf38);}),it('does\x20not\x20equal\x20non-fragments',()=>{const _0xf0a9d6=a0_0x1cd0,_0x4ebb4a=_0x50538a(RelayClassic_DEPRECATED['QL']`
      query {
        me {
          firstName
        }
      }
    `),_0x532f28=_0x4ebb4a[_0xf0a9d6(0x113)]()[0x0];expect(_0x1656a0[_0xf0a9d6(0x135)](_0x4ebb4a))[_0xf0a9d6(0x11b)](![]),expect(_0x1656a0[_0xf0a9d6(0x135)](_0x532f28))[_0xf0a9d6(0x11b)](![]);}),it(_0x4fee72(0x112),()=>{const _0x200218=_0x4fee72,_0x4b2a15=_0x50538a(RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
      }
    `);expect(_0x1656a0[_0x200218(0x135)](_0x4b2a15))[_0x200218(0x11b)](![]),expect(_0x4b2a15[_0x200218(0x135)](_0x1656a0))[_0x200218(0x11b)](![]);}),it('does\x20not\x20return\x20a\x20source\x20composite\x20hash\x20for\x20un-cloned\x20fragments',()=>{const _0x36a953=_0x4fee72;expect(_0x1656a0[_0x36a953(0x145)]())[_0x36a953(0x11b)](null);}),it(_0x4fee72(0x128),()=>{const _0x8ad687=_0x4fee72;expect(_0x1656a0[_0x8ad687(0x135)](_0x1656a0))[_0x8ad687(0x11b)](!![]);const _0xdd66e9=RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
      }
    `,_0x46f49=_0x50538a(RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        city
        ${_0xdd66e9}
      }
    `);expect(_0x1656a0[_0x8ad687(0x135)](_0x46f49))[_0x8ad687(0x11b)](![]),expect(_0x46f49[_0x8ad687(0x135)](_0x1656a0))[_0x8ad687(0x11b)](![]);}),it(_0x4fee72(0x12e),()=>{const _0x12d277=_0x4fee72;expect(_0x1656a0['equals'](_0x1656a0))[_0x12d277(0x11b)](!![]);const _0x503aa0=RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        city
      }
    `,_0x1440e1=_0x50538a(RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
        ${_0x503aa0}
      }
    `);expect(_0x1656a0[_0x12d277(0x135)](_0x1440e1))['toBe'](!![]),expect(_0x1440e1[_0x12d277(0x135)](_0x1656a0))[_0x12d277(0x11b)](!![]);}),it(_0x4fee72(0x143),()=>{const _0x10ac0b=_0x4fee72,_0x1f4cd8=_0x50538a(RelayClassic_DEPRECATED['QL']`fragment on Node { id }`),_0x2dd3e7=_0x50538a(RelayClassic_DEPRECATED['QL']`fragment on Node { id }`);expect(_0x1f4cd8[_0x10ac0b(0x135)](_0x2dd3e7))['toBe'](!![]),expect(_0x2dd3e7[_0x10ac0b(0x135)](_0x1f4cd8))['toBe'](!![]);}),it(_0x4fee72(0x11d),()=>{const _0x2b2c10=_0x4fee72,_0x123610=RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
      }
    `;_0x1656a0=_0x50538a(_0x123610),expect(_0x1656a0['getDebugName']())[_0x2b2c10(0x11b)]('RelayQueryFragmentRelayQL'),expect(_0x1656a0['getType']())[_0x2b2c10(0x11b)]('StreetAddress');}),it(_0x4fee72(0x12f),()=>{const _0x52b3da=_0x4fee72,_0x39b69c=_0x1656a0[_0x52b3da(0x113)]();expect(_0x39b69c[_0x52b3da(0x140)])[_0x52b3da(0x11b)](0x2),expect(_0x39b69c[0x0][_0x52b3da(0x13d)]())[_0x52b3da(0x11b)]('country'),expect(_0x39b69c[0x1][_0x52b3da(0x126)]())['toBe'](_0x52b3da(0x137));}),it('returns\x20same\x20object\x20when\x20cloning\x20with\x20same\x20children',()=>{const _0x798091=_0x4fee72,_0xe30ec1=_0x1656a0['getChildren']();expect(_0x1656a0[_0x798091(0x11a)](_0xe30ec1))['toBe'](_0x1656a0),expect(_0x1656a0[_0x798091(0x11a)](_0xe30ec1['map'](_0x4773bf=>_0x4773bf)))[_0x798091(0x11b)](_0x1656a0);}),it(_0x4fee72(0x125),()=>{const _0x2bf9c1=_0x4fee72,_0x2b2fee=_0x50538a(RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
        city
      }
    `),_0x520fb4=_0x1656a0['clone']([_0x2b2fee[_0x2bf9c1(0x113)]()[0x0]]);expect(_0x520fb4[_0x2bf9c1(0x145)]())[_0x2bf9c1(0x11b)](_0x1656a0[_0x2bf9c1(0x136)]());}),it(_0x4fee72(0x118),()=>{const _0x43ccc0=_0x4fee72;expect(_0x1656a0['clone']([]))[_0x43ccc0(0x11b)](null),expect(_0x1656a0[_0x43ccc0(0x11a)]([null]))[_0x43ccc0(0x11b)](null);}),it(_0x4fee72(0x121),()=>{const _0x5ad505=_0x4fee72,_0x2798dc=_0x50538a(RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        country
        city
      }
    `),_0x2a98e1=_0x1656a0[_0x5ad505(0x11a)]([_0x2798dc[_0x5ad505(0x113)]()[0x0]]);expect(_0x2a98e1[_0x5ad505(0x113)]()[_0x5ad505(0x140)])[_0x5ad505(0x11b)](0x1),expect(_0x2a98e1[_0x5ad505(0x113)]()[0x0][_0x5ad505(0x13d)]())['toBe'](_0x5ad505(0x13e)),expect(_0x2a98e1['getFieldByStorageKey'](_0x5ad505(0x13a)))[_0x5ad505(0x11b)](undefined);}),it(_0x4fee72(0x11c),()=>{const _0x49a634=_0x4fee72;expect(_0x1656a0[_0x49a634(0x116)]())[_0x49a634(0x11b)](![]);}),it(_0x4fee72(0x142),()=>{const _0x37313e=_0x4fee72;expect(_0x1656a0[_0x37313e(0x147)]())[_0x37313e(0x11b)](![]);}),it('creates\x20nodes',()=>{const _0x17d13a=_0x4fee72,_0x236323=RelayClassic_DEPRECATED['QL']`
      fragment on StreetAddress {
        city
      }
    `;_0x1656a0=_0x50538a(_0x236323);const _0x4bb987=_0x1656a0[_0x17d13a(0x130)](_0x236323);expect(_0x4bb987 instanceof RelayQuery[_0x17d13a(0x146)])['toBe'](!![]),expect(_0x4bb987[_0x17d13a(0x111)]())[_0x17d13a(0x11b)]('StreetAddress'),expect(_0x4bb987['getRoute']())[_0x17d13a(0x11b)](_0x1656a0[_0x17d13a(0x114)]()),expect(_0x4bb987['getVariables']())[_0x17d13a(0x11b)](_0x1656a0[_0x17d13a(0x12b)]());}),it(_0x4fee72(0x120),()=>{const _0x5da9de=_0x4fee72;_0x1656a0=_0x50538a(RelayClassic_DEPRECATED['QL']`
      fragment on Story @include(if: $cond) {
        feedback
      }
    `,{'cond':!![]}),expect(_0x1656a0[_0x5da9de(0x12d)]())['toEqual']([{'args':[{'name':'if','value':!![]}],'name':_0x5da9de(0x138)}]);}),describe(_0x4fee72(0x129),()=>{const _0x296e5c=_0x4fee72;it(_0x296e5c(0x134),()=>{const _0x3de82b=_0x296e5c;expect(_0x1656a0[_0x3de82b(0x131)]())[_0x3de82b(0x11b)](!![]),expect(_0x50538a(RelayClassic_DEPRECATED['QL']`fragment on Viewer { ${null} }`)[_0x3de82b(0x131)]())[_0x3de82b(0x11b)](!![]);});}),describe(_0x4fee72(0x12a),()=>{const _0x1f6167=_0x4fee72;it(_0x1f6167(0x12c),()=>{const _0x4d17c6=_0x1f6167,_0x3b0385=_0x50538a(RelayClassic_DEPRECATED['QL']`
        fragment on User {
          ... on User @relay(variables: ["inner"]) {
            profilePicture(size: $inner)
          }
        }
      `,{'inner':0x64}),_0x3ee77c=_0x3b0385['getChildren']()[0x1];expect(_0x3ee77c instanceof RelayQuery[_0x4d17c6(0x146)])[_0x4d17c6(0x11b)](!![]),expect(_0x3ee77c[_0x4d17c6(0x12b)]())['toEqual']({'inner':0x64});}),it(_0x1f6167(0x144),()=>{const _0x2ce1b6=_0x1f6167,_0x40ddba=_0x50538a(RelayClassic_DEPRECATED['QL']`
        fragment on User {
          ... on User @relay(variables: []) {
            profilePicture(size: $inner)
          }
        }
      `,{'inner':0x64}),_0x40d938=_0x40ddba[_0x2ce1b6(0x113)]()[0x1];expect(_0x40d938 instanceof RelayQuery[_0x2ce1b6(0x146)])[_0x2ce1b6(0x11b)](!![]),expect(_0x40d938['getVariables']())[_0x2ce1b6(0x119)]({});});});});