/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4ef777=a0_0x1e66;function a0_0x39d4(){var _0x4f0299=['@stdlib/stats/base/dists/degenerate/cdf','exports','4398670QAaLSp','6586iObYtu','@stdlib/math/base/assert/is-nan','975JIrmJU','2068520tAKRRH','508354QYqJRu','824274zlNVml','1337192qPEEPl','21738ydCqWE','@stdlib/math/base/special/floor','5ZVFAQR','161peYPPL','9WdOLZC','factory'];a0_0x39d4=function(){return _0x4f0299;};return a0_0x39d4();}(function(_0x15d5a7,_0x14f88b){var _0x40757d=a0_0x1e66,_0x24860d=_0x15d5a7();while(!![]){try{var _0x234678=parseInt(_0x40757d(0xa0))/0x1+-parseInt(_0x40757d(0xab))/0x2*(-parseInt(_0x40757d(0x9d))/0x3)+-parseInt(_0x40757d(0xa1))/0x4*(parseInt(_0x40757d(0xa4))/0x5)+-parseInt(_0x40757d(0xa2))/0x6*(parseInt(_0x40757d(0xa5))/0x7)+-parseInt(_0x40757d(0x9e))/0x8+parseInt(_0x40757d(0xa6))/0x9*(-parseInt(_0x40757d(0xaa))/0xa)+-parseInt(_0x40757d(0x9f))/0xb;if(_0x234678===_0x14f88b)break;else _0x24860d['push'](_0x24860d['shift']());}catch(_0x6c0178){_0x24860d['push'](_0x24860d['shift']());}}}(a0_0x39d4,0xb2c42));function a0_0x1e66(_0x2b6759,_0x4aa047){var _0x39d48b=a0_0x39d4();return a0_0x1e66=function(_0x1e6665,_0x7a12b0){_0x1e6665=_0x1e6665-0x9c;var _0x1f50ae=_0x39d48b[_0x1e6665];return _0x1f50ae;},a0_0x1e66(_0x2b6759,_0x4aa047);}var constantFunction=require('@stdlib/utils/constant-function'),degenerate=require(a0_0x4ef777(0xa8))[a0_0x4ef777(0xa7)],gammainc=require('@stdlib/math/base/special/gammainc'),isnan=require(a0_0x4ef777(0x9c)),floor=require(a0_0x4ef777(0xa3)),PINF=require('@stdlib/constants/float64/pinf');function factory(_0x491bf8){if(isnan(_0x491bf8)||_0x491bf8<0x0)return constantFunction(NaN);if(_0x491bf8===0x0)return degenerate(0x0);return _0x335f70;function _0x335f70(_0x394375){if(isnan(_0x394375))return NaN;if(_0x394375<0x0)return 0x0;if(_0x394375===PINF)return 0x1;return gammainc(_0x491bf8,floor(_0x394375)+0x1,!![],!![]);}}module[a0_0x4ef777(0xa9)]=factory;