/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xdc9542=a0_0x39a1;function a0_0x39a1(_0x447261,_0x5389da){var _0x448b39=a0_0x448b();return a0_0x39a1=function(_0x39a128,_0x76ccd2){_0x39a128=_0x39a128-0x112;var _0x4383a0=_0x448b39[_0x39a128];return _0x4383a0;},a0_0x39a1(_0x447261,_0x5389da);}(function(_0x3953f2,_0xad3ed1){var _0x2c90f5=a0_0x39a1,_0x32ca56=_0x3953f2();while(!![]){try{var _0x2f0d6d=parseInt(_0x2c90f5(0x11a))/0x1*(-parseInt(_0x2c90f5(0x117))/0x2)+parseInt(_0x2c90f5(0x114))/0x3*(parseInt(_0x2c90f5(0x118))/0x4)+-parseInt(_0x2c90f5(0x112))/0x5*(parseInt(_0x2c90f5(0x119))/0x6)+-parseInt(_0x2c90f5(0x113))/0x7+-parseInt(_0x2c90f5(0x116))/0x8+parseInt(_0x2c90f5(0x11d))/0x9+parseInt(_0x2c90f5(0x115))/0xa;if(_0x2f0d6d===_0xad3ed1)break;else _0x32ca56['push'](_0x32ca56['shift']());}catch(_0x5d92e8){_0x32ca56['push'](_0x32ca56['shift']());}}}(a0_0x448b,0x6f57b));var UINT32_NUM_BYTES=require(a0_0xdc9542(0x11c));console[a0_0xdc9542(0x11b)](UINT32_NUM_BYTES);function a0_0x448b(){var _0x16903d=['122596VRrXqS','25612WYWOwJ','7194VCrPVd','7ImxmEQ','log','./../lib','5811066avXEJR','3285cbCVMj','1219981qxGPYJ','426HXAVgS','4255680DmXVYw','1066376JbfXsZ'];a0_0x448b=function(){return _0x16903d;};return a0_0x448b();}