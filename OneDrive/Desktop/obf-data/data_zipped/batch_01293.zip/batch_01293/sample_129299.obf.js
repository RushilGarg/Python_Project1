var a0_0x443459=a0_0x1219;(function(_0x5e3ccc,_0x369593){var _0x5707c9=a0_0x1219,_0x145770=_0x5e3ccc();while(!![]){try{var _0x1b2210=-parseInt(_0x5707c9(0x128))/0x1*(-parseInt(_0x5707c9(0x127))/0x2)+-parseInt(_0x5707c9(0x12b))/0x3+parseInt(_0x5707c9(0x122))/0x4*(-parseInt(_0x5707c9(0x120))/0x5)+parseInt(_0x5707c9(0x123))/0x6*(parseInt(_0x5707c9(0x12d))/0x7)+parseInt(_0x5707c9(0x12c))/0x8*(parseInt(_0x5707c9(0x121))/0x9)+parseInt(_0x5707c9(0x126))/0xa*(parseInt(_0x5707c9(0x12a))/0xb)+-parseInt(_0x5707c9(0x124))/0xc;if(_0x1b2210===_0x369593)break;else _0x145770['push'](_0x145770['shift']());}catch(_0x47f81d){_0x145770['push'](_0x145770['shift']());}}}(a0_0x5896,0xe815a));import a0_0x4b0b4e,{css}from'styled-components';function a0_0x5896(){var _0x2ca72e=['42BBVeen','26487324OHFTiM','phone','109160kdyPDC','15898cmfYFP','83kUVxUh','footer','1232KWGYQh','1952652JHyRlI','2348216eMuJer','1888537ixLoGt','5tnUdZz','27rwUYZM','3370792oBieFI'];a0_0x5896=function(){return _0x2ca72e;};return a0_0x5896();}function a0_0x1219(_0xf3f2ba,_0x21e7a8){var _0x589613=a0_0x5896();return a0_0x1219=function(_0x12190b,_0x267771){_0x12190b=_0x12190b-0x120;var _0x781d2=_0x589613[_0x12190b];return _0x781d2;},a0_0x1219(_0xf3f2ba,_0x21e7a8);}import{rhythm}from'../utils/typography';import a0_0x8540cb from'../utils/media';export default a0_0x4b0b4e[a0_0x443459(0x129)]`
  position: fixed;
  bottom: 0;
  left: 0;
  width: 100vw;
  background-color: #242629;
  height: ${rhythm(0x3)};
  display: grid;
  grid-template-columns:
    [edge-start] minmax(1rem, 1fr) [content-start] repeat(
      12,
      minmax(1rem, 5.20833rem)
    )
    [content-end] minmax(1rem, 1fr) [edge-end];
  grid-column-gap: 0.75%;
  padding: 0;
  align-items: center;

  ${a0_0x8540cb[a0_0x443459(0x125)](css`
    height: 3rem;
    font-size: 10px;
    pre {
      font-size: 10px;
    }
  `)}
`;