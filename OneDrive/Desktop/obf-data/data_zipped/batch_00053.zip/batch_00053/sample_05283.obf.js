/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x40af(_0xf59aa,_0x333dbe){var _0x90f014=a0_0x90f0();return a0_0x40af=function(_0x40afb7,_0x3cb135){_0x40afb7=_0x40afb7-0x132;var _0x5651ea=_0x90f014[_0x40afb7];return _0x5651ea;},a0_0x40af(_0xf59aa,_0x333dbe);}var a0_0x3a3c53=a0_0x40af;(function(_0x2738ba,_0x42040d){var _0x277c49=a0_0x40af,_0x1c2f0a=_0x2738ba();while(!![]){try{var _0x2c00da=-parseInt(_0x277c49(0x134))/0x1+parseInt(_0x277c49(0x140))/0x2*(parseInt(_0x277c49(0x13a))/0x3)+parseInt(_0x277c49(0x13b))/0x4*(-parseInt(_0x277c49(0x143))/0x5)+parseInt(_0x277c49(0x144))/0x6+-parseInt(_0x277c49(0x142))/0x7+-parseInt(_0x277c49(0x132))/0x8+parseInt(_0x277c49(0x138))/0x9;if(_0x2c00da===_0x42040d)break;else _0x1c2f0a['push'](_0x1c2f0a['shift']());}catch(_0x4bdae9){_0x1c2f0a['push'](_0x1c2f0a['shift']());}}}(a0_0x90f0,0x818a6));function a0_0x90f0(){var _0x544329=['resolve','@stdlib/utils/copy','6926337nzcilk','path','22422eztydD','4xgYHsq','dir','@stdlib/process/cwd','./lint.js','./validate.js','156eawUmy','length','3117044vfRyyF','908850rrkVQt','395970HfCYSk','./ignore_patterns.json','./defaults.json','1546680jChKxy','exports','67565FZCRNG','glob'];a0_0x90f0=function(){return _0x544329;};return a0_0x90f0();}var resolve=require(a0_0x3a3c53(0x139))[a0_0x3a3c53(0x136)],glob=require(a0_0x3a3c53(0x135))['sync'],cwd=require(a0_0x3a3c53(0x13d)),copy=require(a0_0x3a3c53(0x137)),DEFAULTS=require(a0_0x3a3c53(0x146)),validate=require(a0_0x3a3c53(0x13f)),linter=require(a0_0x3a3c53(0x13e)),IGNORE=require(a0_0x3a3c53(0x145));function lint(_0x51b86d){var _0x13db41=a0_0x3a3c53,_0x25e67d,_0x43609f,_0x8ea360,_0x375b10,_0x3211d3;_0x8ea360=copy(DEFAULTS);if(arguments[_0x13db41(0x141)]){_0x375b10=validate(_0x8ea360,_0x51b86d);if(_0x375b10)throw _0x375b10;}return _0x8ea360['dir']?_0x3211d3=resolve(cwd(),_0x8ea360[_0x13db41(0x13c)]):_0x3211d3=cwd(),_0x25e67d=_0x8ea360['pattern'],_0x8ea360={'cwd':_0x3211d3,'ignore':IGNORE,'nodir':!![]},_0x43609f=glob(_0x25e67d,_0x8ea360),linter(_0x43609f);}module[a0_0x3a3c53(0x133)]=lint;