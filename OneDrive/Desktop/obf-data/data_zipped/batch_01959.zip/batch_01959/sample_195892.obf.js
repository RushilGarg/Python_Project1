/**
* @license Apache-2.0
*
* Copyright (c) 2021 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x27497e=a0_0x37f3;function a0_0x337b(){var _0x14f2ec=['prototype','52436jPATBw','6290508lKKgrq','exports','notify','8662716xDhGJq','808BsUQjZ','13cTYAyu','44104810lhAsLL','4325775WoDGQB','@stdlib/utils/define-nonenumerable-read-only-property','141cApHfE','240134PTEOek','@stdlib/utils/noop','106211Umjgea'];a0_0x337b=function(){return _0x14f2ec;};return a0_0x337b();}(function(_0x155181,_0x3e8c53){var _0x29f3ec=a0_0x37f3,_0x243fab=_0x155181();while(!![]){try{var _0x741d6=-parseInt(_0x29f3ec(0xee))/0x1*(parseInt(_0x29f3ec(0xf3))/0x2)+parseInt(_0x29f3ec(0xf2))/0x3*(parseInt(_0x29f3ec(0xf7))/0x4)+-parseInt(_0x29f3ec(0xf0))/0x5+-parseInt(_0x29f3ec(0xf8))/0x6+-parseInt(_0x29f3ec(0xf5))/0x7*(parseInt(_0x29f3ec(0xfc))/0x8)+parseInt(_0x29f3ec(0xfb))/0x9+parseInt(_0x29f3ec(0xef))/0xa;if(_0x741d6===_0x3e8c53)break;else _0x243fab['push'](_0x243fab['shift']());}catch(_0x4eaff3){_0x243fab['push'](_0x243fab['shift']());}}}(a0_0x337b,0xefcc3));var setReadOnly=require(a0_0x27497e(0xf1)),noop=require(a0_0x27497e(0xf4));function Notifier(){if(!(this instanceof Notifier))return new Notifier();return this;}function a0_0x37f3(_0x5a2a68,_0x3268ee){var _0x337b08=a0_0x337b();return a0_0x37f3=function(_0x37f338,_0x17dc8d){_0x37f338=_0x37f338-0xee;var _0x3f1ada=_0x337b08[_0x37f338];return _0x3f1ada;},a0_0x37f3(_0x5a2a68,_0x3268ee);}setReadOnly(Notifier[a0_0x27497e(0xf6)],a0_0x27497e(0xfa),noop),module[a0_0x27497e(0xf9)]=Notifier;