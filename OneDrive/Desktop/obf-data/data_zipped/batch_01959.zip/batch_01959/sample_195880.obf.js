/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x42ccde=a0_0x1160;(function(_0xf83f5f,_0x475445){var _0x53bb56=a0_0x1160,_0x375d21=_0xf83f5f();while(!![]){try{var _0x4eb650=-parseInt(_0x53bb56(0x146))/0x1*(parseInt(_0x53bb56(0x152))/0x2)+-parseInt(_0x53bb56(0x14a))/0x3+parseInt(_0x53bb56(0x141))/0x4+parseInt(_0x53bb56(0x144))/0x5*(parseInt(_0x53bb56(0x153))/0x6)+parseInt(_0x53bb56(0x142))/0x7+-parseInt(_0x53bb56(0x14b))/0x8+parseInt(_0x53bb56(0x14f))/0x9;if(_0x4eb650===_0x475445)break;else _0x375d21['push'](_0x375d21['shift']());}catch(_0x30d5ff){_0x375d21['push'](_0x375d21['shift']());}}}(a0_0x4d71,0xae718));var logger=require(a0_0x42ccde(0x150)),objectKeys=require(a0_0x42ccde(0x143)),hasOwnProp=require(a0_0x42ccde(0x14d)),pkg2alias=require(a0_0x42ccde(0x147)),debug=logger(a0_0x42ccde(0x14e));function a0_0x1160(_0x28fa02,_0x2f75b7){var _0x4d71d1=a0_0x4d71();return a0_0x1160=function(_0x116014,_0x5571b2){_0x116014=_0x116014-0x141;var _0x59d76d=_0x4d71d1[_0x116014];return _0x59d76d;},a0_0x1160(_0x28fa02,_0x2f75b7);}function toFlat(_0x5c770e){var _0x182a61=a0_0x42ccde,_0x3b5d03,_0x2478b1,_0x3079ec,_0x1f4dfd,_0x346598,_0x2b8f4f;_0x2478b1={};for(_0x2b8f4f=0x0;_0x2b8f4f<_0x5c770e[_0x182a61(0x14c)];_0x2b8f4f++){_0x346598=_0x5c770e[_0x2b8f4f],debug(_0x182a61(0x149),_0x346598),_0x1f4dfd=pkg2alias(_0x346598),hasOwnProp(_0x2478b1,_0x1f4dfd)&&debug(_0x182a61(0x151),_0x1f4dfd),debug(_0x182a61(0x148),_0x346598,_0x1f4dfd),_0x2478b1[_0x1f4dfd]=_0x346598;}_0x3b5d03=objectKeys(_0x2478b1),_0x3079ec=new Array(_0x3b5d03[_0x182a61(0x14c)]);for(_0x2b8f4f=0x0;_0x2b8f4f<_0x3b5d03['length'];_0x2b8f4f++){_0x1f4dfd=_0x3b5d03[_0x2b8f4f],_0x3079ec[_0x2b8f4f]=[_0x1f4dfd,_0x2478b1[_0x1f4dfd]];}return _0x3079ec;}module[a0_0x42ccde(0x145)]=toFlat;function a0_0x4d71(){var _0x5b2385=['bundle-pkg-list:to-flat-namespace','7455915KNCYDq','debug','WARNING:\x20found\x20a\x20duplicate\x20key:\x20%s.\x20Overriding\x20currently\x20assigned\x20alias.','50814TbhLIa','3354810IjURPJ','2403648lnyjLR','6860056PMqtol','@stdlib/utils/keys','5mngImq','exports','48lJorIV','./pkg_to_alias.js','Mapping\x20package\x20%s\x20to\x20alias\x20%s.','Converting\x20package\x20%s\x20to\x20an\x20alias...','85410zjilbb','8047712QOAlqR','length','@stdlib/assert/has-own-property'];a0_0x4d71=function(){return _0x5b2385;};return a0_0x4d71();}