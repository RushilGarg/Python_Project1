/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x19dd(){var _0x1d373e=['@stdlib/stats/base/dmeanpn','119116VEOUtF','1536075ZLVthN','464389yObRco','2829156YeSxOE','511488vOBEvn','1792ktoncv','888RqNGfH','35jIPQRf','1179672XVWvNK'];a0_0x19dd=function(){return _0x1d373e;};return a0_0x19dd();}var a0_0x4a13e6=a0_0x59e9;function a0_0x59e9(_0x20e41d,_0x266242){var _0x19dd06=a0_0x19dd();return a0_0x59e9=function(_0x59e99d,_0x69331b){_0x59e99d=_0x59e99d-0x1a0;var _0x12250f=_0x19dd06[_0x59e99d];return _0x12250f;},a0_0x59e9(_0x20e41d,_0x266242);}(function(_0x162e70,_0x5f31c5){var _0xf92c60=a0_0x59e9,_0x1abd8c=_0x162e70();while(!![]){try{var _0x2947cf=parseInt(_0xf92c60(0x1a3))/0x1+parseInt(_0xf92c60(0x1a9))/0x2+parseInt(_0xf92c60(0x1a5))/0x3+parseInt(_0xf92c60(0x1a1))/0x4*(-parseInt(_0xf92c60(0x1a8))/0x5)+-parseInt(_0xf92c60(0x1a4))/0x6+parseInt(_0xf92c60(0x1a6))/0x7*(-parseInt(_0xf92c60(0x1a7))/0x8)+-parseInt(_0xf92c60(0x1a2))/0x9;if(_0x2947cf===_0x5f31c5)break;else _0x1abd8c['push'](_0x1abd8c['shift']());}catch(_0x5dc50e){_0x1abd8c['push'](_0x1abd8c['shift']());}}}(a0_0x19dd,0x54633));var dmeanpn=require(a0_0x4a13e6(0x1a0));function dmean(_0xcc2d39,_0x141cac,_0x25f08e){return dmeanpn(_0xcc2d39,_0x141cac,_0x25f08e);}module['exports']=dmean;