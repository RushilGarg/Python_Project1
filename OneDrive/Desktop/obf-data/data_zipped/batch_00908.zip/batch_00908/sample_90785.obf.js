/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0xee06(_0x33f158,_0xf90b70){var _0x5a4c51=a0_0x5a4c();return a0_0xee06=function(_0xee0636,_0x5c6a02){_0xee0636=_0xee0636-0x1df;var _0x168f30=_0x5a4c51[_0xee0636];return _0x168f30;},a0_0xee06(_0x33f158,_0xf90b70);}var a0_0x401e04=a0_0xee06;(function(_0x4dd7d5,_0x35e834){var _0x15c48b=a0_0xee06,_0x2b20f8=_0x4dd7d5();while(!![]){try{var _0x115f05=parseInt(_0x15c48b(0x1e4))/0x1+-parseInt(_0x15c48b(0x1e5))/0x2*(-parseInt(_0x15c48b(0x1df))/0x3)+-parseInt(_0x15c48b(0x1e7))/0x4*(parseInt(_0x15c48b(0x1eb))/0x5)+-parseInt(_0x15c48b(0x1e6))/0x6+parseInt(_0x15c48b(0x1e1))/0x7*(parseInt(_0x15c48b(0x1e2))/0x8)+-parseInt(_0x15c48b(0x1e0))/0x9*(-parseInt(_0x15c48b(0x1e9))/0xa)+parseInt(_0x15c48b(0x1ea))/0xb*(parseInt(_0x15c48b(0x1e8))/0xc);if(_0x115f05===_0x35e834)break;else _0x2b20f8['push'](_0x2b20f8['shift']());}catch(_0x44eecd){_0x2b20f8['push'](_0x2b20f8['shift']());}}}(a0_0x5a4c,0x8701d));var hasUint16ArraySupport=require('@stdlib/assert/has-uint16array-support'),builtin=require('./uint16array.js'),polyfill=require(a0_0x401e04(0x1e3)),ctor;function a0_0x5a4c(){var _0x351179=['./polyfill.js','936540YRRrrF','26aqtCOE','5840178ZKHizj','2443764Vkcwnt','1272732FfGykG','1173880YxHUXO','11kJljWR','5zkiVGT','140721eMkfxS','9eksIbb','7wqveUj','2940104yswiGe'];a0_0x5a4c=function(){return _0x351179;};return a0_0x5a4c();}hasUint16ArraySupport()?ctor=builtin:ctor=polyfill;module['exports']=ctor;