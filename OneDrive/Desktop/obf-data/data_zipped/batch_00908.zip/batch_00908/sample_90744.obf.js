/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x3ca8(){var _0x2d0f09=['equal','the\x20function\x20returns\x20`false`\x20if\x20not\x20provided\x20a\x20number\x20having\x20a\x20positive\x20integer\x20value','main\x20export\x20is\x20a\x20function','./../lib/main.js','returns\x20true','9922TFWHEy','8rEyEiN','3430098PIABCQ','tape','664HBjqHx','@stdlib/number/ctor','993255kAjuoK','190hoSWcJ','end','12QZJGPR','returns\x20false\x20when\x20provided\x20','the\x20function\x20returns\x20`true`\x20if\x20provided\x20a\x20number\x20having\x20a\x20positive\x20integer\x20value','3811752tIWJFg','1735iydQeD','length','78921SSqUsM','function','533742jVYZyL'];a0_0x3ca8=function(){return _0x2d0f09;};return a0_0x3ca8();}var a0_0x3ed4e0=a0_0x48e0;function a0_0x48e0(_0x5a64aa,_0x2583e2){var _0x3ca813=a0_0x3ca8();return a0_0x48e0=function(_0x48e0aa,_0x49511c){_0x48e0aa=_0x48e0aa-0x120;var _0x154fd6=_0x3ca813[_0x48e0aa];return _0x154fd6;},a0_0x48e0(_0x5a64aa,_0x2583e2);}(function(_0x195cfc,_0x4dcc46){var _0x1c4540=a0_0x48e0,_0x5cc0f6=_0x195cfc();while(!![]){try{var _0x1526e9=-parseInt(_0x1c4540(0x12e))/0x1*(parseInt(_0x1c4540(0x125))/0x2)+parseInt(_0x1c4540(0x132))/0x3*(-parseInt(_0x1c4540(0x122))/0x4)+-parseInt(_0x1c4540(0x127))/0x5*(-parseInt(_0x1c4540(0x12a))/0x6)+parseInt(_0x1c4540(0x123))/0x7+parseInt(_0x1c4540(0x12d))/0x8+parseInt(_0x1c4540(0x130))/0x9+-parseInt(_0x1c4540(0x128))/0xa*(-parseInt(_0x1c4540(0x121))/0xb);if(_0x1526e9===_0x4dcc46)break;else _0x5cc0f6['push'](_0x5cc0f6['shift']());}catch(_0x4e920a){_0x5cc0f6['push'](_0x5cc0f6['shift']());}}}(a0_0x3ca8,0x6fc74));var tape=require(a0_0x3ed4e0(0x124)),Number=require(a0_0x3ed4e0(0x126)),isPositiveInteger=require(a0_0x3ed4e0(0x136));tape(a0_0x3ed4e0(0x135),function test(_0x1d7127){var _0x486f7b=a0_0x3ed4e0;_0x1d7127['ok'](!![],__filename),_0x1d7127[_0x486f7b(0x133)](typeof isPositiveInteger,_0x486f7b(0x131),'main\x20export\x20is\x20a\x20function'),_0x1d7127[_0x486f7b(0x129)]();}),tape(a0_0x3ed4e0(0x12c),function test(_0x2e57eb){var _0x5b90bc=a0_0x3ed4e0;_0x2e57eb[_0x5b90bc(0x133)](isPositiveInteger(0x5),!![],_0x5b90bc(0x120)),_0x2e57eb[_0x5b90bc(0x133)](isPositiveInteger(new Number(0x5)),!![],_0x5b90bc(0x120)),_0x2e57eb[_0x5b90bc(0x129)]();}),tape(a0_0x3ed4e0(0x134),function test(_0xc5b6b8){var _0x487506=a0_0x3ed4e0,_0x34eb11,_0x49ee59;_0x34eb11=['5',3.14,-0x1,0x0,null,!![],void 0x0,[],{},function _0x397419(){}];for(_0x49ee59=0x0;_0x49ee59<_0x34eb11[_0x487506(0x12f)];_0x49ee59++){_0xc5b6b8[_0x487506(0x133)](isPositiveInteger(_0x34eb11[_0x49ee59]),![],_0x487506(0x12b)+_0x34eb11[_0x49ee59]);}_0xc5b6b8[_0x487506(0x129)]();});