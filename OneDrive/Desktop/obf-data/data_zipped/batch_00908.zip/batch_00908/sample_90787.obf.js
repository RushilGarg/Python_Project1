/**
* @license Apache-2.0
*
* Copyright (c) 2019 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x22c72e=a0_0x50bc;(function(_0x33170a,_0x279c0e){var _0x477293=a0_0x50bc,_0x494226=_0x33170a();while(!![]){try{var _0x4d5ed5=parseInt(_0x477293(0x1dd))/0x1+parseInt(_0x477293(0x1d7))/0x2*(-parseInt(_0x477293(0x1da))/0x3)+-parseInt(_0x477293(0x1d5))/0x4*(parseInt(_0x477293(0x1d3))/0x5)+parseInt(_0x477293(0x1cf))/0x6+-parseInt(_0x477293(0x1d9))/0x7*(parseInt(_0x477293(0x1d8))/0x8)+-parseInt(_0x477293(0x1d4))/0x9*(-parseInt(_0x477293(0x1d2))/0xa)+parseInt(_0x477293(0x1db))/0xb*(parseInt(_0x477293(0x1d6))/0xc);if(_0x4d5ed5===_0x279c0e)break;else _0x494226['push'](_0x494226['shift']());}catch(_0x451f39){_0x494226['push'](_0x494226['shift']());}}}(a0_0xad73,0x5d970));function a0_0x50bc(_0x5bd4ad,_0x432a60){var _0xad733b=a0_0xad73();return a0_0x50bc=function(_0x50bc02,_0x1b3898){_0x50bc02=_0x50bc02-0x1cf;var _0xced721=_0xad733b[_0x50bc02];return _0xced721;},a0_0x50bc(_0x5bd4ad,_0x432a60);}function a0_0xad73(){var _0xcfd7f9=['8hqMhlV','5192635BetprV','93tDXkZB','11abeGrf','@stdlib/random/iter/uniform','624241kKKhFC','log','4030434voGsWb','./../lib','meanabs2:\x20%d.','10sKFSOL','3310480EDaJYE','2266713jceQwR','4ogAVxB','7195164DNxICc','23238ZEQALr'];a0_0xad73=function(){return _0xcfd7f9;};return a0_0xad73();}var runif=require(a0_0x22c72e(0x1dc)),itermeanabs2=require(a0_0x22c72e(0x1d0)),rand=runif(-0xa,0xa,{'seed':0x4d2,'iter':0x64}),m=itermeanabs2(rand);console[a0_0x22c72e(0x1de)](a0_0x22c72e(0x1d1),m);