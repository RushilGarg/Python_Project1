/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x5337ab=a0_0x252e;function a0_0x57b0(){var _0x3371f3=['Linter','eslint','require(\x20\x27@stdlib/math\x27\x20);','4jOjmXn','68XqosQP','766405GCbRrr','72903oUiAzf','no-unassigned-require','log','147218vQXFqw','./../lib','504bYHRYH','2094729YoAIib','807250FWgEmu','16ZmGSqS','7696923XEYlMf','error','150106IxSRcE','45rVGNNO','30kVhFte'];a0_0x57b0=function(){return _0x3371f3;};return a0_0x57b0();}(function(_0xf770ab,_0x516db3){var _0x2c8dd8=a0_0x252e,_0x5753a8=_0xf770ab();while(!![]){try{var _0x2969f1=parseInt(_0x2c8dd8(0x127))/0x1*(parseInt(_0x2c8dd8(0x135))/0x2)+-parseInt(_0x2c8dd8(0x124))/0x3*(-parseInt(_0x2c8dd8(0x122))/0x4)+parseInt(_0x2c8dd8(0x123))/0x5*(parseInt(_0x2c8dd8(0x131))/0x6)+parseInt(_0x2c8dd8(0x12a))/0x7*(parseInt(_0x2c8dd8(0x12c))/0x8)+parseInt(_0x2c8dd8(0x130))/0x9*(-parseInt(_0x2c8dd8(0x12b))/0xa)+-parseInt(_0x2c8dd8(0x12f))/0xb*(parseInt(_0x2c8dd8(0x129))/0xc)+-parseInt(_0x2c8dd8(0x12d))/0xd;if(_0x2969f1===_0x516db3)break;else _0x5753a8['push'](_0x5753a8['shift']());}catch(_0x293596){_0x5753a8['push'](_0x5753a8['shift']());}}}(a0_0x57b0,0x7af48));function a0_0x252e(_0x23c444,_0x1224b5){var _0x57b09f=a0_0x57b0();return a0_0x252e=function(_0x252efa,_0xbf2981){_0x252efa=_0x252efa-0x122;var _0x2bab88=_0x57b09f[_0x252efa];return _0x2bab88;},a0_0x252e(_0x23c444,_0x1224b5);}var Linter=require(a0_0x5337ab(0x133))[a0_0x5337ab(0x132)],rule=require(a0_0x5337ab(0x128)),linter=new Linter(),result,code=a0_0x5337ab(0x134);linter['defineRule'](a0_0x5337ab(0x125),rule),result=linter['verify'](code,{'rules':{'no-unassigned-require':a0_0x5337ab(0x12e)}}),console[a0_0x5337ab(0x126)](result);