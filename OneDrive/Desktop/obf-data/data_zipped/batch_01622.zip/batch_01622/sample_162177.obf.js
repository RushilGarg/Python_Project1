/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x4dd475=a0_0xcc49;(function(_0x58324b,_0x572ca0){var _0x2767c6=a0_0xcc49,_0x4241dc=_0x58324b();while(!![]){try{var _0x5ba734=-parseInt(_0x2767c6(0x1de))/0x1+-parseInt(_0x2767c6(0x1e6))/0x2*(-parseInt(_0x2767c6(0x1e8))/0x3)+-parseInt(_0x2767c6(0x1da))/0x4+parseInt(_0x2767c6(0x1d8))/0x5*(parseInt(_0x2767c6(0x1e4))/0x6)+parseInt(_0x2767c6(0x1e0))/0x7*(-parseInt(_0x2767c6(0x1e5))/0x8)+-parseInt(_0x2767c6(0x1e2))/0x9*(-parseInt(_0x2767c6(0x1dc))/0xa)+parseInt(_0x2767c6(0x1dd))/0xb;if(_0x5ba734===_0x572ca0)break;else _0x4241dc['push'](_0x4241dc['shift']());}catch(_0x5cbb57){_0x4241dc['push'](_0x4241dc['shift']());}}}(a0_0x4ccf,0x9d4f8));function a0_0xcc49(_0x41cef8,_0x301711){var _0x4ccf29=a0_0x4ccf();return a0_0xcc49=function(_0xcc49c1,_0x5edb7b){_0xcc49c1=_0xcc49c1-0x1d7;var _0x5ab5f2=_0x4ccf29[_0xcc49c1];return _0x5ab5f2;},a0_0xcc49(_0x41cef8,_0x301711);}var Binomial=require('./../lib'),binomial=new Binomial(0xa,0.4),mu=binomial[a0_0x4dd475(0x1e1)];console['log']('Mean\x20=\x20%d',mu);var mode=binomial[a0_0x4dd475(0x1e7)];console['log'](a0_0x4dd475(0x1d9),mode);var s2=binomial[a0_0x4dd475(0x1df)];console['log'](a0_0x4dd475(0x1db),s2);var y=binomial['cdf'](3.5);console[a0_0x4dd475(0x1d7)](a0_0x4dd475(0x1e3),y);function a0_0x4ccf(){var _0x2ff2c6=['variance','107583LivupS','mean','9KvtKry','F(3.5)\x20=\x20%d','1578ZbUUia','296Gauapd','10oSzcwK','mode','216264ffCqzV','log','4580TBzaCv','Mode\x20=\x20%d','3584596xFpWzJ','Variance\x20=\x20%d','3526770GKTszZ','14222087OPFdCl','137796qYHPuH'];a0_0x4ccf=function(){return _0x2ff2c6;};return a0_0x4ccf();}