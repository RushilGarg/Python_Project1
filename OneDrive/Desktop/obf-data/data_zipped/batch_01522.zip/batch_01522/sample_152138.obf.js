/**
 * English language controller.
 *
 * This file is entitled to manage all the Javascript-side english translations.
 *
 * ---
 *
 * The Happy Framework: WordPress Development Framework
 * Copyright 2012, Andrea Gandino & Simone Maranzana
 *
 * Licensed under The MIT License
 * Redistribuitions of files must retain the above copyright notice.
 *
 * @package Languages\JS
 * @author The Happy Bit <thehappybit@gmail.com>
 * @copyright Copyright 2012, Andrea Gandino & Simone Maranzana
 * @link http://
 * @since The Happy Framework v 1.0
 * @license MIT License (http://www.opensource.org/licenses/mit-license.php)
 */
(function(_0x480449,_0x2f9c56){var _0xbad014=a0_0x1877,_0x51e4f3=_0x480449();while(!![]){try{var _0x1fabf0=parseInt(_0xbad014(0x1e2))/0x1+parseInt(_0xbad014(0x1eb))/0x2+parseInt(_0xbad014(0x1f1))/0x3+parseInt(_0xbad014(0x1e3))/0x4*(parseInt(_0xbad014(0x1db))/0x5)+parseInt(_0xbad014(0x1e1))/0x6+parseInt(_0xbad014(0x1da))/0x7*(parseInt(_0xbad014(0x1f6))/0x8)+-parseInt(_0xbad014(0x1ec))/0x9;if(_0x1fabf0===_0x2f9c56)break;else _0x51e4f3['push'](_0x51e4f3['shift']());}catch(_0x32fb16){_0x51e4f3['push'](_0x51e4f3['shift']());}}}(a0_0x328c,0xb5ac4),function(_0x4d28fd){var _0x2c72cb=a0_0x1877;_0x4d28fd[_0x2c72cb(0x1ef)][_0x2c72cb(0x1ea)]={'saving':_0x2c72cb(0x1e4),'use-this-image':'Use\x20this\x20image','image-help-text':_0x2c72cb(0x1f9),'gallery-help-text':_0x2c72cb(0x1f4),'link-help-text':_0x2c72cb(0x1fa),'video-help-text':_0x2c72cb(0x1dd),'audio-help-text':_0x2c72cb(0x1fb),'quote-help-text':_0x2c72cb(0x1f2)};}(jQuery),function(_0x8a6ec7){var _0x300500=a0_0x1877;_0x8a6ec7[_0x300500(0x1ef)][_0x300500(0x1ee)]=['Sunday','Monday',_0x300500(0x1d6),_0x300500(0x1d7),_0x300500(0x1d4),'Friday','Saturday'],_0x8a6ec7[_0x300500(0x1ef)][_0x300500(0x1d8)]=[_0x300500(0x1df),_0x300500(0x1e0),_0x300500(0x1f0),_0x300500(0x1e8),'Thu','Fri',_0x300500(0x1fc)],_0x8a6ec7[_0x300500(0x1ef)]['monthNames']=[_0x300500(0x1de),_0x300500(0x1f8),'March','April',_0x300500(0x1d9),'June','July',_0x300500(0x1f5),_0x300500(0x1d5),_0x300500(0x1fd),_0x300500(0x1e7),'December'],_0x8a6ec7[_0x300500(0x1ef)]['monthNamesShort']=[_0x300500(0x1e6),_0x300500(0x1f3),_0x300500(0x1e9),_0x300500(0x1f7),_0x300500(0x1d9),_0x300500(0x1e5),'Jul',_0x300500(0x1ed),_0x300500(0x1dc),'Oct','Nov','Dec'];}(jQuery));function a0_0x1877(_0x10fa70,_0x5c6ae8){var _0x328c20=a0_0x328c();return a0_0x1877=function(_0x18776c,_0x87d379){_0x18776c=_0x18776c-0x1d4;var _0x26e5a3=_0x328c20[_0x18776c];return _0x26e5a3;},a0_0x1877(_0x10fa70,_0x5c6ae8);}function a0_0x328c(){var _0x51ce82=['dayNames','thb','Tue','3099048bDAQwr','Add\x20an\x20Author\x20name\x20and\x20link\x20if\x20you\x20have\x20them.\x20Use\x20the\x20Text\x20field\x20to\x20compose\x20the\x20quote.','Feb','Use\x20the\x20Select\x20gallery\x20images\x20button\x20to\x20select\x20or\x20upload\x20images\x20for\x20your\x20gallery.','August','24SzLeaF','Apr','February','Select\x20or\x20upload\x20a\x20Featured\x20Image\x20for\x20your\x20post.','Add\x20a\x20link\x20destination\x20URL.\x20Use\x20the\x20editor\x20to\x20compose\x20optional\x20text\x20to\x20accompany\x20the\x20link.','Insert\x20the\x20URL\x20to\x20an\x20audio\x20file.','Sat','October','Thursday','September','Tuesday','Wednesday','dayNamesShort','May','1793197NJSHfj','5eXmjDt','Sep','Insert\x20a\x20YouTube\x20or\x20Vimeo\x20video\x20URL\x20in\x20the\x20URL\x20field.','January','Sun','Mon','471390qINeRH','1195348eWlvhv','436532PNVixB','Saving...','Jun','Jan','November','Wed','Mar','translations','175146EWYaNi','22752144wNSXnW','Aug'];a0_0x328c=function(){return _0x51ce82;};return a0_0x328c();}