/**
 * @license
 * Copyright 2019 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
(function(_0x2455e3,_0x1e36a2){const _0x36891b=a0_0x4e12,_0x5ad479=_0x2455e3();while(!![]){try{const _0x439917=parseInt(_0x36891b(0x9e))/0x1+parseInt(_0x36891b(0x99))/0x2+-parseInt(_0x36891b(0x9f))/0x3+parseInt(_0x36891b(0x98))/0x4+-parseInt(_0x36891b(0x9d))/0x5*(-parseInt(_0x36891b(0x9c))/0x6)+-parseInt(_0x36891b(0x9b))/0x7+-parseInt(_0x36891b(0x9a))/0x8;if(_0x439917===_0x1e36a2)break;else _0x5ad479['push'](_0x5ad479['shift']());}catch(_0x381e22){_0x5ad479['push'](_0x5ad479['shift']());}}}(a0_0x2ccc,0x32f1f));import{parseCSV}from'../src/aws/InvoiceParser';import{setOptions}from'../src/core/config';function a0_0x4e12(_0x1d09d8,_0x54de6c){const _0x2ccc87=a0_0x2ccc();return a0_0x4e12=function(_0x4e127e,_0x5e9950){_0x4e127e=_0x4e127e-0x97;let _0x337a90=_0x2ccc87[_0x4e127e];return _0x337a90;},a0_0x4e12(_0x1d09d8,_0x54de6c);}function a0_0x2ccc(){const _0x372561=['1034128EXDHKp','606652fjWOxn','3084512DnjFaZ','2264969QGzVvE','5904KTIMLq','1010jSpdkG','328220oLfIvO','513132pccfpd','csv/test.csv'];a0_0x2ccc=function(){return _0x372561;};return a0_0x2ccc();}let parsedFile;export async function parseTestFile(){const _0x18d855=a0_0x4e12;return!parsedFile&&(parsedFile=await parseCSV(_0x18d855(0x97))),parsedFile;}