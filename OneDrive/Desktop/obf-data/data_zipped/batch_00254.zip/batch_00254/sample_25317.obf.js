/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x342a44=a0_0x5259;(function(_0x28c487,_0x577eac){var _0x2d6ef3=a0_0x5259,_0x2fa590=_0x28c487();while(!![]){try{var _0x36da62=parseInt(_0x2d6ef3(0x132))/0x1+parseInt(_0x2d6ef3(0x128))/0x2+parseInt(_0x2d6ef3(0x130))/0x3+-parseInt(_0x2d6ef3(0x131))/0x4+-parseInt(_0x2d6ef3(0x129))/0x5*(-parseInt(_0x2d6ef3(0x12f))/0x6)+parseInt(_0x2d6ef3(0x12b))/0x7+-parseInt(_0x2d6ef3(0x12c))/0x8;if(_0x36da62===_0x577eac)break;else _0x2fa590['push'](_0x2fa590['shift']());}catch(_0x212794){_0x2fa590['push'](_0x2fa590['shift']());}}}(a0_0x1392,0xed484));var randu=require(a0_0x342a44(0x12e)),round=require(a0_0x342a44(0x12a)),Float64Array=require(a0_0x342a44(0x126)),gnansum=require('./../lib'),x,i;x=new Float64Array(0xa);function a0_0x1392(){var _0x3df66b=['@stdlib/array/float64','length','346638fLgXJJ','930QgEaWx','@stdlib/math/base/special/round','8038772SggWFo','20511224OHktYv','log','@stdlib/random/base/randu','19110mrmQFF','2449029WbtSsO','4546212kXpGSf','1941896tWurbO'];a0_0x1392=function(){return _0x3df66b;};return a0_0x1392();}for(i=0x0;i<x[a0_0x342a44(0x127)];i++){randu()<0.2?x[i]=NaN:x[i]=round(randu()*0x64);}console[a0_0x342a44(0x12d)](x);function a0_0x5259(_0x21555a,_0x2dcc69){var _0x139273=a0_0x1392();return a0_0x5259=function(_0x525929,_0x33d31d){_0x525929=_0x525929-0x126;var _0x5e3954=_0x139273[_0x525929];return _0x5e3954;},a0_0x5259(_0x21555a,_0x2dcc69);}var v=gnansum(x[a0_0x342a44(0x127)],x,0x1);console[a0_0x342a44(0x12d)](v);