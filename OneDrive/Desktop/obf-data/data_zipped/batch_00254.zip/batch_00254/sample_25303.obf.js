/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x5452(_0x563449,_0x8deec3){var _0xb49d75=a0_0xb49d();return a0_0x5452=function(_0x54523a,_0x45900c){_0x54523a=_0x54523a-0x18a;var _0x27d22e=_0xb49d75[_0x54523a];return _0x27d22e;},a0_0x5452(_0x563449,_0x8deec3);}function a0_0xb49d(){var _0x56af2e=['end','3906447NashWj','@stdlib/bench','pass','265260ZUXogP','2NNXosV','benchmark\x20finished','2340010dNhAWS','./../lib','iterations','fail','length',':of','16fkDXOy','9oijBBt','name','@stdlib/assert/is-uint16array','toc','4185036hHNBpf','132yodGVE','1648306kwSGdy','1597405pvXqVZ','3517619nPSCWn','should\x20have\x20length\x202'];a0_0xb49d=function(){return _0x56af2e;};return a0_0xb49d();}var a0_0x49f0a0=a0_0x5452;(function(_0x529af9,_0xac3520){var _0x28cdfe=a0_0x5452,_0x5cfbe8=_0x529af9();while(!![]){try{var _0x362e19=-parseInt(_0x28cdfe(0x191))/0x1+-parseInt(_0x28cdfe(0x199))/0x2*(-parseInt(_0x28cdfe(0x195))/0x3)+parseInt(_0x28cdfe(0x18e))/0x4+-parseInt(_0x28cdfe(0x198))/0x5*(-parseInt(_0x28cdfe(0x18f))/0x6)+parseInt(_0x28cdfe(0x192))/0x7*(-parseInt(_0x28cdfe(0x1a1))/0x8)+-parseInt(_0x28cdfe(0x18a))/0x9*(-parseInt(_0x28cdfe(0x19b))/0xa)+-parseInt(_0x28cdfe(0x190))/0xb;if(_0x362e19===_0xac3520)break;else _0x5cfbe8['push'](_0x5cfbe8['shift']());}catch(_0xd658f){_0x5cfbe8['push'](_0x5cfbe8['shift']());}}}(a0_0xb49d,0xf3794));var bench=require(a0_0x49f0a0(0x196)),isUint16Array=require(a0_0x49f0a0(0x18c)),pkg=require('./../package.json')[a0_0x49f0a0(0x18b)],Uint16Array=require(a0_0x49f0a0(0x19c));bench(pkg+a0_0x49f0a0(0x1a0),function benchmark(_0x307365){var _0x59f683=a0_0x49f0a0,_0x130003,_0xd2fb3f;_0x307365['tic']();for(_0xd2fb3f=0x0;_0xd2fb3f<_0x307365[_0x59f683(0x19d)];_0xd2fb3f++){_0x130003=Uint16Array['of'](_0xd2fb3f,0x2),_0x130003[_0x59f683(0x19f)]!==0x2&&_0x307365['fail'](_0x59f683(0x193));}_0x307365[_0x59f683(0x18d)](),!isUint16Array(_0x130003)&&_0x307365[_0x59f683(0x19e)]('should\x20return\x20a\x20Uint16Array'),_0x307365[_0x59f683(0x197)](_0x59f683(0x19a)),_0x307365[_0x59f683(0x194)]();});