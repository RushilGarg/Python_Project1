/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x155615=a0_0x4db5;(function(_0x1012f7,_0x3f9c38){var _0x25e8c8=a0_0x4db5,_0x35b085=_0x1012f7();while(!![]){try{var _0x385ba6=parseInt(_0x25e8c8(0x1f7))/0x1+parseInt(_0x25e8c8(0x1f8))/0x2+-parseInt(_0x25e8c8(0x200))/0x3+parseInt(_0x25e8c8(0x1f4))/0x4*(parseInt(_0x25e8c8(0x1fe))/0x5)+-parseInt(_0x25e8c8(0x1f5))/0x6+parseInt(_0x25e8c8(0x1fd))/0x7+parseInt(_0x25e8c8(0x1fa))/0x8*(-parseInt(_0x25e8c8(0x1f9))/0x9);if(_0x385ba6===_0x3f9c38)break;else _0x35b085['push'](_0x35b085['shift']());}catch(_0x2453ff){_0x35b085['push'](_0x35b085['shift']());}}}(a0_0x78a7,0x7e4ed));var randu=require(a0_0x155615(0x1fb)),round=require(a0_0x155615(0x1ff)),Float32Array=require('@stdlib/array/float32'),scumax=require(a0_0x155615(0x201)),y,x,i;x=new Float32Array(0xa),y=new Float32Array(x[a0_0x155615(0x1f6)]);function a0_0x4db5(_0x4f2395,_0x2e946d){var _0x78a744=a0_0x78a7();return a0_0x4db5=function(_0x4db53f,_0x197339){_0x4db53f=_0x4db53f-0x1f4;var _0x2d878d=_0x78a744[_0x4db53f];return _0x2d878d;},a0_0x4db5(_0x4f2395,_0x2e946d);}for(i=0x0;i<x['length'];i++){x[i]=round(randu()*0x64);}function a0_0x78a7(){var _0x591226=['16DXqCaM','@stdlib/random/base/randu','log','5848129HjbXzN','5365DEMpMJ','@stdlib/math/base/special/round','2460066JWvTtO','./../lib','1284VlAKwF','1518858fvOzGg','length','242184kBKTjS','843888jGvRjf','1140687pHoqQi'];a0_0x78a7=function(){return _0x591226;};return a0_0x78a7();}console[a0_0x155615(0x1fc)](x),console['log'](y),scumax(x[a0_0x155615(0x1f6)],x,0x1,y,-0x1),console[a0_0x155615(0x1fc)](y);