/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xdd55bb=a0_0x3163;(function(_0x3ee5ab,_0x59e48e){var _0x3da17f=a0_0x3163,_0x2b491e=_0x3ee5ab();while(!![]){try{var _0x32ef41=-parseInt(_0x3da17f(0x87))/0x1+-parseInt(_0x3da17f(0x8c))/0x2*(-parseInt(_0x3da17f(0x91))/0x3)+-parseInt(_0x3da17f(0x88))/0x4+-parseInt(_0x3da17f(0x8a))/0x5*(parseInt(_0x3da17f(0x8e))/0x6)+-parseInt(_0x3da17f(0x92))/0x7*(-parseInt(_0x3da17f(0x8f))/0x8)+parseInt(_0x3da17f(0x89))/0x9+parseInt(_0x3da17f(0x8b))/0xa;if(_0x32ef41===_0x59e48e)break;else _0x2b491e['push'](_0x2b491e['shift']());}catch(_0x5b11dd){_0x2b491e['push'](_0x2b491e['shift']());}}}(a0_0x26cd,0x501f0));var reUncPath=require(a0_0xdd55bb(0x90)),RE_UNC_PATH=reUncPath();function a0_0x26cd(){var _0x358a25=['5YeKfed','5222190iDRAVo','352590atmcmS','exports','2749458EmAzPP','349240QixQjO','./main.js','6PDhDxk','14OdeCrY','283203tPtzeh','1361300rrnClP','4030452lwxxyB'];a0_0x26cd=function(){return _0x358a25;};return a0_0x26cd();}function a0_0x3163(_0x212fa5,_0x190b3c){var _0x26cd6b=a0_0x26cd();return a0_0x3163=function(_0x3163e2,_0x4d683f){_0x3163e2=_0x3163e2-0x87;var _0xbd26e0=_0x26cd6b[_0x3163e2];return _0xbd26e0;},a0_0x3163(_0x212fa5,_0x190b3c);}module[a0_0xdd55bb(0x8d)]=RE_UNC_PATH;