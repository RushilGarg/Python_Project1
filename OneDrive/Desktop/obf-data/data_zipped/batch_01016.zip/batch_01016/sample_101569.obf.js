function a0_0x8f3d(_0x3c7e39,_0x4266e6){const _0xa18b8f=a0_0xa18b();return a0_0x8f3d=function(_0x8f3d26,_0xce23e8){_0x8f3d26=_0x8f3d26-0x117;let _0x17404f=_0xa18b8f[_0x8f3d26];return _0x17404f;},a0_0x8f3d(_0x3c7e39,_0x4266e6);}const a0_0xaf9bfa=a0_0x8f3d;(function(_0x29332f,_0xbc9209){const _0x2d35fa=a0_0x8f3d,_0x1cab3d=_0x29332f();while(!![]){try{const _0x4023cb=parseInt(_0x2d35fa(0x139))/0x1*(parseInt(_0x2d35fa(0x13b))/0x2)+parseInt(_0x2d35fa(0x13d))/0x3+parseInt(_0x2d35fa(0x11f))/0x4*(parseInt(_0x2d35fa(0x13f))/0x5)+-parseInt(_0x2d35fa(0x147))/0x6*(parseInt(_0x2d35fa(0x138))/0x7)+-parseInt(_0x2d35fa(0x12a))/0x8*(parseInt(_0x2d35fa(0x144))/0x9)+-parseInt(_0x2d35fa(0x141))/0xa+parseInt(_0x2d35fa(0x13a))/0xb*(parseInt(_0x2d35fa(0x119))/0xc);if(_0x4023cb===_0xbc9209)break;else _0x1cab3d['push'](_0x1cab3d['shift']());}catch(_0x5e9460){_0x1cab3d['push'](_0x1cab3d['shift']());}}}(a0_0xa18b,0xe63f8));const window=require('global/window'),css=require('sheetify'),html=require(a0_0xaf9bfa(0x129)),framework=require(a0_0xaf9bfa(0x146)),{getToken,saveToken,subscribeToken,unsubscribeToken}=require(a0_0xaf9bfa(0x123)),{urlBase64ToUint8Array}=require('./util'),serviceWorkerSupported='serviceWorker'in navigator,notificationPermission=a0_0xaf9bfa(0x118)in window?window[a0_0xaf9bfa(0x118)][a0_0xaf9bfa(0x125)]:a0_0xaf9bfa(0x133),applicationServerKey=urlBase64ToUint8Array(process['env'][a0_0xaf9bfa(0x12b)]);css(a0_0xaf9bfa(0x134)),css`
  html, body {
    width: 100%;
    height: 100%;
  }

  main {
    width: 100%;
    min-height: 100%;
  }
`;const horizontalFlip=css`
  :host {
    transform: scale(-1, 1);
  }
`,LoadingView=_0x4daaf9=>{const _0x284750=a0_0xaf9bfa;let _0x3e98ed;if(_0x4daaf9['err'])_0x3e98ed=html`
      <span>
        Something went wrong...
        <pre class="">${_0x4daaf9[_0x284750(0x12c)][_0x284750(0x145)]}</pre>
      </span>
    `;else{if(_0x4daaf9[_0x284750(0x132)]===_0x284750(0x11a))_0x3e98ed=_0x284750(0x140);else{if(_0x4daaf9[_0x284750(0x132)]===_0x284750(0x133)||!_0x4daaf9['serviceWorkerSupported'])_0x3e98ed='Your\x20browser\x20doesn\x27t\x20support\x20web\x20push\x20notifications.\x20Write\x20to\x20your\x20local\x20representative,\x20or\x20use\x20something\x20like\x20Chrome\x20or\x20Firefox.';else{if(_0x4daaf9[_0x284750(0x132)]===_0x284750(0x12f))_0x3e98ed='We\x27ll\x20get\x20started\x20once\x20you\x20accept\x20the\x20request\x20to\x20show\x20notifications.';else!_0x4daaf9[_0x284750(0x11b)]?_0x3e98ed=_0x284750(0x12e):_0x3e98ed=_0x284750(0x136);}}}return html`
    <p class="lh-copy o-60 measure">${_0x3e98ed}</p>
  `;},Divider=_0x43a261=>{const _0x4a1a53=a0_0xaf9bfa;var _0x54d3f1=_0x4a1a53(0x117);if(_0x43a261)_0x54d3f1+='\x20'+horizontalFlip;return html`
    <div class=${_0x54d3f1}>📌📌📌📌📌</div>
  `;},MainView=(_0x54bbd1,_0x5ad5ca)=>{const _0x41d0c4=a0_0xaf9bfa;function _0x2b3b1c(_0x122fde){const _0x32ce5b=a0_0x8f3d;_0x122fde[_0x32ce5b(0x11e)](),window[_0x32ce5b(0x126)](_0x32ce5b(0x11d))&&resetToken(_0x54bbd1[_0x32ce5b(0x11b)],_0x54bbd1[_0x32ce5b(0x130)]);}return html`
    <div class="measure">
      <section class="mv4">
        <p class="lh-copy">
          Your push notification URL is:
        </p>
        <div class="code pa2 br2 bg-dark-green light-blue overflow-y-scroll nowrap">
          ${window['location'][_0x41d0c4(0x143)]}${_0x54bbd1[_0x41d0c4(0x11b)]}/notify
        </div>

        <p class="lh-copy">
          You can receive notifications when you send a request to that URL,
          even when this page isn't open. This URL will stay the same (even if
          you refresh) until you clear your browser data. If you want a new
          token, <a class="link underline hover-light-blue pointer" onclick=${_0x2b3b1c}>click here</a>.
        </p>
      </section>

      ${Divider(![])}

      <section class="mv4">
        <p class="lh-copy">
          Try it out! Run this command to see if it works
        </p>
        <div class="code pa2 br2 bg-dark-green light-blue">
          curl '${window[_0x41d0c4(0x12d)][_0x41d0c4(0x143)]}${_0x54bbd1[_0x41d0c4(0x11b)]}/notify?title=nanopush&body=This%20is%20a%20test'
        </div>
      </section>

      ${Divider(!![])}

      <section class="mv4">
        <h2 class="f4 fw7 mb2 lh-title">
          API
        </h2>

        <h3 class="code f5 fw7 mt0 mb1 lh-copy">
          GET ${window['location']['href']}${_0x54bbd1[_0x41d0c4(0x11b)]}/notify
        </h3>
        <p class="ml2 mv1">
          Takes parameters by query string.
        </p>

        <h3 class="code f5 fw7 mt2 mb1 lh-copy">
          POST ${window[_0x41d0c4(0x12d)][_0x41d0c4(0x143)]}${_0x54bbd1[_0x41d0c4(0x11b)]}/notify
        </h3>
        <p class="ml2 mv1">
          Takes parameters by JSON body.
        </p>

        <h4 class="f5 fw7 mt3 mb1">
          Parameters
        </h4>
        <ul class="list mv1">
          <li>
            <span class="code">title</span>: The title text of the notification.
          </li>
          <li>
            <span class="code">body</span>: The body text of the notification.
          </li>
          <li>
            <span class="code">icon</span>: A URL to an icon for the notification.
          </li>
        </ul>
      </section>
    </div>
  `;},AppView=(_0x16749a,_0x592be3)=>{const _0x453a43=_0x16749a['token']?MainView:LoadingView;return html`
    <main class="helvetica bg-green washed-blue pa3">
      <h1 class="f3 fw7 mt0 mb3">nanopush 📌</h1>
      <div class="f5">
        <p class="lh-copy measure">nanopush is a tool that sends push notifications. No installation. No registration.</p>
        <div id="root">${_0x453a43(_0x16749a,_0x592be3)}</div>
      </div>
      <footer class="f5 fw3 o-60">
        <div class="vh-25"></div>
        <ul class="list pl0">
          <li>Created with 👌 by <a class="link fw5 dim washed-blue" href="http://rahatah.me/d">Rahat Ahmed</a></li>
          <li><a class="link fw5 dim washed-blue" href="https://github.com/rahatarmanahmed/nanopush">Github</a></li>
        </ul>
      </footer>
    </main>
  `;},f=framework(AppView),el=f[a0_0xaf9bfa(0x128)]({'serviceWorkerSupported':serviceWorkerSupported,'notificationPermission':notificationPermission,'token':null,'subscription':null});document[a0_0xaf9bfa(0x124)][a0_0xaf9bfa(0x131)](el);serviceWorkerSupported&&navigator[a0_0xaf9bfa(0x122)][a0_0xaf9bfa(0x11c)](a0_0xaf9bfa(0x13c))[a0_0xaf9bfa(0x142)](_0xff8b47=>{const _0x5c23ba=a0_0xaf9bfa;return navigator[_0x5c23ba(0x122)]['ready'][_0x5c23ba(0x142)](()=>_0xff8b47['pushManager'][_0x5c23ba(0x127)]())[_0x5c23ba(0x142)](_0x35aaaf=>{const _0xe7d8ac=_0x5c23ba;if(_0x35aaaf)return _0x35aaaf;return _0xff8b47[_0xe7d8ac(0x121)]['subscribe']({'userVisibleOnly':!![],'applicationServerKey':applicationServerKey});});})[a0_0xaf9bfa(0x142)](_0x19ce3d=>{const _0x2bbb40=a0_0xaf9bfa;return f[_0x2bbb40(0x120)]({'notificationPermission':window[_0x2bbb40(0x118)][_0x2bbb40(0x125)]}),updateSubscription(_0x19ce3d);})[a0_0xaf9bfa(0x135)](_0x258246=>{const _0x22f180=a0_0xaf9bfa;_0x258246[_0x22f180(0x137)]===_0x22f180(0x13e)?f[_0x22f180(0x120)]({'notificationPermission':window[_0x22f180(0x118)]['permission']}):f[_0x22f180(0x120)]({'err':_0x258246});});const updateSubscription=_0x5a5189=>{return getToken()['then'](_0x3bd7bc=>{const _0x3166f3=a0_0x8f3d;return saveToken(_0x3bd7bc)['then'](()=>subscribeToken(_0x3bd7bc,_0x5a5189))[_0x3166f3(0x142)](()=>f[_0x3166f3(0x120)]({'token':_0x3bd7bc,'subscription':_0x5a5189}));});},resetToken=(_0x1c7f69,_0x516739)=>{const _0x5ccb79=a0_0xaf9bfa;return unsubscribeToken(_0x1c7f69)[_0x5ccb79(0x142)](()=>updateSubscription(_0x516739));};function a0_0xa18b(){const _0x1d450e=['confirm','getSubscription','start','bel','8dsiVZe','applicationServerKey','err','location','Registering\x20web\x20push\x20notifications...','default','subscription','appendChild','notificationPermission','unsupported','tachyons','catch','Something\x20went\x20wrong...\x20sorry.','name','85939uxsOZZ','2525lysqCw','9537EdIElt','254idzmfW','sw.js','3504279XbWhix','NotAllowedError','5905Hzmojf','Seems\x20like\x20you\x20denied\x20the\x20request\x20to\x20show\x20notifications.\x20You\x27re\x20gonna\x20have\x20to\x20reset\x20that\x20if\x20you\x20want\x20to\x20use\x20this\x20app.','6649820ASZKGH','then','href','15961662SMkagf','stack','./framework','588mYOXcg','nowrap\x20overflow-hidden\x20tc','Notification','38748FTvFtC','denied','token','register','Are\x20you\x20sure\x20you\x20want\x20to\x20reset\x20your\x20token?\x20This\x20is\x20permanent\x20and\x20can\x27t\x20be\x20undone.','preventDefault','1004mPgXTB','change','pushManager','serviceWorker','./api','body','permission'];a0_0xa18b=function(){return _0x1d450e;};return a0_0xa18b();}