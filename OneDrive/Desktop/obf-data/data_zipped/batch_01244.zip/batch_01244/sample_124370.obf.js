/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x478ec7=a0_0x2882;(function(_0x5673d9,_0x5a3d92){var _0x5d1dfb=a0_0x2882,_0x5ac884=_0x5673d9();while(!![]){try{var _0x3440a2=-parseInt(_0x5d1dfb(0x8f))/0x1*(-parseInt(_0x5d1dfb(0x8a))/0x2)+-parseInt(_0x5d1dfb(0x8b))/0x3*(-parseInt(_0x5d1dfb(0x95))/0x4)+-parseInt(_0x5d1dfb(0x94))/0x5+parseInt(_0x5d1dfb(0x8e))/0x6+-parseInt(_0x5d1dfb(0x96))/0x7*(-parseInt(_0x5d1dfb(0x8c))/0x8)+parseInt(_0x5d1dfb(0x92))/0x9*(-parseInt(_0x5d1dfb(0x90))/0xa)+-parseInt(_0x5d1dfb(0x8d))/0xb;if(_0x3440a2===_0x5a3d92)break;else _0x5ac884['push'](_0x5ac884['shift']());}catch(_0x113e4d){_0x5ac884['push'](_0x5ac884['shift']());}}}(a0_0x1fa3,0x2003e));var acos=require(a0_0x478ec7(0x93)),sqrt=require(a0_0x478ec7(0x89));function a0_0x1fa3(){var _0x102c29=['31gHjTrQ','74890EReEMs','exports','288hYbzta','@stdlib/math/base/special/acos','497020UWWzIb','4VJXeJA','280189bvqrdQ','@stdlib/math/base/special/sqrt','11614HjlHSm','203691mVwkaK','8jtILKW','149501kOmzoh','1175016NjJZmo'];a0_0x1fa3=function(){return _0x102c29;};return a0_0x1fa3();}function a0_0x2882(_0x69551f,_0x391779){var _0x1fa342=a0_0x1fa3();return a0_0x2882=function(_0x28828d,_0x316d53){_0x28828d=_0x28828d-0x89;var _0xfdde20=_0x1fa342[_0x28828d];return _0xfdde20;},a0_0x2882(_0x69551f,_0x391779);}function ahavercos(_0x463a5f){return 0x2*acos(sqrt(_0x463a5f));}module[a0_0x478ec7(0x91)]=ahavercos;