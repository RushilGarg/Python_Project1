/**
 * HiPay Fullservice Magento
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Apache 2.0 Licence
 * that is bundled with this package in the file LICENSE.md.
 * It is also available through the world-wide-web at this URL:
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * @author    Kassim Belghait <kassim@sirateck.com>
 * @copyright Copyright (c) 2016 - HiPay
 * @license   http://www.apache.org/licenses/LICENSE-2.0 Apache 2.0 Licence
 * @link      https://github.com/hipay/hipay-fullservice-sdk-magento2
 */
var a0_0x40ea26=a0_0x2a1a;function a0_0x1e7b(){var _0x14ef26=['174dMSBea','jquery','770004cViKmY','1816101zhurHq','564776PzjPdB','hipay_bbva','25898PBDNZF','14dQcMNm','8531016OvQlOm','2065395HOPZDe','extend','498575jOosBG'];a0_0x1e7b=function(){return _0x14ef26;};return a0_0x1e7b();}function a0_0x2a1a(_0x202417,_0x35d16f){var _0x1e7b4c=a0_0x1e7b();return a0_0x2a1a=function(_0x2a1abb,_0x32e0c8){_0x2a1abb=_0x2a1abb-0x1b2;var _0x142795=_0x1e7b4c[_0x2a1abb];return _0x142795;},a0_0x2a1a(_0x202417,_0x35d16f);}(function(_0x3f4242,_0x285f7c){var _0x3e618a=a0_0x2a1a,_0x39942a=_0x3f4242();while(!![]){try{var _0x402299=-parseInt(_0x3e618a(0x1b9))/0x1+-parseInt(_0x3e618a(0x1b4))/0x2*(parseInt(_0x3e618a(0x1ba))/0x3)+-parseInt(_0x3e618a(0x1bc))/0x4+parseInt(_0x3e618a(0x1b7))/0x5+parseInt(_0x3e618a(0x1b6))/0x6+parseInt(_0x3e618a(0x1b5))/0x7*(parseInt(_0x3e618a(0x1b2))/0x8)+parseInt(_0x3e618a(0x1bd))/0x9;if(_0x402299===_0x285f7c)break;else _0x39942a['push'](_0x39942a['shift']());}catch(_0x19b2c3){_0x39942a['push'](_0x39942a['shift']());}}}(a0_0x1e7b,0xb3a24),define([a0_0x40ea26(0x1bb),'HiPay_FullserviceMagento/js/view/payment/method-renderer/hipay-astropay'],function(_0x3f544e,_0x52ea1d){'use strict';var _0x7c05fe=a0_0x40ea26;return _0x52ea1d[_0x7c05fe(0x1b8)]({'defaults':{'template':'HiPay_FullserviceMagento/payment/hipay-astropay','redirectAfterPlaceOrder':![]},'getCode':function(){var _0x187f0c=_0x7c05fe;return _0x187f0c(0x1b3);},'isActive':function(){return!![];}});}));