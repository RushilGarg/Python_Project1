/**
 * @author Tom De Caluwé
 * @copyright 2016 Tom De Caluwé
 * @license Apache-2.0
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
'use strict';var a0_0x153c62=a0_0x5ca7;(function(_0x3c1d7c,_0x28eb1b){var _0x3e8e4b=a0_0x5ca7,_0x437f52=_0x3c1d7c();while(!![]){try{var _0x50a45c=parseInt(_0x3e8e4b(0xc6))/0x1+-parseInt(_0x3e8e4b(0xbe))/0x2*(parseInt(_0x3e8e4b(0xbd))/0x3)+-parseInt(_0x3e8e4b(0xb6))/0x4*(parseInt(_0x3e8e4b(0xc7))/0x5)+parseInt(_0x3e8e4b(0xbf))/0x6*(parseInt(_0x3e8e4b(0xc5))/0x7)+-parseInt(_0x3e8e4b(0xbc))/0x8*(parseInt(_0x3e8e4b(0xb3))/0x9)+-parseInt(_0x3e8e4b(0xc1))/0xa+parseInt(_0x3e8e4b(0xc3))/0xb*(parseInt(_0x3e8e4b(0xba))/0xc);if(_0x50a45c===_0x28eb1b)break;else _0x437f52['push'](_0x437f52['shift']());}catch(_0x5b2316){_0x437f52['push'](_0x437f52['shift']());}}}(a0_0x5a78,0x72ca5));var Counter=function(){var _0x4e42c6=a0_0x5ca7;this[_0x4e42c6(0xb9)]={'segment':0x0,'element':0x0,'component':0x0};};function a0_0x5a78(){var _0x71d73d=['236616WxVdEs','22wFfrdV','168FSYjWT','segment','6755540kVdVnb','onopensegment','224972PtDQUm','onclosesegment','112588eykfTk','774767xlFrRY','5fVJksc','40095JBbWcm','exports','onclosecomponent','3405572fkFJLT','prototype','component','counts','996ZTjxEv','onelement','104tFlckW'];a0_0x5a78=function(){return _0x71d73d;};return a0_0x5a78();}function a0_0x5ca7(_0x3a872e,_0x145e75){var _0x5a785e=a0_0x5a78();return a0_0x5ca7=function(_0x5ca7ad,_0xe56af0){_0x5ca7ad=_0x5ca7ad-0xb3;var _0x18fae7=_0x5a785e[_0x5ca7ad];return _0x18fae7;},a0_0x5ca7(_0x3a872e,_0x145e75);}Counter[a0_0x153c62(0xb7)][a0_0x153c62(0xc2)]=function(){var _0x555d16=a0_0x153c62;this['counts'][_0x555d16(0xc0)]+=0x1;},Counter['prototype'][a0_0x153c62(0xbb)]=function(){var _0x139963=a0_0x153c62;this['counts']['element']+=0x1,this[_0x139963(0xb9)][_0x139963(0xb8)]=0x0;},Counter[a0_0x153c62(0xb7)]['onopencomponent']=function(){},Counter[a0_0x153c62(0xb7)][a0_0x153c62(0xb5)]=function(){var _0x1486bc=a0_0x153c62;this[_0x1486bc(0xb9)][_0x1486bc(0xb8)]+=+0x1;},Counter[a0_0x153c62(0xb7)][a0_0x153c62(0xc4)]=function(){var _0x22dec2=a0_0x153c62;this[_0x22dec2(0xb9)]['element']=0x0;},module[a0_0x153c62(0xb4)]=Counter;