/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x35fa(){var _0x47400b=['2735955QwqIHf','2235996PLvsOa','232661qkqGSc','1423667YBLBYa','1408uifJZw','log','5361whvRSb','4460720YPLQdt','./../lib','@stdlib/constants/float64/ninf','7xlWcGK','201302VjnaCC','6BDbPOb','30qSDhCb'];a0_0x35fa=function(){return _0x47400b;};return a0_0x35fa();}var a0_0x5517df=a0_0x55ca;(function(_0x46756f,_0x2dd246){var _0x3fdea6=a0_0x55ca,_0x5a5362=_0x46756f();while(!![]){try{var _0x1aa63f=parseInt(_0x3fdea6(0x1a1))/0x1*(-parseInt(_0x3fdea6(0x1a2))/0x2)+-parseInt(_0x3fdea6(0x19d))/0x3*(-parseInt(_0x3fdea6(0x19b))/0x4)+parseInt(_0x3fdea6(0x1a5))/0x5+parseInt(_0x3fdea6(0x1a3))/0x6*(parseInt(_0x3fdea6(0x1a8))/0x7)+-parseInt(_0x3fdea6(0x19e))/0x8+parseInt(_0x3fdea6(0x1a6))/0x9+parseInt(_0x3fdea6(0x1a4))/0xa*(parseInt(_0x3fdea6(0x1a7))/0xb);if(_0x1aa63f===_0x2dd246)break;else _0x5a5362['push'](_0x5a5362['shift']());}catch(_0x30320b){_0x5a5362['push'](_0x5a5362['shift']());}}}(a0_0x35fa,0x68d22));function a0_0x55ca(_0x3fc135,_0x2bf3ce){var _0x35fabb=a0_0x35fa();return a0_0x55ca=function(_0x55caae,_0x5858b1){_0x55caae=_0x55caae-0x19b;var _0x30e93f=_0x35fabb[_0x55caae];return _0x30e93f;},a0_0x55ca(_0x3fc135,_0x2bf3ce);}var PINF=require('@stdlib/constants/float64/pinf'),NINF=require(a0_0x5517df(0x1a0)),isInfinite=require(a0_0x5517df(0x19f));console[a0_0x5517df(0x19c)](isInfinite(PINF)),console[a0_0x5517df(0x19c)](isInfinite(NINF)),console[a0_0x5517df(0x19c)](isInfinite(0x5)),console[a0_0x5517df(0x19c)](isInfinite(NaN));