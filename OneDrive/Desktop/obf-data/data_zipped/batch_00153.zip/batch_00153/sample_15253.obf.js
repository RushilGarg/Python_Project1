/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0x148978=a0_0x4e8a;function a0_0x4e8a(_0x35ee5e,_0x199863){var _0x384898=a0_0x3848();return a0_0x4e8a=function(_0x4e8ade,_0x1da053){_0x4e8ade=_0x4e8ade-0x9e;var _0x577f6b=_0x384898[_0x4e8ade];return _0x577f6b;},a0_0x4e8a(_0x35ee5e,_0x199863);}(function(_0x48ece4,_0x515af3){var _0x551344=a0_0x4e8a,_0x53e360=_0x48ece4();while(!![]){try{var _0x1c5d46=-parseInt(_0x551344(0xa2))/0x1+parseInt(_0x551344(0xa7))/0x2+parseInt(_0x551344(0xa8))/0x3*(parseInt(_0x551344(0x9f))/0x4)+-parseInt(_0x551344(0xa1))/0x5+parseInt(_0x551344(0x9e))/0x6+-parseInt(_0x551344(0xa9))/0x7*(parseInt(_0x551344(0xa3))/0x8)+parseInt(_0x551344(0xaa))/0x9*(-parseInt(_0x551344(0xb0))/0xa);if(_0x1c5d46===_0x515af3)break;else _0x53e360['push'](_0x53e360['shift']());}catch(_0x7d5dc){_0x53e360['push'](_0x53e360['shift']());}}}(a0_0x3848,0xeccc5));function a0_0x3848(){var _0x3d482c=['mean','160BnYGvZ','variance','4024080YlesDd','571820SQpFcv','cdf','48155UipZGW','720691wNhXdw','72bUtLWL','Mean\x20=\x20%d','Variance\x20=\x20%d','./../lib','1952972kKDhgK','12ZVhcPW','381101OVctVP','16173zjnPFl','mode','Mode\x20=\x20%d','log','F(10.5)\x20=\x20%d'];a0_0x3848=function(){return _0x3d482c;};return a0_0x3848();}var Hypergeometric=require(a0_0x148978(0xa6)),hypergeometric=new Hypergeometric(0x64,0x32,0x14),mu=hypergeometric[a0_0x148978(0xaf)];console[a0_0x148978(0xad)](a0_0x148978(0xa4),mu);var mode=hypergeometric[a0_0x148978(0xab)];console[a0_0x148978(0xad)](a0_0x148978(0xac),mode);var s2=hypergeometric[a0_0x148978(0xb1)];console[a0_0x148978(0xad)](a0_0x148978(0xa5),s2);var y=hypergeometric[a0_0x148978(0xa0)](10.5);console[a0_0x148978(0xad)](a0_0x148978(0xae),y);