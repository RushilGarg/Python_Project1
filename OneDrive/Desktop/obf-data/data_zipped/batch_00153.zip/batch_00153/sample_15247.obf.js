/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0xb01e(_0x55ba11,_0x410a94){var _0x163103=a0_0x1631();return a0_0xb01e=function(_0xb01e3a,_0x1a9b23){_0xb01e3a=_0xb01e3a-0x114;var _0x285e89=_0x163103[_0xb01e3a];return _0x285e89;},a0_0xb01e(_0x55ba11,_0x410a94);}var a0_0x43b5fd=a0_0xb01e;(function(_0x34c2ea,_0x10319b){var _0x17a928=a0_0xb01e,_0x1d9b1f=_0x34c2ea();while(!![]){try{var _0x1968b3=-parseInt(_0x17a928(0x11c))/0x1+-parseInt(_0x17a928(0x119))/0x2+-parseInt(_0x17a928(0x116))/0x3+parseInt(_0x17a928(0x118))/0x4*(parseInt(_0x17a928(0x117))/0x5)+parseInt(_0x17a928(0x115))/0x6*(-parseInt(_0x17a928(0x124))/0x7)+-parseInt(_0x17a928(0x123))/0x8+parseInt(_0x17a928(0x121))/0x9;if(_0x1968b3===_0x10319b)break;else _0x1d9b1f['push'](_0x1d9b1f['shift']());}catch(_0x1e39fc){_0x1d9b1f['push'](_0x1d9b1f['shift']());}}}(a0_0x1631,0x932b9));var tape=require('tape'),isNegativeNumber=require(a0_0x43b5fd(0x114));function a0_0x1631(){var _0x550418=['1490817PPuyJB','485665WvrhnD','4zujpLl','1406538CAfOXK','isPrimitive','function','513893CxhXZW','equal','main\x20export\x20is\x20a\x20function','export\x20is\x20a\x20function','attached\x20to\x20the\x20main\x20export\x20is\x20a\x20method\x20to\x20test\x20for\x20a\x20number\x20object\x20having\x20a\x20negative\x20value','25318314DWqdfi','end','4423104PeKyTh','49qDgPHU','isObject','./../lib','34698nfxOFm'];a0_0x1631=function(){return _0x550418;};return a0_0x1631();}tape('main\x20export\x20is\x20a\x20function',function test(_0x42872){var _0x4ad892=a0_0x43b5fd;_0x42872['ok'](!![],__filename),_0x42872[_0x4ad892(0x11d)](typeof isNegativeNumber,_0x4ad892(0x11b),_0x4ad892(0x11e)),_0x42872[_0x4ad892(0x122)]();}),tape('attached\x20to\x20the\x20main\x20export\x20is\x20a\x20method\x20to\x20test\x20for\x20a\x20primitive\x20number\x20having\x20a\x20negative\x20value',function test(_0x430d25){var _0x32fbc0=a0_0x43b5fd;_0x430d25[_0x32fbc0(0x11d)](typeof isNegativeNumber[_0x32fbc0(0x11a)],_0x32fbc0(0x11b),_0x32fbc0(0x11f)),_0x430d25['end']();}),tape(a0_0x43b5fd(0x120),function test(_0x148b98){var _0x2fb46e=a0_0x43b5fd;_0x148b98[_0x2fb46e(0x11d)](typeof isNegativeNumber[_0x2fb46e(0x125)],_0x2fb46e(0x11b),_0x2fb46e(0x11f)),_0x148b98['end']();});