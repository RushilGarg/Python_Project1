/**
* brief description of file
*
* @author      Tom Murtagh
* @author      Kim Jackson
* @author      Ian Johnson   <ian.johnson@sydney.edu.au>
* @author      Stephen White   <stephen.white@sydney.edu.au>
* @author      Artem Osmakov   <artem.osmakov@sydney.edu.au>
* @copyright   (C) 2005-2013 University of Sydney
* @link        http://Sydney.edu.au/Heurist
* @version     3.1.0
* @license     http://www.gnu.org/licenses/gpl-3.0.txt GNU License 3.0
* @package     Heurist academic knowledge management system
* @subpackage  !!!subpackagename for file such as Administration, Search, Edit, Application, Library
*/
function a0_0x797d(_0x511c22,_0x4ea911){var _0x4a8889=a0_0x4a88();return a0_0x797d=function(_0x797da,_0xdb6255){_0x797da=_0x797da-0x71;var _0x57819d=_0x4a8889[_0x797da];return _0x57819d;},a0_0x797d(_0x511c22,_0x4ea911);}function a0_0x4a88(){var _0x575416=['src','getTime','251176tumqPn','contentType','type','&u=','26523edBRIm','538277wZhPdr','getElementById','records/add/addRecordPopup.php?t=','2749092DcQupA','2862696xRPsAg','__heurist_bookmarklet_div','setTimeout','import/bookmarklet/bookmarkletPopup.php?','init','title','http://heuristscholar.org/h3/','getElementsByTagName','slice','createElement','9ZHfOab','384XZkutA','8312380JjTveg','text/javascript','613375LDDXHS'];a0_0x4a88=function(){return _0x575416;};return a0_0x4a88();}(function(_0x465408,_0x265fb3){var _0x46ef2a=a0_0x797d,_0x1f3ad0=_0x465408();while(!![]){try{var _0x351aa6=-parseInt(_0x46ef2a(0x86))/0x1+-parseInt(_0x46ef2a(0x81))/0x2+-parseInt(_0x46ef2a(0x85))/0x3*(parseInt(_0x46ef2a(0x7b))/0x4)+parseInt(_0x46ef2a(0x7c))/0x5+parseInt(_0x46ef2a(0x89))/0x6+-parseInt(_0x46ef2a(0x7e))/0x7+parseInt(_0x46ef2a(0x8a))/0x8*(parseInt(_0x46ef2a(0x7a))/0x9);if(_0x351aa6===_0x265fb3)break;else _0x1f3ad0['push'](_0x1f3ad0['shift']());}catch(_0x81a7fb){_0x1f3ad0['push'](_0x1f3ad0['shift']());}}}(a0_0x4a88,0xd66bd));_0x1709ce:(function(){var _0xa1c9b4=a0_0x797d;h=_0xa1c9b4(0x76),d=document,c=d[_0xa1c9b4(0x82)];if(c=='text/html'||!c){if(d[_0xa1c9b4(0x87)](_0xa1c9b4(0x71)))return Heurist[_0xa1c9b4(0x74)]();s=d[_0xa1c9b4(0x79)]('script'),s[_0xa1c9b4(0x83)]=_0xa1c9b4(0x7d),s[_0xa1c9b4(0x7f)]=(h+_0xa1c9b4(0x73)+new Date()[_0xa1c9b4(0x80)]())[_0xa1c9b4(0x78)](0x0,-0x8),d[_0xa1c9b4(0x77)]('head')[0x0]['appendChild'](s);}else e=encodeURIComponent,w=open(h+_0xa1c9b4(0x88)+e(d[_0xa1c9b4(0x75)])+_0xa1c9b4(0x84)+e(location['href'])),window[_0xa1c9b4(0x72)]('w.focus()',0xc8);}());