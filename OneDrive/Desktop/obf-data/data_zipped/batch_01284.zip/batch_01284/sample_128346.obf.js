/**
* @license Apache-2.0
*
* Copyright (c) 2020 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';function a0_0x254c(){var _0x3ccea4=['7405995bXtPzt','4itICCg','2HwbwRU','334652EitdwE','exports','185040MpXzhi','join','3265338GWzoyp','288ivzcQR','644iEszrr','./native.js','136784VaiTzG','@stdlib/utils/try-require','10096141TZlDOH','4929150DTmOxf'];a0_0x254c=function(){return _0x3ccea4;};return a0_0x254c();}function a0_0xfd4d(_0x440bd9,_0x64328){var _0x254ccd=a0_0x254c();return a0_0xfd4d=function(_0xfd4de5,_0x129246){_0xfd4de5=_0xfd4de5-0xb5;var _0xb99c21=_0x254ccd[_0xfd4de5];return _0xb99c21;},a0_0xfd4d(_0x440bd9,_0x64328);}var a0_0x41711c=a0_0xfd4d;(function(_0x4548ee,_0x2887d6){var _0x4864eb=a0_0xfd4d,_0x72f6d=_0x4548ee();while(!![]){try{var _0x5de22c=-parseInt(_0x4864eb(0xba))/0x1*(parseInt(_0x4864eb(0xb9))/0x2)+parseInt(_0x4864eb(0xbe))/0x3*(-parseInt(_0x4864eb(0xb8))/0x4)+parseInt(_0x4864eb(0xb7))/0x5+parseInt(_0x4864eb(0xb6))/0x6+-parseInt(_0x4864eb(0xc0))/0x7*(parseInt(_0x4864eb(0xc2))/0x8)+parseInt(_0x4864eb(0xbf))/0x9*(parseInt(_0x4864eb(0xbc))/0xa)+parseInt(_0x4864eb(0xb5))/0xb;if(_0x5de22c===_0x2887d6)break;else _0x72f6d['push'](_0x72f6d['shift']());}catch(_0x5c483b){_0x72f6d['push'](_0x72f6d['shift']());}}}(a0_0x254c,0xc75b9));var join=require('path')[a0_0x41711c(0xbd)],tryRequire=require(a0_0x41711c(0xc3)),dnannsumkbn=require('./main.js'),tmp=tryRequire(join(__dirname,a0_0x41711c(0xc1)));!(tmp instanceof Error)&&(dnannsumkbn=tmp);module[a0_0x41711c(0xbb)]=dnannsumkbn;