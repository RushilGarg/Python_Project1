function a0_0x4eea(){const _0x28643e=['6QFbNue','3323504RLJdMD','158442tnrSnu','36yUzkhX','41282710JGQAMN','5579854eVGmiP','11YlKPrS','1548322vDozPP','306766hBehOY','6821604OTlvQC','115AaZtfz'];a0_0x4eea=function(){return _0x28643e;};return a0_0x4eea();}(function(_0x4994e2,_0x3c6e2b){const _0x4e924f=a0_0x18a4,_0x409297=_0x4994e2();while(!![]){try{const _0x18488e=-parseInt(_0x4e924f(0x1e8))/0x1+parseInt(_0x4e924f(0x1de))/0x2*(parseInt(_0x4e924f(0x1e1))/0x3)+-parseInt(_0x4e924f(0x1df))/0x4+-parseInt(_0x4e924f(0x1e0))/0x5*(-parseInt(_0x4e924f(0x1e3))/0x6)+parseInt(_0x4e924f(0x1e6))/0x7+-parseInt(_0x4e924f(0x1e2))/0x8*(parseInt(_0x4e924f(0x1e4))/0x9)+-parseInt(_0x4e924f(0x1e5))/0xa*(-parseInt(_0x4e924f(0x1e7))/0xb);if(_0x18488e===_0x3c6e2b)break;else _0x409297['push'](_0x409297['shift']());}catch(_0x4dda99){_0x409297['push'](_0x409297['shift']());}}}(a0_0x4eea,0xe198d));import a0_0x46ccbb from'graphql-tag';import{operationFieldsFragment}from'./fragments';export const createOperationMutation=a0_0x46ccbb`
  mutation createOperation($operation: OperationInput!) {
    operation: createOperation(operation: $operation) {
      ...operationFields
    }
  }
  ${operationFieldsFragment}
`;export const updateOperationMutation=a0_0x46ccbb`
  mutation updateOperation($id: ID!, $operation: OperationInput!) {
    operation: updateOperation(id: $id, operation: $operation) {
      ...operationFields
    }
  }
  ${operationFieldsFragment}
`;function a0_0x18a4(_0x66429,_0x29b5a6){const _0x4eea83=a0_0x4eea();return a0_0x18a4=function(_0x18a4a2,_0x2e22dc){_0x18a4a2=_0x18a4a2-0x1de;let _0x369e98=_0x4eea83[_0x18a4a2];return _0x369e98;},a0_0x18a4(_0x66429,_0x29b5a6);}export const addOperationProductMutation=a0_0x46ccbb`
  mutation addOperationProduct($id: ID!, $productId: ID!) {
    result: addOperationProduct(id: $id, productId: $productId)
  }
`;export const removeOperationProductMutation=a0_0x46ccbb`
  mutation removeOperationProduct($id: ID!, $productId: ID!) {
    result: removeOperationProduct(id: $id, productId: $productId)
  }
`;