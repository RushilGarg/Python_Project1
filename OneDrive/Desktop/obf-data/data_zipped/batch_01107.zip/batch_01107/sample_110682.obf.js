/**
* @license Apache-2.0
*
* Copyright (c) 2018 The Stdlib Authors.
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*    http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
*/
'use strict';var a0_0xc66c1a=a0_0x2bbe;(function(_0x4bc451,_0x4e245c){var _0x19c4ac=a0_0x2bbe,_0x2a145f=_0x4bc451();while(!![]){try{var _0x42c853=-parseInt(_0x19c4ac(0xc3))/0x1*(parseInt(_0x19c4ac(0xc2))/0x2)+parseInt(_0x19c4ac(0xcc))/0x3*(-parseInt(_0x19c4ac(0xca))/0x4)+-parseInt(_0x19c4ac(0xc9))/0x5+-parseInt(_0x19c4ac(0xc6))/0x6+parseInt(_0x19c4ac(0xc4))/0x7*(parseInt(_0x19c4ac(0xcb))/0x8)+parseInt(_0x19c4ac(0xc8))/0x9*(parseInt(_0x19c4ac(0xc7))/0xa)+parseInt(_0x19c4ac(0xc0))/0xb*(parseInt(_0x19c4ac(0xcd))/0xc);if(_0x42c853===_0x4e245c)break;else _0x2a145f['push'](_0x2a145f['shift']());}catch(_0x51cda6){_0x2a145f['push'](_0x2a145f['shift']());}}}(a0_0x49da,0x7df54));function a0_0x49da(){var _0x5d430e=['6044QikMNm','664Yoetzf','1821GMzwbt','24OwdAUa','17623254ihXVwo','exports','450236sMUuYo','4yVhtQG','49994wgVCLJ','./beta.js','5479056rdjtvB','420llICrx','81855OhTELj','4661275CFdUCw'];a0_0x49da=function(){return _0x5d430e;};return a0_0x49da();}var beta=require(a0_0xc66c1a(0xc5));function a0_0x2bbe(_0xe483f9,_0xea2f48){var _0x49da93=a0_0x49da();return a0_0x2bbe=function(_0x2bbe2c,_0x45a73a){_0x2bbe2c=_0x2bbe2c-0xc0;var _0x34b4da=_0x49da93[_0x2bbe2c];return _0x34b4da;},a0_0x2bbe(_0xe483f9,_0xea2f48);}module[a0_0xc66c1a(0xc1)]=beta;