/**
 * @fileoverview Lego WeDo 2.0 Commands
 *
 * @license Copyright 2018 The Coding with Chrome Authors.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *   http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * @author mbordihn@google.com (Markus Bordihn)
 */
const a0_0x53aca4=a0_0x488f;function a0_0x34b0(){const _0x56d2cc=['playTone','1990294aTKqPj','PORT1','3583926MpBeqN','6063028USwFqi','setCharacteristic','730278qqdbOW','writeByte','writeShort','5ZPnHZd','module','setRGB','Channel','00001565-1212-efde-1523-785feabcd123','8HwHpTa','567697vRwrTz','11GLmRzi','49FSqQql','writeChannel','cwc.lib.protocol.lego.weDo2.Buffer','cwc.lib.protocol.lego.weDo2.Commands','cwc.lib.protocol.lego.weDo2.Constants','writeLength','3390414SEkzWX','11975870smvNMT','TONE','require'];a0_0x34b0=function(){return _0x56d2cc;};return a0_0x34b0();}(function(_0x2fbaa4,_0x279455){const _0x334213=a0_0x488f,_0x191573=_0x2fbaa4();while(!![]){try{const _0x3b2ffe=-parseInt(_0x334213(0x15c))/0x1+parseInt(_0x334213(0x14e))/0x2+-parseInt(_0x334213(0x149))/0x3+-parseInt(_0x334213(0x151))/0x4*(-parseInt(_0x334213(0x156))/0x5)+-parseInt(_0x334213(0x153))/0x6*(parseInt(_0x334213(0x15e))/0x7)+-parseInt(_0x334213(0x15b))/0x8*(parseInt(_0x334213(0x150))/0x9)+-parseInt(_0x334213(0x14a))/0xa*(-parseInt(_0x334213(0x15d))/0xb);if(_0x3b2ffe===_0x279455)break;else _0x191573['push'](_0x191573['shift']());}catch(_0x1d40a2){_0x191573['push'](_0x191573['shift']());}}}(a0_0x34b0,0xb9a83),goog[a0_0x53aca4(0x157)](a0_0x53aca4(0x161)));function a0_0x488f(_0x526750,_0x7c33b){const _0x34b042=a0_0x34b0();return a0_0x488f=function(_0x488f1b,_0x354686){_0x488f1b=_0x488f1b-0x148;let _0x10c13d=_0x34b042[_0x488f1b];return _0x10c13d;},a0_0x488f(_0x526750,_0x7c33b);}const Buffer=goog['require'](a0_0x53aca4(0x160)),Constants=goog[a0_0x53aca4(0x14c)](a0_0x53aca4(0x162)),defaultCharacteristic=a0_0x53aca4(0x15a);exports[a0_0x53aca4(0x14d)]=function(_0x35abee,_0x5df22a=0x1f4){const _0x37a4ca=a0_0x53aca4;return new Buffer()['setCharacteristic'](defaultCharacteristic)['writeChannel'](Constants[_0x37a4ca(0x159)][_0x37a4ca(0x14b)])['writeByte'](0x2)[_0x37a4ca(0x148)](0x4)['writeShort'](_0x35abee)[_0x37a4ca(0x155)](_0x5df22a);},exports[a0_0x53aca4(0x158)]=function(_0x5a4504=0x0){const _0x89c416=a0_0x53aca4;return new Buffer()[_0x89c416(0x152)](defaultCharacteristic)[_0x89c416(0x15f)](Constants['Channel']['RGB'])[_0x89c416(0x154)](0x4)[_0x89c416(0x148)](0x1)[_0x89c416(0x154)](_0x5a4504);},exports['movePower']=function(_0x2b90cd,_0x304ee1=Constants[a0_0x53aca4(0x159)][a0_0x53aca4(0x14f)]){const _0x28f17c=a0_0x53aca4;return new Buffer()[_0x28f17c(0x152)](defaultCharacteristic)['writeChannel'](_0x304ee1)[_0x28f17c(0x154)](0x1)[_0x28f17c(0x148)](0x1)[_0x28f17c(0x154)](_0x2b90cd);},exports['setSensorMode']=function(_0x3115e7,_0x469bfc,_0xd3b6b0=0x0){const _0x2f1001=a0_0x53aca4;return new Buffer()['setCharacteristic']('00001563-1212-efde-1523-785feabcd123')['writeByte'](0x1)[_0x2f1001(0x154)](0x2)[_0x2f1001(0x15f)](_0x3115e7)[_0x2f1001(0x154)](_0x469bfc)[_0x2f1001(0x154)](_0xd3b6b0)[_0x2f1001(0x154)](0x1)[_0x2f1001(0x154)](0x0)[_0x2f1001(0x154)](0x0)['writeByte'](0x0)['writeByte'](0x2)[_0x2f1001(0x154)](0x1);};