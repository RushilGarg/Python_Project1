const a0_0x58f78c=a0_0x47e5;(function(_0x31dc21,_0x54fd1e){const _0x148fac=a0_0x47e5,_0x21e61b=_0x31dc21();while(!![]){try{const _0x1be034=-parseInt(_0x148fac(0x110))/0x1*(-parseInt(_0x148fac(0x121))/0x2)+-parseInt(_0x148fac(0x122))/0x3*(-parseInt(_0x148fac(0xfe))/0x4)+parseInt(_0x148fac(0x11e))/0x5*(-parseInt(_0x148fac(0x10c))/0x6)+-parseInt(_0x148fac(0x10a))/0x7+-parseInt(_0x148fac(0x112))/0x8+parseInt(_0x148fac(0x12e))/0x9+parseInt(_0x148fac(0x11f))/0xa*(parseInt(_0x148fac(0x113))/0xb);if(_0x1be034===_0x54fd1e)break;else _0x21e61b['push'](_0x21e61b['shift']());}catch(_0x1a46d3){_0x21e61b['push'](_0x21e61b['shift']());}}}(a0_0x1199,0x1cc3f));import{PolymerElement}from'../../../../node_modules/@polymer/polymer/polymer-element.js';import{html}from'../../../../node_modules/@polymer/polymer/lib/utils/html-tag.js';import'../../../../node_modules/@polymer/iron-icon/iron-icon.js';import'../../../../node_modules/@polymer/paper-icon-button/paper-icon-button.js';import'../../../../node_modules/@polymer/paper-item/paper-icon-item.js';function a0_0x47e5(_0x2ae67f,_0x5c1b65){const _0x1199bc=a0_0x1199();return a0_0x47e5=function(_0x47e507,_0x13c3ce){_0x47e507=_0x47e507-0xfa;let _0x570fc7=_0x1199bc[_0x47e507];return _0x570fc7;},a0_0x47e5(_0x2ae67f,_0x5c1b65);}import'../../../../node_modules/@polymer/paper-item/paper-item.js';import'../../../../node_modules/@polymer/paper-listbox/paper-listbox.js';function a0_0x1199(){const _0x57cabf=['JSON','contentType','item','Form','application/json','772261uyNEpl','files','6gnAMlI','value','define','Plain','66131phpOQP','x-www-form-urlencoded','474512fCcrkh','22BYcBSU','_onContentTypeChanged','form-data','ace/mode/text','ace/mode/json','rester-ace-input','some','length','getSuggestedContentType','ready','settings','587290xniUfD','925920ZUVJsP','maybeEncodeVariableValue','2soFKUV','765nPifHg','xml','notifyVisibilityChanged','title','XML','_isInputOptionSelected','_selectInputOption','rester-body-input','beautifyMethod','close','includes','json','657207YUgwoa','template','shadowRoot','selectedInputOption','isInputTypeAce','1264gGcyTp','plain','_computeAceMaxLines(settings.requestBodyFullSize)','options','contentTypeSearch','application/x-www-form-urlencoded','_toggleFullSize'];a0_0x1199=function(){return _0x57cabf;};return a0_0x1199();}import'../../../../node_modules/@polymer/paper-menu-button/paper-menu-button.js';import a0_0x3d7d1f from'../../../../node_modules/frigus02-vkbeautify/vkbeautify.js';import'../styles/rester-icons.js';import'./rester-ace-input.js';import'./rester-form-data-input.js';import a0_0x6a1932 from'../data/rester-data-settings-mixin.js';import{formatJson}from'../data/scripts/format-json.js';class RESTerBodyInput extends a0_0x6a1932(PolymerElement){static get[a0_0x58f78c(0xfa)](){return html`
            <style>
                :host {
                    display: block;
                    position: relative;
                }

                #options {
                    position: absolute;
                    top: 8px;
                    right: 16px; /* Make sure the scrollbar is clickable */
                    z-index: 10;
                    padding: 0;
                    background-color: var(--primary-background-color);

                    --paper-menu: {
                        width: 256px;
                    }
                }

                .menu-item-divider {
                    border-top: 1px solid var(--divider-color);
                    margin: 4px 0;
                }

                rester-ace-input {
                    padding-top: 8px;
                }

                rester-form-data-input {
                    margin-right: 40px;
                }
            </style>

            <paper-menu-button
                id="options"
                horizontal-align="right"
                restore-focus-on-close
            >
                <paper-icon-button
                    slot="dropdown-trigger"
                    icon="more-vert"
                ></paper-icon-button>
                <paper-listbox
                    slot="dropdown-content"
                    selectable="[role='menuitemradio']"
                >
                    <template is="dom-repeat" items="[[inputOptions]]">
                        <paper-icon-item
                            role="menuitemradio"
                            on-tap="_selectInputOption"
                        >
                            <iron-icon
                                slot="item-icon"
                                icon="check"
                                hidden$="[[!_isInputOptionSelected(item, selectedInputOption)]]"
                            ></iron-icon>
                            [[item.title]]
                        </paper-icon-item>
                    </template>
                    <div
                        class="menu-item-divider"
                        hidden$="[[!selectedInputOption.isInputTypeAce]]"
                    ></div>
                    <paper-icon-item
                        role="menuitemcheckbox"
                        hidden$="[[!selectedInputOption.isInputTypeAce]]"
                        on-tap="_toggleFullSize"
                    >
                        <iron-icon
                            slot="item-icon"
                            icon="check"
                            hidden$="[[!settings.requestBodyFullSize]]"
                        ></iron-icon>
                        Full Size
                    </paper-icon-item>
                    <div
                        class="menu-item-divider"
                        hidden$="[[!selectedInputOption.beautifyMethod]]"
                    ></div>
                    <paper-icon-item
                        role="menuitem"
                        hidden$="[[!selectedInputOption.beautifyMethod]]"
                        on-tap="_beautify"
                    >
                        <iron-icon
                            slot="item-icon"
                            icon="format-paint"
                        ></iron-icon>
                        Beautify
                    </paper-icon-item>
                </paper-listbox>
            </paper-menu-button>

            <template
                is="dom-if"
                if="[[selectedInputOption.isInputTypeAce]]"
                restamp
            >
                <rester-ace-input
                    mode="[[selectedInputOption.aceMode]]"
                    value="{{value}}"
                    max-lines="[[aceMaxLines]]"
                    disable-search="[[settings.requestBodyFullSize]]"
                >
                </rester-ace-input>
            </template>

            <template
                is="dom-if"
                if="[[selectedInputOption.isInputTypeForm]]"
                restamp
            >
                <rester-form-data-input value="{{value}}" files="{{files}}">
                </rester-form-data-input>
            </template>
        `;}static get['is'](){const _0x464ffd=a0_0x58f78c;return _0x464ffd(0x129);}static get['properties'](){const _0x44d539=a0_0x58f78c;return{'value':{'type':String,'notify':!![],'value':''},'files':{'type':Object},'contentType':{'type':String,'observer':_0x44d539(0x114)},'inputOptions':{'type':Array,'readOnly':!![],'value':[{'title':_0x44d539(0x10f),'isInputTypeAce':!![],'contentTypeSearch':[_0x44d539(0xff)],'aceMode':_0x44d539(0x116)},{'title':'JSON','isInputTypeAce':!![],'contentTypeSearch':[_0x44d539(0x12d)],'aceMode':_0x44d539(0x117),'beautifyMethod':'json'},{'title':_0x44d539(0x126),'isInputTypeAce':!![],'contentTypeSearch':[_0x44d539(0x123)],'aceMode':'ace/mode/xml','beautifyMethod':_0x44d539(0x123)},{'title':_0x44d539(0x108),'isInputTypeForm':!![],'contentTypeSearch':[_0x44d539(0x111),_0x44d539(0x115)]}]},'selectedInputOption':Object,'aceMaxLines':{'type':Number,'computed':_0x44d539(0x100)}};}[a0_0x58f78c(0x11c)](){const _0x410c7b=a0_0x58f78c;super[_0x410c7b(0x11c)](),this[_0x410c7b(0xfc)]=this['inputOptions'][0x0];}[a0_0x58f78c(0x11b)](){const _0xb54965=a0_0x58f78c;if(this[_0xb54965(0xfc)]['title']===_0xb54965(0x105))return _0xb54965(0x109);else{if(this[_0xb54965(0xfc)][_0xb54965(0x125)]===_0xb54965(0x126))return'application/xml';else{if(this[_0xb54965(0xfc)][_0xb54965(0x125)]==='Form')return this[_0xb54965(0x10b)]&&Object['keys'](this['files'])[_0xb54965(0x11a)]>0x0?'multipart/form-data':_0xb54965(0x103);}}}[a0_0x58f78c(0x120)](_0x448e3f){const _0x4dd74f=a0_0x58f78c;if(this[_0x4dd74f(0xfc)][_0x4dd74f(0x125)]==='Form')return encodeURIComponent(_0x448e3f);return _0x448e3f;}[a0_0x58f78c(0x124)](){const _0x55a59f=a0_0x58f78c;this[_0x55a59f(0xfc)][_0x55a59f(0xfd)]&&this[_0x55a59f(0xfb)]['querySelector'](_0x55a59f(0x118))['notifyVisibilityChanged']();}['_computeAceMaxLines'](_0x7d3cb4){return _0x7d3cb4?Infinity:0x14;}[a0_0x58f78c(0x114)](){const _0x465abc=a0_0x58f78c,_0x48ccaa=(this[_0x465abc(0x106)]||'')['toLowerCase'](),_0x290d97=this['inputOptions']['find'](_0x5af2cf=>_0x5af2cf[_0x465abc(0x102)]&&_0x5af2cf[_0x465abc(0x102)][_0x465abc(0x119)](_0x162cb9=>_0x48ccaa[_0x465abc(0x12c)](_0x162cb9)));_0x290d97&&(this[_0x465abc(0xfc)]=_0x290d97);}[a0_0x58f78c(0x127)](_0x385aae,_0x31454f){return _0x31454f===_0x385aae;}[a0_0x58f78c(0x128)](_0x234fa8){const _0x154193=a0_0x58f78c;this['selectedInputOption']=_0x234fa8['model'][_0x154193(0x107)];}[a0_0x58f78c(0x104)](){const _0x15ca86=a0_0x58f78c;this['$']['options']['close'](),this['settings']['requestBodyFullSize']=!this[_0x15ca86(0x11d)]['requestBodyFullSize'];}['_beautify'](){const _0x4faf6e=a0_0x58f78c;this['$'][_0x4faf6e(0x101)][_0x4faf6e(0x12b)]();if(this['selectedInputOption'][_0x4faf6e(0x12a)]===_0x4faf6e(0x12d))this[_0x4faf6e(0x10d)]=formatJson(this[_0x4faf6e(0x10d)]);else this[_0x4faf6e(0xfc)][_0x4faf6e(0x12a)]===_0x4faf6e(0x123)&&(this[_0x4faf6e(0x10d)]=a0_0x3d7d1f[_0x4faf6e(0x123)](this[_0x4faf6e(0x10d)],0x4));}}customElements[a0_0x58f78c(0x10e)](RESTerBodyInput['is'],RESTerBodyInput);