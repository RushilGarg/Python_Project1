/*
* 2007-2012 PrestaShop
*
* NOTICE OF LICENSE
*
* This source file is subject to the Open Software License (OSL 3.0)
* that is bundled with this package in the file LICENSE.txt.
* It is also available through the world-wide-web at this URL:
* http://opensource.org/licenses/osl-3.0.php
* If you did not receive a copy of the license and are unable to
* obtain it through the world-wide-web, please send an email
* to license@prestashop.com so we can send you a copy immediately.
*
* DISCLAIMER
*
* Do not edit or add to this file if you wish to upgrade PrestaShop to newer
* versions in the future. If you wish to customize PrestaShop for your
* needs please refer to http://www.prestashop.com for more information.
*
*  @author PrestaShop SA <contact@prestashop.com>
*  @copyright  2007-2012 PrestaShop SA
*  @license    http://opensource.org/licenses/osl-3.0.php  Open Software License (OSL 3.0)
*  International Registered Trademark & Property of PrestaShop SA
*/
function a0_0xcaca(_0x2b8daf,_0xdbad21){var _0x1bc805=a0_0x1bc8();return a0_0xcaca=function(_0xcaca30,_0x305df6){_0xcaca30=_0xcaca30-0xf2;var _0x2a005d=_0x1bc805[_0xcaca30];return _0x2a005d;},a0_0xcaca(_0x2b8daf,_0xdbad21);}function a0_0x1bc8(){var _0xc7e389=['12igyYPh','fail','204172CzGgtB','259816puXWnQ','native','<br\x20/>','userInfos','395044DewlAu','52908NnyRjN','html','1505400VaZGkp','removeClass','1319304VhOtVn','1735090RiIsrM','slideDown','input[name=PS_MAIL_SMTP_PORT]','input[name=PS_MAIL_METHOD]:checked','<img\x20src=\x22../img/admin/ajax-loader.gif\x22\x20alt=\x22\x22\x20/>','ajax','addClass','#testEmail[value=]','#mailResultCheck','#testEmail','AdminEmails','test','smtp','slow','input[name=PS_MAIL_SERVER]','input[name=PS_MAIL_USER]','val','sendMailTest'];a0_0x1bc8=function(){return _0xc7e389;};return a0_0x1bc8();}(function(_0x4d3e9c,_0x7eee55){var _0x7daf12=a0_0xcaca,_0x4694a3=_0x4d3e9c();while(!![]){try{var _0x57e7c8=-parseInt(_0x7daf12(0xfc))/0x1+parseInt(_0x7daf12(0xf7))/0x2*(parseInt(_0x7daf12(0xf5))/0x3)+parseInt(_0x7daf12(0xfd))/0x4+-parseInt(_0x7daf12(0xff))/0x5+parseInt(_0x7daf12(0x101))/0x6+parseInt(_0x7daf12(0x102))/0x7+parseInt(_0x7daf12(0xf8))/0x8;if(_0x57e7c8===_0x7eee55)break;else _0x4694a3['push'](_0x4694a3['shift']());}catch(_0x20b2fa){_0x4694a3['push'](_0x4694a3['shift']());}}}(a0_0x1bc8,0x3718e),verifMailREGEX=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/);function verifyMail(_0x3df312,_0x276e1c){var _0x11fb92=a0_0xcaca;$(_0x11fb92(0x10a))[_0x11fb92(0x100)]('ok')[_0x11fb92(0x100)](_0x11fb92(0xf6))[_0x11fb92(0xfe)](_0x11fb92(0x106)),$(_0x11fb92(0x10a))[_0x11fb92(0x103)](_0x11fb92(0x10f));if($(_0x11fb92(0x109))['length']>0x0)return $('#mailResultCheck')[_0x11fb92(0x108)](_0x11fb92(0xf6))[_0x11fb92(0x100)]('ok')[_0x11fb92(0x100)](_0x11fb92(0xfb))[_0x11fb92(0xfe)](errorMail),![];else{if(!verifMailREGEX[_0x11fb92(0x10d)]($(_0x11fb92(0x10b))[_0x11fb92(0xf3)]()))return $(_0x11fb92(0x10a))[_0x11fb92(0x108)](_0x11fb92(0xf6))['removeClass']('ok')[_0x11fb92(0x100)](_0x11fb92(0xfb))['html'](errorMail),![];else $[_0x11fb92(0x107)]({'url':'index.php','cache':![],'type':'POST','data':{'mailMethod':$(_0x11fb92(0x105))[_0x11fb92(0xf3)]()==0x2?_0x11fb92(0x10e):_0x11fb92(0xf9),'smtpSrv':$(_0x11fb92(0x110))['val'](),'testEmail':$(_0x11fb92(0x10b))[_0x11fb92(0xf3)](),'smtpLogin':$(_0x11fb92(0xf2))[_0x11fb92(0xf3)](),'smtpPassword':$('input[name=PS_MAIL_PASSWD]')['val'](),'smtpPort':$(_0x11fb92(0x104))[_0x11fb92(0xf3)](),'smtpEnc':$('select[name=PS_MAIL_SMTP_ENCRYPTION]')['val'](),'testMsg':textMsg,'testSubject':textSubject,'token':token_mail,'ajax':0x1,'tab':_0x11fb92(0x10c),'action':_0x11fb92(0xf4)},'success':function(_0x35a2ab){var _0xf4a49b=_0x11fb92;_0x35a2ab=='ok'?($(_0xf4a49b(0x10a))[_0xf4a49b(0x108)]('ok')[_0xf4a49b(0x100)](_0xf4a49b(0xf6))[_0xf4a49b(0x100)](_0xf4a49b(0xfb))[_0xf4a49b(0xfe)](textSendOk),mailIsOk=!![]):(mailIsOk=![],$(_0xf4a49b(0x10a))['addClass'](_0xf4a49b(0xf6))[_0xf4a49b(0x100)]('ok')[_0xf4a49b(0x100)](_0xf4a49b(0xfb))[_0xf4a49b(0xfe)](textSendError+_0xf4a49b(0xfa)+_0x35a2ab));}});}}