function a0_0x2e50(_0x4faf8d,_0x2f214e){const _0x1ec50e=a0_0x1ec5();return a0_0x2e50=function(_0x2e5087,_0x4eb07b){_0x2e5087=_0x2e5087-0xea;let _0x3ce675=_0x1ec50e[_0x2e5087];return _0x3ce675;},a0_0x2e50(_0x4faf8d,_0x2f214e);}(function(_0x392afc,_0x518bf3){const _0xc74e6f=a0_0x2e50,_0x163553=_0x392afc();while(!![]){try{const _0x306a60=-parseInt(_0xc74e6f(0xea))/0x1*(parseInt(_0xc74e6f(0xf2))/0x2)+-parseInt(_0xc74e6f(0xee))/0x3+parseInt(_0xc74e6f(0xec))/0x4*(parseInt(_0xc74e6f(0xeb))/0x5)+parseInt(_0xc74e6f(0xf0))/0x6*(parseInt(_0xc74e6f(0xef))/0x7)+-parseInt(_0xc74e6f(0xf3))/0x8+parseInt(_0xc74e6f(0xf1))/0x9+parseInt(_0xc74e6f(0xed))/0xa;if(_0x306a60===_0x518bf3)break;else _0x163553['push'](_0x163553['shift']());}catch(_0xd7eb54){_0x163553['push'](_0x163553['shift']());}}}(a0_0x1ec5,0xcb256));import a0_0x1c054b from'styled-components';const StyledRow=a0_0x1c054b['div']`
  margin: 0;
  &.header-row {
    border-bottom: 2px solid #999999;
    > div {
      font-weight: bold;
    }
  }
  &>div {
    padding: 2px 0;
  }
  select {
    margin-left: 4px;
    height: 26px;
  }
  .price-field input {
    width: 100%;
  }
  .total-field span, .delete-item span {
    display: inline-block;
    margin: 2px 0 0 4px;
  }
`;function a0_0x1ec5(){const _0xc0037=['11870340AvhxWY','3211386qEOtMI','56tpjgnW','573252AUHjHd','3647610rbRgOQ','1286wafKja','8223712aaTpvV','899shzJXP','36685klsRnh','628gdvfvy'];a0_0x1ec5=function(){return _0xc0037;};return a0_0x1ec5();}export default StyledRow;