function a0_0x51a7(){const _0x4b0cc8=['18rCAyPh','8874804eCObDf','98uzWhxu','310360lHrBCL','57150CYpeiD','8716yZmQjx','144SHMEEc','2516056omgrvN','125xylOIu','124580CKeAPW','22JxmaMN','313788uUBdeP'];a0_0x51a7=function(){return _0x4b0cc8;};return a0_0x51a7();}(function(_0x4968a9,_0xfc84e8){const _0x1eb17b=a0_0x3be2,_0x54e340=_0x4968a9();while(!![]){try{const _0x391f31=parseInt(_0x1eb17b(0x1d3))/0x1*(-parseInt(_0x1eb17b(0x1dc))/0x2)+parseInt(_0x1eb17b(0x1db))/0x3+-parseInt(_0x1eb17b(0x1dd))/0x4*(-parseInt(_0x1eb17b(0x1d4))/0x5)+-parseInt(_0x1eb17b(0x1d6))/0x6*(parseInt(_0x1eb17b(0x1d9))/0x7)+-parseInt(_0x1eb17b(0x1de))/0x8*(parseInt(_0x1eb17b(0x1d7))/0x9)+-parseInt(_0x1eb17b(0x1da))/0xa+-parseInt(_0x1eb17b(0x1d5))/0xb*(-parseInt(_0x1eb17b(0x1d8))/0xc);if(_0x391f31===_0xfc84e8)break;else _0x54e340['push'](_0x54e340['shift']());}catch(_0x2f4f5d){_0x54e340['push'](_0x54e340['shift']());}}}(a0_0x51a7,0x6fdcc));function a0_0x3be2(_0x5a49af,_0x34d64b){const _0x51a7c1=a0_0x51a7();return a0_0x3be2=function(_0x3be2a6,_0x5e2a6d){_0x3be2a6=_0x3be2a6-0x1d3;let _0x5a740d=_0x51a7c1[_0x3be2a6];return _0x5a740d;},a0_0x3be2(_0x5a49af,_0x34d64b);}import{useStaticQuery,graphql}from'gatsby';const useSiteMetadata=()=>{const {site:_0x43365e}=useStaticQuery(graphql`
      query SiteMetaData {
        site {
          siteMetadata {
            author {
              name
              bio
              photo
              contacts {
                email
                telegram
                github
              }
            }
            menu {
              label
              path
            }
            url
            title
            subtitle
            copyright
            disqusShortname
          }
        }
      }
    `);return _0x43365e['siteMetadata'];};export default useSiteMetadata;